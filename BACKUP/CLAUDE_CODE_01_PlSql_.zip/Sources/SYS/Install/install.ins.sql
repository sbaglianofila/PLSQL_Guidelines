prompt File: install.ins.sql <start>
-- =============================================================================
-- File:     install.ins.sql
-- Oggetto:  Orchestratore del provisioning privilegiato (SYS) del set #APP#
-- Schema:   eseguire come utente privilegiato / DBA
-- Scopo:    Crea, nell'ordine dettato dalle dipendenze (schemi.md), tablespace,
--           utenze, ruoli e grant di sistema del set di schemi #APP#. È lo
--           script che si consegna a chi ha i privilegi che noi non abbiamo,
--           quando il database è gestito dal cliente.
-- Ordine:   tablespace -> utenze -> ruoli -> grant (sessione, privilegi di
--           sistema, appartenenza ai ruoli, proxy). I grant di OGGETTO ai ruoli
--           (EXECUTE sull'API, SELECT sulle viste, DML per l'AM) NON stanno qui:
--           li emette l'owner #APP# man mano che l'API viene sviluppata, dalla
--           cartella Grants del proprio schema.
-- Nota:     Nessuna password reale: le utenze nascono con segnaposto, il segreto
--           si imposta nell'ambiente. Adeguare le righe opzionali (proxy, batch,
--           schemi esterni) a ciò che il progetto richiede. Il blocco dev/test
--           (#APP#_GEN) è separato in fondo e va eseguito SOLO fuori produzione.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260719  AA   Creazione
-- =============================================================================

whenever sqlerror exit failure rollback
whenever oserror  exit failure
set echo        off
set feedback     on
set define       off
set serveroutput on size unlimited

prompt ============================================================
prompt Provisioning #APP# (privilegiato): start
prompt ============================================================

prompt SYS: Tablespace
@@../Tablespaces/#APP#_data.tbs.sql
@@../Tablespaces/#APP#_am_data.tbs.sql

prompt SYS: Utenze
@@../Users/#APP#.usr.sql
-- @@../Users/#APP#_proxy.usr.sql       -- opzionale: solo con modello proxy
@@../Users/#APP#_app.usr.sql
-- @@../Users/#APP#_batch.usr.sql       -- opzionale: solo con elaborazioni batch
@@../Users/#APP#_ro.usr.sql
@@../Users/#APP#_am.usr.sql
-- @@../Users/#APP#_ext_<nome>.usr.sql  -- per-progetto: una per applicazione esterna

prompt SYS: Ruoli
@@../Roles/#APP#_app_role.rol.sql
-- @@../Roles/#APP#_batch_role.rol.sql  -- opzionale: solo con elaborazioni batch
@@../Roles/#APP#_ro_role.rol.sql
@@../Roles/#APP#_am_role.rol.sql

prompt SYS: Grant di sistema, appartenenza ai ruoli e proxy
@@../Grants/#APP#.grt.sql
@@../Grants/#APP#_app.grt.sql
-- @@../Grants/#APP#_batch.grt.sql      -- opzionale: solo con elaborazioni batch
@@../Grants/#APP#_ro.grt.sql
@@../Grants/#APP#_am.grt.sql

prompt ============================================================
prompt Provisioning #APP#: completed
prompt ============================================================

-- ---------------------------------------------------------------------------
-- SOLO SVILUPPO/TEST: schema di tooling #APP#_GEN.
-- Sbloccare le righe seguenti unicamente negli ambienti di sviluppo e test.
-- Non deve mai esistere in produzione (privilegi di dizionario ampi) e resta
-- fuori dai pacchetti di release. Lo schema di test #APP#_TST ha invece un
-- proprio provisioning in Sources/#APP#_TST/Provisioning/.
-- ---------------------------------------------------------------------------
-- prompt SYS (dev/test): schema di tooling #APP#_GEN
-- @@../Users/#APP#_gen.usr.sql
-- prompt SYS (dev/test): directory di output della generazione (path per-ambiente)
-- @@../Directories/#APP#_output_docgen.dir.sql
-- @@../Directories/#APP#_output_codegen.dir.sql
-- @@../Grants/#APP#_gen.grt.sql

prompt File: install.ins.sql <end>
