prompt File: #APP#_app_role.rol.sql <start>
-- =============================================================================
-- File:     #APP#_app_role.rol.sql
-- Oggetto:  #APP#_app_role (ruolo di profilo del front end)
-- Schema:   eseguire come utente privilegiato / DBA
-- Scopo:    Ruolo che raccoglie i grant di EXECUTE sull'API esposta al front
--           end. I grant di oggetto si assegnano al ruolo negli script emessi
--           dall'owner #APP# (cartella Grants dello schema owner), non qui:
--           qui si crea solo il ruolo. L'assegnazione allo schema #APP#_APP è
--           in Grants/#APP#_app.grt.sql (vedi schemi.md).
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260719  AA   Creazione
-- =============================================================================

prompt #APP#_app_role: Creazione ruolo

create role #APP#_app_role;

prompt File: #APP#_app_role.rol.sql <end>
