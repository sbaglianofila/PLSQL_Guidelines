prompt File: #APP#_batch_role.rol.sql <start>
-- =============================================================================
-- File:     #APP#_batch_role.rol.sql
-- Oggetto:  #APP#_batch_role (ruolo di profilo delle elaborazioni batch)
-- Schema:   eseguire come utente privilegiato / DBA
-- Scopo:    Ruolo che raccoglie i grant di EXECUTE sull'API batch. I grant di
--           oggetto si assegnano al ruolo negli script emessi dall'owner #APP#;
--           qui si crea solo il ruolo. L'assegnazione allo schema #APP#_BATCH è
--           in Grants/#APP#_batch.grt.sql (vedi schemi.md).
-- Nota:     OPZIONALE. Si crea solo nei progetti con elaborazioni batch.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260719  AA   Creazione
-- =============================================================================

prompt #APP#_batch_role: Creazione ruolo

create role #APP#_batch_role;

prompt File: #APP#_batch_role.rol.sql <end>
