prompt File: #APP#_am_role.rol.sql <start>
-- =============================================================================
-- File:     #APP#_am_role.rol.sql
-- Oggetto:  #APP#_am_role (ruolo di profilo dell'Application Maintenance)
-- Schema:   eseguire come utente privilegiato / DBA
-- Scopo:    Ruolo che raccoglie i grant di lavoro sui dati dell'owner:
--           SELECT/INSERT/UPDATE/DELETE sulle tabelle ed EXECUTE sui package.
--           I grant di oggetto si assegnano al ruolo negli script emessi
--           dall'owner #APP#; qui si crea solo il ruolo. L'assegnazione allo
--           schema #APP#_AM è in Grants/#APP#_am.grt.sql. I privilegi di
--           dizionario NON passano dal ruolo: sono grant diretti all'AM
--           (vedi schemi.md).
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260719  AA   Creazione
-- =============================================================================

prompt #APP#_am_role: Creazione ruolo

create role #APP#_am_role;

prompt File: #APP#_am_role.rol.sql <end>
