prompt File: #APP#_ro_role.rol.sql <start>
-- =============================================================================
-- File:     #APP#_ro_role.rol.sql
-- Oggetto:  #APP#_ro_role (ruolo di profilo di sola lettura)
-- Schema:   eseguire come utente privilegiato / DBA
-- Scopo:    Ruolo che raccoglie i soli grant di SELECT sulle viste di lettura.
--           I grant di oggetto si assegnano al ruolo negli script emessi
--           dall'owner #APP#; qui si crea solo il ruolo. L'assegnazione allo
--           schema #APP#_RO è in Grants/#APP#_ro.grt.sql (vedi schemi.md).
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260719  AA   Creazione
-- =============================================================================

prompt #APP#_ro_role: Creazione ruolo

create role #APP#_ro_role;

prompt File: #APP#_ro_role.rol.sql <end>
