# Provisioning privilegiato (`Sources/SYS/`)

Questa cartella raccoglie tutto ciò che va eseguito con **un'utenza privilegiata** (SYS, `SYSTEM` o un DBA con i privilegi equivalenti): la creazione dei tablespace, delle utenze, dei ruoli e dei grant di sistema del set di schemi `#APP#`. Non è uno schema applicativo: è l'insieme delle **richieste da sottoporre ai DBA** quando il database è gestito dal cliente e i privilegi di creazione non sono nostri. Tenerla separata dagli oggetti applicativi ne chiarisce natura e destinatario. Il modello degli schemi, con il razionale di ogni scelta di privilegio, è in [`schemi.md`](../../Architettura_DB/schemi.md); l'alberatura in [`sorgenti.md`](../../Gestione_Sorgenti/sorgenti.md).

## Cosa contiene

L'ordine delle sottocartelle richiama l'ordine di installazione, dettato dalle dipendenze: prima i contenitori fisici, poi le utenze, poi i ruoli, infine i grant che li mettono in relazione.

- **`Tablespaces/`** — i tablespace dati dedicati `#APP#_DATA` (owner) e `#APP#_AM_DATA` (AM). Il percorso del datafile e il dimensionamento dipendono dall'ambiente e li decide il DBA.
- **`Users/`** — le `create user`. L'owner `#APP#` (e l'opzionale `#APP#_PROXY`), gli schemi consumer `#APP#_APP`, `#APP#_BATCH`, `#APP#_RO`, l'`#APP#_AM`, e il tooling dev/test `#APP#_GEN`. I file creano **solo** l'utente; sessione e privilegi stanno nei grant.
- **`Roles/`** — le `create role` dei ruoli di profilo (`#APP#_app_role`, `#APP#_batch_role`, `#APP#_ro_role`, `#APP#_am_role`). Solo la creazione del ruolo: i grant di oggetto al ruolo li emette l'owner.
- **`Grants/`** — per ciascuna utenza: `CREATE SESSION`, i privilegi di sistema (creazione oggetti per owner e AM), l'`EXECUTE` esplicito sui package SYS usati, l'appartenenza ai ruoli e il proxy opzionale.
- **`Install/`** — l'orchestratore [`install.ins.sql`](Install/install.ins.sql) che mette in sequenza i file nell'ordine corretto.

## Il confine con i grant di oggetto

Qui vive solo il provisioning **privilegiato**. I **grant di oggetto ai ruoli** — `EXECUTE` sui singoli package dell'API, `SELECT` sulle viste di lettura, `SELECT/INSERT/UPDATE/DELETE` per l'AM — **non** stanno in questa cartella: li emette l'owner `#APP#` man mano che l'API viene sviluppata, dalla propria cartella `Grants/` (schema `#APP#`). La ragione è che dipendono dagli oggetti applicativi, che a questo punto non esistono ancora. Lo stesso vale per i **sinonimi privati** negli schemi consumer, creati al provisioning da un'utenza di installazione.

## Password

Nessun file contiene password reali: le utenze nascono con il segnaposto `"<placeholder_password>"`. Il segreto vero si imposta nell'ambiente di destinazione (o si gestisce con il modello proxy) e **non entra mai nel version control**.

## Righe opzionali

L'orchestratore lascia commentate le parti che dipendono dal progetto: l'utenza e l'abilitazione **proxy**, lo schema e il ruolo **batch**, gli schemi delle **applicazioni esterne** `#APP#_EXT_<nome>` (una per integrazione, con nome che ne identifica l'origine), e il blocco **dev/test** `#APP#_GEN`, che va eseguito solo fuori produzione e resta fuori dai pacchetti di release. Lo schema di test `#APP#_TST` ha un proprio provisioning in [`Sources/#APP#_TST/Provisioning/`](../%23APP%23_TST/README.md).
