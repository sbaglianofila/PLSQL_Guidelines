prompt File: #APP#_output_docgen.dir.sql <start>
-- =============================================================================
-- File:     #APP#_output_docgen.dir.sql
-- Oggetto:  DIRECTORY #APP#_output_docgen (output della documentazione generata)
-- Schema:   eseguire come DBA (CREATE ANY DIRECTORY)
-- Scopo:    Cartella in cui gen_doc scrive la documentazione HTML generata dal
--           dizionario. SOLO ambienti di sviluppo/test: la generazione vive nello
--           schema #APP#_GEN, assente in produzione. La scrittura è di #APP#_GEN via
--           sys.utl_file diretto (opzione B), quindi il READ/WRITE è concesso a
--           #APP#_GEN (non a #APP#) in SYS/Grants/#APP#_gen.grt.sql.
-- Nome:     prefissato #APP#_ perche gli oggetti DIRECTORY sono globali sull'istanza
--           (due applicazioni derivate sulla stessa istanza non devono collidere).
-- Path:     segnaposto per-ambiente, da sostituire in fase di provisioning con il
--           percorso reale sul filesystem del server.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260801  AA   Creazione (opzione B: output di gen_doc su #APP#_GEN)
-- =============================================================================

prompt Creating directory #APP#_output_docgen

create or replace directory #APP#_output_docgen as '<PATH_OUTPUT_DOCGEN>';

prompt File: #APP#_output_docgen.dir.sql <end>
