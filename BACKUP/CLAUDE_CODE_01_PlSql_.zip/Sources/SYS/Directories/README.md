# Directory del filesystem — strategia e provisioning

Gli oggetti `DIRECTORY` di Oracle sono il ponte fra il database e il filesystem del server. Questa cartella li crea (come DBA, serve `CREATE ANY DIRECTORY`); i relativi grant di lettura/scrittura vivono nei file `Grants/`. Sono oggetti privilegiati e per questo stanno sotto `Sources/SYS/`.

## Un principio prima di tutto: i nomi sono globali

A differenza di tabelle e package, gli oggetti `DIRECTORY` **non sono di schema**: il loro nome è **globale sull'istanza**. Un `INPUT_DIR` nudo collide se un domani due applicazioni derivate finiscono sulla stessa istanza — lo stesso motivo per cui lo schema owner è `#APP#` e non un nome generico. Perciò **ogni directory è prefissata `#APP#_`**, e la sostituzione del placeholder `#APP#` all'adozione della base rende i nomi unici insieme allo schema.

## Due tier, per due mondi diversi

Le directory si dividono per scopo e, di conseguenza, per chi le scrive e in quali ambienti esistono.

**Tier generazione (dev/test only).** Sono l'output del tooling `#APP#_GEN`, che esiste solo in sviluppo e test. La scrittura è dello schema di tooling via **`sys.utl_file` diretto** (opzione B), quindi il READ/WRITE è concesso a **`#APP#_GEN`**, non all'owner `#APP#`: così le directory di generazione non compaiono mai nei grant di uno schema di produzione.

| Directory | Scopo | Scrive | File |
|---|---|---|---|
| `#APP#_output_docgen` | documentazione HTML generata da `gen_doc` | `#APP#_GEN` | `#APP#_output_docgen.dir.sql` |
| `#APP#_output_codegen` | codice generato (es. `gen_shell`) | `#APP#_GEN` | `#APP#_output_codegen.dir.sql` |

**Tier integrazione (tutti gli ambienti).** Sono i canali di scambio file con i sistemi esterni. La scrittura/lettura passa dall'applicazione via **`#APP#.lib_file`** (a diritti del definer), quindi i grant vanno all'owner **`#APP#`**. Questo tier è **struttura documentata da riempire** quando arrivano i sistemi veri: i file concreti si aggiungono qui allora.

| Directory | Scopo | Lato Oracle | Accesso esterno (OS) |
|---|---|---|---|
| `#APP#_input_<SISTX>` | inbound dal sistema esterno `<SISTX>` | READ a `#APP#` | `<SISTX>` scrive |
| `#APP#_output` | outbound generico interno del sistema | READ/WRITE a `#APP#` | consumatori interni |
| `#APP#_output_<SISTX>` | outbound dedicato al consumer `<SISTX>` | WRITE a `#APP#` | `<SISTX>` legge |

L'isolamento fra sistemi esterni **non è di Oracle ma dell'OS**: il grant governa solo il lato `#APP#`; il sistema esterno vede la cartella via filesystem (SFTP/share), e gli si dà il permesso OS **solo sulla propria** directory. È per questo che una `#APP#_output_<SISTX>` separata tiene il consumatore fuori dalla `#APP#_output` generica: non lo tiene fuori Oracle, lo tiene fuori l'ACL della cartella. Stesso motivo, rovesciato, per l'inbound per-sistema: due sorgenti nello stesso inbound si vedrebbero e sovrascriverebbero i file.

## Perché tutta l'I/O passa da `lib_file` (e la generazione no)

Nel tier integrazione la scrittura passa da `#APP#.lib_file`: un solo punto che valida il nome file (niente path traversal) e mappa gli errori. Nessun consumer fa `UTL_FILE` grezzo; solo `#APP#` ha i grant sulle directory di integrazione. È una proprietà di sicurezza, non un caso.

La **generazione** è l'eccezione deliberata (opzione B): `gen_doc` usa `utl_file` diretto perché così le sue directory restano grantate al solo `#APP#_GEN` dev/test, invece di far comparire un grant dev-only sull'owner di produzione. Il nome file lo produce comunque il generatore (`<schema>_<tipo>_<nome>.html`), senza separatori di path, quindi il rischio di traversal non si pone.

## Path e ambienti

I `create directory ... as '<PATH_...>'` portano **segnaposto**: il percorso reale sul filesystem è una scelta per-ambiente, da sostituire al provisioning. Le directory di generazione si creano **solo** in sviluppo/test (nell'orchestratore SYS stanno nel blocco dev/test, accanto a `#APP#_GEN`).

## Convenzione sorgenti

Nuova sotto-estensione **`.dir`** per i file di creazione delle directory, da registrare in `Gestione_Sorgenti/sorgenti.md` accanto a `.tbs`/`.usr`/`.rol`/`.grt`. Un file per directory; i grant restano nei file `Grants/`.
