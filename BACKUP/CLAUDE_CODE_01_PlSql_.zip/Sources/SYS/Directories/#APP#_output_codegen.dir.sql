prompt File: #APP#_output_codegen.dir.sql <start>
-- =============================================================================
-- File:     #APP#_output_codegen.dir.sql
-- Oggetto:  DIRECTORY #APP#_output_codegen (output del codice generato)
-- Schema:   eseguire come DBA (CREATE ANY DIRECTORY)
-- Scopo:    Cartella in cui i generatori di codice (es. il futuro gen_shell)
--           scrivono gli artefatti di codice generati. SOLO ambienti di
--           sviluppo/test: la generazione vive nello schema #APP#_GEN, assente in
--           produzione. Scrittura di #APP#_GEN via sys.utl_file diretto (opzione B);
--           READ/WRITE a #APP#_GEN in SYS/Grants/#APP#_gen.grt.sql.
-- Nome:     prefissato #APP#_ perche gli oggetti DIRECTORY sono globali sull'istanza.
-- Path:     segnaposto per-ambiente, da sostituire in fase di provisioning.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260801  AA   Creazione (opzione B: output dei generatori di codice)
-- =============================================================================

prompt Creating directory #APP#_output_codegen

create or replace directory #APP#_output_codegen as '<PATH_OUTPUT_CODEGEN>';

prompt File: #APP#_output_codegen.dir.sql <end>
