prompt File: #APP#_ro.usr.sql <start>
-- =============================================================================
-- File:     #APP#_ro.usr.sql
-- Oggetto:  #APP#_RO (schema di sola lettura)
-- Schema:   eseguire come utente privilegiato / DBA
-- Scopo:    Schema per gli operatori che consultano i dati senza modificarli.
--           L'accesso avviene sempre tramite VISTE, mai tramite tabelle, così
--           da controllare colonne esposte e filtri di riga. Soli SELECT via
--           ruolo #APP#_ro_role, nessuna quota, nessun privilegio di creazione
--           (vedi schemi.md).
-- Nota:     Sessione e ruolo #APP#_ro_role sono in Grants/#APP#_ro.grt.sql.
--           Nessuna password reale qui: solo un segnaposto.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260719  AA   Creazione
-- =============================================================================

prompt #APP#_ro: Creazione schema di sola lettura

create user #APP#_ro identified by "<placeholder_password>"
   default tablespace   users
   temporary tablespace temp;

prompt File: #APP#_ro.usr.sql <end>
