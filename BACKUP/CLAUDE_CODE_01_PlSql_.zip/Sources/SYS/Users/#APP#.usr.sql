prompt File: #APP#.usr.sql <start>
-- =============================================================================
-- File:     #APP#.usr.sql
-- Oggetto:  #APP# (utente / schema owner dell'applicativo)
-- Schema:   eseguire come utente privilegiato / DBA
-- Scopo:    Crea l'owner che possiede tutti gli oggetti applicativi (tabelle,
--           package, viste, ...). Crea oggetti, quindi ha un tablespace dati
--           dedicato e una quota SCOPED su quel tablespace: mai il privilegio
--           di sistema globale UNLIMITED TABLESPACE, che permetterebbe di
--           occupare tablespace non di sua competenza (vedi schemi.md).
-- Nota:     Nessuna password reale qui: solo un segnaposto; il segreto vero si
--           imposta nell'ambiente, mai nel version control. I privilegi di
--           sistema e i grant sui package SYS sono in Grants/#APP#.grt.sql.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260719  AA   Creazione
-- =============================================================================

prompt #APP#: Creazione utente owner

create user #APP# identified by "<placeholder_password>"
   default tablespace   #APP#_data
   temporary tablespace temp
   quota unlimited on   #APP#_data;

prompt File: #APP#.usr.sql <end>
