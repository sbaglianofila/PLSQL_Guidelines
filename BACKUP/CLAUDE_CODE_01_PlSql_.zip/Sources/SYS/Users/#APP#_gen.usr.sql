prompt File: #APP#_gen.usr.sql <start>
-- =============================================================================
-- File:     #APP#_gen.usr.sql
-- Oggetto:  #APP#_GEN (schema di tooling, SOLO SVILUPPO/TEST)
-- Schema:   eseguire come utente privilegiato / DBA
-- Scopo:    Ospita gli strumenti di sviluppo che generano codice e
--           documentazione dai metadati (package gen_*). LEGGE il dizionario ed
--           EMETTE artefatti, ma non scrive sull'owner: nessun CREATE ANY,
--           nessun DDL su #APP#. Crea solo i propri oggetti transitori su un
--           tablespace di default con quota (vedi schemi.md).
-- Nota:     VINCOLO D'AMBIENTE: si crea SOLO in sviluppo/test e non deve mai
--           esistere in produzione (ha bisogno di privilegi di dizionario
--           ampi). I suoi script restano fuori dai pacchetti di release.
--           Sessione, privilegi di creazione e di dizionario sono in
--           Grants/#APP#_gen.grt.sql. Nessuna password reale qui.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260719  AA   Creazione
-- =============================================================================

prompt #APP#_gen: Creazione schema di tooling (dev/test)

create user #APP#_gen identified by "<placeholder_password>"
   default tablespace   users
   temporary tablespace temp
   quota unlimited on   users;

prompt File: #APP#_gen.usr.sql <end>
