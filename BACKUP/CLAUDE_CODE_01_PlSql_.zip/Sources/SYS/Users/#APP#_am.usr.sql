prompt File: #APP#_am.usr.sql <start>
-- =============================================================================
-- File:     #APP#_am.usr.sql
-- Oggetto:  #APP#_AM (schema di Application Maintenance)
-- Schema:   eseguire come utente privilegiato / DBA
-- Scopo:    Profilo più potente dopo l'owner, ma con potenza asimmetrica: può
--           lavorare sui DATI (SELECT/INSERT/UPDATE/DELETE + EXECUTE via ruolo)
--           ma NON può alterare gli OGGETTI dell'owner. Crea i propri oggetti
--           di lavoro in un tablespace dedicato #APP#_AM_DATA con quota scoped
--           (vedi schemi.md).
-- Nota:     Sessione, privilegi di creazione dei propri oggetti, ruolo AM e
--           privilegi di dizionario sono in Grants/#APP#_am.grt.sql.
--           Nessuna password reale qui: solo un segnaposto.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260719  AA   Creazione
-- =============================================================================

prompt #APP#_am: Creazione schema di Application Maintenance

create user #APP#_am identified by "<placeholder_password>"
   default tablespace   #APP#_am_data
   temporary tablespace temp
   quota unlimited on   #APP#_am_data;

prompt File: #APP#_am.usr.sql <end>
