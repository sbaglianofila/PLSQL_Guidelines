prompt File: #APP#_batch.usr.sql <start>
-- =============================================================================
-- File:     #APP#_batch.usr.sql
-- Oggetto:  #APP#_BATCH (schema delle elaborazioni batch)
-- Schema:   eseguire come utente privilegiato / DBA
-- Scopo:    Schema per job schedulati, import, riconciliazioni e chiusure.
--           Stesse necessità di isolamento del front end: accesso alla sola API
--           batch tramite ruolo dedicato, nessun accesso diretto alle tabelle,
--           nessuna quota. Tenuto separato da #APP#_APP perché i due profili
--           espongono API diverse (vedi schemi.md).
-- Nota:     OPZIONALE. Nei progetti senza batch questo schema non si crea.
--           Sessione e ruolo #APP#_batch_role sono in
--           Grants/#APP#_batch.grt.sql. Nessuna password reale qui.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260719  AA   Creazione
-- =============================================================================

prompt #APP#_batch: Creazione schema batch

create user #APP#_batch identified by "<placeholder_password>"
   default tablespace   users
   temporary tablespace temp;

prompt File: #APP#_batch.usr.sql <end>
