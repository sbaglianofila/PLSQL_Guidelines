prompt File: #APP#_app.usr.sql <start>
-- =============================================================================
-- File:     #APP#_app.usr.sql
-- Oggetto:  #APP#_APP (schema applicativo / front end)
-- Schema:   eseguire come utente privilegiato / DBA
-- Scopo:    Schema con cui si connette il front end. NON vede l'applicativo:
--           nessun grant sulle tabelle, interagisce solo con l'API (package
--           esposti) e, per leggere, con le viste guscio. Non crea nulla,
--           quindi NESSUNA quota su alcun tablespace (vedi schemi.md).
-- Nota:     Sessione e ruolo #APP#_app_role sono in Grants/#APP#_app.grt.sql.
--           Nessuna password reale qui: solo un segnaposto.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260719  AA   Creazione
-- =============================================================================

prompt #APP#_app: Creazione schema applicativo

create user #APP#_app identified by "<placeholder_password>"
   default tablespace   users
   temporary tablespace temp;

prompt File: #APP#_app.usr.sql <end>
