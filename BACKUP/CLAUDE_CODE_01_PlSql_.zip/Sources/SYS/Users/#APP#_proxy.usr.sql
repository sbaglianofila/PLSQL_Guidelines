prompt File: #APP#_proxy.usr.sql <start>
-- =============================================================================
-- File:     #APP#_proxy.usr.sql
-- Oggetto:  #APP#_PROXY (utenza di proxy verso l'owner)
-- Schema:   eseguire come utente privilegiato / DBA
-- Scopo:    Utenza del modello di autenticazione proxy (preferibile quando il
--           database è gestito dal cliente): ci si connette come proxy
--           specificando l'owner tra parentesi quadre
--           (#APP#_proxy[#APP#]/...) e si opera con i privilegi dell'owner
--           SENZA conoscerne la password. Vantaggi: nessun segreto dell'owner
--           da conoscere e piena auditabilità (vedi schemi.md).
-- Nota:     OPZIONALE. Si crea solo se il progetto adotta il modello proxy.
--           L'abilitazione "connect through" è in Grants/#APP#.grt.sql.
--           Nessuna password reale qui: solo un segnaposto.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260719  AA   Creazione
-- =============================================================================

prompt #APP#_proxy: Creazione utenza proxy

create user #APP#_proxy identified by "<placeholder_password>";

prompt File: #APP#_proxy.usr.sql <end>
