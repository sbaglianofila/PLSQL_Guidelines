prompt File: #APP#_data.tbs.sql <start>
-- =============================================================================
-- File:     #APP#_data.tbs.sql
-- Oggetto:  #APP#_DATA (tablespace dati dell'owner)
-- Schema:   eseguire come utente privilegiato / DBA
-- Scopo:    Tablespace dedicato ai dati dell'applicativo, posseduti dall'owner
--           #APP#. L'isolamento in un tablespace proprio separa i dati
--           dell'applicazione da quelli di altri schemi e semplifica backup,
--           monitoraggio e gestione dello spazio (vedi schemi.md).
-- Nota:     Il percorso del datafile e il dimensionamento dipendono
--           dall'ambiente di destinazione e li decide di norma il DBA: adeguare
--           i valori sotto. In ambienti con Oracle Managed Files si può
--           omettere la clausola datafile.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260719  AA   Creazione
-- =============================================================================

prompt #APP#_DATA: Creazione tablespace

create tablespace #APP#_data
   datafile '<datafile_path>' size <initial_size>
   autoextend on next <next_size> maxsize <max_size>
   extent management local
   segment space management auto;

prompt File: #APP#_data.tbs.sql <end>
