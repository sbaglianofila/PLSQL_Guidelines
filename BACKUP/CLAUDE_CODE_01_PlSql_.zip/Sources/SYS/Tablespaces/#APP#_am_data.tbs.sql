prompt File: #APP#_am_data.tbs.sql <start>
-- =============================================================================
-- File:     #APP#_am_data.tbs.sql
-- Oggetto:  #APP#_AM_DATA (tablespace di lavoro dell'AM)
-- Schema:   eseguire come utente privilegiato / DBA
-- Scopo:    Tablespace dedicato agli oggetti di lavoro dell'Application
--           Maintenance (tabelle di appoggio, viste di analisi, procedure di
--           diagnosi). Tenerlo separato dal tablespace dell'owner impedisce la
--           commistione degli strumenti dell'AM con i dati di produzione
--           (vedi schemi.md).
-- Nota:     Il percorso del datafile e il dimensionamento dipendono
--           dall'ambiente di destinazione e li decide di norma il DBA: adeguare
--           i valori sotto. In ambienti con Oracle Managed Files si può
--           omettere la clausola datafile.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260719  AA   Creazione
-- =============================================================================

prompt #APP#_AM_DATA: Creazione tablespace

create tablespace #APP#_am_data
   datafile '<datafile_path>' size <initial_size>
   autoextend on next <next_size> maxsize <max_size>
   extent management local
   segment space management auto;

prompt File: #APP#_am_data.tbs.sql <end>
