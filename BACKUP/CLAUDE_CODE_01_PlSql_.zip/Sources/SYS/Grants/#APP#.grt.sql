prompt File: #APP#.grt.sql <start>
-- =============================================================================
-- File:     #APP#.grt.sql
-- Oggetto:  Privilegi di sistema, package SYS e proxy per l'owner #APP#
-- Schema:   eseguire come utente privilegiato / DBA
-- Scopo:    Concede all'owner il minimo per possedere e gestire l'applicativo:
--           creazione degli oggetti che gli competono, EXECUTE esplicito sui
--           soli package SYS che l'applicazione usa davvero, e (opzionale)
--           l'abilitazione del proxy. Due assenze DELIBERATE: nessun
--           CREATE PUBLIC SYNONYM (si usano solo sinonimi privati) e nessun
--           privilegio di dizionario (SELECT ANY DICTIONARY / SELECT_CATALOG_
--           ROLE), che restano confinati ad AM e al tooling (vedi schemi.md).
-- Nota:     Adeguare i grant sui package SYS a ciò che il progetto usa davvero
--           e sbloccare le righe opzionali solo se servono.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260719  AA   Creazione
-- =============================================================================

prompt #APP#: Grant CREATE SESSION
grant create session to #APP#;

prompt #APP#: Grant dei privilegi di creazione oggetti
-- Nessun CREATE PUBLIC SYNONYM, nessun privilegio di dizionario (vedi header).
grant create table             to #APP#;
grant create view              to #APP#;
grant create sequence          to #APP#;
grant create procedure         to #APP#;
grant create trigger           to #APP#;
grant create type              to #APP#;
grant create synonym           to #APP#;   -- sinonimi privati, non pubblici
grant create any context       to #APP#;   -- contesto applicativo APP_CTX (lib_session):
                                            -- crea solo namespace di contesto, nessun
                                            -- accesso ai dati di altri schemi
grant create materialized view to #APP#;   -- richiesto: mv_user_effective_perms (RBAC, utenti_profili.md)
grant create job               to #APP#;   -- richiesto: job DBMS_SCHEDULER di refresh giornaliero
                                            -- della MV dei permessi (Jobs/authz_refresh_mv, 00:00)

prompt #APP#: Grant EXECUTE sui package SYS (espliciti, per package)
-- Gia' eseguibili da PUBLIC (nessun grant): dbms_output, dbms_utility,
-- dbms_application_info, dbms_scheduler, dbms_sql, dbms_mview (refresh della MV dei
-- permessi da lib_authz.refresh_mv), dbms_assert (quest'ultimo usato da lib_workflow
-- per validare il nome del dispatcher delle guardie prima della chiamata dinamica).
grant execute on sys.dbms_lock   to #APP#;   -- lock applicativi (11_patterns.md, lib_lock)
grant execute on sys.utl_file    to #APP#;   -- I/O su file (lib_file); richiede anche oggetti DIRECTORY con read/write all'owner

grant execute on sys.dbms_snapshot  to #APP#;

-- grant execute on sys.dbms_crypto to #APP#;   -- hashing/cifratura, solo se usato
-- grant execute on sys.utl_smtp    to #APP#;   -- lib_mail motore utl_smtp; richiede ACL di rete
-- grant execute on sys.utl_http    to #APP#;   -- HTTP in uscita, se usato; richiede ACL di rete

prompt #APP#: Autenticazione proxy (opzionale)
-- Sbloccare solo se si adotta il modello proxy e si e' creato #APP#_PROXY.
-- grant create session to #APP#_proxy;
-- alter user #APP# grant connect through #APP#_proxy;

prompt File: #APP#.grt.sql <end>
