prompt File: #APP#_ro.grt.sql <start>
-- =============================================================================
-- File:     #APP#_ro.grt.sql
-- Oggetto:  Privilegi di sistema e appartenenza al ruolo per #APP#_RO
-- Schema:   eseguire come utente privilegiato / DBA
-- Scopo:    Allo schema di sola lettura si concede il minimo per connettersi e
--           leggere: CREATE SESSION e il ruolo #APP#_ro_role. Nessun privilegio
--           di creazione, nessuna quota. I grant di SELECT sulle viste di
--           lettura vanno al RUOLO, negli script emessi dall'owner #APP#
--           (vedi schemi.md).
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260719  AA   Creazione
-- =============================================================================

prompt #APP#_ro: Grant CREATE SESSION
grant create session to #APP#_ro;

prompt #APP#_ro: Assegnazione del ruolo di profilo
grant #APP#_ro_role to #APP#_ro;
alter user #APP#_ro default role all;

prompt File: #APP#_ro.grt.sql <end>
