prompt File: #APP#_am.grt.sql <start>
-- =============================================================================
-- File:     #APP#_am.grt.sql
-- Oggetto:  Privilegi di sistema, ruolo e dizionario per #APP#_AM
-- Schema:   eseguire come utente privilegiato / DBA
-- Scopo:    All'AM si concede: CREATE SESSION; i privilegi per creare i PROPRI
--           oggetti di lavoro (nel tablespace #APP#_AM_DATA); il ruolo
--           #APP#_am_role che porta il lavoro sui dati dell'owner
--           (SELECT/INSERT/UPDATE/DELETE + EXECUTE, grantati al ruolo negli
--           script dell'owner); e i privilegi di dizionario per la diagnosi.
--           L'AM puo' toccare i DATI ma NON gli OGGETTI dell'owner: nessun
--           ALTER ANY TABLE ne' DDL sull'applicativo (vedi schemi.md).
-- Nota:     I privilegi di dizionario sono grant DIRETTI all'AM, non passano
--           dal ruolo di profilo.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260719  AA   Creazione
-- =============================================================================

prompt #APP#_am: Grant CREATE SESSION
grant create session to #APP#_am;

prompt #APP#_am: Grant di creazione dei propri oggetti di lavoro
grant create table, create view, create procedure, create sequence, create synonym to #APP#_am;

prompt #APP#_am: Assegnazione del ruolo di profilo
grant #APP#_am_role to #APP#_am;
alter user #APP#_am default role all;

prompt #APP#_am: Grant di introspezione del dizionario (diagnosi)
grant select_catalog_role   to #APP#_am;
grant select any dictionary to #APP#_am;

prompt File: #APP#_am.grt.sql <end>
