prompt File: #APP#_app.grt.sql <start>
-- =============================================================================
-- File:     #APP#_app.grt.sql
-- Oggetto:  Privilegi di sistema e appartenenza al ruolo per #APP#_APP
-- Schema:   eseguire come utente privilegiato / DBA
-- Scopo:    Allo schema del front end si concede il minimo per connettersi e
--           usare l'API: CREATE SESSION e il ruolo #APP#_app_role. Nessun
--           privilegio di creazione, nessuna quota. I grant di EXECUTE sui
--           singoli package dell'API vanno al RUOLO, negli script emessi
--           dall'owner #APP# (vedi schemi.md).
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260719  AA   Creazione
-- =============================================================================

prompt #APP#_app: Grant CREATE SESSION
grant create session to #APP#_app;

prompt #APP#_app: Assegnazione del ruolo di profilo
grant #APP#_app_role to #APP#_app;
alter user #APP#_app default role all;

prompt File: #APP#_app.grt.sql <end>
