prompt File: #APP#_gen.grt.sql <start>
-- =============================================================================
-- File:     #APP#_gen.grt.sql
-- Oggetto:  Privilegi di sistema e dizionario per #APP#_GEN (SOLO DEV/TEST)
-- Schema:   eseguire come utente privilegiato / DBA
-- Scopo:    Al tooling si concede: CREATE SESSION; i privilegi per creare i
--           propri oggetti di generazione; e i privilegi di lettura sulle sole
--           viste di dizionario che i generatori gen_* interrogano. NON riceve
--           alcun privilegio di DDL sull'owner (nessun CREATE ANY): legge ed
--           emette artefatti, non scrive su #APP# (vedi schemi.md).
-- Nota:     VINCOLO D'AMBIENTE: si esegue SOLO in sviluppo/test, dove questo
--           schema non deve esistere in produzione. La lettura del dizionario è
--           comunque data per grant MIRATE (una lista fissa di viste DBA_*), non
--           per privilegi ampi: vedi la sezione "introspezione" più sotto.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260719  AA   Creazione
--   20260731  AA   Introspezione da grant mirate sulle viste DBA_* (soluzione A)
--                  al posto di select_catalog_role / select any dictionary: il
--                  ruolo era inefficace nel PL/SQL definer's rights (ORA-00942).
--   20260801  AA   Opzione B: aggiunti EXECUTE su sys.utl_file e READ/WRITE sulle
--                  directory di output (gen_doc scrive diretto, dev/test only).
-- =============================================================================

prompt #APP#_gen: Grant CREATE SESSION
grant create session to #APP#_gen;

prompt #APP#_gen: Grant di creazione dei propri oggetti di generazione
grant create procedure, create table, create view to #APP#_gen;

prompt #APP#_gen: Grant EXECUTE su sys.utl_file (scrittura diretta dei file, opzione B)
-- gen_doc scrive i file con sys.utl_file diretto, non via #APP#.lib_file, così le
-- directory di generazione restano su questo schema dev/test (vedi il body di
-- gen_doc e Sources/#APP#_GEN/README.md). Grant DIRETTA: un ruolo non varrebbe nel
-- PL/SQL definer's rights.
grant execute on sys.utl_file to #APP#_gen;

prompt #APP#_gen: READ/WRITE sulle directory di output della generazione (SOLO dev/test)
-- Le directory sono create in Sources/SYS/Directories/ e devono gia esistere qui
-- (l'orchestratore SYS le crea prima). Nomi prefissati #APP#_ perche gli oggetti
-- DIRECTORY sono globali sull'istanza (evita collisioni fra applicazioni derivate).
grant read, write on directory #APP#_output_docgen  to #APP#_gen;
grant read, write on directory #APP#_output_codegen to #APP#_gen;

prompt #APP#_gen: Grant di introspezione del dizionario (soluzione A: viste DBA_* mirate)
-- Grant DIRETTE sulle sole viste di dizionario che il tooling gen_* interroga.
-- Perché dirette e non un ruolo: i ruoli (es. select_catalog_role) sono
-- DISATTIVATI dentro il PL/SQL a diritti del definer, quindi un package gen_*
-- che legge queste viste fallirebbe con ORA-00942 pur funzionando in SQL
-- interattivo. La lista è fissa: cresce solo se il tooling tocca una vista nuova,
-- non quando #APP# aggiunge oggetti. Nessun privilegio di dizionario ampio
-- (niente SELECT ANY DICTIONARY / SELECT_CATALOG_ROLE). Vedi il razionale in
-- Pacchetti_Base/pacchetti_base.md (gen_doc) e in Architettura_DB/schemi.md.
grant select on sys.dba_objects            to #APP#_gen;
grant select on sys.dba_tables             to #APP#_gen;
grant select on sys.dba_tab_comments       to #APP#_gen;
grant select on sys.dba_tab_cols           to #APP#_gen;
grant select on sys.dba_tab_columns        to #APP#_gen;
grant select on sys.dba_col_comments       to #APP#_gen;
grant select on sys.dba_constraints        to #APP#_gen;
grant select on sys.dba_cons_columns       to #APP#_gen;
grant select on sys.dba_indexes            to #APP#_gen;
grant select on sys.dba_ind_columns        to #APP#_gen;
grant select on sys.dba_ind_expressions    to #APP#_gen;
grant select on sys.dba_triggers           to #APP#_gen;
grant select on sys.dba_dependencies       to #APP#_gen;
grant select on sys.dba_synonyms           to #APP#_gen;
grant select on sys.dba_tab_privs          to #APP#_gen;
grant select on sys.dba_part_tables        to #APP#_gen;
grant select on sys.dba_tab_partitions     to #APP#_gen;
grant select on sys.dba_part_key_columns   to #APP#_gen;
grant select on sys.dba_mview_logs         to #APP#_gen;
grant select on sys.dba_redaction_columns  to #APP#_gen;
grant select on sys.dba_redaction_policies to #APP#_gen;
grant select on sys.dba_tab_statistics     to #APP#_gen;
grant select on sys.dba_tab_col_statistics to #APP#_gen;

prompt File: #APP#_gen.grt.sql <end>
