prompt File: #APP#_batch.grt.sql <start>
-- =============================================================================
-- File:     #APP#_batch.grt.sql
-- Oggetto:  Privilegi di sistema e appartenenza al ruolo per #APP#_BATCH
-- Schema:   eseguire come utente privilegiato / DBA
-- Scopo:    Allo schema batch si concede il minimo per connettersi e usare
--           l'API batch: CREATE SESSION e il ruolo #APP#_batch_role. Nessun
--           privilegio di creazione, nessuna quota. I grant di EXECUTE sui
--           package dell'API batch vanno al RUOLO, negli script emessi
--           dall'owner #APP# (vedi schemi.md).
-- Nota:     OPZIONALE. Si esegue solo nei progetti con elaborazioni batch.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260719  AA   Creazione
-- =============================================================================

prompt #APP#_batch: Grant CREATE SESSION
grant create session to #APP#_batch;

prompt #APP#_batch: Assegnazione del ruolo di profilo
grant #APP#_batch_role to #APP#_batch;
alter user #APP#_batch default role all;

prompt File: #APP#_batch.grt.sql <end>
