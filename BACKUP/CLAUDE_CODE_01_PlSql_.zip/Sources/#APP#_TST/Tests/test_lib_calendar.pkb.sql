prompt File: test_lib_calendar.pkb.sql <start>
-- =============================================================================
-- File:     test_lib_calendar.pkb.sql
-- Oggetto:  test_lib_calendar (corpo del wrapper di test)
-- Schema:   #APP#_TST
-- Scopo:    Corpo del wrapper. Ogni procedura test_* apre una run del harness,
--           itera i casi presi dalla vista _tc_v, chiama il target di #APP# e
--           delega esiti e assert ai package tst_*. Il codice qui è sottile e
--           stabile: i dati dei casi stanno nella vista, non nel wrapper, così
--           un'aggiunta di casi non tocca questo file.
--
--           Isolamento: un savepoint di setup racchiude il fixture (festività di
--           prova); un savepoint per-caso isola l'eventuale DML del target. A fine
--           run si torna al savepoint di setup, quindi il fixture non persiste.
--
--           Correlazione a due livelli: si genera un correlation id, lo si passa a
--           start_case (che lo scrive su tst_case) e lo si imposta sulla sessione
--           con lib_session.set_correlation, così gli eventuali log_events di #APP#
--           della chiamata sono ricongiungibili al caso. lib_calendar è puro e non
--           logga: qui la correlazione è cablata ma senza righe da correlare - il
--           meccanismo si ripaga sui target che loggano (orchestratori, pkg_*).
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260716  AA   Creazione (proof-of-concept gradino 0)
--   20260716  AA   Integrazione nel framework: parametri tst_* a i_, correlation
--                  id passato a start_case (rimosso il workaround con update diretta)
-- =============================================================================

prompt test_lib_calendar: Creating package body

create or replace
package body test_lib_calendar
is

-- Nome del package target, ripetuto nelle run per tracciabilità.
k_SOURCE_PACKAGE constant varchar2(30) := 'LIB_CALENDAR';

--------------------------------------------------------------------------------
-- Semina la festività di prova usata dai casi (martedì 2026-01-06). Sta dentro
-- il savepoint di setup del chiamante, quindi viene annullata a fine run.
procedure seed_holidays
is
begin
    insert into ref_holidays ( calendar_code, holiday_date, description )
    values ( 'DEFAULT', date '2026-01-06', 'Festività di test (martedì)' );
end seed_holidays;

--------------------------------------------------------------------------------
procedure test_add_working_days
is
    l_run_id       number;
    l_case_id      number;
    l_correlation  varchar2(64);
    l_result       date;
begin
    l_run_id := tst_runner.start_run( i_owner                  => '#APP#'
                                    , i_package_name           => k_SOURCE_PACKAGE
                                    , i_program_name           => 'ADD_WORKING_DAYS'
                                    , i_generated_package_name => 'TEST_LIB_CALENDAR'
                                    , i_transaction_mode       => 'ROLLBACK'
                                    , i_note                   => 'Wrapper integrato - vista dei casi disaccoppiata.' );

    savepoint tst_setup_sp;
    seed_holidays;

    for r in ( select * from lib_calendar_add_working_days_tc_v )
    loop
        savepoint tst_case_sp;

        l_correlation := lib_logging.new_correlation_id;

        l_case_id := tst_runner.start_case( i_run_id           => l_run_id
                                          , i_case_code        => r.case_code
                                          , i_case_description => r.case_description
                                          , i_expect_error     => r.expect_error
                                          , i_expect_sqlcode   => r.expect_sqlcode
                                          , i_correlation_id   => l_correlation );

        begin
            lib_session.set_correlation( i_correlation_id => l_correlation );

            tst_log.log_param( l_case_id, 'I_DATE',     'IN', 'DATE',     r.i_date );
            tst_log.log_param( l_case_id, 'I_DAYS',     'IN', 'NUMBER',   r.i_days );
            tst_log.log_param( l_case_id, 'I_CALENDAR', 'IN', 'VARCHAR2', r.i_calendar );

            l_result := lib_calendar.add_working_days( i_date     => r.i_date
                                                     , i_days     => r.i_days
                                                     , i_calendar => r.i_calendar );

            tst_log.log_return_value( l_case_id, 'DATE', l_result );

            tst_assert.eq_date( i_case_id  => l_case_id
                              , i_name     => 'RETURN_VALUE'
                              , i_expected => r.expected_result
                              , i_actual   => l_result );

            tst_runner.end_case_success( l_case_id );
            rollback to tst_case_sp;
        exception
            when others
            then
                tst_runner.end_case_error( i_case_id     => l_case_id
                                         , i_sqlcode     => sqlcode
                                         , i_sqlerrm     => sqlerrm
                                         , i_error_stack => dbms_utility.format_error_stack
                                         , i_backtrace   => dbms_utility.format_error_backtrace );
                rollback to tst_case_sp;
        end;
    end loop;

    rollback to tst_setup_sp;   -- teardown del fixture
    tst_runner.end_run_success( l_run_id );
exception
    when others
    then
        if ( l_run_id is not null )
        then
            tst_runner.end_run_error( i_run_id => l_run_id, i_sqlcode => sqlcode, i_sqlerrm => sqlerrm );
        end if;
        raise;
end test_add_working_days;

--------------------------------------------------------------------------------
procedure test_is_working_day
is
    l_run_id       number;
    l_case_id      number;
    l_correlation  varchar2(64);
    l_result_flag  varchar2(1);
begin
    l_run_id := tst_runner.start_run( i_owner                  => '#APP#'
                                    , i_package_name           => k_SOURCE_PACKAGE
                                    , i_program_name           => 'IS_WORKING_DAY'
                                    , i_generated_package_name => 'TEST_LIB_CALENDAR'
                                    , i_transaction_mode       => 'ROLLBACK'
                                    , i_note                   => 'Ritorno booleano reso a flag via tst_util.' );

    savepoint tst_setup_sp;
    seed_holidays;

    for r in ( select * from lib_calendar_is_working_day_tc_v )
    loop
        savepoint tst_case_sp;

        l_correlation := lib_logging.new_correlation_id;

        l_case_id := tst_runner.start_case( i_run_id           => l_run_id
                                          , i_case_code        => r.case_code
                                          , i_case_description => r.case_description
                                          , i_expect_error     => r.expect_error
                                          , i_expect_sqlcode   => r.expect_sqlcode
                                          , i_correlation_id   => l_correlation );

        begin
            lib_session.set_correlation( i_correlation_id => l_correlation );

            tst_log.log_param( l_case_id, 'I_DATE',     'IN', 'DATE',     r.i_date );
            tst_log.log_param( l_case_id, 'I_CALENDAR', 'IN', 'VARCHAR2', r.i_calendar );

            -- BOOLEAN non attraversa SQL: si converte a flag prima di loggare e confrontare.
            l_result_flag := tst_util.boolean_to_varchar2(
                                 lib_calendar.is_working_day( i_date     => r.i_date
                                                            , i_calendar => r.i_calendar ) );

            tst_log.log_output( l_case_id, 'RETURN_VALUE', 'VARCHAR2', l_result_flag );

            tst_assert.eq_varchar2( i_case_id  => l_case_id
                                  , i_name     => 'RETURN_VALUE'
                                  , i_expected => r.expected_flag
                                  , i_actual   => l_result_flag );

            tst_runner.end_case_success( l_case_id );
            rollback to tst_case_sp;
        exception
            when others
            then
                tst_runner.end_case_error( i_case_id     => l_case_id
                                         , i_sqlcode     => sqlcode
                                         , i_sqlerrm     => sqlerrm
                                         , i_error_stack => dbms_utility.format_error_stack
                                         , i_backtrace   => dbms_utility.format_error_backtrace );
                rollback to tst_case_sp;
        end;
    end loop;

    rollback to tst_setup_sp;
    tst_runner.end_run_success( l_run_id );
exception
    when others
    then
        if ( l_run_id is not null )
        then
            tst_runner.end_run_error( i_run_id => l_run_id, i_sqlcode => sqlcode, i_sqlerrm => sqlerrm );
        end if;
        raise;
end test_is_working_day;

--------------------------------------------------------------------------------

end test_lib_calendar;
/

show errors package body test_lib_calendar

prompt File: test_lib_calendar.pkb.sql <end>
