prompt File: test_lib_calendar.pks.sql <start>
-- =============================================================================
-- File:     test_lib_calendar.pks.sql
-- Oggetto:  test_lib_calendar (specifica del wrapper di test)
-- Schema:   #APP#_TST
-- Scopo:    Wrapper di test per #APP#.lib_calendar, nello stile del test harness.
--           Vive nello schema di test #APP#_TST (dev/test only), separato
--           dall'owner: raggiunge la logica di #APP# tramite sinonimi privati e
--           registra gli esiti sulle tabelle tst_* del runtime. Il dettaglio
--           interno delle chiamate, se il target logga, resta sui log di #APP#
--           (log_events) ed è correlabile per correlation_id.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260716  AA   Creazione (proof-of-concept gradino 0)
-- =============================================================================

prompt test_lib_calendar: Creating package specification

create or replace
package test_lib_calendar
is
--------------------------------------------------------------------------------
-- Esercita lib_calendar.add_working_days sui casi della vista omonima _tc_v.
procedure test_add_working_days;
--------------------------------------------------------------------------------
-- Esercita lib_calendar.is_working_day (ritorno booleano) sui casi _tc_v.
procedure test_is_working_day;
--------------------------------------------------------------------------------

end test_lib_calendar;
/

show errors package test_lib_calendar

prompt File: test_lib_calendar.pks.sql <end>
