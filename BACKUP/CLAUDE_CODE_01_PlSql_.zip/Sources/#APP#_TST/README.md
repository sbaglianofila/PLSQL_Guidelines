# Schema `#APP#_TST` — Test harness

Questo albero ospita il **test harness**: il runtime che esegue i test, li isola in transazione e ne registra gli esiti su tabelle interrogabili, più i **wrapper di test** che esercitano la logica di `#APP#`. È lo schema gemello di `#APP#_GEN` sul piano del ciclo di vita: esiste **solo negli ambienti di sviluppo e test**, non deve mai comparire in produzione e i suoi script restano fuori dai pacchetti di release.

Nasce dalla scelta di adottare, in alternativa a utPLSQL, un harness più leggero e con un generatore che parte dalla firma delle procedure. Il razionale, i confronti e le decisioni sono in `STATUS.md`; qui si documenta com'è organizzato lo schema. Il codice del harness è **codice del framework a tutti gli effetti**: segue le convenzioni (identificatori inglesi, commenti italiani UTF-8, stile di codifica, un file per oggetto) come qualsiasi altro sorgente. Il prefisso `tst_` è il prefisso di pillar dei test, in fila con `ref_`, `log_`, `wfl_`, `adm_`.

## Organizzazione

- `Tables/` — le tabelle del harness, una per file: `tst_run` (testata di una esecuzione), `tst_case` (il singolo caso, con `correlation_id` per la verifica a due livelli), `tst_case_param` / `tst_case_output` (input e output osservati), `tst_assert_result` (esito delle asserzioni), `tst_log_msg` (log tecnico interno).
- `FKs/` — le foreign key, in file separati secondo la convenzione dei sorgenti.
- `Packages/` — i package del runtime: `tst_util` (utilità), `tst_log` (registrazione di parametri/output/messaggi), `tst_assert` (asserzioni PASS/FAIL), `tst_runner` (ciclo di vita di run e casi).
- `Views/` — le viste di lettura del harness (`tst_v_run_summary`, `tst_v_case_detail`, `tst_v_assert_failure`) e le **viste dei casi** `*_tc_v`.
- `Tests/` — i **wrapper** di test (`test_<package>`).
- `Provisioning/` — creazione dello schema, ruolo, grant e sinonimi (vedi sotto).
- `Install/install.ins.sql` — l'orchestratore che installa il tutto nell'ordine di dipendenza.

## Le viste dei casi (`*_tc_v`)

Ogni vista `*_tc_v` disaccoppia il **dato** dei casi di test dal wrapper che li esegue: il wrapper si limita a citare le colonne della vista nel proprio cursore. Il beneficio è duplice — i casi (decine di righe) stanno fuori dal codice, e un cambio di firma del target che tocca le colonne fa fallire la **compilazione** del wrapper invece di passare inosservato. È il meccanismo che rende il wrapper stabile e (in prospettiva) rigenerabile senza merge manuale dei casi.

## I due livelli di log

Il harness registra gli esiti sulle proprie tabelle `tst_*` (cosa ho testato e com'è andato). Il **dettaglio interno** delle chiamate resta invece sui log di `#APP#` (`log_events`), quando il target logga. I due livelli si congiungono per `correlation_id`: il wrapper genera un correlation id, lo passa a `tst_runner.start_case` (che lo scrive su `tst_case`) e lo imposta sulla sessione, così gli eventuali `log_events` scritti dentro `#APP#` durante la chiamata portano lo stesso id. Il valore di questo aggancio è proporzionale a quanto il target logga: sui package puri (come `lib_calendar`) è nullo; sugli orchestratori e sui `pkg_*` di business è alto.

Le asserzioni (`tst_assert`) e il log tecnico (`tst_log`) del harness sono volutamente **distinti** da `lib_assert` e `lib_logging` di `#APP#`: quelli validano e loggano il codice applicativo, questi giudicano e raccontano un test. Sono concern diversi, come lo sono in utPLSQL.

## Provisioning e la deroga al meccanismo guscio

Poiché i wrapper vivono **fuori** da `#APP#`, per esercitare la logica lo schema di test riceve `EXECUTE` sui package di **logica dal nome pulito** — non sul guscio `_shell`. È l'unica deroga all'invariante "la logica non si granta mai", ed è deliberata: il guscio protegge il codice dai consumatori **in produzione**, dove `#APP#_TST` non esiste; in sviluppo chi scrive i test ha già i sorgenti. L'invariante va quindi letto come "la logica non si granta mai **in produzione**". Il ragionamento completo è in `Architettura_DB/schemi.md` e nel commento in testa a `Provisioning/#APP#_tst_object_grants.grt.sql`.

Ordine di provisioning (una tantum per ambiente), da eseguire prima dell'install:

1. `#APP#_tst.usr.sql` — come DBA: crea l'utente e i privilegi di sistema.
2. `#APP#_tst_role.rol.sql` — come DBA: crea il ruolo e lo assegna all'utente.
3. `#APP#_tst_object_grants.grt.sql` — come owner `#APP#`: grant di logica, log e fixture al ruolo.
4. `#APP#_tst_synonyms.syn.sql` — come utenza con `CREATE ANY SYNONYM`: sinonimi privati.

Poi, come `#APP#_TST`: `@@Install/install.ins.sql`.
