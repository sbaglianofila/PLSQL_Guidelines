prompt File: tst_case.fky.sql <start>
-- =============================================================================
-- File:     tst_case.fky.sql
-- Oggetto:  Foreign key di tst_case
-- Schema:   #APP#_TST
-- Scopo:    Lega ogni caso alla sua run. In file separato secondo la convenzione
--           dei sorgenti, eseguito dopo la creazione delle tabelle.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260716  AA   Creazione (integrazione del test harness nel framework)
-- =============================================================================

prompt tst_case: Adding foreign keys

alter table tst_case
   add constraint tst_case_fk_run foreign key ( run_id ) references tst_run ( run_id );

prompt File: tst_case.fky.sql <end>
