prompt File: tst_log_msg.fky.sql <start>
-- =============================================================================
-- File:     tst_log_msg.fky.sql
-- Oggetto:  Foreign key di tst_log_msg
-- Schema:   #APP#_TST
-- Scopo:    Lega il log tecnico alla run e, quando presente, al caso.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260716  AA   Creazione (integrazione del test harness nel framework)
-- =============================================================================

prompt tst_log_msg: Adding foreign keys

alter table tst_log_msg
   add constraint tst_log_msg_fk_run foreign key ( run_id ) references tst_run ( run_id );

alter table tst_log_msg
   add constraint tst_log_msg_fk_case foreign key ( case_id ) references tst_case ( case_id );

prompt File: tst_log_msg.fky.sql <end>
