prompt File: tst_assert_result.fky.sql <start>
-- =============================================================================
-- File:     tst_assert_result.fky.sql
-- Oggetto:  Foreign key di tst_assert_result
-- Schema:   #APP#_TST
-- Scopo:    Lega ogni asserzione al suo caso.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260716  AA   Creazione (integrazione del test harness nel framework)
-- =============================================================================

prompt tst_assert_result: Adding foreign keys

alter table tst_assert_result
   add constraint tst_assert_result_fk_case foreign key ( case_id ) references tst_case ( case_id );

prompt File: tst_assert_result.fky.sql <end>
