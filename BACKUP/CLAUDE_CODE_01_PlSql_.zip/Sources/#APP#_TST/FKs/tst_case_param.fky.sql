prompt File: tst_case_param.fky.sql <start>
-- =============================================================================
-- File:     tst_case_param.fky.sql
-- Oggetto:  Foreign key di tst_case_param
-- Schema:   #APP#_TST
-- Scopo:    Lega ogni riga di parametro al suo caso.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260716  AA   Creazione (integrazione del test harness nel framework)
-- =============================================================================

prompt tst_case_param: Adding foreign keys

alter table tst_case_param
   add constraint tst_case_param_fk_case foreign key ( case_id ) references tst_case ( case_id );

prompt File: tst_case_param.fky.sql <end>
