prompt File: tst_case_output.fky.sql <start>
-- =============================================================================
-- File:     tst_case_output.fky.sql
-- Oggetto:  Foreign key di tst_case_output
-- Schema:   #APP#_TST
-- Scopo:    Lega ogni riga di output al suo caso.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260716  AA   Creazione (integrazione del test harness nel framework)
-- =============================================================================

prompt tst_case_output: Adding foreign keys

alter table tst_case_output
   add constraint tst_case_output_fk_case foreign key ( case_id ) references tst_case ( case_id );

prompt File: tst_case_output.fky.sql <end>
