prompt File: #APP#_tst_object_grants.grt.sql <start>
-- =============================================================================
-- File:     #APP#_tst_object_grants.grt.sql
-- Oggetto:  Grant di oggetto da #APP# a #APP#_tst_role
-- Schema:   eseguire come owner #APP#
-- Scopo:    Espone alla schema di test ciò che le serve per esercitare la logica.
--
--           ECCEZIONE ALL'INVARIANTE DEL GUSCIO - da leggere. La regola generale
--           di schemi.md è che la logica dal nome pulito non si granta MAI: si
--           granta solo il guscio _shell. Qui si granta EXECUTE sulla logica pulita
--           (lib_*, e in un progetto i pkg_*). Non è una violazione, è il confine
--           preciso dell'invariante: il guscio protegge il codice dai CONSUMATORI
--           IN PRODUZIONE, e #APP#_TST - come #APP#_GEN - in produzione NON ESISTE.
--           In sviluppo chi scrive i test ha già i sorgenti in mano: non c'è nulla
--           da nascondere. L'invariante va quindi letto come "la logica non si
--           granta mai in produzione". Inoltre il framework testa la logica (non il
--           guscio), quindi è alla logica che il test deve arrivare.
--
--           I grant vanno al ruolo #APP#_tst_role, non all'utente, coerentemente
--           col modello a ruoli. In un progetto reale si elencano qui i package di
--           logica sotto test; per la base si mostra il pattern su lib_calendar e
--           le dipendenze del wrapper.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260716  AA   Creazione (gradino 1)
-- =============================================================================

prompt #APP#_tst_role: EXECUTE sulla logica sotto test e sulle dipendenze del wrapper

grant execute on lib_calendar to #APP#_tst_role;   -- target sotto test
grant execute on lib_session  to #APP#_tst_role;   -- set_correlation (aggancio dei log)
grant execute on lib_logging  to #APP#_tst_role;   -- new_correlation_id

prompt #APP#_tst_role: SELECT sui log per la verifica a due livelli

grant select on log_events        to #APP#_tst_role;
grant select on log_error_details to #APP#_tst_role;

prompt #APP#_tst_role: DML sulle tabelle usate come fixture dai wrapper

grant select, insert, update, delete on ref_holidays to #APP#_tst_role;

prompt File: #APP#_tst_object_grants.grt.sql <end>
