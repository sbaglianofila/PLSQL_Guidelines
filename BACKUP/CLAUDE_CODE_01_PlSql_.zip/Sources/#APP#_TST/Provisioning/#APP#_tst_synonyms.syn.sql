prompt File: #APP#_tst_synonyms.syn.sql <start>
-- =============================================================================
-- File:     #APP#_tst_synonyms.syn.sql
-- Oggetto:  Sinonimi privati di #APP#_TST verso l'owner #APP#
-- Schema:   eseguire in fase di provisioning da un'utenza con CREATE ANY SYNONYM
-- Scopo:    Crea nello schema di test i sinonimi privati che permettono ai wrapper
--           di citare gli oggetti di #APP# col nome pulito, senza qualificare con
--           il nome dell'owner (che cambia da progetto a progetto). Stessa via di
--           schemi.md: i sinonimi privati dei consumer si creano al provisioning da
--           un'utenza di installazione, così lo schema di test resta senza
--           CREATE SYNONYM. I grant sottostanti sono in #APP#_tst_object_grants.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260716  AA   Creazione (gradino 1)
-- =============================================================================

prompt #APP#_tst: Creating private synonyms to #APP#

create synonym #APP#_tst.lib_calendar      for #APP#.lib_calendar;
create synonym #APP#_tst.lib_session       for #APP#.lib_session;
create synonym #APP#_tst.lib_logging       for #APP#.lib_logging;
create synonym #APP#_tst.ref_holidays      for #APP#.ref_holidays;
create synonym #APP#_tst.log_events        for #APP#.log_events;
create synonym #APP#_tst.log_error_details for #APP#.log_error_details;

prompt File: #APP#_tst_synonyms.syn.sql <end>
