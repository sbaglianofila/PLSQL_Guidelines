prompt File: #APP#_tst_role.rol.sql <start>
-- =============================================================================
-- File:     #APP#_tst_role.rol.sql
-- Oggetto:  #APP#_tst_role (ruolo di profilo dello schema di test)
-- Schema:   eseguire come utente privilegiato / DBA
-- Scopo:    Ruolo che raccoglie i grant di cui il test harness ha bisogno verso
--           #APP#: EXECUTE sulla logica, SELECT sui log, DML sulle tabelle usate
--           come fixture. I grant di oggetto si assegnano al ruolo negli script
--           eseguiti dall'owner (#APP#_tst_object_grants.grt.sql). Assegnato poi a
--           #APP#_tst. Esiste solo in dev/test.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260716  AA   Creazione (gradino 1)
-- =============================================================================

prompt #APP#_tst_role: Creating role
create role #APP#_tst_role;

prompt #APP#_tst_role: Granting role to the test schema
grant #APP#_tst_role to #APP#_tst;

prompt File: #APP#_tst_role.rol.sql <end>
