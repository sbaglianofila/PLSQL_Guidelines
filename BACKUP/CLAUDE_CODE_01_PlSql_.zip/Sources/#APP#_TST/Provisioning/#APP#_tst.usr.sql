prompt File: #APP#_tst.usr.sql <start>
-- =============================================================================
-- File:     #APP#_tst.usr.sql
-- Oggetto:  #APP#_TST (utente / schema di test)
-- Schema:   eseguire come utente privilegiato / DBA
-- Scopo:    Crea lo schema che ospita il test harness (runtime tst_*) e i wrapper
--           di test. Come #APP#_GEN, è uno schema di SOLO SVILUPPO/TEST: non deve
--           mai esistere in produzione e i suoi script restano fuori dai pacchetti
--           di release. Crea oggetti propri (tabelle tst_*, package, viste), quindi
--           ha privilegi di creazione e una quota sul tablespace di default.
-- Nota:     Nessuna password reale qui: solo un segnaposto; il segreto vero si
--           imposta nell'ambiente, mai nel version control.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260716  AA   Creazione (gradino 1)
-- =============================================================================

prompt #APP#_tst: Creating user

create user #APP#_tst identified by "<placeholder_password>"
   default tablespace   users
   temporary tablespace temp
   quota unlimited on   users;

prompt #APP#_tst: Granting system privileges

grant create session   to #APP#_tst;
grant create table     to #APP#_tst;   -- tabelle del runtime tst_*
grant create view      to #APP#_tst;   -- viste dei casi _tc_v e viste del runtime
grant create procedure to #APP#_tst;   -- wrapper di test e package del runtime

prompt File: #APP#_tst.usr.sql <end>
