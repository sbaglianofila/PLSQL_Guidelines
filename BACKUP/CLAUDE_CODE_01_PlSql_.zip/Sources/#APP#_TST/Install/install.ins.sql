prompt File: install.ins.sql <start>
-- =============================================================================
-- File:     install.ins.sql
-- Oggetto:  Orchestratore di install dello schema #APP#_TST (test harness)
-- Schema:   #APP#_TST (solo ambienti di sviluppo/test)
-- Scopo:    Installa il test harness in ordine di dipendenza: tabelle, foreign
--           key, specifiche e corpi dei package, viste di lettura, viste dei casi
--           e wrapper di test. Eseguire connessi come #APP#_TST, dopo che #APP# è
--           installato e dopo il provisioning (utente, ruolo, grant, sinonimi).
--           MAI in produzione, MAI in un pacchetto di release.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260716  AA   Creazione (integrazione del test harness nel framework)
-- =============================================================================

whenever sqlerror exit failure rollback
whenever oserror  exit failure
set echo        off
set feedback     on
set define       off
set serveroutput on size unlimited

prompt ============================================================
prompt Install #APP#_TST test harness: start
prompt ============================================================

prompt #APP#_TST: Tabelle
@@../Tables/tst_run.tab.sql
@@../Tables/tst_case.tab.sql
@@../Tables/tst_case_param.tab.sql
@@../Tables/tst_case_output.tab.sql
@@../Tables/tst_assert_result.tab.sql
@@../Tables/tst_log_msg.tab.sql

prompt #APP#_TST: Foreign key
@@../FKs/tst_case.fky.sql
@@../FKs/tst_case_param.fky.sql
@@../FKs/tst_case_output.fky.sql
@@../FKs/tst_assert_result.fky.sql
@@../FKs/tst_log_msg.fky.sql

prompt #APP#_TST: Specifiche dei package
@@../Packages/tst_util.pks.sql
@@../Packages/tst_log.pks.sql
@@../Packages/tst_assert.pks.sql
@@../Packages/tst_runner.pks.sql

prompt #APP#_TST: Corpi dei package
@@../Packages/tst_util.pkb.sql
@@../Packages/tst_log.pkb.sql
@@../Packages/tst_assert.pkb.sql
@@../Packages/tst_runner.pkb.sql

prompt #APP#_TST: Viste di lettura del harness
@@../Views/tst_v_run_summary.vw.sql
@@../Views/tst_v_case_detail.vw.sql
@@../Views/tst_v_assert_failure.vw.sql

prompt #APP#_TST: Viste dei casi di test
@@../Views/lib_calendar_add_working_days_tc_v.vw.sql
@@../Views/lib_calendar_is_working_day_tc_v.vw.sql

prompt #APP#_TST: Wrapper di test
@@../Tests/test_lib_calendar.pks.sql
@@../Tests/test_lib_calendar.pkb.sql

prompt ============================================================
prompt Install #APP#_TST test harness: completed
prompt Esegui i wrapper con, ad esempio:
prompt   begin test_lib_calendar.test_add_working_days; end;
prompt Consulta gli esiti su tst_v_run_summary / tst_v_case_detail
prompt ============================================================
prompt File: install.ins.sql <end>
