prompt File: tst_log.pkb.sql <start>
-- =============================================================================
-- File:     tst_log.pkb.sql
-- Oggetto:  tst_log (corpo del package)
-- Schema:   #APP#_TST
-- Scopo:    Implementazione della registrazione di parametri, output e messaggi.
--           Le scritture avvengono in transazione autonoma, così da persistere
--           anche quando il caso fa rollback.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260716  AA   Creazione (integrazione del test harness nel framework)
-- =============================================================================

prompt tst_log: Creating package body

create or replace
package body tst_log
is

--------------------------------------------------------------------------------
-- Inserimento tipizzato su tst_case_param (transazione autonoma).
procedure insert_param( i_case_id         in number
                      , i_param_name      in varchar2
                      , i_param_mode      in varchar2
                      , i_param_type      in varchar2
                      , i_value_varchar2  in varchar2 default null
                      , i_value_number    in number default null
                      , i_value_date      in date default null
                      , i_value_timestamp in timestamp default null
                      , i_value_clob      in clob default null
                      )
is
    pragma autonomous_transaction;
begin
    insert into tst_case_param ( case_id, param_name, param_mode, param_type
                               , value_varchar2, value_number, value_date, value_timestamp, value_clob )
    values ( i_case_id, upper(trim(i_param_name)), upper(trim(i_param_mode)), upper(trim(i_param_type))
           , i_value_varchar2, i_value_number, i_value_date, i_value_timestamp, i_value_clob );

    commit;
exception
    when others
    then
        rollback;
        raise;
end insert_param;
--------------------------------------------------------------------------------
-- Inserimento tipizzato su tst_case_output (transazione autonoma).
procedure insert_output( i_case_id         in number
                       , i_output_name     in varchar2
                       , i_output_type     in varchar2
                       , i_value_varchar2  in varchar2 default null
                       , i_value_number    in number default null
                       , i_value_date      in date default null
                       , i_value_timestamp in timestamp default null
                       , i_value_clob      in clob default null
                       )
is
    pragma autonomous_transaction;
begin
    insert into tst_case_output ( case_id, output_name, output_type
                                , value_varchar2, value_number, value_date, value_timestamp, value_clob )
    values ( i_case_id, upper(trim(i_output_name)), upper(trim(i_output_type))
           , i_value_varchar2, i_value_number, i_value_date, i_value_timestamp, i_value_clob );

    commit;
exception
    when others
    then
        rollback;
        raise;
end insert_output;
--------------------------------------------------------------------------------
procedure message( i_run_id  in number default null
                 , i_case_id in number default null
                 , i_level   in varchar2 default 'INFO'
                 , i_message in clob
                 , i_sqlcode in number default null
                 , i_sqlerrm in varchar2 default null
                 )
is
    pragma autonomous_transaction;
    l_level varchar2(20);
begin
    l_level := upper(nvl(trim(i_level), 'INFO'));

    if ( l_level not in ('DEBUG','INFO','WARN','ERROR') )
    then
        l_level := 'INFO';
    end if;

    insert into tst_log_msg ( run_id, case_id, log_level, message, sqlcode_value, sqlerrm_value )
    values ( i_run_id, i_case_id, l_level, i_message, i_sqlcode, i_sqlerrm );

    commit;
exception
    when others
    then
        rollback;
        raise;
end message;
--------------------------------------------------------------------------------
procedure log_param(i_case_id in number, i_param_name in varchar2, i_param_mode in varchar2, i_param_type in varchar2, i_value in varchar2)
is
begin
    insert_param( i_case_id => i_case_id, i_param_name => i_param_name, i_param_mode => i_param_mode
                , i_param_type => i_param_type, i_value_varchar2 => i_value );
end log_param;
--------------------------------------------------------------------------------
procedure log_param(i_case_id in number, i_param_name in varchar2, i_param_mode in varchar2, i_param_type in varchar2, i_value in number)
is
begin
    insert_param( i_case_id => i_case_id, i_param_name => i_param_name, i_param_mode => i_param_mode
                , i_param_type => i_param_type, i_value_number => i_value );
end log_param;
--------------------------------------------------------------------------------
procedure log_param(i_case_id in number, i_param_name in varchar2, i_param_mode in varchar2, i_param_type in varchar2, i_value in date)
is
begin
    insert_param( i_case_id => i_case_id, i_param_name => i_param_name, i_param_mode => i_param_mode
                , i_param_type => i_param_type, i_value_date => i_value );
end log_param;
--------------------------------------------------------------------------------
procedure log_param(i_case_id in number, i_param_name in varchar2, i_param_mode in varchar2, i_param_type in varchar2, i_value in timestamp)
is
begin
    insert_param( i_case_id => i_case_id, i_param_name => i_param_name, i_param_mode => i_param_mode
                , i_param_type => i_param_type, i_value_timestamp => i_value );
end log_param;
--------------------------------------------------------------------------------
procedure log_param_clob(i_case_id in number, i_param_name in varchar2, i_param_mode in varchar2, i_param_type in varchar2, i_value in clob)
is
begin
    insert_param( i_case_id => i_case_id, i_param_name => i_param_name, i_param_mode => i_param_mode
                , i_param_type => i_param_type, i_value_varchar2 => tst_util.clob_preview(i_value), i_value_clob => i_value );
end log_param_clob;
--------------------------------------------------------------------------------
procedure log_output(i_case_id in number, i_output_name in varchar2, i_output_type in varchar2, i_value in varchar2)
is
begin
    insert_output( i_case_id => i_case_id, i_output_name => i_output_name, i_output_type => i_output_type, i_value_varchar2 => i_value );
end log_output;
--------------------------------------------------------------------------------
procedure log_output(i_case_id in number, i_output_name in varchar2, i_output_type in varchar2, i_value in number)
is
begin
    insert_output( i_case_id => i_case_id, i_output_name => i_output_name, i_output_type => i_output_type, i_value_number => i_value );
end log_output;
--------------------------------------------------------------------------------
procedure log_output(i_case_id in number, i_output_name in varchar2, i_output_type in varchar2, i_value in date)
is
begin
    insert_output( i_case_id => i_case_id, i_output_name => i_output_name, i_output_type => i_output_type, i_value_date => i_value );
end log_output;
--------------------------------------------------------------------------------
procedure log_output(i_case_id in number, i_output_name in varchar2, i_output_type in varchar2, i_value in timestamp)
is
begin
    insert_output( i_case_id => i_case_id, i_output_name => i_output_name, i_output_type => i_output_type, i_value_timestamp => i_value );
end log_output;
--------------------------------------------------------------------------------
procedure log_output_clob(i_case_id in number, i_output_name in varchar2, i_output_type in varchar2, i_value in clob)
is
begin
    insert_output( i_case_id => i_case_id, i_output_name => i_output_name, i_output_type => i_output_type
                 , i_value_varchar2 => tst_util.clob_preview(i_value), i_value_clob => i_value );
end log_output_clob;
--------------------------------------------------------------------------------
procedure log_return_value(i_case_id in number, i_value_type in varchar2, i_value in varchar2)
is
begin
    log_output(i_case_id, 'RETURN_VALUE', i_value_type, i_value);
end log_return_value;
--------------------------------------------------------------------------------
procedure log_return_value(i_case_id in number, i_value_type in varchar2, i_value in number)
is
begin
    log_output(i_case_id, 'RETURN_VALUE', i_value_type, i_value);
end log_return_value;
--------------------------------------------------------------------------------
procedure log_return_value(i_case_id in number, i_value_type in varchar2, i_value in date)
is
begin
    log_output(i_case_id, 'RETURN_VALUE', i_value_type, i_value);
end log_return_value;
--------------------------------------------------------------------------------
procedure log_return_value(i_case_id in number, i_value_type in varchar2, i_value in timestamp)
is
begin
    log_output(i_case_id, 'RETURN_VALUE', i_value_type, i_value);
end log_return_value;
--------------------------------------------------------------------------------
procedure log_return_value_clob(i_case_id in number, i_value_type in varchar2, i_value in clob)
is
begin
    log_output_clob(i_case_id, 'RETURN_VALUE', i_value_type, i_value);
end log_return_value_clob;
--------------------------------------------------------------------------------

end tst_log;
/

show errors package body tst_log

prompt File: tst_log.pkb.sql <end>
