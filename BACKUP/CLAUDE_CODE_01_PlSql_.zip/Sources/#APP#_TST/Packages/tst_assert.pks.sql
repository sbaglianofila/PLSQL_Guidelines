prompt File: tst_assert.pks.sql <start>
-- =============================================================================
-- File:     tst_assert.pks.sql
-- Oggetto:  tst_assert (specifica del package)
-- Schema:   #APP#_TST
-- Scopo:    Asserzioni minime del test harness: registrano su tst_assert_result
--           l'esito PASS/FAIL del confronto tra valore atteso ed effettivo. Sono
--           l'impianto di verifica del harness, distinto da lib_assert (che valida
--           gli argomenti del codice applicativo): qui si giudica un test.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260716  AA   Creazione (integrazione del test harness nel framework)
-- =============================================================================

prompt tst_assert: Creating package specification

create or replace
package tst_assert
is

--------------------------------------------------------------------------------
-- Registra un PASS esplicito per il caso.
procedure pass(i_case_id in number, i_name in varchar2, i_message in varchar2 default null);
--------------------------------------------------------------------------------
-- Registra un FAIL esplicito, con atteso ed effettivo opzionali.
procedure fail( i_case_id  in number
              , i_name     in varchar2
              , i_message  in varchar2 default null
              , i_expected in clob default null
              , i_actual   in clob default null
              );
--------------------------------------------------------------------------------
-- Asserisce che una condizione booleana sia vera (un null è trattato come FAIL).
procedure assert_true( i_case_id   in number
                     , i_name      in varchar2
                     , i_condition in boolean
                     , i_message   in varchar2 default null
                     );
--------------------------------------------------------------------------------
-- Confronto di uguaglianza per tipo, con null-safe (null = null è PASS).
procedure eq_varchar2( i_case_id  in number
                     , i_name     in varchar2
                     , i_expected in varchar2
                     , i_actual   in varchar2
                     , i_message  in varchar2 default null
                     );
procedure eq_number( i_case_id   in number
                   , i_name      in varchar2
                   , i_expected  in number
                   , i_actual    in number
                   , i_tolerance in number default 0
                   , i_message   in varchar2 default null
                   );
procedure eq_date( i_case_id  in number
                 , i_name     in varchar2
                 , i_expected in date
                 , i_actual   in date
                 , i_message  in varchar2 default null
                 );
procedure eq_timestamp( i_case_id  in number
                      , i_name     in varchar2
                      , i_expected in timestamp
                      , i_actual   in timestamp
                      , i_message  in varchar2 default null
                      );
--------------------------------------------------------------------------------
-- Asserisce che un valore sia (o non sia) nullo.
procedure is_null(i_case_id in number, i_name in varchar2, i_actual in varchar2, i_message in varchar2 default null);
procedure is_not_null(i_case_id in number, i_name in varchar2, i_actual in varchar2, i_message in varchar2 default null);
--------------------------------------------------------------------------------

end tst_assert;
/

show errors package tst_assert

prompt File: tst_assert.pks.sql <end>
