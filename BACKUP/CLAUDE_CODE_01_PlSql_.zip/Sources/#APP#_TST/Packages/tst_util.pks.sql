prompt File: tst_util.pks.sql <start>
-- =============================================================================
-- File:     tst_util.pks.sql
-- Oggetto:  tst_util (specifica del package)
-- Schema:   #APP#_TST
-- Scopo:    Utilità comuni del test harness: normalizzazione dei nomi, conversione
--           booleano/flag, calcolo della durata e resa a testo dei valori tipizzati.
--           È il livello di base su cui poggiano gli altri package tst_*.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260716  AA   Creazione (integrazione del test harness nel framework)
-- =============================================================================

prompt tst_util: Creating package specification

create or replace
package tst_util
is

subtype t_name is varchar2(128);

--------------------------------------------------------------------------------
-- Normalizza un nome semplice SQL (maiuscolo, trimmato) e ne verifica la forma.
-- i_name : nome da normalizzare.
-- return : il nome normalizzato.
function normalize_name(i_name in varchar2)
    return varchar2;
--------------------------------------------------------------------------------
-- Rende un booleano come testo ('TRUE'/'FALSE'/'NULL'), per loggarlo o confrontarlo.
function boolean_to_varchar2(i_value in boolean)
    return varchar2;
--------------------------------------------------------------------------------
-- Interpreta un flag testuale (Y/N, SI/NO, TRUE/FALSE, 1/0, ...) come booleano.
function flag_to_boolean(i_value in varchar2)
    return boolean;
--------------------------------------------------------------------------------
-- Durata in millisecondi tra due istanti; null se un estremo è null.
function elapsed_ms(i_started_at in timestamp, i_ended_at in timestamp default systimestamp)
    return number;
--------------------------------------------------------------------------------
-- Anteprima testuale di un CLOB, troncata alla lunghezza richiesta (max 4000).
function clob_preview(i_value in clob, i_length in pls_integer default 4000)
    return varchar2;
--------------------------------------------------------------------------------
-- Rende a CLOB un valore tipizzato, con formato stabile per date e timestamp.
function to_text(i_value in varchar2)
    return clob;
function to_text(i_value in number)
    return clob;
function to_text(i_value in date)
    return clob;
function to_text(i_value in timestamp)
    return clob;
function to_text(i_value in clob)
    return clob;
--------------------------------------------------------------------------------

end tst_util;
/

show errors package tst_util

prompt File: tst_util.pks.sql <end>
