prompt File: tst_util.pkb.sql <start>
-- =============================================================================
-- File:     tst_util.pkb.sql
-- Oggetto:  tst_util (corpo del package)
-- Schema:   #APP#_TST
-- Scopo:    Implementazione delle utilità comuni del test harness.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260716  AA   Creazione (integrazione del test harness nel framework)
-- =============================================================================

prompt tst_util: Creating package body

create or replace
package body tst_util
is

--------------------------------------------------------------------------------
function normalize_name(i_name in varchar2)
    return varchar2
is
    l_name varchar2(128);
begin
    l_name := upper(trim(i_name));

    if ( l_name is null )
    then
        raise_application_error(-20900, 'Il nome non può essere nullo.');
    end if;

    if ( not regexp_like(l_name, '^[A-Z][A-Z0-9_$#]*$') )
    then
        raise_application_error(-20901, 'Nome SQL semplice non valido: ' || i_name);
    end if;

    return (l_name);
end normalize_name;
--------------------------------------------------------------------------------
function boolean_to_varchar2(i_value in boolean)
    return varchar2
is
begin
    if ( i_value is null )
    then
        return ('NULL');
    elsif ( i_value )
    then
        return ('TRUE');
    else
        return ('FALSE');
    end if;
end boolean_to_varchar2;
--------------------------------------------------------------------------------
function flag_to_boolean(i_value in varchar2)
    return boolean
is
    l_value varchar2(30);
begin
    l_value := upper(trim(i_value));

    if ( l_value in ('Y','YES','S','SI','TRUE','T','1') )
    then
        return (true);
    elsif ( l_value in ('N','NO','FALSE','F','0') )
    then
        return (false);
    elsif ( l_value is null )
    then
        return (null);
    else
        raise_application_error(-20902, 'Flag booleano non valido: ' || i_value);
    end if;
end flag_to_boolean;
--------------------------------------------------------------------------------
function elapsed_ms(i_started_at in timestamp, i_ended_at in timestamp default systimestamp)
    return number
is
    l_interval interval day to second;
begin
    if ( i_started_at is null or i_ended_at is null )
    then
        return (null);
    end if;

    l_interval := i_ended_at - i_started_at;

    return (   extract(day    from l_interval) * 86400000
             + extract(hour   from l_interval) * 3600000
             + extract(minute from l_interval) * 60000
             + extract(second from l_interval) * 1000 );
end elapsed_ms;
--------------------------------------------------------------------------------
function clob_preview(i_value in clob, i_length in pls_integer default 4000)
    return varchar2
is
begin
    if ( i_value is null )
    then
        return (null);
    end if;

    return (dbms_lob.substr(i_value, least(nvl(i_length, 4000), 4000), 1));
end clob_preview;
--------------------------------------------------------------------------------
function to_text(i_value in varchar2)
    return clob
is
begin
    return (to_clob(i_value));
end to_text;
--------------------------------------------------------------------------------
function to_text(i_value in number)
    return clob
is
begin
    if ( i_value is null )
    then
        return (null);
    end if;

    return (to_clob(to_char(i_value)));
end to_text;
--------------------------------------------------------------------------------
function to_text(i_value in date)
    return clob
is
begin
    if ( i_value is null )
    then
        return (null);
    end if;

    return (to_clob(to_char(i_value, 'YYYY-MM-DD HH24:MI:SS')));
end to_text;
--------------------------------------------------------------------------------
function to_text(i_value in timestamp)
    return clob
is
begin
    if ( i_value is null )
    then
        return (null);
    end if;

    return (to_clob(to_char(i_value, 'YYYY-MM-DD HH24:MI:SS.FF6')));
end to_text;
--------------------------------------------------------------------------------
function to_text(i_value in clob)
    return clob
is
begin
    return (i_value);
end to_text;
--------------------------------------------------------------------------------

end tst_util;
/

show errors package body tst_util

prompt File: tst_util.pkb.sql <end>
