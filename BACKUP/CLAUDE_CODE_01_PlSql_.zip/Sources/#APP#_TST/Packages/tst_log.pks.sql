prompt File: tst_log.pks.sql <start>
-- =============================================================================
-- File:     tst_log.pks.sql
-- Oggetto:  tst_log (specifica del package)
-- Schema:   #APP#_TST
-- Scopo:    Registrazione di input, output, valore di ritorno e messaggi tecnici
--           di un caso di test, su tst_case_param / tst_case_output / tst_log_msg.
--           Gli overload per tipo evitano conversioni a carico del wrapper.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260716  AA   Creazione (integrazione del test harness nel framework)
-- =============================================================================

prompt tst_log: Creating package specification

create or replace
package tst_log
is

--------------------------------------------------------------------------------
-- Messaggio tecnico di run/caso (transazione autonoma).
procedure message( i_run_id  in number default null
                 , i_case_id in number default null
                 , i_level   in varchar2 default 'INFO'
                 , i_message in clob
                 , i_sqlcode in number default null
                 , i_sqlerrm in varchar2 default null
                 );
--------------------------------------------------------------------------------
-- Registra un parametro di input, con overload per tipo.
procedure log_param(i_case_id in number, i_param_name in varchar2, i_param_mode in varchar2, i_param_type in varchar2, i_value in varchar2);
procedure log_param(i_case_id in number, i_param_name in varchar2, i_param_mode in varchar2, i_param_type in varchar2, i_value in number);
procedure log_param(i_case_id in number, i_param_name in varchar2, i_param_mode in varchar2, i_param_type in varchar2, i_value in date);
procedure log_param(i_case_id in number, i_param_name in varchar2, i_param_mode in varchar2, i_param_type in varchar2, i_value in timestamp);
procedure log_param_clob(i_case_id in number, i_param_name in varchar2, i_param_mode in varchar2, i_param_type in varchar2, i_value in clob);
--------------------------------------------------------------------------------
-- Registra un output osservato, con overload per tipo.
procedure log_output(i_case_id in number, i_output_name in varchar2, i_output_type in varchar2, i_value in varchar2);
procedure log_output(i_case_id in number, i_output_name in varchar2, i_output_type in varchar2, i_value in number);
procedure log_output(i_case_id in number, i_output_name in varchar2, i_output_type in varchar2, i_value in date);
procedure log_output(i_case_id in number, i_output_name in varchar2, i_output_type in varchar2, i_value in timestamp);
procedure log_output_clob(i_case_id in number, i_output_name in varchar2, i_output_type in varchar2, i_value in clob);
--------------------------------------------------------------------------------
-- Registra il valore di ritorno di una function (output di nome RETURN_VALUE).
procedure log_return_value(i_case_id in number, i_value_type in varchar2, i_value in varchar2);
procedure log_return_value(i_case_id in number, i_value_type in varchar2, i_value in number);
procedure log_return_value(i_case_id in number, i_value_type in varchar2, i_value in date);
procedure log_return_value(i_case_id in number, i_value_type in varchar2, i_value in timestamp);
procedure log_return_value_clob(i_case_id in number, i_value_type in varchar2, i_value in clob);
--------------------------------------------------------------------------------

end tst_log;
/

show errors package tst_log

prompt File: tst_log.pks.sql <end>
