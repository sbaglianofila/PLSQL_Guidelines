prompt File: tst_runner.pks.sql <start>
-- =============================================================================
-- File:     tst_runner.pks.sql
-- Oggetto:  tst_runner (specifica del package)
-- Schema:   #APP#_TST
-- Scopo:    Ciclo di vita di una esecuzione di test: apertura/chiusura di run e
--           casi, aggiornamento degli stati e dei conteggi, gestione dell'errore
--           atteso. È l'API che il wrapper chiama per aprire e chiudere i casi.
--           start_case accetta il correlation id della chiamata e lo registra su
--           tst_case, per congiungere il caso ai log_events di #APP#.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260716  AA   Creazione (integrazione del test harness nel framework);
--                  start_case riceve i_correlation_id (prima scritto a parte dal
--                  wrapper con una update diretta)
-- =============================================================================

prompt tst_runner: Creating package specification

create or replace
package tst_runner
is

--------------------------------------------------------------------------------
-- Apre una run per un target e ne restituisce l'id.
function start_run( i_owner                  in varchar2
                  , i_package_name           in varchar2 default null
                  , i_program_name           in varchar2 default null
                  , i_generated_package_name in varchar2 default null
                  , i_profile_mode           in varchar2 default 'NONE'
                  , i_coverage_mode          in varchar2 default 'NONE'
                  , i_transaction_mode       in varchar2 default 'ROLLBACK'
                  , i_note                   in clob default null
                  )
    return number;
--------------------------------------------------------------------------------
-- Apre un caso dentro una run e ne restituisce l'id. i_correlation_id, se
-- valorizzato, viene scritto su tst_case per la verifica a due livelli.
function start_case( i_run_id           in number
                   , i_case_code        in varchar2 default null
                   , i_case_description in varchar2 default null
                   , i_expect_error     in varchar2 default 'N'
                   , i_expect_sqlcode   in number default null
                   , i_correlation_id   in varchar2 default null
                   )
    return number;
--------------------------------------------------------------------------------
-- Chiude un caso concluso senza errore (l'esito PASS/FAIL dipende dagli assert).
procedure end_case_success(i_case_id in number);
--------------------------------------------------------------------------------
-- Chiude un caso terminato con errore, giudicandolo rispetto all'errore atteso.
procedure end_case_error( i_case_id     in number
                        , i_sqlcode     in number
                        , i_sqlerrm     in varchar2
                        , i_error_stack in clob default null
                        , i_backtrace   in clob default null
                        );
--------------------------------------------------------------------------------
-- Marca un caso come saltato, con motivo.
procedure skip_case(i_case_id in number, i_reason in varchar2 default null);
--------------------------------------------------------------------------------
-- Chiude una run conclusa; lo stato dipende dai casi falliti o ancora aperti.
procedure end_run_success(i_run_id in number);
--------------------------------------------------------------------------------
-- Chiude una run interrotta da un errore non gestito.
procedure end_run_error(i_run_id in number, i_sqlcode in number, i_sqlerrm in varchar2);
--------------------------------------------------------------------------------

end tst_runner;
/

show errors package tst_runner

prompt File: tst_runner.pks.sql <end>
