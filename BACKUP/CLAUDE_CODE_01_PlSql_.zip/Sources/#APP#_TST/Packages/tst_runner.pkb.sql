prompt File: tst_runner.pkb.sql <start>
-- =============================================================================
-- File:     tst_runner.pkb.sql
-- Oggetto:  tst_runner (corpo del package)
-- Schema:   #APP#_TST
-- Scopo:    Implementazione del ciclo di vita di run e casi. Ogni transizione di
--           stato avviene in transazione autonoma, così da persistere anche
--           quando il codice sotto test fa rollback.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260716  AA   Creazione (integrazione del test harness nel framework);
--                  start_case registra il correlation id su tst_case
-- =============================================================================

prompt tst_runner: Creating package body

create or replace
package body tst_runner
is

--------------------------------------------------------------------------------
-- Ricalcola i conteggi aggregati della run dai suoi casi.
procedure refresh_run_counts(i_run_id in number)
is
begin
    update tst_run r
       set (total_cases, success_cases, failed_cases, warning_cases) =
           ( select count(*)
                  , nvl(sum(case when c.status = 'PASS' then 1 else 0 end), 0)
                  , nvl(sum(case when c.status in ('FAIL','ERROR') then 1 else 0 end), 0)
                  , nvl(sum(case when c.status = 'SKIPPED' then 1 else 0 end), 0)
               from tst_case c
              where c.run_id = i_run_id )
     where r.run_id = i_run_id;
end refresh_run_counts;
--------------------------------------------------------------------------------
-- Inserisce un'asserzione generata dal runner (senza transazione autonoma: gira
-- già dentro quella del chiamante end_case_*).
procedure insert_runner_assert( i_case_id  in number
                              , i_name     in varchar2
                              , i_expected in clob
                              , i_actual   in clob
                              , i_status   in varchar2
                              , i_message  in varchar2
                              )
is
begin
    insert into tst_assert_result ( case_id, assert_name, expected_value, actual_value, status, message )
    values ( i_case_id, upper(trim(i_name)), i_expected, i_actual, upper(trim(i_status)), i_message );
end insert_runner_assert;
--------------------------------------------------------------------------------
function start_run( i_owner                  in varchar2
                  , i_package_name           in varchar2 default null
                  , i_program_name           in varchar2 default null
                  , i_generated_package_name in varchar2 default null
                  , i_profile_mode           in varchar2 default 'NONE'
                  , i_coverage_mode          in varchar2 default 'NONE'
                  , i_transaction_mode       in varchar2 default 'ROLLBACK'
                  , i_note                   in clob default null
                  )
    return number
is
    pragma autonomous_transaction;
    l_run_id                 number;
    l_owner                  varchar2(128);
    l_package_name           varchar2(128);
    l_program_name           varchar2(128);
    l_generated_package_name varchar2(128);
    l_profile_mode           varchar2(30);
    l_coverage_mode          varchar2(30);
    l_transaction_mode       varchar2(30);
begin
    l_owner := tst_util.normalize_name(i_owner);

    if ( i_package_name is not null )
    then
        l_package_name := tst_util.normalize_name(i_package_name);
    end if;

    if ( i_program_name is not null )
    then
        l_program_name := tst_util.normalize_name(i_program_name);
    end if;

    if ( i_generated_package_name is not null )
    then
        l_generated_package_name := tst_util.normalize_name(i_generated_package_name);
    end if;

    l_profile_mode     := upper(nvl(trim(i_profile_mode), 'NONE'));
    l_coverage_mode    := upper(nvl(trim(i_coverage_mode), 'NONE'));
    l_transaction_mode := upper(nvl(trim(i_transaction_mode), 'ROLLBACK'));

    insert into tst_run ( source_owner, source_package_name, source_program_name, generated_package_name
                        , status, profile_mode, coverage_mode, transaction_mode
                        , client_identifier, module_name, action_name, note )
    values ( l_owner, l_package_name, l_program_name, l_generated_package_name
           , 'RUNNING', l_profile_mode, l_coverage_mode, l_transaction_mode
           , sys_context('USERENV','CLIENT_IDENTIFIER'), 'TST_HARNESS'
           , substr(nvl(l_package_name, '-') || '.' || nvl(l_program_name, '-'), 1, 128), i_note )
    returning run_id into l_run_id;

    dbms_application_info.set_module( module_name => 'TST_HARNESS'
                                    , action_name => substr(nvl(l_package_name, '-') || '.' || nvl(l_program_name, '-'), 1, 64) );

    commit;
    return (l_run_id);
exception
    when others
    then
        rollback;
        raise;
end start_run;
--------------------------------------------------------------------------------
function start_case( i_run_id           in number
                   , i_case_code        in varchar2 default null
                   , i_case_description in varchar2 default null
                   , i_expect_error     in varchar2 default 'N'
                   , i_expect_sqlcode   in number default null
                   , i_correlation_id   in varchar2 default null
                   )
    return number
is
    pragma autonomous_transaction;
    l_case_id      number;
    l_expect_error varchar2(1);
begin
    l_expect_error := upper(nvl(trim(i_expect_error), 'N'));

    if ( l_expect_error not in ('Y','N') )
    then
        raise_application_error(-20910, 'i_expect_error deve valere Y o N.');
    end if;

    insert into tst_case ( run_id, case_code, case_description, status, expect_error, expect_sqlcode, correlation_id )
    values ( i_run_id, i_case_code, i_case_description, 'RUNNING', l_expect_error, i_expect_sqlcode, i_correlation_id )
    returning case_id into l_case_id;

    dbms_application_info.set_action( action_name => substr('CASE: ' || nvl(i_case_code, to_char(l_case_id)), 1, 64) );

    refresh_run_counts(i_run_id);

    commit;
    return (l_case_id);
exception
    when others
    then
        rollback;
        raise;
end start_case;
--------------------------------------------------------------------------------
procedure end_case_success(i_case_id in number)
is
    pragma autonomous_transaction;
    l_started_at     timestamp(6);
    l_ended_at       timestamp(6) := systimestamp;
    l_run_id         number;
    l_expect_error   varchar2(1);
    l_expect_sqlcode number;
    l_fail_asserts   number;
    l_status         varchar2(30);
begin
    select started_at, run_id, expect_error, expect_sqlcode
      into l_started_at, l_run_id, l_expect_error, l_expect_sqlcode
      from tst_case
     where case_id = i_case_id
       for update;

    if ( l_expect_error = 'Y' )
    then
        insert_runner_assert( i_case_id  => i_case_id
                            , i_name     => 'EXPECTED_ERROR'
                            , i_expected => to_clob('SQLCODE ' || nvl(to_char(l_expect_sqlcode), '<ANY>'))
                            , i_actual   => to_clob('NO ERROR')
                            , i_status   => 'FAIL'
                            , i_message  => 'Il caso si attendeva un errore, ma il target è terminato con successo.' );
    end if;

    select count(*)
      into l_fail_asserts
      from tst_assert_result
     where case_id = i_case_id
       and status  = 'FAIL';

    if ( l_fail_asserts > 0 )
    then
        l_status := 'FAIL';
    else
        l_status := 'PASS';
    end if;

    update tst_case
       set ended_at   = l_ended_at
         , elapsed_ms = tst_util.elapsed_ms(l_started_at, l_ended_at)
         , status     = l_status
     where case_id = i_case_id;

    refresh_run_counts(l_run_id);

    commit;
exception
    when others
    then
        rollback;
        raise;
end end_case_success;
--------------------------------------------------------------------------------
procedure end_case_error( i_case_id     in number
                        , i_sqlcode     in number
                        , i_sqlerrm     in varchar2
                        , i_error_stack in clob default null
                        , i_backtrace   in clob default null
                        )
is
    pragma autonomous_transaction;
    l_started_at     timestamp(6);
    l_ended_at       timestamp(6) := systimestamp;
    l_run_id         number;
    l_expect_error   varchar2(1);
    l_expect_sqlcode number;
    l_status         varchar2(30);
begin
    select started_at, run_id, expect_error, expect_sqlcode
      into l_started_at, l_run_id, l_expect_error, l_expect_sqlcode
      from tst_case
     where case_id = i_case_id
       for update;

    if ( l_expect_error = 'Y' )
    then
        if ( l_expect_sqlcode is null or l_expect_sqlcode = i_sqlcode )
        then
            l_status := 'PASS';

            insert_runner_assert( i_case_id  => i_case_id
                                , i_name     => 'EXPECTED_ERROR'
                                , i_expected => to_clob('SQLCODE ' || nvl(to_char(l_expect_sqlcode), '<ANY>'))
                                , i_actual   => to_clob('SQLCODE ' || to_char(i_sqlcode))
                                , i_status   => 'PASS'
                                , i_message  => 'Errore atteso verificatosi.' );
        else
            l_status := 'FAIL';

            insert_runner_assert( i_case_id  => i_case_id
                                , i_name     => 'EXPECTED_ERROR'
                                , i_expected => to_clob('SQLCODE ' || to_char(l_expect_sqlcode))
                                , i_actual   => to_clob('SQLCODE ' || to_char(i_sqlcode))
                                , i_status   => 'FAIL'
                                , i_message  => 'Errore verificatosi, ma con SQLCODE diverso dall''atteso.' );
        end if;
    else
        l_status := 'ERROR';
    end if;

    update tst_case
       set ended_at        = l_ended_at
         , elapsed_ms      = tst_util.elapsed_ms(l_started_at, l_ended_at)
         , status          = l_status
         , sqlcode_value   = i_sqlcode
         , sqlerrm_value   = substr(i_sqlerrm, 1, 4000)
         , error_stack     = i_error_stack
         , error_backtrace = i_backtrace
     where case_id = i_case_id;

    refresh_run_counts(l_run_id);

    commit;
exception
    when others
    then
        rollback;
        raise;
end end_case_error;
--------------------------------------------------------------------------------
procedure skip_case(i_case_id in number, i_reason in varchar2 default null)
is
    pragma autonomous_transaction;
    l_started_at timestamp(6);
    l_ended_at   timestamp(6) := systimestamp;
    l_run_id     number;
begin
    select started_at, run_id
      into l_started_at, l_run_id
      from tst_case
     where case_id = i_case_id
       for update;

    update tst_case
       set ended_at      = l_ended_at
         , elapsed_ms    = tst_util.elapsed_ms(l_started_at, l_ended_at)
         , status        = 'SKIPPED'
         , sqlerrm_value = substr(i_reason, 1, 4000)
     where case_id = i_case_id;

    refresh_run_counts(l_run_id);

    commit;
exception
    when others
    then
        rollback;
        raise;
end skip_case;
--------------------------------------------------------------------------------
procedure end_run_success(i_run_id in number)
is
    pragma autonomous_transaction;
    l_started_at    timestamp(6);
    l_ended_at      timestamp(6) := systimestamp;
    l_failed_cases  number;
    l_running_cases number;
    l_status        varchar2(30);
begin
    select started_at
      into l_started_at
      from tst_run
     where run_id = i_run_id
       for update;

    refresh_run_counts(i_run_id);

    select failed_cases
      into l_failed_cases
      from tst_run
     where run_id = i_run_id;

    select count(*)
      into l_running_cases
      from tst_case
     where run_id = i_run_id
       and status = 'RUNNING';

    if ( l_failed_cases > 0 or l_running_cases > 0 )
    then
        l_status := 'FAILED';
    else
        l_status := 'SUCCESS';
    end if;

    update tst_run
       set ended_at   = l_ended_at
         , elapsed_ms = tst_util.elapsed_ms(l_started_at, l_ended_at)
         , status     = l_status
     where run_id = i_run_id;

    dbms_application_info.set_action(null);
    dbms_application_info.set_module(null, null);

    commit;
exception
    when others
    then
        rollback;
        raise;
end end_run_success;
--------------------------------------------------------------------------------
procedure end_run_error(i_run_id in number, i_sqlcode in number, i_sqlerrm in varchar2)
is
    pragma autonomous_transaction;
    l_started_at timestamp(6);
    l_ended_at   timestamp(6) := systimestamp;
begin
    select started_at
      into l_started_at
      from tst_run
     where run_id = i_run_id
       for update;

    refresh_run_counts(i_run_id);

    update tst_run
       set ended_at   = l_ended_at
         , elapsed_ms = tst_util.elapsed_ms(l_started_at, l_ended_at)
         , status     = 'ERROR'
         , note       = coalesce(note, to_clob(''))
                        || to_clob(chr(10) || 'RUN ERROR SQLCODE=' || i_sqlcode || ' SQLERRM=' || substr(i_sqlerrm, 1, 1000))
     where run_id = i_run_id;

    dbms_application_info.set_action(null);
    dbms_application_info.set_module(null, null);

    commit;
exception
    when others
    then
        rollback;
        raise;
end end_run_error;
--------------------------------------------------------------------------------

end tst_runner;
/

show errors package body tst_runner

prompt File: tst_runner.pkb.sql <end>
