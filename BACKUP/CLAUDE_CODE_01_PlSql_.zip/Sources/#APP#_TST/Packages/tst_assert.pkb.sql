prompt File: tst_assert.pkb.sql <start>
-- =============================================================================
-- File:     tst_assert.pkb.sql
-- Oggetto:  tst_assert (corpo del package)
-- Schema:   #APP#_TST
-- Scopo:    Implementazione delle asserzioni. Ogni esito è salvato in transazione
--           autonoma, così da persistere anche se il caso fa rollback.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260716  AA   Creazione (integrazione del test harness nel framework)
-- =============================================================================

prompt tst_assert: Creating package body

create or replace
package body tst_assert
is

--------------------------------------------------------------------------------
-- Salva un esito di asserzione in transazione autonoma.
procedure save_result( i_case_id  in number
                     , i_name     in varchar2
                     , i_expected in clob
                     , i_actual   in clob
                     , i_status   in varchar2
                     , i_message  in varchar2
                     )
is
    pragma autonomous_transaction;
begin
    insert into tst_assert_result ( case_id, assert_name, expected_value, actual_value, status, message )
    values ( i_case_id, upper(trim(i_name)), i_expected, i_actual, upper(trim(i_status)), i_message );

    commit;
exception
    when others
    then
        rollback;
        raise;
end save_result;
--------------------------------------------------------------------------------
-- Uguaglianza null-safe tra due stringhe.
function same_varchar2(i_expected in varchar2, i_actual in varchar2)
    return boolean
is
begin
    if ( i_expected is null and i_actual is null )
    then
        return (true);
    elsif ( i_expected is null or i_actual is null )
    then
        return (false);
    else
        return (i_expected = i_actual);
    end if;
end same_varchar2;
--------------------------------------------------------------------------------
procedure pass(i_case_id in number, i_name in varchar2, i_message in varchar2 default null)
is
begin
    save_result( i_case_id  => i_case_id
               , i_name     => i_name
               , i_expected => null
               , i_actual   => null
               , i_status   => 'PASS'
               , i_message  => i_message );
end pass;
--------------------------------------------------------------------------------
procedure fail( i_case_id  in number
              , i_name     in varchar2
              , i_message  in varchar2 default null
              , i_expected in clob default null
              , i_actual   in clob default null
              )
is
begin
    save_result( i_case_id  => i_case_id
               , i_name     => i_name
               , i_expected => i_expected
               , i_actual   => i_actual
               , i_status   => 'FAIL'
               , i_message  => i_message );
end fail;
--------------------------------------------------------------------------------
procedure assert_true( i_case_id   in number
                     , i_name      in varchar2
                     , i_condition in boolean
                     , i_message   in varchar2 default null
                     )
is
begin
    if ( i_condition is null )
    then
        save_result(i_case_id, i_name, to_clob('TRUE'), to_clob('NULL'), 'FAIL', nvl(i_message, 'La condizione è NULL.'));
    elsif ( i_condition )
    then
        save_result(i_case_id, i_name, to_clob('TRUE'), to_clob('TRUE'), 'PASS', i_message);
    else
        save_result(i_case_id, i_name, to_clob('TRUE'), to_clob('FALSE'), 'FAIL', nvl(i_message, 'La condizione è FALSE.'));
    end if;
end assert_true;
--------------------------------------------------------------------------------
procedure eq_varchar2( i_case_id  in number
                     , i_name     in varchar2
                     , i_expected in varchar2
                     , i_actual   in varchar2
                     , i_message  in varchar2 default null
                     )
is
begin
    if ( same_varchar2(i_expected, i_actual) )
    then
        save_result(i_case_id, i_name, tst_util.to_text(i_expected), tst_util.to_text(i_actual), 'PASS', i_message);
    else
        save_result(i_case_id, i_name, tst_util.to_text(i_expected), tst_util.to_text(i_actual), 'FAIL', nvl(i_message, 'Valori VARCHAR2 diversi.'));
    end if;
end eq_varchar2;
--------------------------------------------------------------------------------
procedure eq_number( i_case_id   in number
                   , i_name      in varchar2
                   , i_expected  in number
                   , i_actual    in number
                   , i_tolerance in number default 0
                   , i_message   in varchar2 default null
                   )
is
    l_ok boolean;
begin
    if ( i_expected is null and i_actual is null )
    then
        l_ok := true;
    elsif ( i_expected is null or i_actual is null )
    then
        l_ok := false;
    else
        l_ok := abs(i_expected - i_actual) <= nvl(i_tolerance, 0);
    end if;

    if ( l_ok )
    then
        save_result(i_case_id, i_name, tst_util.to_text(i_expected), tst_util.to_text(i_actual), 'PASS', i_message);
    else
        save_result(i_case_id, i_name, tst_util.to_text(i_expected), tst_util.to_text(i_actual), 'FAIL', nvl(i_message, 'Valori NUMBER diversi.'));
    end if;
end eq_number;
--------------------------------------------------------------------------------
procedure eq_date( i_case_id  in number
                 , i_name     in varchar2
                 , i_expected in date
                 , i_actual   in date
                 , i_message  in varchar2 default null
                 )
is
    l_ok boolean;
begin
    if ( i_expected is null and i_actual is null )
    then
        l_ok := true;
    elsif ( i_expected is null or i_actual is null )
    then
        l_ok := false;
    else
        l_ok := i_expected = i_actual;
    end if;

    if ( l_ok )
    then
        save_result(i_case_id, i_name, tst_util.to_text(i_expected), tst_util.to_text(i_actual), 'PASS', i_message);
    else
        save_result(i_case_id, i_name, tst_util.to_text(i_expected), tst_util.to_text(i_actual), 'FAIL', nvl(i_message, 'Valori DATE diversi.'));
    end if;
end eq_date;
--------------------------------------------------------------------------------
procedure eq_timestamp( i_case_id  in number
                      , i_name     in varchar2
                      , i_expected in timestamp
                      , i_actual   in timestamp
                      , i_message  in varchar2 default null
                      )
is
    l_ok boolean;
begin
    if ( i_expected is null and i_actual is null )
    then
        l_ok := true;
    elsif ( i_expected is null or i_actual is null )
    then
        l_ok := false;
    else
        l_ok := i_expected = i_actual;
    end if;

    if ( l_ok )
    then
        save_result(i_case_id, i_name, tst_util.to_text(i_expected), tst_util.to_text(i_actual), 'PASS', i_message);
    else
        save_result(i_case_id, i_name, tst_util.to_text(i_expected), tst_util.to_text(i_actual), 'FAIL', nvl(i_message, 'Valori TIMESTAMP diversi.'));
    end if;
end eq_timestamp;
--------------------------------------------------------------------------------
procedure is_null(i_case_id in number, i_name in varchar2, i_actual in varchar2, i_message in varchar2 default null)
is
begin
    if ( i_actual is null )
    then
        save_result(i_case_id, i_name, to_clob('NULL'), to_clob('NULL'), 'PASS', i_message);
    else
        save_result(i_case_id, i_name, to_clob('NULL'), tst_util.to_text(i_actual), 'FAIL', nvl(i_message, 'Il valore non è NULL.'));
    end if;
end is_null;
--------------------------------------------------------------------------------
procedure is_not_null(i_case_id in number, i_name in varchar2, i_actual in varchar2, i_message in varchar2 default null)
is
begin
    if ( i_actual is not null )
    then
        save_result(i_case_id, i_name, to_clob('NOT NULL'), tst_util.to_text(i_actual), 'PASS', i_message);
    else
        save_result(i_case_id, i_name, to_clob('NOT NULL'), to_clob('NULL'), 'FAIL', nvl(i_message, 'Il valore è NULL.'));
    end if;
end is_not_null;
--------------------------------------------------------------------------------

end tst_assert;
/

show errors package body tst_assert

prompt File: tst_assert.pkb.sql <end>
