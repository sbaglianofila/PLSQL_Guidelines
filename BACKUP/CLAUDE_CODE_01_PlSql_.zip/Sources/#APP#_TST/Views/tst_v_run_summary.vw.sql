prompt File: tst_v_run_summary.vw.sql <start>
-- =============================================================================
-- File:     tst_v_run_summary.vw.sql
-- Oggetto:  tst_v_run_summary (vista)
-- Schema:   #APP#_TST
-- Scopo:    Riepilogo per run: target, tempi, stato e conteggi degli esiti. È la
--           vista di primo livello per leggere com'è andata una esecuzione.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260716  AA   Creazione (integrazione del test harness nel framework)
-- =============================================================================

prompt tst_v_run_summary: Creating view

create or replace view tst_v_run_summary
as
select r.run_id
     , r.source_owner
     , r.source_package_name
     , r.source_program_name
     , r.generated_package_name
     , r.started_at
     , r.ended_at
     , r.elapsed_ms
     , r.status
     , r.total_cases
     , r.success_cases
     , r.failed_cases
     , r.warning_cases
     , r.profile_mode
     , r.coverage_mode
     , r.transaction_mode
     , r.created_by
  from tst_run r;

prompt File: tst_v_run_summary.vw.sql <end>
