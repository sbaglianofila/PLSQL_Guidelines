prompt File: lib_calendar_is_working_day_tc_v.vw.sql <start>
-- =============================================================================
-- File:     lib_calendar_is_working_day_tc_v.vw.sql
-- Oggetto:  lib_calendar_is_working_day_tc_v (vista dei casi di test)
-- Schema:   #APP#_TST
-- Scopo:    Casi di test per lib_calendar.is_working_day. La funzione ritorna un
--           BOOLEAN: nella vista l'atteso è espresso come flag 'Y'/'N', perché
--           SQL non conosce il tipo boolean; la conversione avviene nel wrapper.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260716  AA   Creazione (proof-of-concept gradino 0)
-- =============================================================================

prompt lib_calendar_is_working_day_tc_v: Creating view

create or replace view lib_calendar_is_working_day_tc_v
as
select 'ISWD_WEEKEND'              as case_code
     , 'Il sabato non è lavorativo' as case_description
     , date '2026-01-03'    as i_date          -- sabato
     , 'DEFAULT'            as i_calendar
     , 'N'                  as expected_flag    -- atteso booleano reso come flag
     , 'N'                  as expect_error
     , cast(null as number) as expect_sqlcode
  from dual
union all
select 'ISWD_PLAIN'
     , 'Un lunedì ordinario è lavorativo'
     , date '2026-01-05'    -- lunedì
     , 'DEFAULT'
     , 'Y'
     , 'N'
     , cast(null as number)
  from dual
union all
select 'ISWD_HOLIDAY'
     , 'Una festività a calendario non è lavorativa'
     , date '2026-01-06'    -- martedì, festivo nel fixture
     , 'DEFAULT'
     , 'N'
     , 'N'
     , cast(null as number)
  from dual
;

prompt File: lib_calendar_is_working_day_tc_v.vw.sql <end>
