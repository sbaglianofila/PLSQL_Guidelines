prompt File: lib_calendar_add_working_days_tc_v.vw.sql <start>
-- =============================================================================
-- File:     lib_calendar_add_working_days_tc_v.vw.sql
-- Oggetto:  lib_calendar_add_working_days_tc_v (vista dei casi di test)
-- Schema:   #APP#_TST
-- Scopo:    Casi di test per lib_calendar.add_working_days. La vista è il punto
--           di disaccoppiamento tra il dato dei casi (qui) e il wrapper che li
--           esegue: il wrapper cita solo le colonne, così un cambio di firma che
--           tocca le colonne rompe la compilazione invece di passare inosservato.
--           Le date sono letterali ANSI per essere indipendenti dalle NLS.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260716  AA   Creazione (proof-of-concept gradino 0)
-- =============================================================================

prompt lib_calendar_add_working_days_tc_v: Creating view

create or replace view lib_calendar_add_working_days_tc_v
as
select 'ADD_SKIP_HOL'                                                              as case_code
     , 'Aggiunta di 1 giorno lavorativo che scavalca una festività infrasettimanale' as case_description
     , date '2026-01-05'    as i_date            -- lunedì
     , 1                    as i_days
     , 'DEFAULT'            as i_calendar
     , date '2026-01-07'    as expected_result   -- mercoledì: martedì 06 è festivo nel fixture
     , 'N'                  as expect_error
     , cast(null as number) as expect_sqlcode
  from dual
union all
select 'ADD_WEEKEND'
     , 'Aggiunta di 1 giorno lavorativo di venerdì: salta il fine settimana'
     , date '2026-01-02'    -- venerdì
     , 1
     , 'DEFAULT'
     , date '2026-01-05'    -- lunedì
     , 'N'
     , cast(null as number)
  from dual
union all
select 'ADD_ZERO'
     , 'Offset zero: restituisce la data di partenza troncata, invariata'
     , date '2026-01-05'
     , 0
     , 'DEFAULT'
     , date '2026-01-05'
     , 'N'
     , cast(null as number)
  from dual
;

prompt File: lib_calendar_add_working_days_tc_v.vw.sql <end>
