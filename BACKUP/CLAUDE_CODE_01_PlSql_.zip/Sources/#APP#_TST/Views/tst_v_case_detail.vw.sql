prompt File: tst_v_case_detail.vw.sql <start>
-- =============================================================================
-- File:     tst_v_case_detail.vw.sql
-- Oggetto:  tst_v_case_detail (vista)
-- Schema:   #APP#_TST
-- Scopo:    Dettaglio per caso con il conteggio delle asserzioni e di quelle
--           fallite, oltre al correlation id per saltare ai log_events di #APP#.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260716  AA   Creazione (integrazione del test harness nel framework)
-- =============================================================================

prompt tst_v_case_detail: Creating view

create or replace view tst_v_case_detail
as
select c.case_id
     , c.run_id
     , r.source_owner
     , r.source_package_name
     , r.source_program_name
     , c.case_code
     , c.case_description
     , c.started_at
     , c.ended_at
     , c.elapsed_ms
     , c.status
     , c.expect_error
     , c.expect_sqlcode
     , c.sqlcode_value
     , c.sqlerrm_value
     , c.correlation_id
     , ( select count(*)
           from tst_assert_result a
          where a.case_id = c.case_id ) as assert_count
     , ( select count(*)
           from tst_assert_result a
          where a.case_id = c.case_id
            and a.status  = 'FAIL' ) as failed_assert_count
  from tst_case c
  join tst_run  r on r.run_id = c.run_id;

prompt File: tst_v_case_detail.vw.sql <end>
