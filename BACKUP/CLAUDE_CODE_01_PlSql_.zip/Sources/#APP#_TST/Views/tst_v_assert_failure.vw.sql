prompt File: tst_v_assert_failure.vw.sql <start>
-- =============================================================================
-- File:     tst_v_assert_failure.vw.sql
-- Oggetto:  tst_v_assert_failure (vista)
-- Schema:   #APP#_TST
-- Scopo:    Solo le asserzioni fallite, con atteso ed effettivo troncati a testo,
--           per andare dritti al motivo di un fallimento.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260716  AA   Creazione (integrazione del test harness nel framework)
-- =============================================================================

prompt tst_v_assert_failure: Creating view

create or replace view tst_v_assert_failure
as
select a.assert_id
     , a.case_id
     , c.run_id
     , r.source_owner
     , r.source_package_name
     , r.source_program_name
     , c.case_code
     , a.assert_name
     , dbms_lob.substr(a.expected_value, 4000, 1) as expected_value
     , dbms_lob.substr(a.actual_value,   4000, 1) as actual_value
     , a.message
     , a.created_at
  from tst_assert_result a
  join tst_case c on c.case_id = a.case_id
  join tst_run  r on r.run_id  = c.run_id
 where a.status = 'FAIL';

prompt File: tst_v_assert_failure.vw.sql <end>
