prompt File: tst_case_param.tab.sql <start>
-- =============================================================================
-- File:     tst_case_param.tab.sql
-- Oggetto:  tst_case_param (tabella)
-- Schema:   #APP#_TST
-- Scopo:    Valori dei parametri passati al target in un caso di test, uno per
--           riga, con lo slot tipizzato coerente al tipo del parametro. Registra
--           l'input effettivo di ogni chiamata per la lettura degli esiti.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260716  AA   Creazione (integrazione del test harness nel framework)
-- =============================================================================

prompt tst_case_param: Creating table

create table tst_case_param
   ( param_id        number              generated always as identity  constraint tst_case_param_nn_param_id  not null
   , case_id         number              constraint tst_case_param_nn_case_id     not null
   , param_name      varchar2(128 char)  constraint tst_case_param_nn_param_name   not null
   , param_mode      varchar2(20 char)   constraint tst_case_param_nn_param_mode   not null
   , param_type      varchar2(128 char)  constraint tst_case_param_nn_param_type   not null
   , value_varchar2  varchar2(4000 char)
   , value_number    number
   , value_date      date
   , value_timestamp timestamp(6)
   , value_clob      clob
   , created_at      timestamp(6)        constraint tst_case_param_nn_created_at   not null
   );

prompt tst_case_param: Adding defaults

alter table tst_case_param
   modify ( created_at default systimestamp );

prompt tst_case_param: Adding constraints

alter table tst_case_param
   add constraint tst_case_param_pk primary key ( param_id )
   using index;

alter table tst_case_param
   add constraint tst_case_param_ck_mode check ( param_mode in ( 'IN', 'OUT', 'IN OUT', 'RETURN' ) );

prompt tst_case_param: Adding comments

comment on table  tst_case_param                 is 'Valori dei parametri passati al target in un caso, uno per riga, con slot tipizzato.';
comment on column tst_case_param.param_id        is 'Chiave surrogata, identity generata.';
comment on column tst_case_param.case_id         is 'Caso di appartenenza.';
comment on column tst_case_param.param_name      is 'Nome del parametro.';
comment on column tst_case_param.param_mode      is 'Modo del parametro: IN, OUT, IN OUT o RETURN.';
comment on column tst_case_param.param_type      is 'Tipo dichiarato del parametro.';
comment on column tst_case_param.value_varchar2  is 'Valore quando il parametro è testuale.';
comment on column tst_case_param.value_number    is 'Valore quando il parametro è numerico.';
comment on column tst_case_param.value_date      is 'Valore quando il parametro è una data.';
comment on column tst_case_param.value_timestamp is 'Valore quando il parametro è un timestamp.';
comment on column tst_case_param.value_clob      is 'Valore quando il parametro è un CLOB.';
comment on column tst_case_param.created_at      is 'Istante di creazione della riga.';

prompt tst_case_param: Creating indexes

create index tst_case_param_idx_case on tst_case_param ( case_id, param_name );

prompt File: tst_case_param.tab.sql <end>
