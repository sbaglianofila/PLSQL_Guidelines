prompt File: tst_run.tab.sql <start>
-- =============================================================================
-- File:     tst_run.tab.sql
-- Oggetto:  tst_run (tabella)
-- Schema:   #APP#_TST
-- Scopo:    Testata di una esecuzione di test (una run): identifica il target
--           esercitato, la modalità transazionale e i conteggi aggregati degli
--           esiti dei casi. È la radice a cui si appendono i casi (tst_case).
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260716  AA   Creazione (integrazione del test harness nel framework)
-- =============================================================================

prompt tst_run: Creating table

create table tst_run
   ( run_id                 number               generated always as identity  constraint tst_run_nn_run_id           not null
   , source_owner           varchar2(128 char)   constraint tst_run_nn_source_owner      not null
   , source_package_name    varchar2(128 char)
   , source_program_name    varchar2(128 char)
   , generated_package_name varchar2(128 char)
   , started_at             timestamp(6)         constraint tst_run_nn_started_at        not null
   , ended_at               timestamp(6)
   , elapsed_ms             number(18,3)
   , status                 varchar2(30 char)    constraint tst_run_nn_status            not null
   , total_cases            number               constraint tst_run_nn_total_cases       not null
   , success_cases          number               constraint tst_run_nn_success_cases     not null
   , failed_cases           number               constraint tst_run_nn_failed_cases      not null
   , warning_cases          number               constraint tst_run_nn_warning_cases     not null
   , profile_mode           varchar2(30 char)    constraint tst_run_nn_profile_mode      not null
   , coverage_mode          varchar2(30 char)    constraint tst_run_nn_coverage_mode     not null
   , transaction_mode       varchar2(30 char)    constraint tst_run_nn_transaction_mode  not null
   , client_identifier      varchar2(256 char)
   , module_name            varchar2(128 char)
   , action_name            varchar2(128 char)
   , note                   clob
   , created_by             varchar2(128 char)   constraint tst_run_nn_created_by        not null
   , created_at             timestamp(6)         constraint tst_run_nn_created_at        not null
   );

prompt tst_run: Adding defaults

alter table tst_run
   modify ( started_at       default systimestamp
          , status           default 'RUNNING'
          , total_cases      default 0
          , success_cases    default 0
          , failed_cases     default 0
          , warning_cases    default 0
          , profile_mode     default 'NONE'
          , coverage_mode    default 'NONE'
          , transaction_mode default 'ROLLBACK'
          , created_by       default sys_context('USERENV','SESSION_USER')
          , created_at       default systimestamp
          );

prompt tst_run: Adding constraints

alter table tst_run
   add constraint tst_run_pk primary key ( run_id )
   using index;

alter table tst_run
   add constraint tst_run_ck_status check ( status in ( 'RUNNING', 'SUCCESS', 'FAILED', 'ERROR' ) );

alter table tst_run
   add constraint tst_run_ck_profile check ( profile_mode in ( 'NONE', 'PROFILER', 'HPROF' ) );

alter table tst_run
   add constraint tst_run_ck_coverage check ( coverage_mode in ( 'NONE', 'BASIC', 'FULL' ) );

alter table tst_run
   add constraint tst_run_ck_trn check ( transaction_mode in ( 'ROLLBACK', 'COMMIT', 'MANUAL' ) );

prompt tst_run: Adding comments

comment on table  tst_run                        is 'Testata di una esecuzione di test: target esercitato, modalità transazionale e conteggi aggregati degli esiti.';
comment on column tst_run.run_id                 is 'Chiave surrogata, identity generata.';
comment on column tst_run.source_owner           is 'Schema che possiede il codice sotto test (tipicamente #APP#).';
comment on column tst_run.source_package_name    is 'Package target sotto test.';
comment on column tst_run.source_program_name    is 'Sottoprogramma target sotto test.';
comment on column tst_run.generated_package_name is 'Nome del package wrapper di test che ha aperto la run.';
comment on column tst_run.started_at             is 'Istante di apertura della run.';
comment on column tst_run.ended_at               is 'Istante di chiusura della run.';
comment on column tst_run.elapsed_ms             is 'Durata della run in millisecondi.';
comment on column tst_run.status                 is 'Stato della run: RUNNING, SUCCESS, FAILED o ERROR.';
comment on column tst_run.total_cases            is 'Numero totale di casi eseguiti nella run.';
comment on column tst_run.success_cases          is 'Numero di casi in PASS.';
comment on column tst_run.failed_cases           is 'Numero di casi in FAIL o ERROR.';
comment on column tst_run.warning_cases          is 'Numero di casi in SKIPPED.';
comment on column tst_run.profile_mode           is 'Modalità di profiling: NONE, PROFILER o HPROF (usata dal tooling generatore).';
comment on column tst_run.coverage_mode          is 'Modalità di coverage: NONE, BASIC o FULL (usata dal tooling generatore).';
comment on column tst_run.transaction_mode       is 'Disciplina transazionale della run: ROLLBACK, COMMIT o MANUAL.';
comment on column tst_run.client_identifier      is 'CLIENT_IDENTIFIER della sessione al momento della run.';
comment on column tst_run.module_name            is 'Module di dbms_application_info impostato durante la run.';
comment on column tst_run.action_name            is 'Action di dbms_application_info impostata durante la run.';
comment on column tst_run.note                   is 'Nota libera sulla run.';
comment on column tst_run.created_by             is 'Utente di sessione che ha creato la riga.';
comment on column tst_run.created_at             is 'Istante di creazione della riga.';

prompt File: tst_run.tab.sql <end>
