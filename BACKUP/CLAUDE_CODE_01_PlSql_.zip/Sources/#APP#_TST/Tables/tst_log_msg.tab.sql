prompt File: tst_log_msg.tab.sql <start>
-- =============================================================================
-- File:     tst_log_msg.tab.sql
-- Oggetto:  tst_log_msg (tabella)
-- Schema:   #APP#_TST
-- Scopo:    Log tecnico interno del harness (messaggi di diagnostica di run e
--           casi), scritto in transazione autonoma così da sopravvivere al
--           rollback dei casi. È distinto dai log_events di #APP#: questo racconta
--           il harness, quello racconta il codice applicativo.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260716  AA   Creazione (integrazione del test harness nel framework)
-- =============================================================================

prompt tst_log_msg: Creating table

create table tst_log_msg
   ( log_id        number              generated always as identity  constraint tst_log_msg_nn_log_id  not null
   , run_id        number
   , case_id       number
   , log_ts        timestamp(6)        constraint tst_log_msg_nn_log_ts     not null
   , log_level     varchar2(20 char)   constraint tst_log_msg_nn_log_level   not null
   , message       clob
   , sqlcode_value number
   , sqlerrm_value varchar2(4000 char)
   , created_by    varchar2(128 char)  constraint tst_log_msg_nn_created_by  not null
   );

prompt tst_log_msg: Adding defaults

alter table tst_log_msg
   modify ( log_ts     default systimestamp
          , log_level  default 'INFO'
          , created_by default sys_context('USERENV','SESSION_USER')
          );

prompt tst_log_msg: Adding constraints

alter table tst_log_msg
   add constraint tst_log_msg_pk primary key ( log_id )
   using index;

alter table tst_log_msg
   add constraint tst_log_msg_ck_level check ( log_level in ( 'DEBUG', 'INFO', 'WARN', 'ERROR' ) );

prompt tst_log_msg: Adding comments

comment on table  tst_log_msg               is 'Log tecnico interno del harness (run/casi), in transazione autonoma. Distinto dai log_events di #APP#.';
comment on column tst_log_msg.log_id        is 'Chiave surrogata, identity generata.';
comment on column tst_log_msg.run_id        is 'Run di riferimento, se applicabile.';
comment on column tst_log_msg.case_id       is 'Caso di riferimento, se applicabile.';
comment on column tst_log_msg.log_ts        is 'Istante del messaggio.';
comment on column tst_log_msg.log_level     is 'Livello del messaggio: DEBUG, INFO, WARN o ERROR.';
comment on column tst_log_msg.message       is 'Testo del messaggio.';
comment on column tst_log_msg.sqlcode_value is 'sqlcode associato, se il messaggio nasce da un errore.';
comment on column tst_log_msg.sqlerrm_value is 'sqlerrm associato, se il messaggio nasce da un errore.';
comment on column tst_log_msg.created_by    is 'Utente di sessione che ha scritto la riga.';

prompt tst_log_msg: Creating indexes

create index tst_log_msg_idx_run_case on tst_log_msg ( run_id, case_id, log_ts );

prompt File: tst_log_msg.tab.sql <end>
