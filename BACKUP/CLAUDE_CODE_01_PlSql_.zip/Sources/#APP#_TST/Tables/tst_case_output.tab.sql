prompt File: tst_case_output.tab.sql <start>
-- =============================================================================
-- File:     tst_case_output.tab.sql
-- Oggetto:  tst_case_output (tabella)
-- Schema:   #APP#_TST
-- Scopo:    Valori di output osservati in un caso di test (parametri OUT, valore
--           di ritorno, stato del database letto dopo la chiamata), uno per riga
--           con lo slot tipizzato coerente al tipo.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260716  AA   Creazione (integrazione del test harness nel framework)
-- =============================================================================

prompt tst_case_output: Creating table

create table tst_case_output
   ( output_id       number              generated always as identity  constraint tst_case_output_nn_output_id  not null
   , case_id         number              constraint tst_case_output_nn_case_id     not null
   , output_name     varchar2(128 char)  constraint tst_case_output_nn_output_name  not null
   , output_type     varchar2(128 char)  constraint tst_case_output_nn_output_type  not null
   , value_varchar2  varchar2(4000 char)
   , value_number    number
   , value_date      date
   , value_timestamp timestamp(6)
   , value_clob      clob
   , created_at      timestamp(6)        constraint tst_case_output_nn_created_at   not null
   );

prompt tst_case_output: Adding defaults

alter table tst_case_output
   modify ( created_at default systimestamp );

prompt tst_case_output: Adding constraints

alter table tst_case_output
   add constraint tst_case_output_pk primary key ( output_id )
   using index;

prompt tst_case_output: Adding comments

comment on table  tst_case_output                 is 'Valori di output osservati in un caso (OUT, valore di ritorno, stato del DB), uno per riga con slot tipizzato.';
comment on column tst_case_output.output_id        is 'Chiave surrogata, identity generata.';
comment on column tst_case_output.case_id          is 'Caso di appartenenza.';
comment on column tst_case_output.output_name      is 'Nome dell''output (es. RETURN_VALUE o il nome di una colonna verificata).';
comment on column tst_case_output.output_type      is 'Tipo dichiarato dell''output.';
comment on column tst_case_output.value_varchar2   is 'Valore quando l''output è testuale.';
comment on column tst_case_output.value_number     is 'Valore quando l''output è numerico.';
comment on column tst_case_output.value_date       is 'Valore quando l''output è una data.';
comment on column tst_case_output.value_timestamp  is 'Valore quando l''output è un timestamp.';
comment on column tst_case_output.value_clob       is 'Valore quando l''output è un CLOB.';
comment on column tst_case_output.created_at       is 'Istante di creazione della riga.';

prompt tst_case_output: Creating indexes

create index tst_case_output_idx_case on tst_case_output ( case_id, output_name );

prompt File: tst_case_output.tab.sql <end>
