prompt File: tst_case.tab.sql <start>
-- =============================================================================
-- File:     tst_case.tab.sql
-- Oggetto:  tst_case (tabella)
-- Schema:   #APP#_TST
-- Scopo:    Un singolo caso di test dentro una run: descrizione, esito, gestione
--           dell'errore atteso e diagnostica in caso di errore. La colonna
--           correlation_id congiunge il caso ai log_events di #APP# della stessa
--           esecuzione (verifica a due livelli): la scrive il wrapper via
--           tst_runner.start_case dopo aver impostato il correlation id di sessione.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260716  AA   Creazione (integrazione del test harness nel framework)
-- =============================================================================

prompt tst_case: Creating table

create table tst_case
   ( case_id          number              generated always as identity  constraint tst_case_nn_case_id       not null
   , run_id           number              constraint tst_case_nn_run_id        not null
   , case_code        varchar2(100 char)
   , case_description varchar2(4000 char)
   , started_at       timestamp(6)        constraint tst_case_nn_started_at     not null
   , ended_at         timestamp(6)
   , elapsed_ms       number(18,3)
   , status           varchar2(30 char)   constraint tst_case_nn_status         not null
   , expect_error     varchar2(1 char)    constraint tst_case_nn_expect_error   not null
   , expect_sqlcode   number
   , sqlcode_value    number
   , sqlerrm_value    varchar2(4000 char)
   , error_stack      clob
   , error_backtrace  clob
   , correlation_id   varchar2(64 char)
   , created_by       varchar2(128 char)  constraint tst_case_nn_created_by     not null
   , created_at       timestamp(6)        constraint tst_case_nn_created_at     not null
   );

prompt tst_case: Adding defaults

alter table tst_case
   modify ( started_at   default systimestamp
          , status       default 'RUNNING'
          , expect_error default 'N'
          , created_by   default sys_context('USERENV','SESSION_USER')
          , created_at   default systimestamp
          );

prompt tst_case: Adding constraints

alter table tst_case
   add constraint tst_case_pk primary key ( case_id )
   using index;

alter table tst_case
   add constraint tst_case_ck_status check ( status in ( 'RUNNING', 'PASS', 'FAIL', 'ERROR', 'SKIPPED' ) );

alter table tst_case
   add constraint tst_case_ck_expect_error check ( expect_error in ( 'Y', 'N' ) );

prompt tst_case: Adding comments

comment on table  tst_case                  is 'Un caso di test dentro una run: esito, gestione dell''errore atteso e diagnostica. correlation_id congiunge il caso ai log_events di #APP#.';
comment on column tst_case.case_id          is 'Chiave surrogata, identity generata.';
comment on column tst_case.run_id           is 'Run di appartenenza.';
comment on column tst_case.case_code        is 'Codice mnemonico del caso, unico dentro la run per convenzione del wrapper.';
comment on column tst_case.case_description is 'Descrizione leggibile del caso.';
comment on column tst_case.started_at       is 'Istante di apertura del caso.';
comment on column tst_case.ended_at         is 'Istante di chiusura del caso.';
comment on column tst_case.elapsed_ms       is 'Durata del caso in millisecondi.';
comment on column tst_case.status           is 'Esito del caso: RUNNING, PASS, FAIL, ERROR o SKIPPED.';
comment on column tst_case.expect_error     is 'Y se il caso si attende un errore dal target, N altrimenti.';
comment on column tst_case.expect_sqlcode   is 'sqlcode atteso quando expect_error = Y; nullo per "qualsiasi errore".';
comment on column tst_case.sqlcode_value    is 'sqlcode effettivo catturato in caso di errore.';
comment on column tst_case.sqlerrm_value    is 'sqlerrm effettivo (o motivo dello skip) catturato.';
comment on column tst_case.error_stack      is 'Catena degli errori (dbms_utility.format_error_stack) in caso di errore.';
comment on column tst_case.error_backtrace  is 'Backtrace (dbms_utility.format_error_backtrace) in caso di errore.';
comment on column tst_case.correlation_id   is 'Correlation id della chiamata sotto test; congiunge questo caso ai log_events di #APP# della stessa esecuzione.';
comment on column tst_case.created_by       is 'Utente di sessione che ha creato la riga.';
comment on column tst_case.created_at       is 'Istante di creazione della riga.';

prompt tst_case: Creating indexes

create index tst_case_idx_run_status     on tst_case ( run_id, status );
create index tst_case_idx_case_code      on tst_case ( case_code );
create index tst_case_idx_correlation_id on tst_case ( correlation_id );

prompt File: tst_case.tab.sql <end>
