prompt File: tst_assert_result.tab.sql <start>
-- =============================================================================
-- File:     tst_assert_result.tab.sql
-- Oggetto:  tst_assert_result (tabella)
-- Schema:   #APP#_TST
-- Scopo:    Esito di una singola asserzione dentro un caso: valore atteso, valore
--           effettivo ed esito PASS/FAIL. È il livello a cui si legge perché un
--           caso è fallito.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260716  AA   Creazione (integrazione del test harness nel framework)
-- =============================================================================

prompt tst_assert_result: Creating table

create table tst_assert_result
   ( assert_id      number              generated always as identity  constraint tst_assert_result_nn_assert_id  not null
   , case_id        number              constraint tst_assert_result_nn_case_id      not null
   , assert_name    varchar2(200 char)  constraint tst_assert_result_nn_assert_name   not null
   , expected_value clob
   , actual_value   clob
   , status         varchar2(10 char)   constraint tst_assert_result_nn_status        not null
   , message        varchar2(4000 char)
   , created_at     timestamp(6)        constraint tst_assert_result_nn_created_at    not null
   );

prompt tst_assert_result: Adding defaults

alter table tst_assert_result
   modify ( created_at default systimestamp );

prompt tst_assert_result: Adding constraints

alter table tst_assert_result
   add constraint tst_assert_result_pk primary key ( assert_id )
   using index;

alter table tst_assert_result
   add constraint tst_assert_result_ck_status check ( status in ( 'PASS', 'FAIL' ) );

prompt tst_assert_result: Adding comments

comment on table  tst_assert_result                is 'Esito di una singola asserzione dentro un caso: atteso, effettivo, PASS/FAIL.';
comment on column tst_assert_result.assert_id      is 'Chiave surrogata, identity generata.';
comment on column tst_assert_result.case_id        is 'Caso di appartenenza.';
comment on column tst_assert_result.assert_name    is 'Nome dell''asserzione (es. RETURN_VALUE, EXPECTED_ERROR).';
comment on column tst_assert_result.expected_value is 'Valore atteso, reso a testo.';
comment on column tst_assert_result.actual_value   is 'Valore effettivo, reso a testo.';
comment on column tst_assert_result.status         is 'Esito dell''asserzione: PASS o FAIL.';
comment on column tst_assert_result.message        is 'Messaggio esplicativo, tipicamente valorizzato sui FAIL.';
comment on column tst_assert_result.created_at     is 'Istante di creazione della riga.';

prompt tst_assert_result: Creating indexes

create index tst_assert_result_idx_case on tst_assert_result ( case_id, status );

prompt File: tst_assert_result.tab.sql <end>
