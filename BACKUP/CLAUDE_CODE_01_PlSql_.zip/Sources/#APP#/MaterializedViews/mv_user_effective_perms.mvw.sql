prompt ------------------------------------------------------------

prompt File: mv_user_effective_perms.mvw.sql <start>

prompt

-- =============================================================================
-- File:     mv_user_effective_perms.mvw.sql
-- Oggetto:  mv_user_effective_perms (materialized view)
-- Schema:   #APP#
-- Scopo:    Strato veloce dei permessi effettivi: precalcola, per ogni coppia
--           (utente, funzionalita'), il modo di accesso gia' aggregato in OR sui
--           profili validi OGGI. Risponde alla domanda calda "questo utente puo'
--           fare questa cosa?" con un singolo accesso a indice, evitando di
--           ripercorrere ogni volta la catena a quattro tabelle.
--
--           PERIMETRO: materializza SOLO il contributo dai profili. Le eccezioni
--           nominali (adm_user_functionalities) restano FUORI, lette al volo da
--           lib_authz, cosi' has_access = MV(profilo, valida oggi) OR live(eccezione
--           valida ora). Tenute fuori perche' minuscole e per non legare la loro
--           finestra (che un domani potrebbe essere piu' fine del giorno) alla
--           cadenza di refresh della vista.
--
--           FORMA: risultato AGGREGATO (una riga per utente/funzionalita', modi in
--           OR), non il prodotto cartesiano utente x ruolo x profilo x maschera x
--           funzionalita'. L'OR sui flag 'Y'/'N' e' reso da max() ('Y' > 'N').
--
--           TEMPO: filtro a grana data su trunc(sysdate); estremi inclusi; null =
--           da sempre / senza scadenza. La vista fotografa lo stato "valido oggi".
--
--           REFRESH: complete on demand, ATOMICO (atomic_refresh => true, default;
--           mai una finestra vuota che negherebbe l'accesso a tutti). Politica:
--           (a) su evento, dopo ogni commit amministrativo alla mappa dei permessi;
--           (b) schedulato una volta al giorno a 00:00, per far scattare i confini
--           di data delle finestre temporali (che cambiano senza DML). I due insieme
--           danno zero finestra di incoerenza grazie alla grana giornaliera.
--           NB: la vista NON e' sorgente di verita' - e' una proiezione calcolata,
--           ricostruibile in ogni momento dalle tabelle adm_*.
--           Vedi Architettura_DB/utenti_profili.md.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260725  AA   Creazione
-- =============================================================================

prompt -- Creating materialized view

create materialized view mv_user_effective_perms
   build immediate
   refresh complete on demand
as
   select up.user_id                as user_id
        , pf.functionality_code     as functionality_code
        , max(pf.can_read)          as can_read
        , max(pf.can_write)         as can_write
        , max(pf.can_execute)       as can_execute
        , f.mask_code               as mask_code
        , m.module_code             as module_code
     from adm_user_profiles            up
     join adm_profile_functionalities  pf  on pf.profile_code = up.profile_code
     join adm_functionalities          f   on f.functionality_code = pf.functionality_code
     join adm_masks                    m   on m.mask_code = f.mask_code
    where ( up.valid_from is null or up.valid_from <= trunc(sysdate) )
      and ( up.valid_to   is null or up.valid_to   >= trunc(sysdate) )
      and ( pf.valid_from is null or pf.valid_from <= trunc(sysdate) )
      and ( pf.valid_to   is null or pf.valid_to   >= trunc(sysdate) )
    group by up.user_id
           , pf.functionality_code
           , f.mask_code
           , m.module_code;

prompt -- Adding unique index (lookup su chiave, materializza la "primary key" della vista)

-- Una riga per coppia (utente, funzionalita'): l'indice univoco impone l'unicita'
-- e serve la lettura calda di has_access con un singolo accesso a chiave.
create unique index mv_user_effective_perms_uk
   on mv_user_effective_perms ( user_id, functionality_code );

prompt -- Adding comments

comment on materialized view mv_user_effective_perms is 'Strato veloce: permessi effettivi da profilo, aggregati in OR e validi oggi, una riga per (utente, funzionalità). Solo contributo dai profili; le eccezioni nominali sono lette al volo. Proiezione calcolata, non sorgente di verità. Vedi utenti_profili.md.';

prompt File: mv_user_effective_perms.mvw.sql <end>

prompt
