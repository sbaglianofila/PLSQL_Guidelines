prompt ------------------------------------------------------------

prompt File: adm_functionalities.tab.sql <start>

prompt

-- =============================================================================
-- File:     adm_functionalities.tab.sql
-- Oggetto:  adm_functionalities (tabella)
-- Schema:   #APP#
-- Scopo:    Le capacita' operative dell'applicazione, ciascuna legata a una
--           maschera. E' la cosa che si granta ai profili (o in eccezione agli
--           utenti). Una maschera espone tipicamente piu' funzionalita': la
--           relazione con la maschera e' molti-a-uno via foreign key.
--           La foreign key verso adm_masks e' in FKs/adm_functionalities.fky.sql.
--           Vedi Architettura_DB/utenti_profili.md.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260725  AA   Creazione
-- =============================================================================

prompt -- Creating table

create table adm_functionalities
   ( functionality_code  varchar2(32 char)   constraint adm_functionalities_nn_func_code  not null
   , mask_code           varchar2(32 char)   constraint adm_functionalities_nn_mask_code  not null
   , name                varchar2(128 char)  constraint adm_functionalities_nn_name       not null
   , description         varchar2(512 char)
   -- Colonne amministrative: blocco fisso, popolato dal trigger
   -- (vedi Architettura_DB/colonne_amministrative.md).
   , row_version       number               default 1  constraint adm_functionalities_nn_row_version  not null
   , created_by        varchar2(64 char)    invisible  constraint adm_functionalities_nn_created_by   not null
   , created_at        timestamp(6)         invisible  constraint adm_functionalities_nn_created_at   not null
   , created_app       varchar2(64 char)    invisible  constraint adm_functionalities_nn_created_app  not null
   , modified_by       varchar2(64 char)    invisible
   , modified_at       timestamp(6)         invisible
   , modified_app      varchar2(64 char)    invisible
   );

prompt -- Adding constraints

alter table adm_functionalities
   add constraint adm_functionalities_pk primary key ( functionality_code )
   using index;

prompt -- Adding comments

comment on table  adm_functionalities                     is 'Le capacità operative dell''applicazione, ciascuna legata a una maschera; è l''unità che si granta ai profili o in eccezione agli utenti.';
comment on column adm_functionalities.functionality_code  is 'Codice della funzionalità, chiave primaria naturale.';
comment on column adm_functionalities.mask_code           is 'Maschera di appartenenza (foreign key verso adm_masks).';
comment on column adm_functionalities.name                is 'Nome leggibile della funzionalità.';
comment on column adm_functionalities.description         is 'Cosa consente di fare.';
-- Colonne amministrative (standard su ogni tabella; vedi colonne_amministrative.md)
comment on column adm_functionalities.row_version   is 'Versione della riga per il locking ottimistico, incrementata dal trigger a ogni modifica.';
comment on column adm_functionalities.created_by    is 'Utente applicativo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column adm_functionalities.created_at    is 'Istante dell''inserimento (invisibile, impostata dal trigger).';
comment on column adm_functionalities.created_app   is 'Programma/modulo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column adm_functionalities.modified_by   is 'Utente applicativo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column adm_functionalities.modified_at   is 'Istante dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column adm_functionalities.modified_app  is 'Programma/modulo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';

prompt File: adm_functionalities.tab.sql <end>

prompt
