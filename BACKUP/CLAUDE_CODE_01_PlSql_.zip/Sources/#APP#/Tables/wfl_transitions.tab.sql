prompt ------------------------------------------------------------

prompt File: wfl_transitions.tab.sql <start>

prompt

-- =============================================================================
-- File:     wfl_transitions.tab.sql
-- Oggetto:  wfl_transitions (tabella)
-- Schema:   #APP#
-- Scopo:    La macchina a stati vera e propria: gli archi ammessi tra uno stato e
--           l'altro, una riga per transizione permessa. Tabella UNICA per tutti i
--           workflow (non declinata per entità): la definizione è configurazione a
--           basso volume, senza foreign key verso il business, consumata da un
--           motore generico (lib_workflow) che resta statico. La transizione porta
--           un transition_code proprio perché in interfaccia l'utente sceglie
--           un'AZIONE ("Approva"), non uno stato di arrivo, e due azioni diverse
--           possono portare allo stesso stato. Le foreign key sono in
--           FKs/wfl_transitions.fky.sql; i ruoli autorizzati in wfl_transition_roles
--           (vedi Architettura_DB/stati_workflow.md).
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260723  AA   Creazione
-- =============================================================================

prompt -- Creating table

create table wfl_transitions
   ( workflow_code    varchar2(32 char)   constraint wfl_transitions_nn_workflow  not null
   , transition_code  varchar2(32 char)   constraint wfl_transitions_nn_trans     not null
   , from_status      varchar2(32 char)   constraint wfl_transitions_nn_from       not null
   , to_status        varchar2(32 char)   constraint wfl_transitions_nn_to         not null
   , label            varchar2(128 char)  constraint wfl_transitions_nn_label      not null
   , requires_reason  varchar2(1 char)    constraint wfl_transitions_nn_reason     not null
   , is_valid         varchar2(1 char)    constraint wfl_transitions_nn_valid      not null
   -- Colonne amministrative: blocco fisso, popolato dal trigger
   -- (vedi Architettura_DB/colonne_amministrative.md).
   , row_version       number               default 1  constraint wfl_transitions_nn_row_version  not null
   , created_by        varchar2(64 char)    invisible  constraint wfl_transitions_nn_created_by   not null
   , created_at        timestamp(6)         invisible  constraint wfl_transitions_nn_created_at   not null
   , created_app       varchar2(64 char)    invisible  constraint wfl_transitions_nn_created_app  not null
   , modified_by       varchar2(64 char)    invisible
   , modified_at       timestamp(6)         invisible
   , modified_app      varchar2(64 char)    invisible
   );

prompt -- Adding defaults

alter table wfl_transitions
   modify ( requires_reason  default 'N'
          , is_valid         default 'Y'
          );

prompt -- Adding constraints

-- Chiave su (workflow_code, transition_code): la transizione ha un'identità
-- propria, l'azione scelta dall'utente.
alter table wfl_transitions
   add constraint wfl_transitions_pk primary key ( workflow_code, transition_code )
   using index;

-- Un'azione è univoca a partire da uno stato: da uno stato non possono partire
-- due transizioni con lo stesso codice azione.
alter table wfl_transitions
   add constraint wfl_transitions_uk_from unique ( workflow_code, from_status, transition_code )
   using index;

alter table wfl_transitions
   add constraint wfl_transitions_ck_reason check ( requires_reason in ( 'Y', 'N' ) );

alter table wfl_transitions
   add constraint wfl_transitions_ck_valid check ( is_valid in ( 'Y', 'N' ) );

alter table wfl_transitions
   add constraint wfl_transitions_ck_loop check ( from_status <> to_status );

prompt -- Adding comments

comment on table  wfl_transitions               is 'Gli archi ammessi della macchina a stati: una riga per transizione permessa, tabella unica per tutti i workflow. Letta e validata da lib_workflow.';
comment on column wfl_transitions.workflow_code   is 'Workflow di appartenenza (foreign key verso wfl_workflows).';
comment on column wfl_transitions.transition_code is 'Codice dell''azione che compie la transizione (es. APPROVE); identità della transizione, agganciata all''etichetta del bottone.';
comment on column wfl_transitions.from_status     is 'Stato di partenza (foreign key composita verso wfl_statuses).';
comment on column wfl_transitions.to_status       is 'Stato di arrivo (foreign key composita verso wfl_statuses).';
comment on column wfl_transitions.label           is 'Etichetta dell''azione mostrata a video.';
comment on column wfl_transitions.requires_reason is 'Y se la causale è obbligatoria quando si compie questa transizione.';
comment on column wfl_transitions.is_valid        is 'Y se la transizione è attiva; N se disattivata (senza ricompilare nulla).';
-- Colonne amministrative (standard su ogni tabella; vedi colonne_amministrative.md)
comment on column wfl_transitions.row_version     is 'Versione della riga per il locking ottimistico, incrementata dal trigger a ogni modifica.';
comment on column wfl_transitions.created_by      is 'Utente applicativo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column wfl_transitions.created_at      is 'Istante dell''inserimento (invisibile, impostata dal trigger).';
comment on column wfl_transitions.created_app     is 'Programma/modulo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column wfl_transitions.modified_by     is 'Utente applicativo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column wfl_transitions.modified_at     is 'Istante dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column wfl_transitions.modified_app    is 'Programma/modulo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';

prompt File: wfl_transitions.tab.sql <end>

prompt
