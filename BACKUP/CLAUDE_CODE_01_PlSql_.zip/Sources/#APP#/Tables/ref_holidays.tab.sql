prompt File: ref_holidays.tab.sql <start>
-- =============================================================================
-- File:     ref_holidays.tab.sql
-- Oggetto:  ref_holidays (tabella)
-- Schema:   #APP#
-- Scopo:    Calendario delle festività consumato da lib_calendar. Oracle non sa
--           nulla di giorni lavorativi e festività; questa lookup colma la lacuna.
--           La colonna calendar_code supporta più calendari (es. per sede); il
--           calendario di default è 'DEFAULT'. Popolata per progetto: nessun seed
--           è distribuito perché le festività (e le feste mobili) sono specifiche
--           di progetto e di anno.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260705  AA   Creazione
-- =============================================================================

prompt ref_holidays: Creating table

create table ref_holidays
   ( calendar_code  varchar2(32 char)   constraint ref_holidays_nn_calendar  not null
   , holiday_date   date                constraint ref_holidays_nn_date       not null
   , description    varchar2(512 char)
   );

prompt ref_holidays: Adding defaults

alter table ref_holidays
   modify ( calendar_code  default 'DEFAULT'
          );

prompt ref_holidays: Adding constraints

alter table ref_holidays
   add constraint ref_holidays_pk primary key ( calendar_code, holiday_date )
   using index;

prompt ref_holidays: Adding comments

comment on table  ref_holidays               is 'Calendario delle festività consumato da lib_calendar; supporta più calendari tramite calendar_code.';
comment on column ref_holidays.calendar_code is 'Calendario a cui appartiene la festività; DEFAULT per il caso a calendario unico.';
comment on column ref_holidays.holiday_date  is 'Data della festività (componente orario ignorata).';
comment on column ref_holidays.description   is 'Nome leggibile della festività.';

prompt File: ref_holidays.tab.sql <end>
