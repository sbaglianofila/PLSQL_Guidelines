prompt ------------------------------------------------------------

prompt File: cfg_parameter_groups.tab.sql <start>

prompt

-- =============================================================================
-- File:     cfg_parameter_groups.tab.sql
-- Oggetto:  cfg_parameter_groups (tabella)
-- Schema:   #APP#
-- Scopo:    Lista governata dei raggruppamenti logici dei parametri applicativi,
--           referenziata da cfg_parameters.param_group. Esiste per tre ragioni:
--           impedire che i gruppi proliferino per refuso (LOGGING / Logging /
--           LOGGIN), dare a ciascun gruppo un'etichetta leggibile e una
--           descrizione, e fissarne l'ordine di presentazione tramite sort_order.
--           Quest'ultimo punto è il motivo per cui la tabella esiste invece di
--           lasciare param_group a testo libero: la documentazione generata dei
--           parametri esce in sezioni ordinate come si vuole, non in ordine
--           alfabetico del codice.
-- Nota:     Tabella dedicata del pillar cfg_ e non un set di ref_lookups, per
--           due motivi: un gruppo di parametri è metadato di configurazione, non
--           un valore di dominio mostrato all'utente (distinzione posta in
--           lookups.md), e tenerla qui evita che la configurazione - che è
--           fondamenta e viene creata e seminata per prima - dipenda dal
--           meccanismo delle lookup. Stessa scelta già fatta per i cataloghi
--           cfg_error_messages e cfg_messages.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260720  AA   Creazione
-- =============================================================================

prompt -- Creating table

create table cfg_parameter_groups
   ( group_code     varchar2(32 char)    constraint cfg_parameter_groups_nn_code  not null
   , name           varchar2(128 char)   constraint cfg_parameter_groups_nn_name  not null
   , description    varchar2(512 char)
   , sort_order     number               constraint cfg_parameter_groups_nn_sort  not null
   -- Colonne amministrative: blocco fisso, popolato dal trigger
   -- (vedi Architettura_DB/colonne_amministrative.md).
   , row_version       number               default 1  constraint cfg_parameter_groups_nn_row_version  not null
   , created_by        varchar2(64 char)    invisible  constraint cfg_parameter_groups_nn_created_by   not null
   , created_at        timestamp(6)         invisible  constraint cfg_parameter_groups_nn_created_at   not null
   , created_app       varchar2(64 char)    invisible  constraint cfg_parameter_groups_nn_created_app  not null
   , modified_by       varchar2(64 char)    invisible
   , modified_at       timestamp(6)         invisible
   , modified_app      varchar2(64 char)    invisible
   );

prompt -- Adding defaults

alter table cfg_parameter_groups
   modify ( sort_order  default 0
          );

prompt -- Adding constraints

alter table cfg_parameter_groups
   add constraint cfg_parameter_groups_pk primary key ( group_code )
   using index;

prompt -- Adding comments

comment on table  cfg_parameter_groups             is 'Lista governata dei raggruppamenti dei parametri applicativi, referenziata da cfg_parameters.param_group; porta etichetta, descrizione e ordine di presentazione per la documentazione generata.';
comment on column cfg_parameter_groups.group_code  is 'Codice del gruppo (chiave naturale), il valore memorizzato in cfg_parameters.param_group (es. LOGGING).';
comment on column cfg_parameter_groups.name        is 'Etichetta leggibile del gruppo, usata come titolo di sezione nella documentazione.';
comment on column cfg_parameter_groups.description is 'Cosa copre il gruppo: quali aspetti del comportamento applicativo governano i suoi parametri.';
comment on column cfg_parameter_groups.sort_order  is 'Ordine di presentazione del gruppo nella documentazione e nelle interrogazioni; a parità di valore si ordina per group_code.';
-- Colonne amministrative (standard su ogni tabella; vedi colonne_amministrative.md)
comment on column cfg_parameter_groups.row_version  is 'Versione della riga per il locking ottimistico, incrementata dal trigger a ogni modifica.';
comment on column cfg_parameter_groups.created_by   is 'Utente applicativo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column cfg_parameter_groups.created_at   is 'Istante dell''inserimento (invisibile, impostata dal trigger).';
comment on column cfg_parameter_groups.created_app  is 'Programma/modulo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column cfg_parameter_groups.modified_by  is 'Utente applicativo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column cfg_parameter_groups.modified_at  is 'Istante dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column cfg_parameter_groups.modified_app is 'Programma/modulo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';

prompt File: cfg_parameter_groups.tab.sql <end>

prompt
