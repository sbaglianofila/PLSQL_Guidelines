prompt ------------------------------------------------------------

prompt File: wfl_transition_roles.tab.sql <start>

prompt

-- =============================================================================
-- File:     wfl_transition_roles.tab.sql
-- Oggetto:  wfl_transition_roles (tabella)
-- Schema:   #APP#
-- Scopo:    I ruoli aziendali autorizzati a compiere una transizione. Tabella
--           ponte perché la stessa azione ("Approva") può spettare a più ruoli
--           (Responsabile o Direttore): un attributo singolo sulla transizione
--           costringerebbe a duplicare la riga per moltiplicare i ruoli. L'assenza
--           di righe per una transizione significa "nessuna guardia di ruolo":
--           la transizione è ammessa a chiunque (la sola macchina a stati decide).
--           role_code è il codice del ruolo aziendale applicativo (adm_roles del
--           pillar RBAC), non un ruolo di database (vedi utenti_profili.md). La
--           foreign key verso adm_roles è predisposta ma differita finché quel
--           pillar non è realizzato (vedi FKs/wfl_transition_roles.fky.sql e
--           Architettura_DB/stati_workflow.md).
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260723  AA   Creazione
-- =============================================================================

prompt -- Creating table

create table wfl_transition_roles
   ( workflow_code    varchar2(32 char)   constraint wfl_transition_roles_nn_workflow  not null
   , transition_code  varchar2(32 char)   constraint wfl_transition_roles_nn_trans     not null
   , role_code        varchar2(32 char)   constraint wfl_transition_roles_nn_role      not null
   -- Colonne amministrative: blocco fisso, popolato dal trigger
   -- (vedi Architettura_DB/colonne_amministrative.md).
   , row_version       number               default 1  constraint wfl_transition_roles_nn_row_version  not null
   , created_by        varchar2(64 char)    invisible  constraint wfl_transition_roles_nn_created_by   not null
   , created_at        timestamp(6)         invisible  constraint wfl_transition_roles_nn_created_at   not null
   , created_app       varchar2(64 char)    invisible  constraint wfl_transition_roles_nn_created_app  not null
   , modified_by       varchar2(64 char)    invisible
   , modified_at       timestamp(6)         invisible
   , modified_app      varchar2(64 char)    invisible
   );

prompt -- Adding constraints

alter table wfl_transition_roles
   add constraint wfl_transition_roles_pk primary key ( workflow_code, transition_code, role_code )
   using index;

prompt -- Adding comments

comment on table  wfl_transition_roles                 is 'Ruoli aziendali autorizzati a compiere una transizione (tabella ponte molti-a-molti). Nessuna riga per una transizione significa nessuna guardia di ruolo. Letta da lib_workflow.';
comment on column wfl_transition_roles.workflow_code   is 'Workflow di appartenenza (parte della foreign key verso wfl_transitions).';
comment on column wfl_transition_roles.transition_code is 'Transizione autorizzata (parte della foreign key verso wfl_transitions).';
comment on column wfl_transition_roles.role_code       is 'Codice del ruolo aziendale applicativo autorizzato (adm_roles del pillar RBAC), non un ruolo di database.';
-- Colonne amministrative (standard su ogni tabella; vedi colonne_amministrative.md)
comment on column wfl_transition_roles.row_version     is 'Versione della riga per il locking ottimistico, incrementata dal trigger a ogni modifica.';
comment on column wfl_transition_roles.created_by      is 'Utente applicativo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column wfl_transition_roles.created_at      is 'Istante dell''inserimento (invisibile, impostata dal trigger).';
comment on column wfl_transition_roles.created_app     is 'Programma/modulo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column wfl_transition_roles.modified_by     is 'Utente applicativo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column wfl_transition_roles.modified_at     is 'Istante dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column wfl_transition_roles.modified_app    is 'Programma/modulo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';

prompt File: wfl_transition_roles.tab.sql <end>

prompt
