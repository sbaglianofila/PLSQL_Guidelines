prompt ------------------------------------------------------------

prompt File: cfg_parameters.tab.sql <start>

prompt

-- =============================================================================
-- File:     cfg_parameters.tab.sql
-- Oggetto:  cfg_parameters (tabella)
-- Schema:   #APP#
-- Scopo:    Unico contenitore dei parametri applicativi, letti attraverso
--           lib_config. Ogni riga dichiara un valore tipizzato; lib_config esegue
--           la conversione controllata (formati espliciti) e mette in cache i
--           valori. L'unica via di scrittura supportata è lib_config.set_value.
--           param_group raggruppa logicamente i parametri della stessa area,
--           rendendo esplicito ciò che finora era solo una convenzione di naming
--           (i prefissi LOG_, MAIL_): serve a interrogare la tabella per area e a
--           produrre una documentazione in sezioni anziché un elenco piatto. I
--           gruppi ammessi sono una lista governata in cfg_parameter_groups, a cui
--           la colonna è legata dalla foreign key cfg_parameters_fk_group (in
--           FKs/cfg_parameters.fky.sql): è ciò che impedisce che proliferino per
--           refuso ed è la fonte di etichette, descrizioni e ordinamento.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260705  AA   Creazione
--   20260720  AA   Aggiunta param_group (raggruppamento logico dei parametri),
--                  con foreign key verso la lista governata cfg_parameter_groups;
--                  per le istanze già create vedi cfg_parameters.20260720_01.alt.sql
-- =============================================================================

prompt -- Creating table

create table cfg_parameters
   ( param_name     varchar2(128 char)   constraint cfg_parameters_nn_param_name   not null
   , param_group    varchar2(32 char)    constraint cfg_parameters_nn_param_group  not null
   , param_value    varchar2(4000 char)  constraint cfg_parameters_nn_param_value  not null
   , param_type     varchar2(32 char)    constraint cfg_parameters_nn_param_type   not null
   , description    varchar2(512 char)   constraint cfg_parameters_nn_description  not null
   , is_modifiable  varchar2(1 char)     constraint cfg_parameters_nn_modifiable   not null
   -- Colonne amministrative: blocco fisso, popolato dal trigger
   -- (vedi Architettura_DB/colonne_amministrative.md).
   , row_version       number               default 1  constraint cfg_parameters_nn_row_version  not null
   , created_by        varchar2(64 char)    invisible  constraint cfg_parameters_nn_created_by   not null
   , created_at        timestamp(6)         invisible  constraint cfg_parameters_nn_created_at   not null
   , created_app       varchar2(64 char)    invisible  constraint cfg_parameters_nn_created_app  not null
   , modified_by       varchar2(64 char)    invisible
   , modified_at       timestamp(6)         invisible
   , modified_app      varchar2(64 char)    invisible
   );

prompt -- Adding defaults

alter table cfg_parameters
   modify ( param_group    default 'GENERAL'
          , param_type     default 'STRING'
          , is_modifiable  default 'Y'
          );

prompt -- Adding constraints

alter table cfg_parameters
   add constraint cfg_parameters_pk primary key ( param_name )
   using index;

alter table cfg_parameters
   add constraint cfg_parameters_ck_param_type check ( param_type in ( 'STRING', 'NUMBER', 'DATE', 'FLAG' ) );

alter table cfg_parameters
   add constraint cfg_parameters_ck_modifiable check ( is_modifiable in ( 'Y', 'N' ) );

prompt -- Adding comments

comment on table  cfg_parameters               is 'Parametri applicativi letti attraverso lib_config; valori tipizzati con conversione controllata e cache.';
comment on column cfg_parameters.param_name    is 'Nome del parametro (chiave naturale).';
comment on column cfg_parameters.param_group   is 'Raggruppamento logico del parametro (GENERAL, LOGGING, MAIL, ...), referenziato a cfg_parameter_groups da cui prende etichetta, descrizione e ordinamento: tiene insieme i parametri che afferiscono alla stessa area e ordina la documentazione generata.';
comment on column cfg_parameters.param_value   is 'Valore del parametro memorizzato come testo; convertito da lib_config in base a param_type.';
comment on column cfg_parameters.param_type    is 'Tipo dichiarato che guida la conversione: STRING, NUMBER, DATE o FLAG.';
comment on column cfg_parameters.description   is 'Descrizione leggibile del parametro e del suo effetto.';
comment on column cfg_parameters.is_modifiable is 'Y se il valore può essere cambiato tramite lib_config.set_value, N se è di solo provisioning.';
-- Colonne amministrative (standard su ogni tabella; vedi colonne_amministrative.md)
comment on column cfg_parameters.row_version   is 'Versione della riga per il locking ottimistico, incrementata dal trigger a ogni modifica.';
comment on column cfg_parameters.created_by    is 'Utente applicativo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column cfg_parameters.created_at    is 'Istante dell''inserimento (invisibile, impostata dal trigger).';
comment on column cfg_parameters.created_app   is 'Programma/modulo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column cfg_parameters.modified_by   is 'Utente applicativo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column cfg_parameters.modified_at   is 'Istante dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column cfg_parameters.modified_app  is 'Programma/modulo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';


prompt File: cfg_parameters.tab.sql <end>

prompt

