prompt ------------------------------------------------------------

prompt File: adm_user_profiles.tab.sql <start>

prompt

-- =============================================================================
-- File:     adm_user_profiles.tab.sql
-- Oggetto:  adm_user_profiles (tabella di associazione)
-- Schema:   #APP#
-- Scopo:    L'assegnazione dei profili a un utente: il punto in cui un utente
--           diventa "qualcuno che puo' fare qualcosa". Chiave (user_id,
--           profile_code). Porta una FINESTRA DI VALIDITA' a grana data
--           (valid_from/valid_to) perche' l'assegnazione e' spesso a termine
--           (sostituzioni, reggenze). Confronto su trunc(sysdate); estremi
--           inclusi; null = da sempre / senza scadenza.
--           Le foreign key sono in FKs/adm_user_profiles.fky.sql.
--           Vedi Architettura_DB/utenti_profili.md.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260725  AA   Creazione
-- =============================================================================

prompt -- Creating table

create table adm_user_profiles
   ( user_id       number(12)          constraint adm_user_profiles_nn_user     not null
   , profile_code  varchar2(32 char)   constraint adm_user_profiles_nn_profile  not null
   , valid_from    date
   , valid_to      date
   -- Colonne amministrative: blocco fisso, popolato dal trigger
   -- (vedi Architettura_DB/colonne_amministrative.md).
   , row_version       number               default 1  constraint adm_user_profiles_nn_row_version  not null
   , created_by        varchar2(64 char)    invisible  constraint adm_user_profiles_nn_created_by   not null
   , created_at        timestamp(6)         invisible  constraint adm_user_profiles_nn_created_at   not null
   , created_app       varchar2(64 char)    invisible  constraint adm_user_profiles_nn_created_app  not null
   , modified_by       varchar2(64 char)    invisible
   , modified_at       timestamp(6)         invisible
   , modified_app      varchar2(64 char)    invisible
   );

prompt -- Adding constraints

alter table adm_user_profiles
   add constraint adm_user_profiles_pk primary key ( user_id, profile_code )
   using index;

alter table adm_user_profiles
   add constraint adm_user_profiles_ck_validity
   check ( valid_from is null or valid_to is null or valid_to >= valid_from );

prompt -- Adding comments

comment on table  adm_user_profiles               is 'Assegnazione dei profili a un utente, con finestra di validità a grana data (assegnazioni a termine).';
comment on column adm_user_profiles.user_id       is 'Utente a cui si assegna il profilo (foreign key verso adm_users).';
comment on column adm_user_profiles.profile_code  is 'Profilo assegnato (foreign key verso adm_profiles).';
comment on column adm_user_profiles.valid_from    is 'Inizio validità dell''assegnazione (incluso, grana data); null = da sempre.';
comment on column adm_user_profiles.valid_to      is 'Fine validità dell''assegnazione (inclusa, grana data); null = senza scadenza.';
-- Colonne amministrative (standard su ogni tabella; vedi colonne_amministrative.md)
comment on column adm_user_profiles.row_version   is 'Versione della riga per il locking ottimistico, incrementata dal trigger a ogni modifica.';
comment on column adm_user_profiles.created_by    is 'Utente applicativo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column adm_user_profiles.created_at    is 'Istante dell''inserimento (invisibile, impostata dal trigger).';
comment on column adm_user_profiles.created_app   is 'Programma/modulo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column adm_user_profiles.modified_by   is 'Utente applicativo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column adm_user_profiles.modified_at   is 'Istante dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column adm_user_profiles.modified_app  is 'Programma/modulo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';

prompt File: adm_user_profiles.tab.sql <end>

prompt
