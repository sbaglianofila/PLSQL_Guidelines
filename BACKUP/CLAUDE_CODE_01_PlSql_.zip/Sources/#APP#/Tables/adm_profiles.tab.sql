prompt ------------------------------------------------------------

prompt File: adm_profiles.tab.sql <start>

prompt

-- =============================================================================
-- File:     adm_profiles.tab.sql
-- Oggetto:  adm_profiles (tabella)
-- Schema:   #APP#
-- Scopo:    I profili: pacchetti di ruoli che rappresentano una figura lavorativa
--           assegnabile agli utenti (es. ADMIN_CLERK). Esistono per non dover
--           riassegnare gli stessi ruoli a ogni utente simile. Chiave primaria
--           naturale sul codice. Vedi Architettura_DB/utenti_profili.md.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260725  AA   Creazione
-- =============================================================================

prompt -- Creating table

create table adm_profiles
   ( profile_code  varchar2(32 char)   constraint adm_profiles_nn_profile_code  not null
   , name          varchar2(128 char)  constraint adm_profiles_nn_name          not null
   , description   varchar2(512 char)
   , is_system     varchar2(1 char)    constraint adm_profiles_nn_is_system     not null
   -- Colonne amministrative: blocco fisso, popolato dal trigger
   -- (vedi Architettura_DB/colonne_amministrative.md).
   , row_version       number               default 1  constraint adm_profiles_nn_row_version  not null
   , created_by        varchar2(64 char)    invisible  constraint adm_profiles_nn_created_by   not null
   , created_at        timestamp(6)         invisible  constraint adm_profiles_nn_created_at   not null
   , created_app       varchar2(64 char)    invisible  constraint adm_profiles_nn_created_app  not null
   , modified_by       varchar2(64 char)    invisible
   , modified_at       timestamp(6)         invisible
   , modified_app      varchar2(64 char)    invisible
   );

prompt -- Adding defaults

alter table adm_profiles
   modify ( is_system  default 'N' );

prompt -- Adding constraints

alter table adm_profiles
   add constraint adm_profiles_pk primary key ( profile_code )
   using index;

alter table adm_profiles
   add constraint adm_profiles_ck_is_system check ( is_system in ( 'Y', 'N' ) );

prompt -- Adding comments

comment on table  adm_profiles               is 'I profili: pacchetti di ruoli che rappresentano una figura lavorativa assegnabile agli utenti.';
comment on column adm_profiles.profile_code  is 'Codice del profilo, chiave primaria naturale (es. ADMIN_CLERK).';
comment on column adm_profiles.name          is 'Nome leggibile della figura.';
comment on column adm_profiles.description    is 'Descrizione della figura lavorativa.';
comment on column adm_profiles.is_system     is 'Y se profilo predefinito del framework, non modificabile dagli amministratori.';
-- Colonne amministrative (standard su ogni tabella; vedi colonne_amministrative.md)
comment on column adm_profiles.row_version   is 'Versione della riga per il locking ottimistico, incrementata dal trigger a ogni modifica.';
comment on column adm_profiles.created_by    is 'Utente applicativo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column adm_profiles.created_at    is 'Istante dell''inserimento (invisibile, impostata dal trigger).';
comment on column adm_profiles.created_app   is 'Programma/modulo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column adm_profiles.modified_by   is 'Utente applicativo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column adm_profiles.modified_at   is 'Istante dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column adm_profiles.modified_app  is 'Programma/modulo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';

prompt File: adm_profiles.tab.sql <end>

prompt
