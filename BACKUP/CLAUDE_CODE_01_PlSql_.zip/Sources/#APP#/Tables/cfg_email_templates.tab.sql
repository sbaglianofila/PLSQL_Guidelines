prompt File: cfg_email_templates.tab.sql <start>
-- =============================================================================
-- File:     cfg_email_templates.tab.sql
-- Oggetto:  cfg_email_templates (tabella)
-- Schema:   #APP#
-- Scopo:    Template di oggetto e corpo usati da lib_mail.send_template, con
--           segnaposto %1..%5 risolti tramite lib_text.format. Permette di
--           cambiare i testi delle email per configurazione anziché per codice.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260705  AA   Creazione
-- =============================================================================

prompt cfg_email_templates: Creating table

create table cfg_email_templates
   ( template_code  varchar2(64 char)
   , subject        varchar2(998 char)  constraint cfg_email_templates_nn_subject  not null
   , body           clob                constraint cfg_email_templates_nn_body     not null
   , is_html        varchar2(1 char)    constraint cfg_email_templates_nn_html     not null
   , description    varchar2(512 char)
   );

prompt cfg_email_templates: Adding defaults

alter table cfg_email_templates
   modify ( is_html  default 'N'
          );

prompt cfg_email_templates: Adding constraints

alter table cfg_email_templates
   add constraint cfg_email_templates_pk primary key ( template_code )
   using index;

alter table cfg_email_templates
   add constraint cfg_email_templates_ck_html check ( is_html in ( 'Y', 'N' ) );

prompt cfg_email_templates: Adding comments

comment on table  cfg_email_templates               is 'Template di oggetto/corpo delle email risolti da lib_mail.send_template tramite lib_text.format.';
comment on column cfg_email_templates.template_code is 'Codice del template (chiave naturale) referenziato da send_template.';
comment on column cfg_email_templates.subject       is 'Template dell''oggetto con segnaposto %1..%5.';
comment on column cfg_email_templates.body          is 'Template del corpo con segnaposto %1..%5.';
comment on column cfg_email_templates.is_html       is 'Y quando il corpo è HTML, N per testo semplice.';
comment on column cfg_email_templates.description   is 'Descrizione del template e del suo uso previsto.';

prompt File: cfg_email_templates.tab.sql <end>
