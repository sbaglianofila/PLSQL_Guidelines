prompt ------------------------------------------------------------

prompt File: ref_lookups.tab.sql <start>

prompt

-- =============================================================================
-- File:     ref_lookups.tab.sql
-- Oggetto:  ref_lookups (tabella)
-- Schema:   #APP#
-- Scopo:    Testata delle liste di valori di riferimento (lookup) generiche: una
--           riga per set di codici, letta attraverso lib_lookup. La chiave è
--           naturale (lookup_code), così la costante che comparirà nelle foreign
--           key composite delle tabelle di business è leggibile e non un numero
--           opaco. Il dettaglio dei valori sta in ref_lookup_values. Le liste
--           con attributi/relazioni proprie o molto referenziate promuovono a
--           tabella ref_ dedicata (vedi Architettura_DB/lookups.md).
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260719  AA   Creazione
-- =============================================================================

prompt -- Creating table

create table ref_lookups
   ( lookup_code          varchar2(32 char)    constraint ref_lookups_nn_lookup        not null
   , name                 varchar2(128 char)   constraint ref_lookups_nn_name          not null
   , description          varchar2(512 char)
   , is_system            varchar2(1 char)     constraint ref_lookups_nn_is_system     not null
   , allow_custom_values  varchar2(1 char)     constraint ref_lookups_nn_allow_custom  not null
   -- Colonne amministrative: blocco fisso, popolato dal trigger
   -- (vedi Architettura_DB/colonne_amministrative.md).
   , row_version       number               default 1  constraint ref_lookups_nn_row_version  not null
   , created_by        varchar2(64 char)    invisible  constraint ref_lookups_nn_created_by   not null
   , created_at        timestamp(6)         invisible  constraint ref_lookups_nn_created_at   not null
   , created_app       varchar2(64 char)    invisible  constraint ref_lookups_nn_created_app  not null
   , modified_by       varchar2(64 char)    invisible
   , modified_at       timestamp(6)         invisible
   , modified_app      varchar2(64 char)    invisible
   );

prompt -- Adding defaults

alter table ref_lookups
   modify ( is_system            default 'N'
          , allow_custom_values  default 'Y'
          );

prompt -- Adding constraints

alter table ref_lookups
   add constraint ref_lookups_pk primary key ( lookup_code )
   using index;

alter table ref_lookups
   add constraint ref_lookups_ck_is_system check ( is_system in ( 'Y', 'N' ) );

alter table ref_lookups
   add constraint ref_lookups_ck_allow_custom check ( allow_custom_values in ( 'Y', 'N' ) );

prompt -- Adding comments

comment on table  ref_lookups                     is 'Testata delle lookup generiche: una riga per set di codici (lookup_code), letta tramite lib_lookup. Il dettaglio dei valori è in ref_lookup_values.';
comment on column ref_lookups.lookup_code         is 'Mnemonico del set (chiave naturale), usato nel codice e nelle foreign key composite (es. CONTACT_TYPE).';
comment on column ref_lookups.name                is 'Etichetta leggibile del set.';
comment on column ref_lookups.description         is 'A cosa serve la lista.';
comment on column ref_lookups.is_system           is 'Y se il set è di proprietà del framework/applicazione e non modificabile dagli amministratori funzionali (la logica lo dà per scontato); N altrimenti.';
comment on column ref_lookups.allow_custom_values is 'Y se gli amministratori funzionali possono aggiungere valori al set; N per bloccarne l''estensione.';
-- Colonne amministrative (standard su ogni tabella; vedi colonne_amministrative.md)
comment on column ref_lookups.row_version         is 'Versione della riga per il locking ottimistico, incrementata dal trigger a ogni modifica.';
comment on column ref_lookups.created_by          is 'Utente applicativo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column ref_lookups.created_at          is 'Istante dell''inserimento (invisibile, impostata dal trigger).';
comment on column ref_lookups.created_app         is 'Programma/modulo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column ref_lookups.modified_by         is 'Utente applicativo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column ref_lookups.modified_at         is 'Istante dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column ref_lookups.modified_app        is 'Programma/modulo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';

prompt File: ref_lookups.tab.sql <end>

prompt
