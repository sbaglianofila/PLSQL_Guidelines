prompt ------------------------------------------------------------

prompt File: cfg_messages.tab.sql <start>

prompt

-- =============================================================================
-- File:     cfg_messages.tab.sql
-- Oggetto:  cfg_messages (tabella)
-- Schema:   #APP#
-- Scopo:    Catalogo dei template dei messaggi di log generici (non di errore),
--           basato su un codice di messaggio di dominio, con segnaposto %1..%10
--           sostituiti da lib_logging al momento del log. È la controparte di
--           cfg_error_messages (basata sul codice numerico e consumata da
--           lib_err): questa serve gli overload a catalogo INFO/WARN/DEBUG di
--           lib_logging, così un progetto può rivedere e correggere il testo
--           informativo a runtime senza ricompilare. Un codice sconosciuto degrada
--           a '[<code>]', così una riga mancante non nasconde mai l'evento.
--           Questa tabella non porta alcun seed di framework: i codici sono di
--           progetto. Ogni dominio inserisce le proprie righe e tiene i codici
--           come costanti in un package *_msg_codes per-dominio (es. ord_msg_codes).
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260708  AA   Creazione
--   20260712  AA   Colonne amministrative allineate allo standard: nomi _app,
--                  rimosso il default on null (fail-loud), row_version visibile,
--                  constraint rinominati cfg_messages_nn_*
-- =============================================================================

prompt -- Creating table

create table cfg_messages
   ( message_code      varchar2(100 char)
   , message_template  varchar2(4000 char)  constraint cfg_messages_nn_message_template  not null
   -- Colonne amministrative: blocco fisso, popolato dal trigger
   -- (vedi Architettura_DB/colonne_amministrative.md).
   , row_version       number               default 1  constraint cfg_messages_nn_row_version  not null
   , created_by        varchar2(64 char)    invisible  constraint cfg_messages_nn_created_by   not null
   , created_at        timestamp(6)         invisible  constraint cfg_messages_nn_created_at   not null
   , created_app       varchar2(64 char)    invisible  constraint cfg_messages_nn_created_app  not null
   , modified_by       varchar2(64 char)    invisible
   , modified_at       timestamp(6)         invisible
   , modified_app      varchar2(64 char)    invisible
   );

prompt -- Adding constraints

alter table cfg_messages
   add constraint cfg_messages_pk primary key ( message_code )
   using index;

prompt -- Adding comments

comment on table  cfg_messages                  is 'Catalogo dei template dei messaggi di log generici (non di errore) basato su un codice di messaggio di dominio; letto dagli overload a catalogo di lib_logging. I codici sono tenuti come costanti in package *_msg_codes per-dominio.';
comment on column cfg_messages.message_code     is 'Codice del messaggio di dominio (chiave naturale), es. ORD_IMPORT_COMPLETED; rispecchia una costante in un package *_msg_codes.';
comment on column cfg_messages.message_template is 'Template del messaggio con segnaposto %1..%10 sostituiti da lib_logging al momento del log.';
-- Colonne amministrative (standard su ogni tabella; vedi colonne_amministrative.md)
comment on column cfg_messages.row_version      is 'Versione della riga per il locking ottimistico, incrementata dal trigger a ogni modifica.';
comment on column cfg_messages.created_by       is 'Utente applicativo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column cfg_messages.created_at       is 'Istante dell''inserimento (invisibile, impostata dal trigger).';
comment on column cfg_messages.created_app      is 'Programma/modulo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column cfg_messages.modified_by      is 'Utente applicativo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column cfg_messages.modified_at      is 'Istante dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column cfg_messages.modified_app     is 'Programma/modulo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';

-- Promemoria: il trigger di audit è in cfg_messages_audit_trg.trg.sql.

prompt File: cfg_messages.tab.sql <end>

prompt
