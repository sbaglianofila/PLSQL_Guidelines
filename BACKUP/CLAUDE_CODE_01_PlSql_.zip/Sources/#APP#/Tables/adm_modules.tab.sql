prompt ------------------------------------------------------------

prompt File: adm_modules.tab.sql <start>

prompt

-- =============================================================================
-- File:     adm_modules.tab.sql
-- Oggetto:  adm_modules (tabella)
-- Schema:   #APP#
-- Scopo:    I moduli applicativi: il livello in cima alla gerarchia del menu
--           (modulo -> maschera -> funzionalita'). Tabella dedicata, e non un
--           attributo testuale su adm_masks, per la stessa ragione per cui le
--           maschere non sono un'etichetta sulle funzionalita': il modulo porta
--           attributi propri (nome leggibile, descrizione, ordinamento a menu) e
--           una lista governata evita i moduli-fantasma da refuso. Chiave primaria
--           naturale sul codice. Referenziato da adm_masks.module_code.
--           Vedi Architettura_DB/utenti_profili.md.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260725  AA   Creazione
-- =============================================================================

prompt -- Creating table

create table adm_modules
   ( module_code  varchar2(32 char)   constraint adm_modules_nn_module_code  not null
   , name         varchar2(128 char)  constraint adm_modules_nn_name         not null
   , description  varchar2(512 char)
   , sort_order   number              constraint adm_modules_nn_sort_order   not null
   , is_active    varchar2(1 char)    constraint adm_modules_nn_is_active    not null
   -- Colonne amministrative: blocco fisso, popolato dal trigger
   -- (vedi Architettura_DB/colonne_amministrative.md).
   , row_version       number               default 1  constraint adm_modules_nn_row_version  not null
   , created_by        varchar2(64 char)    invisible  constraint adm_modules_nn_created_by   not null
   , created_at        timestamp(6)         invisible  constraint adm_modules_nn_created_at   not null
   , created_app       varchar2(64 char)    invisible  constraint adm_modules_nn_created_app  not null
   , modified_by       varchar2(64 char)    invisible
   , modified_at       timestamp(6)         invisible
   , modified_app      varchar2(64 char)    invisible
   );

prompt -- Adding defaults

alter table adm_modules
   modify ( sort_order  default 0
          , is_active   default 'Y'
          );

prompt -- Adding constraints

alter table adm_modules
   add constraint adm_modules_pk primary key ( module_code )
   using index;

alter table adm_modules
   add constraint adm_modules_ck_is_active check ( is_active in ( 'Y', 'N' ) );

prompt -- Adding comments

comment on table  adm_modules              is 'I moduli applicativi: livello in cima alla gerarchia del menu (modulo -> maschera -> funzionalità).';
comment on column adm_modules.module_code  is 'Codice del modulo, chiave primaria naturale (es. ACCOUNTING).';
comment on column adm_modules.name         is 'Nome leggibile del modulo.';
comment on column adm_modules.description  is 'A cosa corrisponde il modulo.';
comment on column adm_modules.sort_order   is 'Ordinamento dei moduli nel menu.';
comment on column adm_modules.is_active    is 'Y se il modulo è attivo; N se dismesso.';
-- Colonne amministrative (standard su ogni tabella; vedi colonne_amministrative.md)
comment on column adm_modules.row_version   is 'Versione della riga per il locking ottimistico, incrementata dal trigger a ogni modifica.';
comment on column adm_modules.created_by    is 'Utente applicativo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column adm_modules.created_at    is 'Istante dell''inserimento (invisibile, impostata dal trigger).';
comment on column adm_modules.created_app   is 'Programma/modulo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column adm_modules.modified_by   is 'Utente applicativo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column adm_modules.modified_at   is 'Istante dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column adm_modules.modified_app  is 'Programma/modulo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';

prompt File: adm_modules.tab.sql <end>

prompt
