prompt ------------------------------------------------------------

prompt File: log_events.tab.sql <start>

prompt

-- =============================================================================
-- File:     log_events.tab.sql
-- Oggetto:  log_events (tabella)
-- Schema:   #APP#
-- Scopo:    Unico stream di log applicativo scritto da lib_logging in una
--           transazione autonoma, così da sopravvivere a un rollback del
--           chiamante. Contiene ogni evento loggato a qualsiasi livello - DEBUG /
--           INFO / WARN ed ERROR - in un solo posto, identificato da un id generato.
--           I dettagli diagnostici specifici degli errori (backtrace, call stack)
--           sono tenuti a parte in log_error_details, una riga per errore, in join
--           su event_id. Letto dalle query di controllo dell'AM.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260708  AA   Creazione (unifica le precedenti log_entries e log_errors)
--   20260708  AA   Aggiunta message_type (START/END/LOG/ERROR) ed execution_id
-- =============================================================================

prompt -- Creating table

create table log_events
   ( event_id        number(24)          generated always as identity  constraint log_events_nn_event_id      not null
   , logged_at       timestamp(6)        constraint log_events_nn_logged_at      not null
   , log_level       varchar2(5 char)    constraint log_events_nn_log_level      not null
   , message_type    varchar2(10 char)   constraint log_events_nn_message_type   not null
   , process_name    varchar2(128 char)
   , scope           varchar2(128 char)
   , message         varchar2(4000 char)
   , error_code      number
   , correlation_id  varchar2(64 char)
   , execution_id    varchar2(64 char)
   , actor           varchar2(128 char)
   );

prompt -- Adding defaults

alter table log_events
   modify ( logged_at     default systimestamp
          , message_type  default 'LOG'
          );

prompt -- Adding constraints

alter table log_events
   add constraint log_events_pk primary key ( event_id )
   using index;

alter table log_events
   add constraint log_events_ck_log_level check ( log_level in ( 'DEBUG', 'INFO', 'WARN', 'ERROR' ) );

alter table log_events
   add constraint log_events_ck_message_type check ( message_type in ( 'START', 'END', 'LOG', 'ERROR' ) );

prompt -- Adding comments

comment on table  log_events                is 'Unico stream di log applicativo (DEBUG/INFO/WARN/ERROR) scritto da lib_logging in una transazione autonoma. I dettagli diagnostici degli errori vivono in log_error_details.';
comment on column log_events.event_id       is 'Chiave surrogata, identity generata.';
comment on column log_events.logged_at      is 'Istante di registrazione dell''evento (tempo della transazione autonoma).';
comment on column log_events.log_level      is 'Gravità dell''evento: DEBUG, INFO, WARN o ERROR (quanto è importante).';
comment on column log_events.message_type   is 'Natura dell''evento, ortogonale alla gravità: START / END (ciclo di vita di una procedura), LOG (voce semplice) o ERROR.';
comment on column log_events.process_name   is 'Processo proprietario (module di dbms_application_info), impostato da lib_batch; usato dalle query di controllo per filtrare una run.';
comment on column log_events.scope          is 'Ambito logico passato dal chiamante, tipicamente package.subprogram: l''unità di codice che ha loggato l''evento.';
comment on column log_events.message        is 'Testo del messaggio; per gli errori porta già il contesto del chiamante e l''sqlerrm.';
comment on column log_events.error_code     is 'sqlcode Oracle catturato per gli eventi ERROR (negativo per gli errori applicativi); nullo altrimenti.';
comment on column log_events.correlation_id is 'Identificatore opzionale fornito dal chiamante che lega insieme tutti gli eventi di una esecuzione/flusso (il trace id; pool-safe: passato esplicitamente, non derivato dallo stato di sessione).';
comment on column log_events.execution_id   is 'Identificatore opzionale per singola invocazione (lo span id): identifica una specifica esecuzione di un sottoprogramma, così START ed END si appaiano anche quando lo stesso scope gira più volte in un flusso.';
comment on column log_events.actor          is 'Attore effettivo (proxy-aware) risolto da lib_session.current_actor.';

prompt -- Creating indexes

create index log_events_idx_logged_at      on log_events ( logged_at );
create index log_events_idx_process_name   on log_events ( process_name );
create index log_events_idx_correlation_id on log_events ( correlation_id );
create index log_events_idx_execution_id   on log_events ( execution_id );
create index log_events_idx_level          on log_events ( log_level, logged_at );

prompt File: log_events.tab.sql <end>

prompt
