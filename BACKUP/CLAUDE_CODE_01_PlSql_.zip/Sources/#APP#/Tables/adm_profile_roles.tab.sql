prompt ------------------------------------------------------------

prompt File: adm_profile_roles.tab.sql <start>

prompt

-- =============================================================================
-- File:     adm_profile_roles.tab.sql
-- Oggetto:  adm_profile_roles (tabella di associazione)
-- Schema:   #APP#
-- Scopo:    La composizione di un profilo in ruoli: materializza "insiemi di
--           ruoli fanno un profilo". Chiave (profile_code, role_code). E'
--           deliberatamente ATEMPORALE: la composizione di un profilo e' una
--           scelta di disegno strutturale, non si apre o chiude nel tempo, e i
--           ruoli non gate direttamente le funzionalita'.
--           Le foreign key sono in FKs/adm_profile_roles.fky.sql.
--           Vedi Architettura_DB/utenti_profili.md.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260725  AA   Creazione
-- =============================================================================

prompt -- Creating table

create table adm_profile_roles
   ( profile_code  varchar2(32 char)   constraint adm_profile_roles_nn_profile  not null
   , role_code     varchar2(32 char)   constraint adm_profile_roles_nn_role     not null
   -- Colonne amministrative: blocco fisso, popolato dal trigger
   -- (vedi Architettura_DB/colonne_amministrative.md).
   , row_version       number               default 1  constraint adm_profile_roles_nn_row_version  not null
   , created_by        varchar2(64 char)    invisible  constraint adm_profile_roles_nn_created_by   not null
   , created_at        timestamp(6)         invisible  constraint adm_profile_roles_nn_created_at   not null
   , created_app       varchar2(64 char)    invisible  constraint adm_profile_roles_nn_created_app  not null
   , modified_by       varchar2(64 char)    invisible
   , modified_at       timestamp(6)         invisible
   , modified_app      varchar2(64 char)    invisible
   );

prompt -- Adding constraints

alter table adm_profile_roles
   add constraint adm_profile_roles_pk primary key ( profile_code, role_code )
   using index;

prompt -- Adding comments

comment on table  adm_profile_roles               is 'Composizione di un profilo in ruoli aziendali (atemporale, strutturale).';
comment on column adm_profile_roles.profile_code  is 'Profilo composto (foreign key verso adm_profiles).';
comment on column adm_profile_roles.role_code     is 'Ruolo che compone il profilo (foreign key verso adm_roles).';
-- Colonne amministrative (standard su ogni tabella; vedi colonne_amministrative.md)
comment on column adm_profile_roles.row_version   is 'Versione della riga per il locking ottimistico, incrementata dal trigger a ogni modifica.';
comment on column adm_profile_roles.created_by    is 'Utente applicativo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column adm_profile_roles.created_at    is 'Istante dell''inserimento (invisibile, impostata dal trigger).';
comment on column adm_profile_roles.created_app   is 'Programma/modulo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column adm_profile_roles.modified_by   is 'Utente applicativo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column adm_profile_roles.modified_at   is 'Istante dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column adm_profile_roles.modified_app  is 'Programma/modulo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';

prompt File: adm_profile_roles.tab.sql <end>

prompt
