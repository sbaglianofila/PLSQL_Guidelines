prompt ------------------------------------------------------------

prompt File: cfg_parameters.20260720_01.alt.sql <start>

prompt

-- =============================================================================
-- File:     cfg_parameters.20260720_01.alt.sql
-- Oggetto:  cfg_parameters (alter: aggiunta di param_group)
-- Schema:   #APP#
-- Scopo:    Allinea un'istanza in cui cfg_parameters è GIÀ stata creata con la
--           versione precedente della baseline, aggiungendo la colonna
--           param_group e valorizzandola sulle righe esistenti.
-- Nota:     Script di ALLINEAMENTO, non parte dell'install. La baseline
--           cfg_parameters.tab.sql contiene già param_group, quindi un'istanza
--           creata da zero NON deve eseguire questo file: è riservato ai database
--           su cui la tabella era stata creata prima del 20260720. Per questo non
--           è cablato in Install/install.ins.sql e va lanciato a mano una volta
--           sola.
--
--           SEQUENZA COMPLETA DI ALLINEAMENTO. Questo file è il quarto di cinque
--           passi: gli altri quattro sono i file canonici dei sorgenti, che si
--           riusano invece di duplicarne il DDL qui (così non c'è nulla da tenere
--           allineato a mano). Eseguire nell'ordine, connessi come #APP#:
--
--             1. @../Tables/cfg_parameter_groups.tab.sql
--             2. @../Triggers/cfg_parameter_groups_audit_trg.trg.sql
--             3. @../Data/cfg_parameter_groups.dat.sql
--             4. @questo file            (aggiunge la colonna e la valorizza)
--             5. @../FKs/cfg_parameters.fky.sql
--
--           L'ordine non è arbitrario: la foreign key del passo 5 va creata per
--           ultima perché pretende sia la colonna (passo 4) sia i gruppi già a
--           catalogo (passo 3), e perché tutte le righe devono già portare un
--           gruppo valido, cosa che garantisce il backfill qui sotto.
--
--           Sulle istanze già create la colonna risulterà in coda alla tabella
--           anziché dopo param_name: differenza solo fisica, ininfluente perché
--           nessun codice accede alle colonne per posizione (lib_config e il seed
--           citano sempre le colonne per nome).
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260720  AA   Creazione
--   20260720  AA   Aggiunta la sequenza con cfg_parameter_groups e la foreign
--                  key, dopo il passaggio da gruppo a testo libero a lista
--                  governata
-- =============================================================================

whenever sqlerror exit failure rollback

prompt -- Adding column

-- Il default popola contestualmente tutte le righe già presenti, quindi il
-- NOT NULL può essere dichiarato subito senza passaggi intermedi.
alter table cfg_parameters
   add ( param_group  varchar2(32 char)  default 'GENERAL'
         constraint cfg_parameters_nn_param_group  not null );

prompt -- Backfilling groups on existing rows

-- Le righe di seed preesistenti sono tutte atterrate su GENERAL per effetto del
-- default: si riportano ai gruppi reali. I parametri di progetto aggiunti a mano
-- restano su GENERAL e vanno riclassificati caso per caso PRIMA del passo 5:
-- con la foreign key attiva, un gruppo non a catalogo verrebbe rifiutato.
update cfg_parameters cfp
   set cfp.param_group = 'LOGGING'
 where cfp.param_name like 'LOG\_%' escape '\';

update cfg_parameters cfp
   set cfp.param_group = 'MAIL'
 where cfp.param_name like 'MAIL\_%' escape '\';

prompt -- Adding comment

comment on column cfg_parameters.param_group is 'Raggruppamento logico del parametro, referenziato a cfg_parameter_groups: tiene insieme i parametri che afferiscono alla stessa area e ordina la documentazione generata.';

prompt -- Committing

commit;

prompt -- Reminder

prompt Ora esegui il passo 5: @../FKs/cfg_parameters.fky.sql
prompt Se qualche parametro di progetto e' rimasto su un gruppo non a catalogo,
prompt riclassificalo o aggiungi il gruppo prima di creare la foreign key.

prompt File: cfg_parameters.20260720_01.alt.sql <end>

prompt
