prompt ------------------------------------------------------------

prompt File: cfg_gate_rule_types.tab.sql <start>

prompt

-- =============================================================================
-- File:     cfg_gate_rule_types.tab.sql
-- Oggetto:  cfg_gate_rule_types (tabella)
-- Schema:   #APP#
-- Scopo:    Il dominio CHIUSO dei tipi di regola che lib_gate sa valutare. Ha due
--           funzioni insieme: è la foreign key che impedisce di configurare una
--           regola inesistente, ed è la documentazione dei parametri attesi da
--           ciascun tipo (a cosa serve param_1, a cosa param_2), che altrimenti
--           vivrebbe solo nella testa di chi ha scritto il dispatch.
-- Nota:     Questa tabella NON si popola a progetto: le sue righe corrispondono
--           una a una ai rami del case di lib_gate.evaluate e arrivano dal seed
--           Data/cfg_gate_rule_types.dat.sql. Aggiungere una riga qui senza
--           scrivere il ramo corrispondente nel body produce una regola fantasma
--           che non blocca nulla: per questo evaluate solleva invece di ignorare
--           un rule_code che non sa smistare. Vedi Pacchetti_Base/precondizioni_esecuzione.md.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260729  AA   Creazione
-- =============================================================================

prompt -- Creating table

create table cfg_gate_rule_types
   ( rule_code      varchar2(32 char)    constraint cfg_gate_rule_types_nn_rule_code  not null
   , description    varchar2(512 char)   constraint cfg_gate_rule_types_nn_descr      not null
   , param_1_usage  varchar2(512 char)
   , param_2_usage  varchar2(512 char)
   -- Colonne amministrative: blocco fisso, popolato dal trigger
   -- (vedi Architettura_DB/colonne_amministrative.md).
   , row_version    number               default 1  constraint cfg_gate_rule_types_nn_row_version  not null
   , created_by     varchar2(64 char)    invisible  constraint cfg_gate_rule_types_nn_created_by   not null
   , created_at     timestamp(6)         invisible  constraint cfg_gate_rule_types_nn_created_at   not null
   , created_app    varchar2(64 char)    invisible  constraint cfg_gate_rule_types_nn_created_app  not null
   , modified_by    varchar2(64 char)    invisible
   , modified_at    timestamp(6)         invisible
   , modified_app   varchar2(64 char)    invisible
   );

prompt -- Adding constraints

alter table cfg_gate_rule_types
   add constraint cfg_gate_rule_types_pk primary key ( rule_code )
   using index;

prompt -- Adding comments

comment on table  cfg_gate_rule_types               is 'Dominio chiuso dei tipi di regola valutabili da lib_gate: una riga per ogni ramo del dispatch, con la documentazione dei parametri attesi. Popolata dal seed, non a progetto.';
comment on column cfg_gate_rule_types.rule_code     is 'Codice del tipo di regola (es. TIME_WINDOW); coincide con un ramo del case di lib_gate.evaluate.';
comment on column cfg_gate_rule_types.description   is 'Che cosa verifica la regola, espresso in positivo: la condizione che deve valere perché il processo possa partire.';
comment on column cfg_gate_rule_types.param_1_usage is 'Significato atteso di cfg_gate_rules.param_1 per questo tipo; nullo se il tipo non usa il primo parametro.';
comment on column cfg_gate_rule_types.param_2_usage is 'Significato atteso di cfg_gate_rules.param_2 per questo tipo; nullo se il tipo non usa il secondo parametro.';
-- Colonne amministrative (standard su ogni tabella; vedi colonne_amministrative.md)
comment on column cfg_gate_rule_types.row_version   is 'Versione della riga per il locking ottimistico, incrementata dal trigger a ogni modifica.';
comment on column cfg_gate_rule_types.created_by    is 'Utente applicativo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column cfg_gate_rule_types.created_at    is 'Istante dell''inserimento (invisibile, impostata dal trigger).';
comment on column cfg_gate_rule_types.created_app   is 'Programma/modulo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column cfg_gate_rule_types.modified_by   is 'Utente applicativo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column cfg_gate_rule_types.modified_at   is 'Istante dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column cfg_gate_rule_types.modified_app  is 'Programma/modulo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';

prompt File: cfg_gate_rule_types.tab.sql <end>

prompt
