prompt ------------------------------------------------------------

prompt File: cfg_gate_rules.tab.sql <start>

prompt

-- =============================================================================
-- File:     cfg_gate_rules.tab.sql
-- Oggetto:  cfg_gate_rules (tabella)
-- Schema:   #APP#
-- Scopo:    L'associazione processo -> regole: quali precondizioni valgono per un
--           certo processo, con quali parametri e con quale gravità. È il lato
--           "dato" del gate; il lato "codice" è il dispatch di lib_gate. Il
--           livello di dinamicità è deliberato e va tenuto così: QUALI regole
--           valgono per QUALE processo è configurazione, COME si valuta una regola
--           è codice compilato.
-- Nota:     La severity sta QUI e non su cfg_gate_rule_types, ed è la ragione per
--           cui la tabella esiste: la stessa identica regola - la finestra oraria,
--           per dire - deve poter essere bloccante per un processo e solo
--           informativa per un altro, senza toccare una riga di codice. SKIP è
--           l'uscita pulita di una condizione fisiologica ("fuori finestra",
--           "niente da elaborare"), ABORT è l'anomalia che deve farsi vedere
--           ("ambiente sbagliato", "predecessore fallito"). Vedi
--           Pacchetti_Base/precondizioni_esecuzione.md.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260729  AA   Creazione
-- =============================================================================

prompt -- Creating table

create table cfg_gate_rules
   ( process_name  varchar2(128 char)   constraint cfg_gate_rules_nn_process    not null
   , rule_seq      number(3)            constraint cfg_gate_rules_nn_rule_seq   not null
   , rule_code     varchar2(32 char)    constraint cfg_gate_rules_nn_rule_code  not null
   , severity      varchar2(10 char)    constraint cfg_gate_rules_nn_severity   not null
   , param_1       varchar2(512 char)
   , param_2       varchar2(512 char)
   , is_active     varchar2(1 char)     constraint cfg_gate_rules_nn_is_active  not null
   , note          varchar2(512 char)
   -- Colonne amministrative: blocco fisso, popolato dal trigger
   -- (vedi Architettura_DB/colonne_amministrative.md).
   , row_version   number               default 1  constraint cfg_gate_rules_nn_row_version  not null
   , created_by    varchar2(64 char)    invisible  constraint cfg_gate_rules_nn_created_by   not null
   , created_at    timestamp(6)         invisible  constraint cfg_gate_rules_nn_created_at   not null
   , created_app   varchar2(64 char)    invisible  constraint cfg_gate_rules_nn_created_app  not null
   , modified_by   varchar2(64 char)    invisible
   , modified_at   timestamp(6)         invisible
   , modified_app  varchar2(64 char)    invisible
   );

prompt -- Adding defaults

alter table cfg_gate_rules
   modify ( is_active  default 'Y' );

prompt -- Adding constraints

alter table cfg_gate_rules
   add constraint cfg_gate_rules_pk primary key ( process_name, rule_seq )
   using index;

alter table cfg_gate_rules
   add constraint cfg_gate_rules_ck_severity check ( severity in ( 'SKIP', 'ABORT' ) );

alter table cfg_gate_rules
   add constraint cfg_gate_rules_ck_is_active check ( is_active in ( 'Y', 'N' ) );

prompt -- Adding comments

comment on table  cfg_gate_rules               is 'Precondizioni di esecuzione configurate per processo, valutate da lib_gate prima del corpo di un main process. Nessuna riga per un processo = nessuna precondizione, verdetto RUN.';
comment on column cfg_gate_rules.process_name  is 'Nome logico del processo, lo stesso passato a lib_batch.start_run: è ciò che tiene insieme regole, run e dipendenze.';
comment on column cfg_gate_rules.rule_seq      is 'Ordine di valutazione della regola dentro il processo; per convenzione a passi di 10, così se ne può inserire una in mezzo senza rinumerare.';
comment on column cfg_gate_rules.rule_code     is 'Tipo di regola, referenziato a cfg_gate_rule_types: determina quale check privato di lib_gate viene invocato.';
comment on column cfg_gate_rules.severity      is 'Che cosa comporta il fallimento di QUESTA regola per QUESTO processo: SKIP (uscita pulita, condizione fisiologica) oppure ABORT (errore visibile, anomalia).';
comment on column cfg_gate_rules.param_1       is 'Primo parametro della regola; il significato dipende dal tipo ed è documentato in cfg_gate_rule_types.param_1_usage.';
comment on column cfg_gate_rules.param_2       is 'Secondo parametro della regola; il significato dipende dal tipo ed è documentato in cfg_gate_rule_types.param_2_usage.';
comment on column cfg_gate_rules.is_active     is 'Y se la regola è valutata, N se è sospesa: permette di disattivare una precondizione senza perdere la configurazione e il suo storico.';
comment on column cfg_gate_rules.note          is 'Motivazione della regola a beneficio di chi la troverà fra un anno: perché questa precondizione, perché questa gravità.';
-- Colonne amministrative (standard su ogni tabella; vedi colonne_amministrative.md)
comment on column cfg_gate_rules.row_version   is 'Versione della riga per il locking ottimistico, incrementata dal trigger a ogni modifica.';
comment on column cfg_gate_rules.created_by    is 'Utente applicativo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column cfg_gate_rules.created_at    is 'Istante dell''inserimento (invisibile, impostata dal trigger).';
comment on column cfg_gate_rules.created_app   is 'Programma/modulo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column cfg_gate_rules.modified_by   is 'Utente applicativo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column cfg_gate_rules.modified_at   is 'Istante dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column cfg_gate_rules.modified_app  is 'Programma/modulo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';

prompt -- Creating indexes

-- Il gate legge sempre "tutte le regole attive di un processo, in ordine": la
-- primary key copre già l'accesso. Questo indice serve alla domanda inversa,
-- quella di chi manutiene la configurazione ("dove è usata questa regola?").
create index cfg_gate_rules_idx_rule_code on cfg_gate_rules ( rule_code );

prompt File: cfg_gate_rules.tab.sql <end>

prompt
