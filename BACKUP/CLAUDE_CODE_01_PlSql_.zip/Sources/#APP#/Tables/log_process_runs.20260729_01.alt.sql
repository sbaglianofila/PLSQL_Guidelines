prompt ------------------------------------------------------------

prompt File: log_process_runs.20260729_01.alt.sql <start>

prompt

-- =============================================================================
-- File:     log_process_runs.20260729_01.alt.sql
-- Oggetto:  log_process_runs (alter: ammissione dello stato SKIPPED)
-- Schema:   #APP#
-- Scopo:    Allinea un'istanza in cui log_process_runs è GIÀ stata creata con la
--           versione precedente della baseline, ammettendo il quarto stato
--           SKIPPED nel check constraint e aggiornando i commenti di status e
--           error_message.
-- Nota:     Script di ALLINEAMENTO, non parte dell'install. La baseline
--           log_process_runs.tab.sql ammette già SKIPPED, quindi un'istanza creata
--           da zero NON deve eseguire questo file: è riservato ai database su cui
--           la tabella era stata creata prima del 20260729. Per questo non è
--           cablato in Install/install.ins.sql e va lanciato a mano una volta sola.
--
--           SKIPPED è l'esito che lib_batch.skip_run scrive quando una
--           precondizione valutata da lib_gate fallisce con severity SKIP: una
--           condizione fisiologica (fuori finestra oraria, niente da elaborare)
--           che deve chiudere il processo in modo pulito ma comunque LASCIARE UNA
--           RIGA. Senza questa riga, "il processo non è partito" e "il processo
--           non è mai stato lanciato" sarebbero indistinguibili, che è esattamente
--           l'indagine che log_process_runs esiste per evitare. Vedi
--           Pacchetti_Base/precondizioni_esecuzione.md.
--
--           Il constraint si ricrea invece di modificarlo perché Oracle non
--           permette di alterare la condizione di un check: è drop + add, ed è
--           un'operazione di solo dizionario (nessuna riga esistente viene
--           riletta, dato che i tre stati precedenti restano tutti ammessi).
--           L'operazione richiede il lock esclusivo sulla tabella per un istante:
--           eseguirla quando nessun batch è in corso.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260729  AA   Creazione
-- =============================================================================

whenever sqlerror exit failure rollback

prompt -- Replacing the status check constraint

alter table log_process_runs
   drop constraint log_process_runs_ck_status;

alter table log_process_runs
   add constraint log_process_runs_ck_status check ( status in ( 'RUNNING', 'SUCCESS', 'FAILED', 'SKIPPED' ) );

prompt -- Updating comments

comment on column log_process_runs.status        is 'Esito dell''esecuzione: RUNNING, SUCCESS, FAILED oppure SKIPPED quando una precondizione di lib_gate con severity SKIP ha fatto uscire il processo prima del suo corpo.';
comment on column log_process_runs.error_message is 'Perché l''esecuzione non è finita in SUCCESS: il testo dell''errore quando è chiusa come FAILED, la precondizione che ha fatto uscire quando è SKIPPED. Una colonna sola perché la domanda dell''AM è la stessa nei due casi.';

prompt -- Reminder

prompt Dopo questo script reinstalla lib_batch (spec + body): la nuova skip_run
prompt scrive lo stato SKIPPED appena ammesso, e le scritture su log_process_runs
prompt passano in transazione autonoma.

prompt File: log_process_runs.20260729_01.alt.sql <end>

prompt
