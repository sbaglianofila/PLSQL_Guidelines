prompt ------------------------------------------------------------

prompt File: adm_user_functionalities.tab.sql <start>

prompt

-- =============================================================================
-- File:     adm_user_functionalities.tab.sql
-- Oggetto:  adm_user_functionalities (tabella di associazione)
-- Schema:   #APP#
-- Scopo:    Le eccezioni nominali: grant diretti di una funzionalita' a un singolo
--           utente, che si affiancano ai grant per profilo. Servono a evitare la
--           proliferazione di profili-fotocopia per pochi permessi individuali.
--           Due vincoli fermi: sono SOLO ADDITIVE (concedono, non negano mai; il
--           permesso effettivo resta l'OR di tutto), e la motivazione (reason) e'
--           OBBLIGATORIA per l'audit. Opzionalmente a tempo (grana data, come i
--           grant per profilo). A differenza dei permessi da profilo NON entrano
--           nella vista materializzata: sono lette al volo da lib_authz, cosi' la
--           loro finestra puo' un domani essere piu' fine del giorno senza toccare
--           la cadenza di refresh della MV.
--           Le foreign key sono in FKs/adm_user_functionalities.fky.sql.
--           Vedi Architettura_DB/utenti_profili.md.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260725  AA   Creazione
-- =============================================================================

prompt -- Creating table

create table adm_user_functionalities
   ( user_id             number(12)         constraint adm_user_func_nn_user      not null
   , functionality_code  varchar2(32 char)  constraint adm_user_func_nn_func      not null
   , can_read            varchar2(1 char)   constraint adm_user_func_nn_read       not null
   , can_write           varchar2(1 char)   constraint adm_user_func_nn_write      not null
   , can_execute         varchar2(1 char)   constraint adm_user_func_nn_execute    not null
   , valid_from          date
   , valid_to            date
   , reason              varchar2(512 char) constraint adm_user_func_nn_reason     not null
   -- Colonne amministrative: blocco fisso, popolato dal trigger
   -- (vedi Architettura_DB/colonne_amministrative.md).
   , row_version       number               default 1  constraint adm_user_func_nn_row_version  not null
   , created_by        varchar2(64 char)    invisible  constraint adm_user_func_nn_created_by   not null
   , created_at        timestamp(6)         invisible  constraint adm_user_func_nn_created_at   not null
   , created_app       varchar2(64 char)    invisible  constraint adm_user_func_nn_created_app  not null
   , modified_by       varchar2(64 char)    invisible
   , modified_at       timestamp(6)         invisible
   , modified_app      varchar2(64 char)    invisible
   );

prompt -- Adding defaults

alter table adm_user_functionalities
   modify ( can_read     default 'N'
          , can_write    default 'N'
          , can_execute  default 'N'
          );

prompt -- Adding constraints

alter table adm_user_functionalities
   add constraint adm_user_func_pk primary key ( user_id, functionality_code )
   using index;

alter table adm_user_functionalities
   add constraint adm_user_func_ck_read check ( can_read in ( 'Y', 'N' ) );

alter table adm_user_functionalities
   add constraint adm_user_func_ck_write check ( can_write in ( 'Y', 'N' ) );

alter table adm_user_functionalities
   add constraint adm_user_func_ck_execute check ( can_execute in ( 'Y', 'N' ) );

alter table adm_user_functionalities
   add constraint adm_user_func_ck_validity
   check ( valid_from is null or valid_to is null or valid_to >= valid_from );

prompt -- Adding comments

comment on table  adm_user_functionalities                    is 'Eccezioni nominali: grant diretti di funzionalità a un utente, solo additivi, opzionalmente a tempo, con motivazione obbligatoria.';
comment on column adm_user_functionalities.user_id            is 'Utente a cui si concede l''eccezione (foreign key verso adm_users).';
comment on column adm_user_functionalities.functionality_code is 'Funzionalità concessa in eccezione (foreign key verso adm_functionalities).';
comment on column adm_user_functionalities.can_read           is 'Y se accesso in lettura.';
comment on column adm_user_functionalities.can_write          is 'Y se accesso in scrittura.';
comment on column adm_user_functionalities.can_execute        is 'Y se accesso in esecuzione.';
comment on column adm_user_functionalities.valid_from         is 'Inizio validità dell''eccezione (incluso, grana data); null = da subito.';
comment on column adm_user_functionalities.valid_to           is 'Fine validità dell''eccezione (inclusa, grana data); null = senza scadenza.';
comment on column adm_user_functionalities.reason             is 'Motivazione dell''eccezione (obbligatoria, per l''audit di sicurezza).';
-- Colonne amministrative (standard su ogni tabella; vedi colonne_amministrative.md)
comment on column adm_user_functionalities.row_version   is 'Versione della riga per il locking ottimistico, incrementata dal trigger a ogni modifica.';
comment on column adm_user_functionalities.created_by    is 'Utente applicativo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column adm_user_functionalities.created_at    is 'Istante dell''inserimento (invisibile, impostata dal trigger).';
comment on column adm_user_functionalities.created_app   is 'Programma/modulo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column adm_user_functionalities.modified_by   is 'Utente applicativo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column adm_user_functionalities.modified_at   is 'Istante dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column adm_user_functionalities.modified_app  is 'Programma/modulo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';

prompt File: adm_user_functionalities.tab.sql <end>

prompt
