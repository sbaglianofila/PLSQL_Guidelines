prompt ------------------------------------------------------------

prompt File: adm_users.tab.sql <start>

prompt

-- =============================================================================
-- File:     adm_users.tab.sql
-- Oggetto:  adm_users (tabella)
-- Schema:   #APP#
-- Scopo:    Anagrafe degli utenti finali dell'applicazione. Non contiene le
--           credenziali: l'autenticazione e' esterna (SSO/LDAP) e qui vive solo
--           l'identita' applicativa e il suo stato. E' il punto in cui username
--           (propagato come CLIENT_IDENTIFIER e in APP_CTX via lib_session) diventa
--           un dato referenziabile. Chiave surrogata user_id.
--           Vedi Architettura_DB/utenti_profili.md.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260725  AA   Creazione
-- =============================================================================

prompt -- Creating table

create table adm_users
   ( user_id     number(12)          generated always as identity  constraint adm_users_nn_user_id   not null
   , username    varchar2(64 char)   constraint adm_users_nn_username   not null
   , full_name   varchar2(128 char)  constraint adm_users_nn_full_name  not null
   , email       varchar2(128 char)
   , is_active   varchar2(1 char)    constraint adm_users_nn_is_active  not null
   -- Colonne amministrative: blocco fisso, popolato dal trigger
   -- (vedi Architettura_DB/colonne_amministrative.md).
   , row_version       number               default 1  constraint adm_users_nn_row_version  not null
   , created_by        varchar2(64 char)    invisible  constraint adm_users_nn_created_by   not null
   , created_at        timestamp(6)         invisible  constraint adm_users_nn_created_at   not null
   , created_app       varchar2(64 char)    invisible  constraint adm_users_nn_created_app  not null
   , modified_by       varchar2(64 char)    invisible
   , modified_at       timestamp(6)         invisible
   , modified_app      varchar2(64 char)    invisible
   );

prompt -- Adding defaults

alter table adm_users
   modify ( is_active  default 'Y' );

prompt -- Adding constraints

alter table adm_users
   add constraint adm_users_pk primary key ( user_id )
   using index;

alter table adm_users
   add constraint adm_users_uk_username unique ( username )
   using index;

alter table adm_users
   add constraint adm_users_ck_is_active check ( is_active in ( 'Y', 'N' ) );

prompt -- Adding comments

comment on table  adm_users            is 'Anagrafe degli utenti finali dell''applicazione (identità applicativa, non credenziali: autenticazione esterna).';
comment on column adm_users.user_id    is 'Chiave surrogata, identity generata.';
comment on column adm_users.username   is 'Identificativo di login, unico; pubblicato in APP_CTX (APP_USER) via lib_session.set_actor.';
comment on column adm_users.full_name  is 'Nome per esteso dell''utente.';
comment on column adm_users.email      is 'Indirizzo di contatto.';
comment on column adm_users.is_active  is 'Y se l''utenza è abilitata; N se disattivata.';
-- Colonne amministrative (standard su ogni tabella; vedi colonne_amministrative.md)
comment on column adm_users.row_version   is 'Versione della riga per il locking ottimistico, incrementata dal trigger a ogni modifica.';
comment on column adm_users.created_by    is 'Utente applicativo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column adm_users.created_at    is 'Istante dell''inserimento (invisibile, impostata dal trigger).';
comment on column adm_users.created_app   is 'Programma/modulo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column adm_users.modified_by   is 'Utente applicativo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column adm_users.modified_at   is 'Istante dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column adm_users.modified_app  is 'Programma/modulo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';

prompt File: adm_users.tab.sql <end>

prompt
