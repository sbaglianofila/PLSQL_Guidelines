prompt ------------------------------------------------------------

prompt File: adm_masks.tab.sql <start>

prompt

-- =============================================================================
-- File:     adm_masks.tab.sql
-- Oggetto:  adm_masks (tabella)
-- Schema:   #APP#
-- Scopo:    Le maschere (schermate) dell'applicazione, ciascuna delle quali
--           raggruppa una o piu' funzionalita'. Tabella dedicata e non un
--           attributo testuale, perche' la maschera porta attributi propri:
--           titolo, modulo di appartenenza, ordinamento a menu. Chiave primaria
--           naturale sul codice. Vedi Architettura_DB/utenti_profili.md.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260725  AA   Creazione
-- =============================================================================

prompt -- Creating table

create table adm_masks
   ( mask_code    varchar2(32 char)   constraint adm_masks_nn_mask_code    not null
   , name         varchar2(128 char)  constraint adm_masks_nn_name         not null
   , description  varchar2(512 char)
   , module_code  varchar2(32 char)   constraint adm_masks_nn_module_code  not null
   , sort_order   number              constraint adm_masks_nn_sort_order   not null
   , is_active    varchar2(1 char)    constraint adm_masks_nn_is_active    not null
   -- Colonne amministrative: blocco fisso, popolato dal trigger
   -- (vedi Architettura_DB/colonne_amministrative.md).
   , row_version       number               default 1  constraint adm_masks_nn_row_version  not null
   , created_by        varchar2(64 char)    invisible  constraint adm_masks_nn_created_by   not null
   , created_at        timestamp(6)         invisible  constraint adm_masks_nn_created_at   not null
   , created_app       varchar2(64 char)    invisible  constraint adm_masks_nn_created_app  not null
   , modified_by       varchar2(64 char)    invisible
   , modified_at       timestamp(6)         invisible
   , modified_app      varchar2(64 char)    invisible
   );

prompt -- Adding defaults

alter table adm_masks
   modify ( sort_order  default 0
          , is_active   default 'Y'
          );

prompt -- Adding constraints

alter table adm_masks
   add constraint adm_masks_pk primary key ( mask_code )
   using index;

alter table adm_masks
   add constraint adm_masks_ck_is_active check ( is_active in ( 'Y', 'N' ) );

prompt -- Adding comments

comment on table  adm_masks              is 'Le maschere (schermate) dell''applicazione: raggruppano funzionalità e portano titolo, modulo e ordinamento a menu.';
comment on column adm_masks.mask_code    is 'Codice della maschera, chiave primaria naturale.';
comment on column adm_masks.name         is 'Titolo della maschera.';
comment on column adm_masks.description   is 'A cosa serve la schermata.';
comment on column adm_masks.module_code  is 'Modulo applicativo di appartenenza.';
comment on column adm_masks.sort_order   is 'Ordinamento nel menu.';
comment on column adm_masks.is_active    is 'Y se la maschera è attiva; N se dismessa.';
-- Colonne amministrative (standard su ogni tabella; vedi colonne_amministrative.md)
comment on column adm_masks.row_version   is 'Versione della riga per il locking ottimistico, incrementata dal trigger a ogni modifica.';
comment on column adm_masks.created_by    is 'Utente applicativo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column adm_masks.created_at    is 'Istante dell''inserimento (invisibile, impostata dal trigger).';
comment on column adm_masks.created_app   is 'Programma/modulo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column adm_masks.modified_by   is 'Utente applicativo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column adm_masks.modified_at   is 'Istante dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column adm_masks.modified_app  is 'Programma/modulo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';

prompt File: adm_masks.tab.sql <end>

prompt
