prompt ------------------------------------------------------------

prompt File: wfl_workflows.tab.sql <start>

prompt

-- =============================================================================
-- File:     wfl_workflows.tab.sql
-- Oggetto:  wfl_workflows (tabella)
-- Schema:   #APP#
-- Scopo:    Testata del pillar workflow: una riga per processo (macchina a stati)
--           governato dall'applicazione. È il padre di wfl_statuses e
--           wfl_transitions e ciò che rende scrivibile la foreign key composita
--           con costante dalle tabelle di business verso gli stati del proprio
--           workflow. Chiave naturale (workflow_code), così la costante che
--           comparirà nelle colonne virtuali di business è leggibile e non un
--           numero opaco. Tabella piccola e stabile, dato di configurazione
--           (vedi Architettura_DB/stati_workflow.md).
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260723  AA   Creazione
-- =============================================================================

prompt -- Creating table

create table wfl_workflows
   ( workflow_code  varchar2(32 char)   constraint wfl_workflows_nn_workflow  not null
   , name           varchar2(128 char)  constraint wfl_workflows_nn_name      not null
   , description    varchar2(512 char)
   , entity_table   varchar2(64 char)
   , guard_handler  varchar2(128 char)
   , is_valid       varchar2(1 char)    constraint wfl_workflows_nn_valid     not null
   -- Colonne amministrative: blocco fisso, popolato dal trigger
   -- (vedi Architettura_DB/colonne_amministrative.md).
   , row_version       number               default 1  constraint wfl_workflows_nn_row_version  not null
   , created_by        varchar2(64 char)    invisible  constraint wfl_workflows_nn_created_by   not null
   , created_at        timestamp(6)         invisible  constraint wfl_workflows_nn_created_at   not null
   , created_app       varchar2(64 char)    invisible  constraint wfl_workflows_nn_created_app  not null
   , modified_by       varchar2(64 char)    invisible
   , modified_at       timestamp(6)         invisible
   , modified_app      varchar2(64 char)    invisible
   );

prompt -- Adding defaults

alter table wfl_workflows
   modify ( is_valid  default 'Y' );

prompt -- Adding constraints

alter table wfl_workflows
   add constraint wfl_workflows_pk primary key ( workflow_code )
   using index;

alter table wfl_workflows
   add constraint wfl_workflows_ck_valid check ( is_valid in ( 'Y', 'N' ) );

prompt -- Adding comments

comment on table  wfl_workflows              is 'Testata del pillar workflow: una riga per processo/macchina a stati. Padre di wfl_statuses e wfl_transitions; letta tramite lib_workflow.';
comment on column wfl_workflows.workflow_code is 'Mnemonico del workflow (chiave naturale), usato nel codice e nelle foreign key composite delle tabelle di business (es. ORDER).';
comment on column wfl_workflows.name          is 'Etichetta leggibile del processo.';
comment on column wfl_workflows.description   is 'Cosa governa il workflow.';
comment on column wfl_workflows.entity_table  is 'Tabella di business governata dal workflow (documentativo; non è una foreign key perché la tabella di business può non esistere ancora).';
comment on column wfl_workflows.guard_handler is 'package.funzione dispatcher che valuta le guardie del workflow (firma fissa, riceve il guard_code e smista); nullo se il workflow non ha guardie. Vedi stati_workflow.md e wfl_transition_guards.';
comment on column wfl_workflows.is_valid      is 'Y se il workflow è attivo; N se dismesso.';
-- Colonne amministrative (standard su ogni tabella; vedi colonne_amministrative.md)
comment on column wfl_workflows.row_version   is 'Versione della riga per il locking ottimistico, incrementata dal trigger a ogni modifica.';
comment on column wfl_workflows.created_by    is 'Utente applicativo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column wfl_workflows.created_at    is 'Istante dell''inserimento (invisibile, impostata dal trigger).';
comment on column wfl_workflows.created_app   is 'Programma/modulo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column wfl_workflows.modified_by   is 'Utente applicativo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column wfl_workflows.modified_at   is 'Istante dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column wfl_workflows.modified_app  is 'Programma/modulo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';

prompt File: wfl_workflows.tab.sql <end>

prompt
