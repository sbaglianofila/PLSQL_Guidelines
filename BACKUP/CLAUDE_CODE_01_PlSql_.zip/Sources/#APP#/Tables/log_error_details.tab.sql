prompt ------------------------------------------------------------

prompt File: log_error_details.tab.sql <start>

prompt

-- =============================================================================
-- File:     log_error_details.tab.sql
-- Oggetto:  log_error_details (tabella)
-- Schema:   #APP#
-- Scopo:    Dettaglio diagnostico dei soli errori per lo stream log_events: una
--           riga per evento ERROR, con backtrace e call stack che ne localizzano
--           l'origine. Tenuto a parte da log_events perché lo stream principale
--           resti snello e il testo diagnostico pesante sia recuperato solo in
--           fase di indagine. Popolato da lib_logging.log_error insieme alla sua
--           riga di log_events, nella stessa transazione autonoma. Letto (in join
--           su event_id) dalle query di controllo dell'AM quando serve il contesto
--           completo dell'errore.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260708  AA   Creazione (separa la diagnostica dalla precedente log_errors)
--   20260708  AA   Aggiunta sqlerrm_text (sqlerrm grezzo, conservato anche quando
--                  il messaggio di log_events mostra un override Oracle a catalogo)
--   20260708  AA   Aggiunta error_stack (format_error_stack) e session_data
--                  (snapshot USERENV + APP_CTX); PK/FK spostate in script separati
-- =============================================================================

prompt -- Creating table

create table log_error_details
   ( event_id         number(24)          constraint log_error_details_nn_event_id  not null
   , sqlerrm_text     varchar2(4000 char)
   , error_backtrace  varchar2(4000 char)
   , call_stack       varchar2(4000 char)
   , error_stack      varchar2(4000 char)
   , session_data     varchar2(4000 char)
   );

prompt -- Adding constraints

alter table log_error_details
   add constraint log_error_details_pk primary key ( event_id )
   using index;

prompt -- Adding comments

comment on table  log_error_details                 is 'Diagnostica dei soli errori (sqlerrm grezzo, backtrace, call stack, error stack e uno snapshot di sessione) per lo stream log_events, una riga per evento ERROR, in join su event_id.';
comment on column log_error_details.event_id        is 'Evento ERROR proprietario in log_events (chiave primaria e chiave esterna).';
comment on column log_error_details.sqlerrm_text    is 'sqlerrm grezzo al momento del log, sempre conservato qui così che il testo Oracle originale sopravviva anche quando log_events.message mostra un override ORACLE a catalogo.';
comment on column log_error_details.error_backtrace is 'dbms_utility.format_error_backtrace: riga in cui l''eccezione è stata sollevata.';
comment on column log_error_details.call_stack      is 'dbms_utility.format_call_stack al momento del log.';
comment on column log_error_details.error_stack     is 'dbms_utility.format_error_stack al momento del log: la catena completa degli errori impilati, non solo l''sqlerrm di testa.';
comment on column log_error_details.session_data    is 'Snapshot di sessione al momento dell''errore da lib_session.session_info: attributi USERENV non già presenti in log_events (session_user, os_user, host, ip_address, sid, instance, service, action, impostazioni NLS) più l''app_user di APP_CTX, come coppie chiave=valore.';

prompt File: log_error_details.tab.sql <end>

prompt
