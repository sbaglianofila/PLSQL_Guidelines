prompt File: cfg_reports.tab.sql <start>
-- =============================================================================
-- File:     cfg_reports.tab.sql
-- Oggetto:  cfg_reports (tabella)
-- Schema:   #APP#
-- Scopo:    Registro dei report tabellari eseguiti da lib_report.run_report: la
--           query da eseguire, il formato di output e il modo di recapito (mail
--           e/o file). Il flag "solo anomalie" sopprime il recapito quando la
--           query non restituisce righe (silenzio = tutto ok), per i report
--           costruiti sulle query di controllo.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260705  AA   Creazione
-- =============================================================================

prompt cfg_reports: Creating table

create table cfg_reports
   ( report_code       varchar2(64 char)
   , description       varchar2(512 char)
   , query_text        clob                constraint cfg_reports_nn_query      not null
   , format            varchar2(8 char)    constraint cfg_reports_nn_format     not null
   , recipients        varchar2(4000 char)
   , output_directory  varchar2(128 char)
   , output_filename   varchar2(512 char)
   , anomalies_only    varchar2(1 char)    constraint cfg_reports_nn_anomalies  not null
   , is_enabled        varchar2(1 char)    constraint cfg_reports_nn_enabled    not null
   );

prompt cfg_reports: Adding defaults

alter table cfg_reports
   modify ( format          default 'CSV'
          , anomalies_only  default 'N'
          , is_enabled      default 'Y'
          );

prompt cfg_reports: Adding constraints

alter table cfg_reports
   add constraint cfg_reports_pk primary key ( report_code )
   using index;

alter table cfg_reports
   add constraint cfg_reports_ck_format check ( format in ( 'CSV', 'HTML' ) );

alter table cfg_reports
   add constraint cfg_reports_ck_anomalies check ( anomalies_only in ( 'Y', 'N' ) );

alter table cfg_reports
   add constraint cfg_reports_ck_enabled check ( is_enabled in ( 'Y', 'N' ) );

prompt cfg_reports: Adding comments

comment on table  cfg_reports                  is 'Registro dei report tabellari prodotti e recapitati da lib_report.';
comment on column cfg_reports.report_code      is 'Codice del report (chiave naturale) passato a run_report.';
comment on column cfg_reports.description      is 'Descrizione; usata anche come oggetto della mail.';
comment on column cfg_reports.query_text       is 'Query SQL eseguita per produrre le righe del report.';
comment on column cfg_reports.format           is 'Formato di output: CSV o HTML.';
comment on column cfg_reports.recipients       is 'Destinatari mail (separati da virgola); nullo per saltare il recapito via mail.';
comment on column cfg_reports.output_directory is 'DIRECTORY Oracle per il recapito su file; nullo per saltare il recapito su file.';
comment on column cfg_reports.output_filename  is 'Nome del file per il recapito su file (dentro output_directory).';
comment on column cfg_reports.anomalies_only   is 'Y per recapitare solo quando la query restituisce righe (silenzio = tutto ok).';
comment on column cfg_reports.is_enabled       is 'Y quando il report può essere eseguito.';

prompt File: cfg_reports.tab.sql <end>
