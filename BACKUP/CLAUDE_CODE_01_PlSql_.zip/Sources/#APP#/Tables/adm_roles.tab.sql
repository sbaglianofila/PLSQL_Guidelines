prompt ------------------------------------------------------------

prompt File: adm_roles.tab.sql <start>

prompt

-- =============================================================================
-- File:     adm_roles.tab.sql
-- Oggetto:  adm_roles (tabella)
-- Schema:   #APP#
-- Scopo:    I ruoli aziendali atomici (es. ACCOUNTANT): l'unita' organizzativa
--           minima che compone i profili. Tabella piccola e stabile, quindi
--           chiave primaria naturale sul codice. Da tenere distinta dai ruoli di
--           database di schemi.md. Vedi Architettura_DB/utenti_profili.md.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260725  AA   Creazione
-- =============================================================================

prompt -- Creating table

create table adm_roles
   ( role_code    varchar2(32 char)   constraint adm_roles_nn_role_code   not null
   , name         varchar2(128 char)  constraint adm_roles_nn_name        not null
   , description  varchar2(512 char)
   , is_system    varchar2(1 char)    constraint adm_roles_nn_is_system   not null
   -- Colonne amministrative: blocco fisso, popolato dal trigger
   -- (vedi Architettura_DB/colonne_amministrative.md).
   , row_version       number               default 1  constraint adm_roles_nn_row_version  not null
   , created_by        varchar2(64 char)    invisible  constraint adm_roles_nn_created_by   not null
   , created_at        timestamp(6)         invisible  constraint adm_roles_nn_created_at   not null
   , created_app       varchar2(64 char)    invisible  constraint adm_roles_nn_created_app  not null
   , modified_by       varchar2(64 char)    invisible
   , modified_at       timestamp(6)         invisible
   , modified_app      varchar2(64 char)    invisible
   );

prompt -- Adding defaults

alter table adm_roles
   modify ( is_system  default 'N' );

prompt -- Adding constraints

alter table adm_roles
   add constraint adm_roles_pk primary key ( role_code )
   using index;

alter table adm_roles
   add constraint adm_roles_ck_is_system check ( is_system in ( 'Y', 'N' ) );

prompt -- Adding comments

comment on table  adm_roles              is 'I ruoli aziendali atomici che compongono i profili (dati applicativi, distinti dai ruoli di database).';
comment on column adm_roles.role_code    is 'Codice del ruolo, chiave primaria naturale (es. ACCOUNTANT).';
comment on column adm_roles.name         is 'Nome leggibile del ruolo.';
comment on column adm_roles.description  is 'A cosa corrisponde il ruolo.';
comment on column adm_roles.is_system    is 'Y se ruolo predefinito del framework, non modificabile dagli amministratori.';
-- Colonne amministrative (standard su ogni tabella; vedi colonne_amministrative.md)
comment on column adm_roles.row_version   is 'Versione della riga per il locking ottimistico, incrementata dal trigger a ogni modifica.';
comment on column adm_roles.created_by    is 'Utente applicativo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column adm_roles.created_at    is 'Istante dell''inserimento (invisibile, impostata dal trigger).';
comment on column adm_roles.created_app   is 'Programma/modulo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column adm_roles.modified_by   is 'Utente applicativo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column adm_roles.modified_at   is 'Istante dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column adm_roles.modified_app  is 'Programma/modulo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';

prompt File: adm_roles.tab.sql <end>

prompt
