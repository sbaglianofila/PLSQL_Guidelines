prompt ------------------------------------------------------------

prompt File: wfl_statuses.tab.sql <start>

prompt

-- =============================================================================
-- File:     wfl_statuses.tab.sql
-- Oggetto:  wfl_statuses (tabella)
-- Schema:   #APP#
-- Scopo:    Gli stati di ciascun workflow: i nodi della macchina a stati. A
--           differenza di un valore di lookup, uno stato porta il suo ruolo nella
--           macchina - se è quello iniziale in cui l'entità nasce, se è terminale -
--           oltre a etichetta e ordinamento. Chiave (workflow_code, status_code).
--           La foreign key verso wfl_workflows è in FKs/wfl_statuses.fky.sql. È
--           il bersaglio della foreign key composita con costante dalle tabelle
--           di business (vedi Architettura_DB/stati_workflow.md).
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260723  AA   Creazione
-- =============================================================================

prompt -- Creating table

create table wfl_statuses
   ( workflow_code  varchar2(32 char)   constraint wfl_statuses_nn_workflow  not null
   , status_code    varchar2(32 char)   constraint wfl_statuses_nn_status    not null
   , label          varchar2(128 char)  constraint wfl_statuses_nn_label     not null
   , sort_order     number              constraint wfl_statuses_nn_sort      not null
   , is_initial     varchar2(1 char)    constraint wfl_statuses_nn_initial   not null
   , is_final       varchar2(1 char)    constraint wfl_statuses_nn_final      not null
   , is_valid       varchar2(1 char)    constraint wfl_statuses_nn_valid      not null
   -- Colonne amministrative: blocco fisso, popolato dal trigger
   -- (vedi Architettura_DB/colonne_amministrative.md).
   , row_version       number               default 1  constraint wfl_statuses_nn_row_version  not null
   , created_by        varchar2(64 char)    invisible  constraint wfl_statuses_nn_created_by   not null
   , created_at        timestamp(6)         invisible  constraint wfl_statuses_nn_created_at   not null
   , created_app       varchar2(64 char)    invisible  constraint wfl_statuses_nn_created_app  not null
   , modified_by       varchar2(64 char)    invisible
   , modified_at       timestamp(6)         invisible
   , modified_app      varchar2(64 char)    invisible
   );

prompt -- Adding defaults

alter table wfl_statuses
   modify ( sort_order  default 0
          , is_initial  default 'N'
          , is_final    default 'N'
          , is_valid    default 'Y'
          );

prompt -- Adding constraints

alter table wfl_statuses
   add constraint wfl_statuses_pk primary key ( workflow_code, status_code )
   using index;

alter table wfl_statuses
   add constraint wfl_statuses_ck_initial check ( is_initial in ( 'Y', 'N' ) );

alter table wfl_statuses
   add constraint wfl_statuses_ck_final check ( is_final in ( 'Y', 'N' ) );

alter table wfl_statuses
   add constraint wfl_statuses_ck_valid check ( is_valid in ( 'Y', 'N' ) );

prompt -- Enforcing a single initial status per workflow

-- Indice unico funzionale: la chiave è valorizzata solo per lo stato iniziale,
-- nulla per gli altri (Oracle non indicizza le chiavi tutte-nulle). Garantisce
-- al più un is_initial='Y' per workflow senza vincolare gli stati non iniziali.
create unique index wfl_statuses_uk_initial
   on wfl_statuses ( case when is_initial = 'Y' then workflow_code end );

prompt -- Adding comments

comment on table  wfl_statuses             is 'Gli stati di ciascun workflow (nodi della macchina a stati). Letta tramite lib_workflow; bersaglio della foreign key composita con costante dalle tabelle di business.';
comment on column wfl_statuses.workflow_code is 'Workflow di appartenenza (foreign key verso wfl_workflows).';
comment on column wfl_statuses.status_code   is 'Codice dello stato, unico entro il workflow (es. OPEN).';
comment on column wfl_statuses.label         is 'Testo mostrato a video.';
comment on column wfl_statuses.sort_order    is 'Ordine di presentazione degli stati.';
comment on column wfl_statuses.is_initial    is 'Y se è lo stato in cui l''entità nasce; al più uno per workflow (indice wfl_statuses_uk_initial).';
comment on column wfl_statuses.is_final      is 'Y se è uno stato terminale oltre il quale non si prosegue; zero o più per workflow.';
comment on column wfl_statuses.is_valid      is 'Y se lo stato è ancora in uso; N se dismesso (resta legittimo per le righe storiche).';
-- Colonne amministrative (standard su ogni tabella; vedi colonne_amministrative.md)
comment on column wfl_statuses.row_version   is 'Versione della riga per il locking ottimistico, incrementata dal trigger a ogni modifica.';
comment on column wfl_statuses.created_by    is 'Utente applicativo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column wfl_statuses.created_at    is 'Istante dell''inserimento (invisibile, impostata dal trigger).';
comment on column wfl_statuses.created_app   is 'Programma/modulo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column wfl_statuses.modified_by   is 'Utente applicativo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column wfl_statuses.modified_at   is 'Istante dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column wfl_statuses.modified_app  is 'Programma/modulo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';

prompt File: wfl_statuses.tab.sql <end>

prompt
