prompt ------------------------------------------------------------

prompt File: ref_lookup_values.tab.sql <start>

prompt

-- =============================================================================
-- File:     ref_lookup_values.tab.sql
-- Oggetto:  ref_lookup_values (tabella)
-- Schema:   #APP#
-- Scopo:    Dettaglio delle lookup generiche: una riga per ciascun valore di
--           ciascun set. value_code è ciò che i dati di business memorizzano e
--           l'utente riconosce; value_id è un surrogato interno. is_valid ritira
--           un valore senza cancellarlo (le righe storiche lo referenziano
--           ancora); is_default marca il preselezionato. I tre slot tipizzati
--           num_value/char_value/date_value attaccano una proprietà scalare al
--           valore senza scomodare una tabella dedicata. La foreign key verso
--           ref_lookups è in FKs/ref_lookup_values.fky.sql (vedi lookups.md).
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260719  AA   Creazione
-- =============================================================================

prompt -- Creating table

create table ref_lookup_values
   ( value_id     number(12)          generated always as identity  constraint ref_lookup_values_nn_id  not null
   , lookup_code  varchar2(32 char)   constraint ref_lookup_values_nn_lookup  not null
   , value_code   varchar2(32 char)   constraint ref_lookup_values_nn_value   not null
   , label        varchar2(128 char)  constraint ref_lookup_values_nn_label   not null
   , description  varchar2(512 char)
   , sort_order   number              constraint ref_lookup_values_nn_sort    not null
   , is_valid     varchar2(1 char)    constraint ref_lookup_values_nn_valid   not null
   , is_default   varchar2(1 char)    constraint ref_lookup_values_nn_deflt   not null
   , num_value    number
   , char_value   varchar2(256 char)
   , date_value   date
   -- Colonne amministrative: blocco fisso, popolato dal trigger
   -- (vedi Architettura_DB/colonne_amministrative.md).
   , row_version       number               default 1  constraint ref_lookup_values_nn_row_version  not null
   , created_by        varchar2(64 char)    invisible  constraint ref_lookup_values_nn_created_by   not null
   , created_at        timestamp(6)         invisible  constraint ref_lookup_values_nn_created_at   not null
   , created_app       varchar2(64 char)    invisible  constraint ref_lookup_values_nn_created_app  not null
   , modified_by       varchar2(64 char)    invisible
   , modified_at       timestamp(6)         invisible
   , modified_app      varchar2(64 char)    invisible
   );

prompt -- Adding defaults

alter table ref_lookup_values
   modify ( sort_order  default 0
          , is_valid    default 'Y'
          , is_default  default 'N'
          );

prompt -- Adding constraints

alter table ref_lookup_values
   add constraint ref_lookup_values_pk primary key ( value_id )
   using index;

alter table ref_lookup_values
   add constraint ref_lookup_values_uk_code unique ( lookup_code, value_code )
   using index;

alter table ref_lookup_values
   add constraint ref_lookup_values_ck_valid check ( is_valid in ( 'Y', 'N' ) );

alter table ref_lookup_values
   add constraint ref_lookup_values_ck_deflt check ( is_default in ( 'Y', 'N' ) );

prompt -- Adding comments

comment on table  ref_lookup_values             is 'Dettaglio delle lookup generiche: una riga per valore di ciascun set. Letta tramite lib_lookup, in join a ref_lookups su lookup_code.';
comment on column ref_lookup_values.value_id    is 'Chiave surrogata interna (identity generata); non è il codice che gira nei dati.';
comment on column ref_lookup_values.lookup_code is 'Set di appartenenza (foreign key verso ref_lookups).';
comment on column ref_lookup_values.value_code  is 'Codice memorizzato e referenziato dai dati di business (es. MOBILE); unico entro il set.';
comment on column ref_lookup_values.label       is 'Testo mostrato a video.';
comment on column ref_lookup_values.description is 'Spiegazione estesa del valore.';
comment on column ref_lookup_values.sort_order  is 'Ordine di presentazione nelle tendine.';
comment on column ref_lookup_values.is_valid    is 'Y se il valore è attualmente selezionabile; N se ritirato (resta legittimo per le righe storiche ma sparisce dalle tendine).';
comment on column ref_lookup_values.is_default  is 'Y se è il valore predefinito del set.';
comment on column ref_lookup_values.num_value   is 'Slot tipizzato: proprietà numerica associata al valore (es. peso di ordinamento di una priorità).';
comment on column ref_lookup_values.char_value  is 'Slot tipizzato: proprietà testuale associata al valore (es. nome icona o classe CSS).';
comment on column ref_lookup_values.date_value  is 'Slot tipizzato: proprietà di tipo data associata al valore.';
-- Colonne amministrative (standard su ogni tabella; vedi colonne_amministrative.md)
comment on column ref_lookup_values.row_version  is 'Versione della riga per il locking ottimistico, incrementata dal trigger a ogni modifica.';
comment on column ref_lookup_values.created_by   is 'Utente applicativo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column ref_lookup_values.created_at   is 'Istante dell''inserimento (invisibile, impostata dal trigger).';
comment on column ref_lookup_values.created_app  is 'Programma/modulo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column ref_lookup_values.modified_by  is 'Utente applicativo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column ref_lookup_values.modified_at  is 'Istante dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column ref_lookup_values.modified_app is 'Programma/modulo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';

prompt File: ref_lookup_values.tab.sql <end>

prompt
