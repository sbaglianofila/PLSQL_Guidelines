prompt ------------------------------------------------------------

prompt File: cfg_error_messages.tab.sql <start>

prompt

-- =============================================================================
-- File:     cfg_error_messages.tab.sql
-- Oggetto:  cfg_error_messages (tabella)
-- Schema:   #APP#
-- Scopo:    Catalogo dei template dei messaggi d'errore, basati sul codice
--           numerico d'errore, con due tipi di riga (error_kind):
--             APP    - errori applicativi nella banda riservata -20999..-20000.
--                      I codici e le relative eccezioni con nome restano nel
--                      codice (spec di lib_err, così i chiamanti intercettano per
--                      nome e il compilatore li controlla); il testo vive qui per
--                      essere correggibile a runtime. Letto da lib_err per comporre
--                      i messaggi.
--             ORACLE - override per gli errori Oracle nativi (qualsiasi sqlcode
--                      fuori dalla banda applicativa, es. -1 per ORA-00001). Letto
--                      da lib_logging quando logga un errore: se il codice Oracle è
--                      a catalogo si usa il testo personalizzato, altrimenti
--                      l'sqlerrm grezzo. Permette a un progetto di umanizzare o
--                      tradurre gli errori Oracle senza toccare il codice.
--           I codici APP e ORACLE non si sovrappongono mai numericamente, quindi
--           una sola tabella con un flag di tipo resta pulita. Un codice
--           sconosciuto degrada a un fallback sicuro, così una riga mancante non
--           blocca mai il logging o la segnalazione. I template usano i segnaposto
--           %1..%10 (gli override ORACLE sono di norma testo statico).
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260708  AA   Creazione
--   20260708  AA   Aggiunta error_kind (APP/ORACLE) per catalogare anche gli errori Oracle
-- =============================================================================

prompt -- Creating table

create table cfg_error_messages
   ( error_code        number
   , error_kind        varchar2(10 char)   constraint cfg_error_messages_nn_kind      not null
   , error_name        varchar2(64 char)   constraint cfg_error_messages_nn_name      not null
   , message_template  varchar2(4000 char) constraint cfg_error_messages_nn_template  not null
   -- Colonne amministrative: blocco fisso, popolato dal trigger
   -- (vedi Architettura_DB/colonne_amministrative.md).
   , row_version       number               default 1  constraint cfg_error_messages_nn_row_version  not null
   , created_by        varchar2(64 char)    invisible  constraint cfg_error_messages_nn_created_by   not null
   , created_at        timestamp(6)         invisible  constraint cfg_error_messages_nn_created_at   not null
   , created_app       varchar2(64 char)    invisible  constraint cfg_error_messages_nn_created_app  not null
   , modified_by       varchar2(64 char)    invisible
   , modified_at       timestamp(6)         invisible
   , modified_app      varchar2(64 char)    invisible
   );

prompt -- Adding defaults

alter table cfg_error_messages
   modify ( error_kind  default 'APP'
          );

prompt -- Adding constraints

alter table cfg_error_messages
   add constraint cfg_error_messages_pk primary key ( error_code )
   using index;

alter table cfg_error_messages
   add constraint cfg_error_messages_uk_name unique ( error_name )
   using index;

alter table cfg_error_messages
   add constraint cfg_error_messages_ck_kind check ( error_kind in ( 'APP', 'ORACLE' ) );

alter table cfg_error_messages
   add constraint cfg_error_messages_ck_code check
      (  ( error_kind = 'APP' and error_code between -20999 and -20000 )
      or   error_kind = 'ORACLE'
      );

prompt -- Adding comments

comment on table  cfg_error_messages                  is 'Catalogo dei template dei messaggi d''errore basati sul codice numerico. Le righe APP (banda -20999..-20000) sono lette da lib_err; le righe ORACLE fanno override degli errori Oracle nativi e sono lette da lib_logging al momento del log.';
comment on column cfg_error_messages.error_code       is 'Codice numerico d''errore: per APP il codice riservato -20999..-20000 (corrisponde a una costante k_ in lib_err); per ORACLE l''sqlcode nativo (es. -1 per ORA-00001).';
comment on column cfg_error_messages.error_kind       is 'APP (errore applicativo, in banda) o ORACLE (override di un errore Oracle nativo).';
comment on column cfg_error_messages.error_name       is 'Nome leggibile: per APP rispecchia la costante k_ di lib_err (es. INVALID_PARAMETER); per ORACLE un mnemonico (es. DUP_VAL_ON_INDEX).';
comment on column cfg_error_messages.message_template is 'Template del messaggio con segnaposto %1..%10 (APP); per ORACLE di norma testo di override statico.';
comment on column cfg_error_messages.row_version      is 'Versione della riga per il locking ottimistico, incrementata dal trigger a ogni modifica.';
comment on column cfg_error_messages.created_by       is 'Utente applicativo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column cfg_error_messages.created_at       is 'Istante dell''inserimento (invisibile, impostata dal trigger).';
comment on column cfg_error_messages.created_app      is 'Programma/modulo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column cfg_error_messages.modified_by      is 'Utente applicativo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column cfg_error_messages.modified_at      is 'Istante dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column cfg_error_messages.modified_app     is 'Programma/modulo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';

prompt File: cfg_error_messages.tab.sql <end>

prompt

