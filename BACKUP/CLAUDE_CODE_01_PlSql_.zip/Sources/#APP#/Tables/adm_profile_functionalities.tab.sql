prompt ------------------------------------------------------------

prompt File: adm_profile_functionalities.tab.sql <start>

prompt

-- =============================================================================
-- File:     adm_profile_functionalities.tab.sql
-- Oggetto:  adm_profile_functionalities (tabella di associazione)
-- Schema:   #APP#
-- Scopo:    I grant delle funzionalita' ai profili, con il modo di accesso e la
--           finestra di validita'. Chiave (profile_code, functionality_code). I
--           tre modi sono flag indipendenti (non gerarchici); il modo effettivo
--           dell'utente e' l'OR sui suoi profili. La finestra a grana data
--           (valid_from/valid_to) permette di aprire/chiudere per data senza
--           creare profili ad hoc. Confronto su trunc(sysdate); estremi inclusi;
--           null = da sempre / senza scadenza.
--           Le foreign key sono in FKs/adm_profile_functionalities.fky.sql.
--           Vedi Architettura_DB/utenti_profili.md.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260725  AA   Creazione
-- =============================================================================

prompt -- Creating table

create table adm_profile_functionalities
   ( profile_code        varchar2(32 char)  constraint adm_profile_func_nn_profile  not null
   , functionality_code  varchar2(32 char)  constraint adm_profile_func_nn_func     not null
   , can_read            varchar2(1 char)   constraint adm_profile_func_nn_read      not null
   , can_write           varchar2(1 char)   constraint adm_profile_func_nn_write     not null
   , can_execute         varchar2(1 char)   constraint adm_profile_func_nn_execute   not null
   , valid_from          date
   , valid_to            date
   -- Colonne amministrative: blocco fisso, popolato dal trigger
   -- (vedi Architettura_DB/colonne_amministrative.md).
   , row_version       number               default 1  constraint adm_profile_func_nn_row_version  not null
   , created_by        varchar2(64 char)    invisible  constraint adm_profile_func_nn_created_by   not null
   , created_at        timestamp(6)         invisible  constraint adm_profile_func_nn_created_at   not null
   , created_app       varchar2(64 char)    invisible  constraint adm_profile_func_nn_created_app  not null
   , modified_by       varchar2(64 char)    invisible
   , modified_at       timestamp(6)         invisible
   , modified_app      varchar2(64 char)    invisible
   );

prompt -- Adding defaults

alter table adm_profile_functionalities
   modify ( can_read     default 'N'
          , can_write    default 'N'
          , can_execute  default 'N'
          );

prompt -- Adding constraints

alter table adm_profile_functionalities
   add constraint adm_profile_func_pk primary key ( profile_code, functionality_code )
   using index;

alter table adm_profile_functionalities
   add constraint adm_profile_func_ck_read check ( can_read in ( 'Y', 'N' ) );

alter table adm_profile_functionalities
   add constraint adm_profile_func_ck_write check ( can_write in ( 'Y', 'N' ) );

alter table adm_profile_functionalities
   add constraint adm_profile_func_ck_execute check ( can_execute in ( 'Y', 'N' ) );

alter table adm_profile_functionalities
   add constraint adm_profile_func_ck_validity
   check ( valid_from is null or valid_to is null or valid_to >= valid_from );

prompt -- Adding comments

comment on table  adm_profile_functionalities                    is 'Grant delle funzionalità ai profili, con modo di accesso a tre flag e finestra di validità a grana data.';
comment on column adm_profile_functionalities.profile_code       is 'Profilo a cui si concede la funzionalità (foreign key verso adm_profiles).';
comment on column adm_profile_functionalities.functionality_code is 'Funzionalità concessa (foreign key verso adm_functionalities).';
comment on column adm_profile_functionalities.can_read           is 'Y se accesso in lettura.';
comment on column adm_profile_functionalities.can_write          is 'Y se accesso in scrittura.';
comment on column adm_profile_functionalities.can_execute        is 'Y se accesso in esecuzione.';
comment on column adm_profile_functionalities.valid_from         is 'Inizio validità del grant (incluso, grana data); null = da sempre.';
comment on column adm_profile_functionalities.valid_to           is 'Fine validità del grant (inclusa, grana data); null = senza scadenza.';
-- Colonne amministrative (standard su ogni tabella; vedi colonne_amministrative.md)
comment on column adm_profile_functionalities.row_version   is 'Versione della riga per il locking ottimistico, incrementata dal trigger a ogni modifica.';
comment on column adm_profile_functionalities.created_by    is 'Utente applicativo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column adm_profile_functionalities.created_at    is 'Istante dell''inserimento (invisibile, impostata dal trigger).';
comment on column adm_profile_functionalities.created_app   is 'Programma/modulo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column adm_profile_functionalities.modified_by   is 'Utente applicativo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column adm_profile_functionalities.modified_at   is 'Istante dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column adm_profile_functionalities.modified_app  is 'Programma/modulo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';

prompt File: adm_profile_functionalities.tab.sql <end>

prompt
