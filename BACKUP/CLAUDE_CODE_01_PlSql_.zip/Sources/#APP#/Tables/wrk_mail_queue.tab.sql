prompt File: wrk_mail_queue.tab.sql <start>
-- =============================================================================
-- File:     wrk_mail_queue.tab.sql
-- Oggetto:  wrk_mail_queue (tabella)
-- Schema:   #APP#
-- Scopo:    Coda della posta in uscita scritta da lib_mail.send e drenata da
--           lib_mail.process_queue (un job schedulato) con retry e backoff, così
--           che l'invio non allunghi né faccia fallire la transazione applicativa.
--           I destinatari sono già filtrati dalla guardia d'ambiente al momento
--           della scrittura.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260705  AA   Creazione
-- =============================================================================

prompt wrk_mail_queue: Creating table

create table wrk_mail_queue
   ( mail_id          number(24)          generated always as identity  constraint wrk_mail_queue_nn_mail_id  not null
   , created_at       timestamp(6)        constraint wrk_mail_queue_nn_created  not null
   , from_addr        varchar2(256 char)
   , to_addr          varchar2(4000 char) constraint wrk_mail_queue_nn_to  not null
   , cc_addr          varchar2(4000 char)
   , bcc_addr         varchar2(4000 char)
   , subject          varchar2(998 char)
   , body             clob
   , is_html          varchar2(1 char)    constraint wrk_mail_queue_nn_html  not null
   , status           varchar2(32 char)   constraint wrk_mail_queue_nn_status  not null
   , attempts         number
   , next_attempt_at  timestamp(6)
   , last_attempt_at  timestamp(6)
   , sent_at          timestamp(6)
   , error_message    varchar2(4000 char)
   );

prompt wrk_mail_queue: Adding defaults

alter table wrk_mail_queue
   modify ( created_at       default systimestamp
          , is_html          default 'N'
          , status           default 'PENDING'
          , attempts         default 0
          , next_attempt_at  default systimestamp
          );

prompt wrk_mail_queue: Adding constraints

alter table wrk_mail_queue
   add constraint wrk_mail_queue_pk primary key ( mail_id )
   using index;

alter table wrk_mail_queue
   add constraint wrk_mail_queue_ck_status check ( status in ( 'PENDING', 'SENT', 'FAILED' ) );

alter table wrk_mail_queue
   add constraint wrk_mail_queue_ck_html check ( is_html in ( 'Y', 'N' ) );

prompt wrk_mail_queue: Adding comments

comment on table  wrk_mail_queue                 is 'Coda della posta in uscita drenata da lib_mail.process_queue con retry e backoff.';
comment on column wrk_mail_queue.mail_id         is 'Chiave surrogata, identity generata.';
comment on column wrk_mail_queue.created_at      is 'Istante di accodamento del messaggio.';
comment on column wrk_mail_queue.from_addr       is 'Indirizzo mittente; se nullo all''accodamento assume il default dalla configurazione.';
comment on column wrk_mail_queue.to_addr         is 'Elenco destinatari (separati da virgola), già filtrati dalla guardia d''ambiente.';
comment on column wrk_mail_queue.cc_addr         is 'Elenco destinatari in copia (separati da virgola).';
comment on column wrk_mail_queue.bcc_addr        is 'Elenco destinatari in copia nascosta (separati da virgola).';
comment on column wrk_mail_queue.subject         is 'Oggetto del messaggio.';
comment on column wrk_mail_queue.body            is 'Corpo del messaggio (testo semplice o HTML secondo is_html).';
comment on column wrk_mail_queue.is_html         is 'Y quando il corpo è HTML, N per testo semplice.';
comment on column wrk_mail_queue.status          is 'PENDING, SENT o FAILED.';
comment on column wrk_mail_queue.attempts        is 'Numero di tentativi di consegna effettuati finora.';
comment on column wrk_mail_queue.next_attempt_at is 'Primo istante in cui può partire il prossimo tentativo di consegna (backoff).';
comment on column wrk_mail_queue.last_attempt_at is 'Istante dell''ultimo tentativo di consegna.';
comment on column wrk_mail_queue.sent_at         is 'Istante in cui il messaggio è stato inviato con successo.';
comment on column wrk_mail_queue.error_message   is 'Testo dell''errore dell''ultimo tentativo fallito.';

prompt wrk_mail_queue: Creating indexes

create index wrk_mail_queue_idx_pending on wrk_mail_queue ( status, next_attempt_at );

prompt File: wrk_mail_queue.tab.sql <end>
