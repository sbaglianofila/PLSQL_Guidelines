prompt ------------------------------------------------------------

prompt File: cfg_gate_objects.tab.sql <start>

prompt

-- =============================================================================
-- File:     cfg_gate_objects.tab.sql
-- Oggetto:  cfg_gate_objects (tabella)
-- Schema:   #APP#
-- Scopo:    La lista bianca degli oggetti interrogabili dalla regola DATA_READY,
--           l'unico check di lib_gate che usa SQL dinamico. Un oggetto non elencato
--           qui non è interrogabile, punto.
-- Nota:     Questa tabella è un controllo di SICUREZZA, non una comodità. Senza,
--           DATA_READY sarebbe una porta aperta: chi ottiene la scrittura su
--           cfg_gate_rules otterrebbe di fatto l'esecuzione di SQL arbitrario nello
--           schema owner. Il nome resta comunque validato con dbms_assert prima di
--           entrare nella statement (difesa in profondità: la lista bianca dice
--           QUALI oggetti, dbms_assert dice che il testo è un identificatore e non
--           un'iniezione). Vedi PlSql_Guidelines/09_language_usage_dynamic_sql.md.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260729  AA   Creazione
-- =============================================================================

prompt -- Creating table

create table cfg_gate_objects
   ( object_name   varchar2(128 char)   constraint cfg_gate_objects_nn_object_name  not null
   , note          varchar2(512 char)
   -- Colonne amministrative: blocco fisso, popolato dal trigger
   -- (vedi Architettura_DB/colonne_amministrative.md).
   , row_version   number               default 1  constraint cfg_gate_objects_nn_row_version  not null
   , created_by    varchar2(64 char)    invisible  constraint cfg_gate_objects_nn_created_by   not null
   , created_at    timestamp(6)         invisible  constraint cfg_gate_objects_nn_created_at   not null
   , created_app   varchar2(64 char)    invisible  constraint cfg_gate_objects_nn_created_app  not null
   , modified_by   varchar2(64 char)    invisible
   , modified_at   timestamp(6)         invisible
   , modified_app  varchar2(64 char)    invisible
   );

prompt -- Adding constraints

alter table cfg_gate_objects
   add constraint cfg_gate_objects_pk primary key ( object_name )
   using index;

-- Il nome è confrontato in maiuscolo dal check DATA_READY: lo si impone in
-- scrittura invece di normalizzare in lettura, così la chiave primaria è davvero
-- univoca e non esistono due righe che differiscono solo per il caso.
alter table cfg_gate_objects
   add constraint cfg_gate_objects_ck_upper check ( object_name = upper(object_name) );

prompt -- Adding comments

comment on table  cfg_gate_objects              is 'Lista bianca degli oggetti interrogabili dalla regola DATA_READY di lib_gate: controllo di sicurezza sull''unico check che usa SQL dinamico.';
comment on column cfg_gate_objects.object_name  is 'Nome dell''oggetto (tabella o vista) su cui DATA_READY può contare le righe, in maiuscolo e senza qualificazione di schema.';
comment on column cfg_gate_objects.note         is 'Quale processo usa questo oggetto come sorgente e perché è stato ammesso.';
-- Colonne amministrative (standard su ogni tabella; vedi colonne_amministrative.md)
comment on column cfg_gate_objects.row_version  is 'Versione della riga per il locking ottimistico, incrementata dal trigger a ogni modifica.';
comment on column cfg_gate_objects.created_by   is 'Utente applicativo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column cfg_gate_objects.created_at   is 'Istante dell''inserimento (invisibile, impostata dal trigger).';
comment on column cfg_gate_objects.created_app  is 'Programma/modulo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column cfg_gate_objects.modified_by  is 'Utente applicativo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column cfg_gate_objects.modified_at  is 'Istante dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column cfg_gate_objects.modified_app is 'Programma/modulo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';

prompt File: cfg_gate_objects.tab.sql <end>

prompt
