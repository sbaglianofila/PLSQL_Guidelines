prompt ------------------------------------------------------------

prompt File: wfl_transition_guards.tab.sql <start>

prompt

-- =============================================================================
-- File:     wfl_transition_guards.tab.sql
-- Oggetto:  wfl_transition_guards (tabella)
-- Schema:   #APP#
-- Scopo:    Le guardie di una transizione: le condizioni sui DATI che devono
--           valere perché l'azione sia ammessa, oltre allo stato e al ruolo.
--           Tabella ponte, gemella di wfl_transition_roles: i ruoli guardano il
--           CHI, le guardie guardano SE i dati lo consentono. Una guardia NON è
--           una condizione espressa come dato (niente operatori/soglie in tabella):
--           è un puntatore a codice PL/SQL compilato, un guard_code logico smistato
--           dal dispatcher unico del workflow (wfl_workflows.guard_handler) che
--           ritorna vero/falso. Più guardie sulla stessa transizione sono in AND;
--           nessuna riga significa nessuna guardia. Alla negazione si solleva il
--           deny_message_code (cfg_messages), così la regola spiega da sé perché
--           ha bloccato (vedi Architettura_DB/stati_workflow.md).
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260725  AA   Creazione
-- =============================================================================

prompt -- Creating table

create table wfl_transition_guards
   ( workflow_code      varchar2(32 char)   constraint wfl_transition_guards_nn_workflow  not null
   , transition_code    varchar2(32 char)   constraint wfl_transition_guards_nn_trans     not null
   , guard_code         varchar2(32 char)   constraint wfl_transition_guards_nn_guard     not null
   , deny_message_code  varchar2(32 char)   constraint wfl_transition_guards_nn_deny      not null
   , sort_order         number              constraint wfl_transition_guards_nn_sort      not null
   -- Colonne amministrative: blocco fisso, popolato dal trigger
   -- (vedi Architettura_DB/colonne_amministrative.md).
   , row_version       number               default 1  constraint wfl_transition_guards_nn_row_version  not null
   , created_by        varchar2(64 char)    invisible  constraint wfl_transition_guards_nn_created_by   not null
   , created_at        timestamp(6)         invisible  constraint wfl_transition_guards_nn_created_at   not null
   , created_app       varchar2(64 char)    invisible  constraint wfl_transition_guards_nn_created_app  not null
   , modified_by       varchar2(64 char)    invisible
   , modified_at       timestamp(6)         invisible
   , modified_app      varchar2(64 char)    invisible
   );

prompt -- Adding defaults

alter table wfl_transition_guards
   modify ( sort_order  default 0 );

prompt -- Adding constraints

alter table wfl_transition_guards
   add constraint wfl_transition_guards_pk primary key ( workflow_code, transition_code, guard_code )
   using index;

prompt -- Adding comments

comment on table  wfl_transition_guards                   is 'Le guardie (condizioni sui dati) di una transizione: guard_code logico valutato dal dispatcher del workflow. Più guardie in AND; nessuna riga = nessuna guardia. Letta da lib_workflow.';
comment on column wfl_transition_guards.workflow_code     is 'Workflow di appartenenza (parte della foreign key verso wfl_transitions).';
comment on column wfl_transition_guards.transition_code   is 'Transizione a cui la guardia si applica (parte della foreign key verso wfl_transitions).';
comment on column wfl_transition_guards.guard_code        is 'Nome logico della regola (es. AMOUNT_UNDER_LIMIT); passato al dispatcher wfl_workflows.guard_handler, non è un nome di codice.';
comment on column wfl_transition_guards.deny_message_code is 'Codice cfg_messages sollevato (sotto k_NOT_ALLOWED) quando la guardia nega: è la regola stessa a spiegare perché ha bloccato.';
comment on column wfl_transition_guards.sort_order        is 'Ordine di valutazione delle guardie della transizione.';
-- Colonne amministrative (standard su ogni tabella; vedi colonne_amministrative.md)
comment on column wfl_transition_guards.row_version       is 'Versione della riga per il locking ottimistico, incrementata dal trigger a ogni modifica.';
comment on column wfl_transition_guards.created_by        is 'Utente applicativo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column wfl_transition_guards.created_at        is 'Istante dell''inserimento (invisibile, impostata dal trigger).';
comment on column wfl_transition_guards.created_app       is 'Programma/modulo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column wfl_transition_guards.modified_by       is 'Utente applicativo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column wfl_transition_guards.modified_at       is 'Istante dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column wfl_transition_guards.modified_app      is 'Programma/modulo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';

prompt File: wfl_transition_guards.tab.sql <end>

prompt
