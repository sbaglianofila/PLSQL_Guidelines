prompt ------------------------------------------------------------

prompt File: log_process_runs.tab.sql <start>

prompt

-- =============================================================================
-- File:     log_process_runs.tab.sql
-- Oggetto:  log_process_runs (tabella)
-- Schema:   #APP#
-- Scopo:    Un'esecuzione tracciata per ogni run di batch, gestita da lib_batch:
--           inizio, fine, esito e contatori. Permette all'AM di rispondere a
--           "com'è andato il batch di stanotte?" con una query invece che con
--           un'indagine. Letta dalla query di controllo "esito e durata delle
--           ultime esecuzioni" e dal check DEPENDENCY di lib_gate, che qui cerca
--           l'ultima esecuzione riuscita del processo predecessore.
-- Nota:     Le righe sono scritte da lib_batch in TRANSAZIONE AUTONOMA, quindi
--           sopravvivono al rollback dell'elaborazione che registrano: un registro
--           di esecuzioni annullabile dall'elaborazione stessa non risponderebbe
--           alla domanda per cui esiste. La conseguenza pratica è che un test non
--           può contare sul rollback per ripulirle.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260705  AA   Creazione
--   20260729  AA   Aggiunto lo stato SKIPPED (esito di una precondizione lib_gate
--                  non soddisfatta con severity SKIP)
-- =============================================================================

prompt -- Creating table

create table log_process_runs
   ( run_id           number(24)          generated always as identity  constraint log_process_runs_nn_run_id   not null
   , process_name     varchar2(128 char)  constraint log_process_runs_nn_process  not null
   , started_at       timestamp(6)        constraint log_process_runs_nn_started  not null
   , ended_at         timestamp(6)
   , status           varchar2(32 char)   constraint log_process_runs_nn_status   not null
   , rows_processed   number
   , rows_rejected    number
   , error_message    varchar2(4000 char)
   , previous_run_id  number(24)
   , actor            varchar2(128 char)
   );

prompt -- Adding defaults

alter table log_process_runs
   modify ( started_at      default systimestamp
          , rows_processed  default 0
          , rows_rejected   default 0
          );

prompt -- Adding constraints

alter table log_process_runs
   add constraint log_process_runs_pk primary key ( run_id )
   using index;

alter table log_process_runs
   add constraint log_process_runs_ck_status check ( status in ( 'RUNNING', 'SUCCESS', 'FAILED', 'SKIPPED' ) );

prompt -- Adding comments

comment on table  log_process_runs                 is 'Ciclo di vita delle esecuzioni batch gestite da lib_batch: inizio, fine, esito e contatori.';
comment on column log_process_runs.run_id          is 'Chiave surrogata, identity generata; restituita da lib_batch.start_run.';
comment on column log_process_runs.process_name    is 'Nome logico del processo in esecuzione.';
comment on column log_process_runs.started_at      is 'Istante di inizio dell''esecuzione.';
comment on column log_process_runs.ended_at        is 'Istante di fine dell''esecuzione; nullo finché è RUNNING.';
comment on column log_process_runs.status          is 'Esito dell''esecuzione: RUNNING, SUCCESS, FAILED oppure SKIPPED quando una precondizione di lib_gate con severity SKIP ha fatto uscire il processo prima del suo corpo.';
comment on column log_process_runs.rows_processed  is 'Numero di righe elaborate con successo.';
comment on column log_process_runs.rows_rejected   is 'Numero di righe scartate durante l''elaborazione.';
comment on column log_process_runs.error_message   is 'Perché l''esecuzione non è finita in SUCCESS: il testo dell''errore quando è chiusa come FAILED, la precondizione che ha fatto uscire quando è SKIPPED. Una colonna sola perché la domanda dell''AM è la stessa nei due casi.';
comment on column log_process_runs.previous_run_id is 'run_id dell''esecuzione precedente dello stesso processo, per il concatenamento.';
comment on column log_process_runs.actor           is 'Attore effettivo che ha aperto l''esecuzione.';

prompt -- Creating indexes

create index log_process_runs_idx_process on log_process_runs ( process_name, started_at );

prompt File: log_process_runs.tab.sql <end>

prompt
