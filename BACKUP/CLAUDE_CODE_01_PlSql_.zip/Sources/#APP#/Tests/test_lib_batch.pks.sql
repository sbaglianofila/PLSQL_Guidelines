prompt File: test_lib_batch.pks.sql <start>
-- =============================================================================
-- File:     test_lib_batch.pks.sql
-- Object:   test_lib_batch (utPLSQL suite specification)
-- Schema:   #APP# (dev/test environments only)
-- Purpose:  Unit tests for lib_batch.
-- -----------------------------------------------------------------------------
-- Changelog (authoritative history: version control)
--   Date      Aut  Change
--   20260705  AA   Creation
--   20260729  AA   Cleanup extended to log_process_runs (rows are now written
--                  autonomously); added skip_run and check_gate cases
-- =============================================================================

prompt test_lib_batch: Creating test package specification
create or replace package test_lib_batch is

--%suite(lib_batch)
--%suitepath(#APP#.base)

-- Removes the rows the tests committed autonomously: the log entries AND the run
-- rows, which since lib_batch writes them in an autonomous transaction are no
-- longer undone by the rollback utPLSQL performs between tests.
--%aftereach
procedure cleanup;

--%test(start_run opens a RUNNING run)
procedure start_run_opens_running;

-- Manual rollback: il test ne esegue uno esplicito, e il rollback automatico di
-- utPLSQL lavora su un savepoint che quello invaliderebbe. Non serve pulizia
-- aggiuntiva perché l'unica cosa che il test scrive sono righe autonome, già a
-- carico di cleanup.
--%test(the run row survives a rollback of the calling transaction)
--%rollback(manual)
procedure run_survives_rollback;

--%test(end_run closes the run as SUCCESS with counters)
procedure end_run_closes_success;

--%test(fail_run closes the run as FAILED)
procedure fail_run_closes_failed;

--%test(skip_run closes the run as SKIPPED with the reason)
procedure skip_run_closes_skipped;

--%test(check_gate returns true and leaves the run open when no rule blocks)
procedure check_gate_allows_run;

--%test(check_gate closes the run as SKIPPED and returns false on a SKIP verdict)
procedure check_gate_skips_run;

--%test(check_gate raises PRECONDITION_FAILED on an ABORT verdict)
--%throws(-20015)
procedure check_gate_aborts;

end test_lib_batch;
/
show errors package test_lib_batch

prompt File: test_lib_batch.pks.sql <end>
