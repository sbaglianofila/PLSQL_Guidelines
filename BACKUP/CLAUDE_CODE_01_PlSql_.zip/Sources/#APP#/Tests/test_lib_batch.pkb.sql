prompt File: test_lib_batch.pkb.sql <start>
-- =============================================================================
-- File:     test_lib_batch.pkb.sql
-- Object:   test_lib_batch (utPLSQL suite body)
-- Schema:   #APP# (dev/test environments only)
-- Purpose:  Unit tests for lib_batch. Both the run rows and the log entries are
--           committed autonomously, so neither is undone by the rollback utPLSQL
--           performs between tests: cleanup removes both explicitly.
-- Note:     The gate rules used by the check_gate cases are ordinary DML on
--           cfg_gate_rules and are rolled back; they are visible to lib_gate
--           because it reads them in the same transaction.
-- -----------------------------------------------------------------------------
-- Changelog (authoritative history: version control)
--   Date      Aut  Change
--   20260705  AA   Creation
--   20260729  AA   Cleanup extended to log_process_runs; added skip_run and
--                  check_gate cases
-- =============================================================================

prompt test_lib_batch: Creating test package body
create or replace package body test_lib_batch is

k_PROCESS  constant lib_types.name_sbt := 'UT_LIB_BATCH';

procedure add_rule( i_rule_code in varchar2
                  , i_severity  in varchar2
                  , i_param_1   in varchar2
                  ) is
begin
   insert into cfg_gate_rules ( process_name, rule_seq, rule_code, severity, param_1 )
   values ( k_PROCESS, 10, i_rule_code, i_severity, i_param_1 );
end add_rule;

procedure cleanup is
   pragma autonomous_transaction;
begin
   delete from log_error_details led
    where led.event_id in (select lev.event_id from log_events lev where lev.message like '%' || k_PROCESS || '%');
   delete from log_events lev where lev.message like '%' || k_PROCESS || '%';
   delete from log_process_runs lpr where lpr.process_name = k_PROCESS;
   commit;
end cleanup;

procedure start_run_opens_running is
   l_run_id  log_process_runs.run_id%type;
   l_status  log_process_runs.status%type;
begin
   l_run_id := lib_batch.start_run(i_process_name => k_PROCESS);
   ut.expect(l_run_id).to_be_not_null;

   select lpr.status
     into l_status
     from log_process_runs lpr
    where lpr.run_id = l_run_id;

   ut.expect(l_status).to_equal('RUNNING');
end start_run_opens_running;

procedure run_survives_rollback is
   l_run_id  log_process_runs.run_id%type;
   l_count   pls_integer;
begin
   -- È la ragione per cui le scritture sono autonome: un'elaborazione che esplode
   -- e viene annullata non deve poter cancellare la prova di essere esistita.
   l_run_id := lib_batch.start_run(i_process_name => k_PROCESS);
   lib_batch.fail_run(i_run_id => l_run_id, i_error_message => 'boom ' || k_PROCESS);

   rollback;

   select count(*)
     into l_count
     from log_process_runs lpr
    where lpr.run_id = l_run_id
      and lpr.status = 'FAILED';

   ut.expect(l_count).to_equal(1);
end run_survives_rollback;

procedure end_run_closes_success is
   l_run_id  log_process_runs.run_id%type;
   l_status  log_process_runs.status%type;
   l_rows    log_process_runs.rows_processed%type;
begin
   l_run_id := lib_batch.start_run(i_process_name => k_PROCESS);
   lib_batch.end_run(i_run_id => l_run_id, i_rows_processed => 5);

   select lpr.status
        , lpr.rows_processed
     into l_status
        , l_rows
     from log_process_runs lpr
    where lpr.run_id = l_run_id;

   ut.expect(l_status).to_equal('SUCCESS');
   ut.expect(l_rows).to_equal(5);
end end_run_closes_success;

procedure fail_run_closes_failed is
   l_run_id  log_process_runs.run_id%type;
   l_status  log_process_runs.status%type;
   l_message log_process_runs.error_message%type;
begin
   l_run_id := lib_batch.start_run(i_process_name => k_PROCESS);
   lib_batch.fail_run(i_run_id => l_run_id, i_error_message => 'boom ' || k_PROCESS);

   select lpr.status
        , lpr.error_message
     into l_status
        , l_message
     from log_process_runs lpr
    where lpr.run_id = l_run_id;

   ut.expect(l_status).to_equal('FAILED');
   ut.expect(l_message).to_be_like('boom%');
end fail_run_closes_failed;

procedure skip_run_closes_skipped is
   l_run_id  log_process_runs.run_id%type;
   l_status  log_process_runs.status%type;
   l_message log_process_runs.error_message%type;
begin
   l_run_id := lib_batch.start_run(i_process_name => k_PROCESS);
   lib_batch.skip_run(i_run_id => l_run_id, i_reason => 'niente da fare ' || k_PROCESS);

   select lpr.status
        , lpr.error_message
     into l_status
        , l_message
     from log_process_runs lpr
    where lpr.run_id = l_run_id;

   ut.expect(l_status).to_equal('SKIPPED');
   ut.expect(l_message).to_be_like('niente da fare%');
end skip_run_closes_skipped;

procedure check_gate_allows_run is
   l_run_id  log_process_runs.run_id%type;
   l_status  log_process_runs.status%type;
   l_go      boolean;
begin
   add_rule(i_rule_code => 'ENVIRONMENT', i_severity => 'ABORT', i_param_1 => lib_config.environment);

   l_run_id := lib_batch.start_run(i_process_name => k_PROCESS);
   l_go     := lib_batch.check_gate(i_run_id => l_run_id, i_process_name => k_PROCESS);

   ut.expect(l_go).to_be_true;

   select lpr.status
     into l_status
     from log_process_runs lpr
    where lpr.run_id = l_run_id;

   -- Il run resta aperto: il gate che dà via libera non chiude niente.
   ut.expect(l_status).to_equal('RUNNING');

   lib_batch.end_run(i_run_id => l_run_id);
end check_gate_allows_run;

procedure check_gate_skips_run is
   l_run_id  log_process_runs.run_id%type;
   l_status  log_process_runs.status%type;
   l_go      boolean;
begin
   add_rule(i_rule_code => 'ENVIRONMENT', i_severity => 'SKIP', i_param_1 => 'NO_SUCH_ENV');

   l_run_id := lib_batch.start_run(i_process_name => k_PROCESS);
   l_go     := lib_batch.check_gate(i_run_id => l_run_id, i_process_name => k_PROCESS);

   ut.expect(l_go).to_be_false;

   select lpr.status
     into l_status
     from log_process_runs lpr
    where lpr.run_id = l_run_id;

   -- Il run è già chiuso: al chiamante resta solo da uscire.
   ut.expect(l_status).to_equal('SKIPPED');
end check_gate_skips_run;

procedure check_gate_aborts is
   l_run_id  log_process_runs.run_id%type;
   l_go      boolean;
begin
   add_rule(i_rule_code => 'ENVIRONMENT', i_severity => 'ABORT', i_param_1 => 'NO_SUCH_ENV');

   l_run_id := lib_batch.start_run(i_process_name => k_PROCESS);
   l_go     := lib_batch.check_gate(i_run_id => l_run_id, i_process_name => k_PROCESS);
end check_gate_aborts;

end test_lib_batch;
/
show errors package body test_lib_batch

prompt File: test_lib_batch.pkb.sql <end>
