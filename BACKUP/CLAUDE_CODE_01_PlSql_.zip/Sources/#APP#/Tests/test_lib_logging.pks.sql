prompt File: test_lib_logging.pks.sql <start>
-- =============================================================================
-- File:     test_lib_logging.pks.sql
-- Object:   test_lib_logging (utPLSQL suite specification)
-- Schema:   #APP# (dev/test environments only)
-- Purpose:  Unit tests for lib_logging.
-- -----------------------------------------------------------------------------
-- Changelog (authoritative history: version control)
--   Date      Aut  Change
--   20260705  AA   Creation
--   20260708  AA   Add correlation_id test
--   20260708  AA   Add start_proc/end_proc execution_id pairing test
--   20260708  AA   Add cfg_messages catalog overload test
--   20260708  AA   Add Oracle-error override tests
-- =============================================================================

prompt test_lib_logging: Creating test package specification
create or replace package test_lib_logging is

--%suite(lib_logging)
--%suitepath(#APP#.base)

--%beforeall
procedure reset_level;

-- Removes the autonomously committed rows written with the test scope.
--%aftereach
procedure cleanup;

--%test(log_info writes an entry)
procedure log_info_writes;

--%test(log_debug is filtered out at the default INFO level)
procedure log_debug_filtered;

--%test(log_error writes an error row)
procedure log_error_writes;

--%test(log_info stores the supplied correlation_id)
procedure log_info_stores_correlation_id;

--%test(start_proc/end_proc write a START/END pair sharing the execution id)
procedure start_end_pairs_by_execution_id;

--%test(the catalog overload composes the message from cfg_messages)
procedure catalog_overload_composes_message;

--%test(a catalogued Oracle error is logged with its ORACLE override text)
procedure oracle_error_uses_catalog_message;

--%test(an uncatalogued Oracle error is logged with the raw sqlerrm)
procedure oracle_error_uncatalogued_uses_sqlerrm;

end test_lib_logging;
/
show errors package test_lib_logging

prompt File: test_lib_logging.pks.sql <end>
