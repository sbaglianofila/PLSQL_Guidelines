prompt File: test_lib_session.pkb.sql <start>
-- =============================================================================
-- File:     test_lib_session.pkb.sql
-- Object:   test_lib_session (utPLSQL suite body)
-- Schema:   #APP# (dev/test environments only)
-- Purpose:  Unit tests for lib_session.
-- -----------------------------------------------------------------------------
-- Changelog (authoritative history: version control)
--   Date      Aut  Change
--   20260705  AA   Creation
--   20260708  AA   Retarget to set_actor / set_correlation (APP_CTX)
-- =============================================================================

prompt test_lib_session: Creating test package body
create or replace package body test_lib_session is

procedure reset_session is
begin
   -- Undo everything the tests published on the session (clear_session also
   -- clears module and action).
   lib_session.clear_session;
end reset_session;

procedure current_actor_not_null is
begin
   ut.expect(lib_session.current_actor).to_be_not_null;
end current_actor_not_null;

procedure set_step_sets_module is
begin
   lib_session.set_step(i_module => 'UTMOD', i_action => 'UTACT');
   ut.expect(lib_session.current_module).to_equal('UTMOD');
   ut.expect(lib_session.current_action).to_equal('UTACT');
end set_step_sets_module;

procedure set_actor_drives_actor is
begin
   lib_session.set_actor(i_user => 'enduser');
   ut.expect(lib_session.current_actor).to_equal('enduser');
end set_actor_drives_actor;

procedure set_correlation_drives_current is
begin
   lib_session.set_correlation(i_correlation_id => 'CORR-0001');
   ut.expect(lib_session.current_correlation).to_equal('CORR-0001');
end set_correlation_drives_current;

procedure open_close_step_restores is
begin
   lib_session.set_step(i_module => 'OUTER', i_action => 'A1');

   lib_session.open_step(i_action => 'B1');
   ut.expect(lib_session.current_action).to_equal('B1');
   ut.expect(lib_session.current_module).to_equal('OUTER');   -- module unchanged by open_step

   lib_session.close_step;
   ut.expect(lib_session.current_action).to_equal('A1');
   ut.expect(lib_session.current_module).to_equal('OUTER');
end open_close_step_restores;

end test_lib_session;
/
show errors package body test_lib_session

prompt File: test_lib_session.pkb.sql <end>
