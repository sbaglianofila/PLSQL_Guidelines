prompt File: test_lib_session.pks.sql <start>
-- =============================================================================
-- File:     test_lib_session.pks.sql
-- Object:   test_lib_session (utPLSQL suite specification)
-- Schema:   #APP# (dev/test environments only)
-- Purpose:  Unit tests for lib_session.
-- -----------------------------------------------------------------------------
-- Changelog (authoritative history: version control)
--   Date      Aut  Change
--   20260705  AA   Creation
--   20260708  AA   Retarget to set_actor / set_correlation (APP_CTX)
--   20260708  AA   Add push_step/pop_step test
--   20260708  AA   Retarget to open_step/close_step
-- =============================================================================

prompt test_lib_session: Creating test package specification
create or replace package test_lib_session is

--%suite(lib_session)
--%suitepath(#APP#.base)

-- Resets the session attributes touched by the tests.
--%aftereach
procedure reset_session;

--%test(current_actor is never null)
procedure current_actor_not_null;

--%test(set_step publishes module and action)
procedure set_step_sets_module;

--%test(set_actor drives the effective actor)
procedure set_actor_drives_actor;

--%test(set_correlation drives the current correlation)
procedure set_correlation_drives_current;

--%test(open_step sets a nested action and close_step restores the caller's)
procedure open_close_step_restores;

end test_lib_session;
/
show errors package test_lib_session

prompt File: test_lib_session.pks.sql <end>
