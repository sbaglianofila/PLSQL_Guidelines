prompt File: test_lib_gate.pks.sql <start>
-- =============================================================================
-- File:     test_lib_gate.pks.sql
-- Object:   test_lib_gate (utPLSQL suite specification)
-- Schema:   #APP# (dev/test environments only)
-- Purpose:  Unit tests for lib_gate. Covers the three-way verdict, the severity
--           partition, each rule type, the configuration defects that must raise
--           rather than produce a verdict, and the side-effect-free invariant the
--           whole design rests on.
-- -----------------------------------------------------------------------------
-- Changelog (authoritative history: version control)
--   Date      Aut  Change
--   20260729  AA   Creation
-- =============================================================================

prompt test_lib_gate: Creating test package specification
create or replace package test_lib_gate is

--%suite(lib_gate)
--%suitepath(#APP#.base)

-- Commits the catalogue rows the suite relies on: the extra rule type used to
-- reach the else branch of the dispatch, and the DATA_READY whitelist entry. They
-- are committed (not left to the test transaction) because they must be visible to
-- the foreign key and to the checks regardless of savepoints; teardown removes
-- them. The rules themselves are inserted per test as ordinary DML, so each test
-- states its own configuration and utPLSQL rolls it back.
--%beforeall
procedure setup_catalogue;

-- Removes the committed catalogue rows.
--%afterall
procedure teardown_catalogue;

-- Removes the log entries lib_logging wrote autonomously while raising: those
-- survive the rollback and would otherwise pile up run after run.
--%aftereach
procedure cleanup;

--%test(a process with no rules configured is allowed to run)
procedure no_rules_returns_run;

--%test(only SKIP rules failing yields SKIP with the failed rules listed)
procedure only_skip_yields_skip;

--%test(one failing ABORT rule outweighs failing SKIP rules)
procedure abort_outweighs_skip;

--%test(an inactive rule is not evaluated even when it would fail)
procedure inactive_rule_is_ignored;

--%test(all rules are evaluated, not just up to the first failure)
procedure every_rule_is_evaluated;

--%test(ENVIRONMENT passes on the current environment and fails elsewhere)
procedure environment_matches_current;

--%test(TIME_WINDOW spanning midnight holds at 23:30 and at 06:00)
procedure time_window_crosses_midnight;

--%test(TIME_WINDOW with coincident bounds admits only that minute)
procedure time_window_single_minute;

--%test(DAY_OF_WEEK numbers days ISO, 1 = Monday)
procedure day_of_week_is_iso;

--%test(DEPENDENCY is satisfied by a SUCCESS run on the reference date)
procedure dependency_sees_success;

--%test(DEPENDENCY is not satisfied by a FAILED predecessor)
procedure dependency_ignores_failed;

--%test(DEPENDENCY is not satisfied by a SUCCESS run on an earlier date)
procedure dependency_ignores_older_date;

--%test(DATA_READY is satisfied by a whitelisted object holding rows)
procedure data_ready_sees_rows;

--%test(DATA_READY on an object outside the whitelist raises)
--%throws(-20999)
procedure data_ready_outside_whitelist;

--%test(a rule type not handled by the dispatch raises instead of passing silently)
--%throws(-20999)
procedure unknown_rule_code_raises;

--%test(a rule missing its mandatory parameter raises)
--%throws(-20999)
procedure missing_parameter_raises;

--%test(assert_can_run raises PRECONDITION_FAILED when the verdict is not RUN)
--%throws(-20015)
procedure assert_can_run_raises;

--%test(assert_can_run is silent when the verdict is RUN)
procedure assert_can_run_passes;

--%test(evaluate is repeatable: twice in a row gives the same verdict)
procedure evaluate_is_repeatable;

--%test(describe lists the configured rules and marks the inactive ones)
procedure describe_lists_rules;

--%test(evaluate restores the session module and action, on success and on error)
procedure session_step_is_restored;

end test_lib_gate;
/
show errors package test_lib_gate

prompt File: test_lib_gate.pks.sql <end>
