prompt File: test_lib_lookup.pkb.sql <start>
-- =============================================================================
-- File:     test_lib_lookup.pkb.sql
-- Object:   test_lib_lookup (utPLSQL suite body)
-- Schema:   #APP# (dev/test environments only)
-- Purpose:  Unit tests for lib_lookup. Seeds a dedicated set with three values -
--           two valid (one of them the default) and one retired - refreshing the
--           cache so the reads see them.
-- -----------------------------------------------------------------------------
-- Changelog (authoritative history: version control)
--   Date      Aut  Change
--   20260719  AA   Creation
-- =============================================================================

prompt test_lib_lookup: Creating test package body
create or replace package body test_lib_lookup is

k_SET  constant varchar2(32 char) := 'UT_LKP';

procedure seed_lookup is
   pragma autonomous_transaction;
begin
   insert into ref_lookups (lookup_code, name, description)
   values (k_SET, 'Test lookup', 'Set dedicato ai test di lib_lookup');

   -- Due valori validi (PHONE è il default) e uno ritirato (FAX).
   insert into ref_lookup_values (lookup_code, value_code, label, sort_order, is_valid, is_default)
   values (k_SET, 'PHONE', 'Telefono', 10, 'Y', 'Y');

   insert into ref_lookup_values (lookup_code, value_code, label, sort_order, is_valid, is_default)
   values (k_SET, 'MOBILE', 'Cellulare', 20, 'Y', 'N');

   insert into ref_lookup_values (lookup_code, value_code, label, sort_order, is_valid, is_default)
   values (k_SET, 'FAX', 'Fax', 30, 'N', 'N');

   commit;
   lib_lookup.refresh;
end seed_lookup;

procedure remove_lookup is
   pragma autonomous_transaction;
begin
   delete from ref_lookup_values rlv where rlv.lookup_code = k_SET;
   delete from ref_lookups        rl  where rl.lookup_code  = k_SET;
   commit;
   lib_lookup.refresh;
end remove_lookup;

procedure values_of_returns_valid_ordered is
   l_values  lib_lookup.t_values := lib_lookup.values_of(i_lookup_code => k_SET);
begin
   -- Solo i due validi, nell'ordine di sort_order (PHONE prima di MOBILE).
   ut.expect(l_values.count).to_equal(2);
   ut.expect(l_values(1).value_code).to_equal('PHONE');
   ut.expect(l_values(2).value_code).to_equal('MOBILE');
end values_of_returns_valid_ordered;

procedure label_of_returns_label is
begin
   ut.expect(lib_lookup.label_of(i_lookup_code => k_SET, i_value_code => 'MOBILE')).to_equal('Cellulare');
   -- Anche un valore ritirato resta leggibile a video.
   ut.expect(lib_lookup.label_of(i_lookup_code => k_SET, i_value_code => 'FAX')).to_equal('Fax');
end label_of_returns_label;

procedure label_of_unknown_is_null is
begin
   ut.expect(lib_lookup.label_of(i_lookup_code => k_SET, i_value_code => 'NOPE')).to_be_null;
end label_of_unknown_is_null;

procedure is_valid_reflects_flag is
begin
   ut.expect(lib_lookup.is_valid(i_lookup_code => k_SET, i_value_code => 'PHONE')).to_be_true;
   ut.expect(lib_lookup.is_valid(i_lookup_code => k_SET, i_value_code => 'FAX')).to_be_false;
   ut.expect(lib_lookup.is_valid(i_lookup_code => k_SET, i_value_code => 'NOPE')).to_be_false;
end is_valid_reflects_flag;

procedure default_of_returns_default is
begin
   ut.expect(lib_lookup.default_of(i_lookup_code => k_SET)).to_equal('PHONE');
end default_of_returns_default;

procedure unknown_set_is_empty is
   l_values  lib_lookup.t_values := lib_lookup.values_of(i_lookup_code => 'UT_NO_SUCH_SET');
begin
   ut.expect(l_values.count).to_equal(0);
end unknown_set_is_empty;

end test_lib_lookup;
/
show errors package body test_lib_lookup

prompt File: test_lib_lookup.pkb.sql <end>
