prompt File: test_lib_gate.pkb.sql <start>
-- =============================================================================
-- File:     test_lib_gate.pkb.sql
-- Object:   test_lib_gate (utPLSQL suite body)
-- Schema:   #APP# (dev/test environments only)
-- Purpose:  Unit tests for lib_gate. Rule rows are ordinary DML rolled back by
--           utPLSQL; only the catalogue rows and the autonomous log entries need
--           explicit cleanup.
-- Note:     The suite drives lib_gate through configuration, never through
--           parameters of a private routine: it exercises the package the way a
--           process does, so a change in the dispatch is caught here rather than
--           in production at three in the morning.
-- -----------------------------------------------------------------------------
-- Changelog (authoritative history: version control)
--   Date      Aut  Change
--   20260729  AA   Creation
-- =============================================================================

prompt test_lib_gate: Creating test package body
create or replace package body test_lib_gate is

k_PROCESS       constant lib_types.name_sbt := 'UT_LIB_GATE';
k_DEP_PROCESS   constant lib_types.name_sbt := 'UT_LIB_GATE_DEP';
-- Tipo di regola a catalogo ma volutamente NON implementato nel dispatch: è il
-- solo modo di raggiungere il ramo else di evaluate senza toccare la foreign key.
k_UNKNOWN_RULE  constant lib_types.code_sbt := 'UT_NOT_IMPLEMENTED';
-- Oggetto in lista bianca per DATA_READY: si usa una tabella del framework che a
-- questo punto ha certamente righe (il seed dei tipi di regola).
k_READY_OBJECT  constant lib_types.object_name_sbt := 'CFG_GATE_RULE_TYPES';

-- Helper -----------------------------------------------------------------------
procedure add_rule( i_seq       in number
                  , i_rule_code in varchar2
                  , i_severity  in varchar2
                  , i_param_1   in varchar2 default null
                  , i_param_2   in varchar2 default null
                  , i_active    in varchar2 default 'Y'
                  , i_process   in varchar2 default k_PROCESS
                  ) is
begin
   insert into cfg_gate_rules ( process_name, rule_seq, rule_code, severity, param_1, param_2, is_active )
   values ( i_process, i_seq, i_rule_code, i_severity, i_param_1, i_param_2, i_active );
end add_rule;

-- Una finestra oraria che contiene certamente l'istante indicato, espressa come
-- l'ora stessa: evita di dipendere dall'ora in cui la suite viene lanciata.
function window_around(i_when in date) return varchar2 is
begin
   return (to_char(i_when, 'HH24:MI'));
end window_around;

-- Fixture ----------------------------------------------------------------------
procedure setup_catalogue is
   pragma autonomous_transaction;
begin
   merge into cfg_gate_rule_types t
   using ( select k_UNKNOWN_RULE as rule_code from dual ) s
      on (t.rule_code = s.rule_code)
    when not matched then
       insert ( t.rule_code, t.description )
       values ( s.rule_code, 'Rule type used by test_lib_gate to reach the unhandled branch.' );

   merge into cfg_gate_objects t
   using ( select k_READY_OBJECT as object_name from dual ) s
      on (t.object_name = s.object_name)
    when not matched then
       insert ( t.object_name, t.note )
       values ( s.object_name, 'Whitelisted by test_lib_gate.' );

   commit;
end setup_catalogue;

procedure teardown_catalogue is
   pragma autonomous_transaction;
begin
   delete from cfg_gate_rules      cgr where cgr.rule_code   = k_UNKNOWN_RULE;
   delete from cfg_gate_rule_types cgt where cgt.rule_code   = k_UNKNOWN_RULE;
   delete from cfg_gate_objects    cgo where cgo.object_name = k_READY_OBJECT;
   commit;
end teardown_catalogue;

procedure cleanup is
   pragma autonomous_transaction;
begin
   delete from log_error_details led
    where led.event_id in (select lev.event_id from log_events lev where lev.message like '%' || k_PROCESS || '%');
   delete from log_events lev where lev.message like '%' || k_PROCESS || '%';
   commit;
end cleanup;

-- Verdetto ---------------------------------------------------------------------
procedure no_rules_returns_run is
   l_verdict  lib_gate.t_verdict_rec;
begin
   l_verdict := lib_gate.evaluate(i_process_name => k_PROCESS);

   ut.expect(l_verdict.decision).to_equal(lib_gate.k_run);
   ut.expect(l_verdict.failed_rules).to_be_null;
end no_rules_returns_run;

procedure only_skip_yields_skip is
   l_verdict  lib_gate.t_verdict_rec;
begin
   add_rule(i_seq => 10, i_rule_code => 'ENVIRONMENT', i_severity => 'SKIP', i_param_1 => 'NO_SUCH_ENV');

   l_verdict := lib_gate.evaluate(i_process_name => k_PROCESS);

   ut.expect(l_verdict.decision).to_equal(lib_gate.k_skip);
   ut.expect(l_verdict.failed_rules).to_equal('ENVIRONMENT');
   ut.expect(l_verdict.message).to_be_not_null;
end only_skip_yields_skip;

procedure abort_outweighs_skip is
   l_verdict  lib_gate.t_verdict_rec;
begin
   -- Una SKIP fallita e una ABORT fallita: l'anomalia prevale sulla condizione
   -- fisiologica, indipendentemente dall'ordine di valutazione.
   add_rule(i_seq => 10, i_rule_code => 'ENVIRONMENT', i_severity => 'SKIP',  i_param_1 => 'NO_SUCH_ENV');
   add_rule(i_seq => 20, i_rule_code => 'DAY_OF_WEEK', i_severity => 'ABORT', i_param_1 => '0');

   l_verdict := lib_gate.evaluate(i_process_name => k_PROCESS);

   ut.expect(l_verdict.decision).to_equal(lib_gate.k_abort);
end abort_outweighs_skip;

procedure inactive_rule_is_ignored is
   l_verdict  lib_gate.t_verdict_rec;
begin
   add_rule(i_seq => 10, i_rule_code => 'ENVIRONMENT', i_severity => 'ABORT', i_param_1 => 'NO_SUCH_ENV', i_active => 'N');

   l_verdict := lib_gate.evaluate(i_process_name => k_PROCESS);

   ut.expect(l_verdict.decision).to_equal(lib_gate.k_run);
end inactive_rule_is_ignored;

procedure every_rule_is_evaluated is
   l_verdict  lib_gate.t_verdict_rec;
begin
   -- Due regole fallite: entrambe devono comparire, perché fermarsi alla prima
   -- costringerebbe a scoprire i problemi uno per volta, un rilancio alla volta.
   add_rule(i_seq => 10, i_rule_code => 'ENVIRONMENT', i_severity => 'SKIP', i_param_1 => 'NO_SUCH_ENV');
   add_rule(i_seq => 20, i_rule_code => 'DAY_OF_WEEK', i_severity => 'SKIP', i_param_1 => '0');

   l_verdict := lib_gate.evaluate(i_process_name => k_PROCESS);

   ut.expect(l_verdict.failed_rules).to_equal('ENVIRONMENT,DAY_OF_WEEK');
end every_rule_is_evaluated;

-- Singoli tipi di regola --------------------------------------------------------
procedure environment_matches_current is
   l_verdict  lib_gate.t_verdict_rec;
begin
   add_rule(i_seq => 10, i_rule_code => 'ENVIRONMENT', i_severity => 'ABORT', i_param_1 => lib_config.environment);

   l_verdict := lib_gate.evaluate(i_process_name => k_PROCESS);
   ut.expect(l_verdict.decision).to_equal(lib_gate.k_run);

   update cfg_gate_rules cgr
      set cgr.param_1 = 'NO_SUCH_ENV'
    where cgr.process_name = k_PROCESS
      and cgr.rule_seq     = 10;

   l_verdict := lib_gate.evaluate(i_process_name => k_PROCESS);
   ut.expect(l_verdict.decision).to_equal(lib_gate.k_abort);
end environment_matches_current;

procedure time_window_crosses_midnight is
   l_verdict  lib_gate.t_verdict_rec;
   k_LATE  constant date := to_date('2026-03-10 23:30', 'YYYY-MM-DD HH24:MI');
   k_EARLY constant date := to_date('2026-03-10 06:00', 'YYYY-MM-DD HH24:MI');
   k_NOON  constant date := to_date('2026-03-10 12:00', 'YYYY-MM-DD HH24:MI');
begin
   add_rule(i_seq => 10, i_rule_code => 'TIME_WINDOW', i_severity => 'SKIP', i_param_1 => '22:00', i_param_2 => '07:00');

   l_verdict := lib_gate.evaluate(i_process_name => k_PROCESS, i_ref_date => k_LATE);
   ut.expect(l_verdict.decision).to_equal(lib_gate.k_run);

   l_verdict := lib_gate.evaluate(i_process_name => k_PROCESS, i_ref_date => k_EARLY);
   ut.expect(l_verdict.decision).to_equal(lib_gate.k_run);

   -- Mezzogiorno è fuori: con una finestra a cavallo della mezzanotte, "dentro"
   -- significa dopo l'inizio OPPURE prima della fine, mai fra i due.
   l_verdict := lib_gate.evaluate(i_process_name => k_PROCESS, i_ref_date => k_NOON);
   ut.expect(l_verdict.decision).to_equal(lib_gate.k_skip);
end time_window_crosses_midnight;

procedure time_window_single_minute is
   l_verdict  lib_gate.t_verdict_rec;
   k_WHEN  constant date := to_date('2026-03-10 08:15', 'YYYY-MM-DD HH24:MI');
   k_OTHER constant date := to_date('2026-03-10 08:16', 'YYYY-MM-DD HH24:MI');
begin
   add_rule( i_seq => 10, i_rule_code => 'TIME_WINDOW', i_severity => 'SKIP'
           , i_param_1 => window_around(k_WHEN), i_param_2 => window_around(k_WHEN) );

   l_verdict := lib_gate.evaluate(i_process_name => k_PROCESS, i_ref_date => k_WHEN);
   ut.expect(l_verdict.decision).to_equal(lib_gate.k_run);

   l_verdict := lib_gate.evaluate(i_process_name => k_PROCESS, i_ref_date => k_OTHER);
   ut.expect(l_verdict.decision).to_equal(lib_gate.k_skip);
end time_window_single_minute;

procedure day_of_week_is_iso is
   l_verdict  lib_gate.t_verdict_rec;
   -- 2026-03-09 è un lunedì: ISO 1, qualunque sia NLS_TERRITORY.
   k_MONDAY  constant date := to_date('2026-03-09', 'YYYY-MM-DD');
   k_SUNDAY  constant date := to_date('2026-03-15', 'YYYY-MM-DD');
begin
   add_rule(i_seq => 10, i_rule_code => 'DAY_OF_WEEK', i_severity => 'SKIP', i_param_1 => '1');

   l_verdict := lib_gate.evaluate(i_process_name => k_PROCESS, i_ref_date => k_MONDAY);
   ut.expect(l_verdict.decision).to_equal(lib_gate.k_run);

   l_verdict := lib_gate.evaluate(i_process_name => k_PROCESS, i_ref_date => k_SUNDAY);
   ut.expect(l_verdict.decision).to_equal(lib_gate.k_skip);
end day_of_week_is_iso;

procedure dependency_sees_success is
   l_verdict  lib_gate.t_verdict_rec;
begin
   insert into log_process_runs ( process_name, status, started_at, ended_at )
   values ( k_DEP_PROCESS, 'SUCCESS', systimestamp, systimestamp );

   add_rule(i_seq => 10, i_rule_code => 'DEPENDENCY', i_severity => 'ABORT', i_param_1 => k_DEP_PROCESS);

   l_verdict := lib_gate.evaluate(i_process_name => k_PROCESS);
   ut.expect(l_verdict.decision).to_equal(lib_gate.k_run);
end dependency_sees_success;

procedure dependency_ignores_failed is
   l_verdict  lib_gate.t_verdict_rec;
begin
   insert into log_process_runs ( process_name, status, started_at, ended_at )
   values ( k_DEP_PROCESS, 'FAILED', systimestamp, systimestamp );

   add_rule(i_seq => 10, i_rule_code => 'DEPENDENCY', i_severity => 'ABORT', i_param_1 => k_DEP_PROCESS);

   l_verdict := lib_gate.evaluate(i_process_name => k_PROCESS);
   ut.expect(l_verdict.decision).to_equal(lib_gate.k_abort);
end dependency_ignores_failed;

procedure dependency_ignores_older_date is
   l_verdict  lib_gate.t_verdict_rec;
begin
   -- Riuscito, ma ieri: senza param_2 la semantica è "nella stessa giornata", e
   -- un predecessore di ieri non autorizza il carico di oggi.
   insert into log_process_runs ( process_name, status, started_at, ended_at )
   values ( k_DEP_PROCESS, 'SUCCESS', systimestamp - 1, systimestamp - 1 );

   add_rule(i_seq => 10, i_rule_code => 'DEPENDENCY', i_severity => 'ABORT', i_param_1 => k_DEP_PROCESS);

   l_verdict := lib_gate.evaluate(i_process_name => k_PROCESS);
   ut.expect(l_verdict.decision).to_equal(lib_gate.k_abort);
end dependency_ignores_older_date;

procedure data_ready_sees_rows is
   l_verdict  lib_gate.t_verdict_rec;
begin
   add_rule(i_seq => 10, i_rule_code => 'DATA_READY', i_severity => 'SKIP', i_param_1 => k_READY_OBJECT);

   l_verdict := lib_gate.evaluate(i_process_name => k_PROCESS);
   ut.expect(l_verdict.decision).to_equal(lib_gate.k_run);
end data_ready_sees_rows;

procedure data_ready_outside_whitelist is
   l_verdict  lib_gate.t_verdict_rec;
begin
   -- Oggetto reale ed esistente, ma non in lista bianca: deve comunque essere
   -- rifiutato, altrimenti la lista bianca non starebbe proteggendo nulla.
   add_rule(i_seq => 10, i_rule_code => 'DATA_READY', i_severity => 'SKIP', i_param_1 => 'CFG_PARAMETERS');

   l_verdict := lib_gate.evaluate(i_process_name => k_PROCESS);
end data_ready_outside_whitelist;

-- Difetti di configurazione ------------------------------------------------------
procedure unknown_rule_code_raises is
   l_verdict  lib_gate.t_verdict_rec;
begin
   add_rule(i_seq => 10, i_rule_code => k_UNKNOWN_RULE, i_severity => 'SKIP');

   l_verdict := lib_gate.evaluate(i_process_name => k_PROCESS);
end unknown_rule_code_raises;

procedure missing_parameter_raises is
   l_verdict  lib_gate.t_verdict_rec;
begin
   add_rule(i_seq => 10, i_rule_code => 'DEPENDENCY', i_severity => 'ABORT', i_param_1 => null);

   l_verdict := lib_gate.evaluate(i_process_name => k_PROCESS);
end missing_parameter_raises;

-- assert_can_run -----------------------------------------------------------------
procedure assert_can_run_raises is
begin
   -- Severity SKIP: anche l'uscita fisiologica diventa un errore qui, ed è
   -- esattamente il senso di questa variante.
   add_rule(i_seq => 10, i_rule_code => 'ENVIRONMENT', i_severity => 'SKIP', i_param_1 => 'NO_SUCH_ENV');

   lib_gate.assert_can_run(i_process_name => k_PROCESS);
end assert_can_run_raises;

procedure assert_can_run_passes is
begin
   add_rule(i_seq => 10, i_rule_code => 'ENVIRONMENT', i_severity => 'ABORT', i_param_1 => lib_config.environment);

   lib_gate.assert_can_run(i_process_name => k_PROCESS);

   ut.expect(1).to_equal(1);
end assert_can_run_passes;

-- Invarianti ----------------------------------------------------------------------
procedure evaluate_is_repeatable is
   l_first   lib_gate.t_verdict_rec;
   l_second  lib_gate.t_verdict_rec;
begin
   -- L'assenza di effetti collaterali è l'invariante su cui poggia tutto il
   -- disegno: se saltasse, il gate diventerebbe esso stesso una sorgente di stato.
   add_rule(i_seq => 10, i_rule_code => 'ENVIRONMENT', i_severity => 'SKIP', i_param_1 => 'NO_SUCH_ENV');
   add_rule(i_seq => 20, i_rule_code => 'DATA_READY',  i_severity => 'SKIP', i_param_1 => k_READY_OBJECT);

   l_first  := lib_gate.evaluate(i_process_name => k_PROCESS);
   l_second := lib_gate.evaluate(i_process_name => k_PROCESS);

   ut.expect(l_second.decision).to_equal(l_first.decision);
   ut.expect(l_second.failed_rules).to_equal(l_first.failed_rules);
   ut.expect(l_second.message).to_equal(l_first.message);
end evaluate_is_repeatable;

procedure describe_lists_rules is
   l_text  lib_types.big_string_sbt;
begin
   ut.expect(lib_gate.describe(i_process_name => k_PROCESS)).to_be_like('Nessuna regola configurata%');

   add_rule(i_seq => 10, i_rule_code => 'ENVIRONMENT', i_severity => 'ABORT', i_param_1 => 'PROD');
   add_rule(i_seq => 20, i_rule_code => 'DAY_OF_WEEK', i_severity => 'SKIP',  i_param_1 => '1', i_active => 'N');

   l_text := lib_gate.describe(i_process_name => k_PROCESS);

   ut.expect(l_text).to_be_like('%ENVIRONMENT%');
   -- La regola spenta compare marcata: è spesso proprio lei la risposta alla
   -- domanda "perché questo processo non parte?".
   ut.expect(l_text).to_be_like('%DAY_OF_WEEK%[DISATTIVA]%');
end describe_lists_rules;

procedure session_step_is_restored is
   k_MODULE  constant lib_types.name_sbt := 'UT_GATE_MOD';
   k_ACTION  constant lib_types.code_sbt := 'UT_GATE_ACT';
   l_verdict lib_gate.t_verdict_rec;
begin
   -- Uscita normale.
   lib_session.set_step(i_module => k_MODULE, i_action => k_ACTION);
   l_verdict := lib_gate.evaluate(i_process_name => k_PROCESS);

   ut.expect(lib_session.current_module).to_equal(k_MODULE);
   ut.expect(lib_session.current_action).to_equal(k_ACTION);

   -- Uscita per eccezione: lo stack dei passi deve richiudersi comunque, altrimenti
   -- la sessione resta strumentata su una regola che non è più in corso.
   add_rule(i_seq => 10, i_rule_code => k_UNKNOWN_RULE, i_severity => 'SKIP');

   lib_session.set_step(i_module => k_MODULE, i_action => k_ACTION);
   begin
      l_verdict := lib_gate.evaluate(i_process_name => k_PROCESS);
      ut.fail('evaluate avrebbe dovuto sollevare sulla regola non gestita');
   exception
      when lib_err.e_business_error
      then
         null;
   end;

   ut.expect(lib_session.current_module).to_equal(k_MODULE);
   ut.expect(lib_session.current_action).to_equal(k_ACTION);
end session_step_is_restored;

end test_lib_gate;
/
show errors package body test_lib_gate

prompt File: test_lib_gate.pkb.sql <end>
