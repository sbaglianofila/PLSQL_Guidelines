prompt File: test_lib_err.pkb.sql <start>
-- =============================================================================
-- File:     test_lib_err.pkb.sql
-- Object:   test_lib_err (utPLSQL suite body)
-- Schema:   #APP# (dev/test environments only)
-- Purpose:  Unit tests for lib_err. Uses a dedicated scope so the autonomously
--           committed log rows can be cleaned up after each test.
-- -----------------------------------------------------------------------------
-- Changelog (authoritative history: version control)
--   Date      Aut  Change
--   20260705  AA   Creation
--   20260708  AA   Add correlation_id and %1..%10 placeholder tests
--   20260708  AA   Retarget to log_events / log_error_details
-- =============================================================================

prompt test_lib_err: Creating test package body
create or replace package body test_lib_err is

k_SCOPE      constant lib_types.scope_sbt := 'test_lib_err';
-- Unused code inside the infrastructure band, seeded on the fly to test the
-- high placeholders without touching the real catalog rows.
k_TEMP_CODE  constant pls_integer := -20050;

-- Inserts (autonomous) a temporary catalog row so message_of can read it.
procedure seed_temp_message(i_template in varchar2) is
   pragma autonomous_transaction;
begin
   merge into cfg_error_messages t
   using ( select k_TEMP_CODE as error_code from dual ) s
      on (t.error_code = s.error_code)
    when matched then
       update set t.message_template = i_template
    when not matched then
       insert (error_code, error_name, message_template)
       values (k_TEMP_CODE, 'UT_TEMP', i_template);
   commit;
end seed_temp_message;

procedure cleanup is
   pragma autonomous_transaction;
begin
   delete from log_error_details led
    where led.event_id in (select lev.event_id from log_events lev where lev.scope = k_SCOPE);
   delete from log_events lev where lev.scope = k_SCOPE;
   delete from cfg_error_messages cem where cem.error_code = k_TEMP_CODE;
   commit;
end cleanup;

procedure message_of_substitutes is
   l_actual  varchar2(4000 char);
begin
   l_actual := lib_err.message_of( i_error => lib_err.k_INVALID_PARAMETER
                                 , i_p1    => 'age'
                                 , i_p2    => '-1'
                                 );
   ut.expect(l_actual).to_equal('Invalid parameter age: -1');
end message_of_substitutes;

procedure message_of_high_placeholders is
   l_actual  varchar2(4000 char);
begin
   seed_temp_message(i_template => 'A %1 B %10 C');

   l_actual := lib_err.message_of( i_error => k_TEMP_CODE
                                 , i_p1    => 'one'
                                 , i_p2    => 'two'
                                 , i_p3    => 'three'
                                 , i_p4    => 'four'
                                 , i_p5    => 'five'
                                 , i_p6    => 'six'
                                 , i_p7    => 'seven'
                                 , i_p8    => 'eight'
                                 , i_p9    => 'nine'
                                 , i_p10   => 'ten'
                                 );
   ut.expect(l_actual).to_equal('A one B ten C');
end message_of_high_placeholders;

procedure raise_signals_code is
begin
   lib_err.raise(i_error => lib_err.k_LOCK_REQUEST_FAILED, i_p1 => 'UT', i_scope => k_SCOPE);
end raise_signals_code;

procedure raise_writes_error_row is
   l_count  pls_integer;
begin
   begin
      lib_err.raise(i_error => lib_err.k_STALE_DATA, i_scope => k_SCOPE);
   exception
      when lib_err.e_stale_data
      then
         null;
   end;

   select count(*)
     into l_count
     from log_events lev
    where lev.scope     = k_SCOPE
      and lev.log_level = 'ERROR';

   ut.expect(l_count).to_be_greater_than(0);
end raise_writes_error_row;

procedure raise_logs_correlation_id is
   k_CORR   constant lib_types.correlation_id_sbt := 'UT-CORR-0001';
   l_count  pls_integer;
begin
   begin
      lib_err.raise( i_error          => lib_err.k_STALE_DATA
                   , i_correlation_id => k_CORR
                   , i_scope          => k_SCOPE
                   );
   exception
      when lib_err.e_stale_data
      then
         null;
   end;

   select count(*)
     into l_count
     from log_events lev
    where lev.scope          = k_SCOPE
      and lev.correlation_id = k_CORR;

   ut.expect(l_count).to_equal(1);
end raise_logs_correlation_id;

end test_lib_err;
/
show errors package body test_lib_err

prompt File: test_lib_err.pkb.sql <end>
