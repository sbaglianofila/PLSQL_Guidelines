prompt File: test_lib_lookup.pks.sql <start>
-- =============================================================================
-- File:     test_lib_lookup.pks.sql
-- Object:   test_lib_lookup (utPLSQL suite specification)
-- Schema:   #APP# (dev/test environments only)
-- Purpose:  Unit tests for lib_lookup.
-- -----------------------------------------------------------------------------
-- Changelog (authoritative history: version control)
--   Date      Aut  Change
--   20260719  AA   Creation
-- =============================================================================

prompt test_lib_lookup: Creating test package specification
create or replace package test_lib_lookup is

--%suite(lib_lookup)
--%suitepath(#APP#.base)

-- Seeds and removes a dedicated test set (header + values), refreshing the cache.
--%beforeall
procedure seed_lookup;

--%afterall
procedure remove_lookup;

--%test(values_of returns only the valid values, ordered by sort_order)
procedure values_of_returns_valid_ordered;

--%test(label_of returns the label, including for a retired value)
procedure label_of_returns_label;

--%test(label_of returns null for an unknown code)
procedure label_of_unknown_is_null;

--%test(is_valid is true for a valid code and false for a retired one)
procedure is_valid_reflects_flag;

--%test(default_of returns the default value code)
procedure default_of_returns_default;

--%test(an unknown set yields an empty list and no error)
procedure unknown_set_is_empty;

end test_lib_lookup;
/
show errors package test_lib_lookup

prompt File: test_lib_lookup.pks.sql <end>
