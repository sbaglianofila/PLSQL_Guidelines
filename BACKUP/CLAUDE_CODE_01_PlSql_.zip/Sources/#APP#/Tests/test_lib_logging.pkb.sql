prompt File: test_lib_logging.pkb.sql <start>
-- =============================================================================
-- File:     test_lib_logging.pkb.sql
-- Object:   test_lib_logging (utPLSQL suite body)
-- Schema:   #APP# (dev/test environments only)
-- Purpose:  Unit tests for lib_logging. lib_logging commits in an autonomous
--           transaction, so the written rows are cleaned up explicitly.
-- -----------------------------------------------------------------------------
-- Changelog (authoritative history: version control)
--   Date      Aut  Change
--   20260705  AA   Creation
--   20260708  AA   Add correlation_id test
--   20260708  AA   Retarget to log_events / log_error_details
--   20260708  AA   Add start_proc/end_proc execution_id pairing test
--   20260708  AA   Add cfg_messages catalog overload test
-- =============================================================================

prompt test_lib_logging: Creating test package body
create or replace package body test_lib_logging is

k_SCOPE     constant lib_types.scope_sbt := 'test_lib_logging';
k_MSG_CODE  constant varchar2(100 char)  := 'UT_LIB_LOGGING_MSG';
-- ORA-01476 (division by zero): a real Oracle sqlcode used to test the override.
k_ORA_CODE  constant pls_integer         := -1476;

-- Inserts (autonomous) a temporary catalog message so the overload can read it.
procedure seed_temp_message(i_template in varchar2) is
   pragma autonomous_transaction;
begin
   merge into cfg_messages t
   using ( select k_MSG_CODE as message_code from dual ) s
      on (t.message_code = s.message_code)
    when matched then
       update set t.message_template = i_template
    when not matched then
       insert (message_code, message_template) values (k_MSG_CODE, i_template);
   commit;
end seed_temp_message;

-- Inserts (autonomous) a temporary ORACLE override so error logging can read it.
procedure seed_temp_error_message(i_template in varchar2) is
   pragma autonomous_transaction;
begin
   merge into cfg_error_messages t
   using ( select k_ORA_CODE as error_code from dual ) s
      on (t.error_code = s.error_code)
    when matched then
       update set t.message_template = i_template
    when not matched then
       insert (error_code, error_kind, error_name, message_template)
       values (k_ORA_CODE, 'ORACLE', 'UT_ORA_ZERO_DIVIDE', i_template);
   commit;
end seed_temp_error_message;

procedure reset_level is
begin
   -- Ensure the minimum level reflects the current configuration (INFO).
   lib_logging.refresh;
end reset_level;

procedure cleanup is
   pragma autonomous_transaction;
begin
   delete from log_error_details led
    where led.event_id in (select lev.event_id from log_events lev where lev.scope = k_SCOPE);
   delete from log_events lev where lev.scope = k_SCOPE;
   delete from cfg_messages cme where cme.message_code = k_MSG_CODE;
   delete from cfg_error_messages cem where cem.error_code = k_ORA_CODE;
   commit;
end cleanup;

procedure log_info_writes is
   l_count  pls_integer;
begin
   lib_logging.log_info(i_text => 'unit test info', i_scope => k_SCOPE);

   select count(*)
     into l_count
     from log_events lev
    where lev.scope = k_SCOPE;

   ut.expect(l_count).to_equal(1);
end log_info_writes;

procedure log_debug_filtered is
   l_count  pls_integer;
begin
   lib_logging.log_debug(i_text => 'unit test debug', i_scope => k_SCOPE);

   select count(*)
     into l_count
     from log_events lev
    where lev.scope     = k_SCOPE
      and lev.log_level = 'DEBUG';

   ut.expect(l_count).to_equal(0);
end log_debug_filtered;

procedure log_error_writes is
   l_count  pls_integer;
begin
   lib_logging.log_error(i_text => 'unit test error', i_scope => k_SCOPE);

   select count(*)
     into l_count
     from log_events lev
    where lev.scope     = k_SCOPE
      and lev.log_level = 'ERROR';

   ut.expect(l_count).to_equal(1);
end log_error_writes;

procedure log_info_stores_correlation_id is
   k_CORR   constant lib_types.correlation_id_sbt := 'UT-LOG-CORR';
   l_count  pls_integer;
begin
   lib_logging.log_info( i_text           => 'unit test correlation'
                       , i_correlation_id => k_CORR
                       , i_scope          => k_SCOPE
                       );

   select count(*)
     into l_count
     from log_events lev
    where lev.scope          = k_SCOPE
      and lev.correlation_id = k_CORR;

   ut.expect(l_count).to_equal(1);
end log_info_stores_correlation_id;

procedure start_end_pairs_by_execution_id is
   l_exec   lib_types.execution_id_sbt;
   l_count  pls_integer;
begin
   l_exec := lib_logging.start_proc(i_scope => k_SCOPE);
   lib_logging.end_proc(i_scope => k_SCOPE, i_execution_id => l_exec);

   -- One START and one END, both carrying the execution id returned by start_proc.
   select count(*)
     into l_count
     from log_events lev
    where lev.scope        = k_SCOPE
      and lev.execution_id = l_exec
      and lev.message_type in ('START', 'END');

   ut.expect(l_count).to_equal(2);
end start_end_pairs_by_execution_id;

procedure catalog_overload_composes_message is
   l_message  log_events.message%type;
begin
   seed_temp_message(i_template => 'Imported %1 rows from %2');

   lib_logging.log_info( i_message_code => k_MSG_CODE
                       , i_p1           => '125'
                       , i_p2           => 'orders.csv'
                       , i_scope        => k_SCOPE
                       );

   select lev.message
     into l_message
     from log_events lev
    where lev.scope = k_SCOPE
      and lev.log_level = 'INFO';

   ut.expect(l_message).to_equal('Imported 125 rows from orders.csv');
end catalog_overload_composes_message;

procedure oracle_error_uses_catalog_message is
   l_message  log_events.message%type;
begin
   seed_temp_error_message(i_template => 'Custom zero-divide text');

   begin
      declare
         l_zero  number := 0;
         l_dummy number;
      begin
         l_dummy := 1 / l_zero;   -- raises ORA-01476 (sqlcode -1476)
      end;
   exception
      when others
      then
         lib_logging.log_error(i_text => 'ctx', i_scope => k_SCOPE);
   end;

   select lev.message
     into l_message
     from log_events lev
    where lev.scope     = k_SCOPE
      and lev.log_level = 'ERROR';

   ut.expect(l_message).to_equal('ctx - Custom zero-divide text');
end oracle_error_uses_catalog_message;

procedure oracle_error_uncatalogued_uses_sqlerrm is
   l_message  log_events.message%type;
begin
   -- No catalog row for ORA-00001 (sqlcode -1): the raw sqlerrm must be used.
   begin
      raise dup_val_on_index;
   exception
      when others
      then
         lib_logging.log_error(i_text => 'ctx', i_scope => k_SCOPE);
   end;

   select lev.message
     into l_message
     from log_events lev
    where lev.scope     = k_SCOPE
      and lev.log_level = 'ERROR';

   ut.expect(l_message).to_be_like('%ORA-00001%');
end oracle_error_uncatalogued_uses_sqlerrm;

end test_lib_logging;
/
show errors package body test_lib_logging

prompt File: test_lib_logging.pkb.sql <end>
