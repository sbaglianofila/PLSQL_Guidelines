prompt ------------------------------------------------------------

prompt File: authz_refresh_mv.job.sql <start>

prompt

-- =============================================================================
-- File:     authz_refresh_mv.job.sql
-- Oggetto:  authz_refresh_mv (job DBMS_SCHEDULER)
-- Schema:   #APP#
-- Scopo:    Refresh giornaliero della vista materializzata dei permessi
--           mv_user_effective_perms, alle 00:00. Fa scattare i confini di data
--           delle finestre temporali (valid_from/valid_to a grana data), che
--           cambiano il permesso effettivo SENZA alcuna DML: un grant che parte
--           il 1 marzo diventa attivo quando la MV viene rinfrescata quel giorno.
--           Insieme al refresh "su evento" (che l'admin API chiamera' dopo un
--           commit sulla mappa dei permessi) da' zero finestra di incoerenza,
--           grazie alla grana giornaliera. Entrambi passano per il punto unico
--           lib_authz.refresh_mv. Vedi Architettura_DB/utenti_profili.md.
-- Nota:     Il quando (schedulazione) e' di DBMS_SCHEDULER; il cosa (il refresh)
--           e' una procedura con un nome (lib_authz.refresh_mv), mai logica inline
--           nel job_action - cosi' lo stesso codice serve scheduled ed evento.
--           Richiede il privilegio di sistema CREATE JOB sull'owner (Sources/SYS).
--           Idempotente: rimuove il job preesistente e lo ricrea.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260725  AA   Creazione
-- =============================================================================

prompt authz_refresh_mv: Dropping existing job (if any)

begin
    sys.dbms_scheduler.drop_job( job_name => 'AUTHZ_REFRESH_MV'
                               , force    => true
                               );
exception
    when others
    then
        -- ORA-27475: "unknown job" - alla prima installazione non esiste ancora.
        if ( sqlcode != -27475 )
        then
            raise;
        end if;
end;
/

prompt authz_refresh_mv: Creating job

begin
    sys.dbms_scheduler.create_job
       ( job_name        => 'AUTHZ_REFRESH_MV'
       , job_type        => 'PLSQL_BLOCK'
       , job_action      => 'begin lib_authz.refresh_mv; end;'
       , start_date      => trunc(systimestamp) + interval '1' day
       , repeat_interval => 'FREQ=DAILY; BYHOUR=0; BYMINUTE=0; BYSECOND=0'
       , enabled         => true
       , auto_drop       => false
       , comments        => 'Refresh giornaliero (00:00) della MV dei permessi mv_user_effective_perms via lib_authz.refresh_mv.'
       );
end;
/

prompt File: authz_refresh_mv.job.sql <end>

prompt
