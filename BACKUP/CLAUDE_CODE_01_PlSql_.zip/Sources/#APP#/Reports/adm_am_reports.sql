-- =============================================================================
-- File:     adm_am_reports.sql
-- Oggetto:  Catalogo di query per report SQL Developer / controlli AM (RBAC)
-- Schema:   #APP#
-- Scopo:    Raccolta di interrogazioni di SOLA LETTURA sulle tabelle amministrative
--           adm_* e sulla vista materializzata mv_user_effective_perms, pensate per
--           essere trasformate in report di SQL Developer e usate dal gruppo di
--           Application Maintenance per i controlli su utenti, profili, ruoli,
--           maschere, funzionalita' e permessi effettivi.
--           Vedi Architettura_DB/utenti_profili.md e Testing/query_di_controllo.md.
--
--           DUE FAMIGLIE, distinte per come si legge l'esito:
--             - Report [R..]  -> restituiscono l'elenco completo (foto dello stato);
--                                si leggono a colpo d'occhio, ogni riga e' informazione.
--             - Controllo [C..]-> stile RILEVAZIONE ANOMALIE: zero righe = tutto a
--                                posto, ogni riga restituita e' un problema da guardare.
--                                Adatti a cfg_reports con anomalies_only = 'Y'.
--
--           CONVENZIONI:
--             - #APP# e' il placeholder dello schema applicativo (sostituito al deploy).
--             - La validita' temporale si valuta su trunc(sysdate); estremi inclusi;
--               null su valid_from = "da sempre", null su valid_to = "senza scadenza".
--             - I parametri sono bind di SQL Developer (:user_id, :days, ...): al
--               lancio del report SQL Developer chiede il valore.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260725  AA   Creazione
-- =============================================================================


-- #############################################################################
-- # 1. CATALOGO / ANAGRAFICHE (report di elenco)                              #
-- #############################################################################

-- -----------------------------------------------------------------------------
-- [R01] Elenco utenti con stato e numero di profili validi oggi.
--       Foto dell'anagrafe: chi c'e', se e' attivo, quanti profili sta usando ora.
-- -----------------------------------------------------------------------------
select u.user_id
     , u.username
     , u.full_name
     , u.email
     , u.is_active
     , ( select count(*)
           from adm_user_profiles up
          where up.user_id = u.user_id
            and ( up.valid_from is null or up.valid_from <= trunc(sysdate) )
            and ( up.valid_to   is null or up.valid_to   >= trunc(sysdate) )
       ) as active_profiles
     , u.created_at
     , u.modified_at
  from adm_users u
 order by u.is_active desc, u.username;


-- -----------------------------------------------------------------------------
-- [R02] Elenco moduli con numero di maschere e stato.
-- -----------------------------------------------------------------------------
select m.module_code
     , m.name
     , m.is_active
     , m.sort_order
     , ( select count(*) from adm_masks k where k.module_code = m.module_code ) as masks
     , m.description
  from adm_modules m
 order by m.sort_order, m.module_code;


-- -----------------------------------------------------------------------------
-- [R03] Gerarchia completa del menu: modulo -> maschera -> funzionalita'.
--       E' la mappa navigabile dell'applicazione, ordinata come a menu.
-- -----------------------------------------------------------------------------
select m.module_code
     , m.name                as module_name
     , m.is_active           as module_active
     , k.mask_code
     , k.name                as mask_name
     , k.is_active           as mask_active
     , f.functionality_code
     , f.name                as functionality_name
  from adm_modules           m
  join adm_masks             k  on k.module_code = m.module_code
  join adm_functionalities   f  on f.mask_code   = k.mask_code
 order by m.sort_order, m.module_code
        , k.sort_order, k.mask_code
        , f.functionality_code;


-- -----------------------------------------------------------------------------
-- [R04] Elenco maschere con il modulo di appartenenza.
-- -----------------------------------------------------------------------------
select k.mask_code
     , k.name                as mask_name
     , k.module_code
     , m.name                as module_name
     , k.is_active
     , k.sort_order
     , ( select count(*) from adm_functionalities f where f.mask_code = k.mask_code ) as functionalities
  from adm_masks     k
  join adm_modules   m  on m.module_code = k.module_code
 order by m.sort_order, k.sort_order, k.mask_code;


-- -----------------------------------------------------------------------------
-- [R05] Elenco funzionalita' con maschera e modulo (catalogo dei permessi grantabili).
-- -----------------------------------------------------------------------------
select f.functionality_code
     , f.name                as functionality_name
     , k.mask_code
     , k.name                as mask_name
     , m.module_code
     , m.name                as module_name
     , f.description
  from adm_functionalities   f
  join adm_masks             k  on k.mask_code   = f.mask_code
  join adm_modules           m  on m.module_code = k.module_code
 order by m.module_code, k.mask_code, f.functionality_code;


-- -----------------------------------------------------------------------------
-- [R06] Elenco ruoli aziendali con numero di profili che li usano.
-- -----------------------------------------------------------------------------
select r.role_code
     , r.name
     , r.is_system
     , ( select count(*) from adm_profile_roles pr where pr.role_code = r.role_code ) as used_by_profiles
     , r.description
  from adm_roles r
 order by r.role_code;


-- -----------------------------------------------------------------------------
-- [R07] Elenco profili con numero di ruoli, funzionalita' grantate e utenti assegnati.
-- -----------------------------------------------------------------------------
select p.profile_code
     , p.name
     , p.is_system
     , ( select count(*) from adm_profile_roles          pr where pr.profile_code = p.profile_code ) as roles
     , ( select count(*) from adm_profile_functionalities pf where pf.profile_code = p.profile_code ) as granted_functionalities
     , ( select count(*) from adm_user_profiles          up
          where up.profile_code = p.profile_code
            and ( up.valid_from is null or up.valid_from <= trunc(sysdate) )
            and ( up.valid_to   is null or up.valid_to   >= trunc(sysdate) )
       ) as active_users
     , p.description
  from adm_profiles p
 order by p.profile_code;


-- #############################################################################
-- # 2. ASSEGNAZIONI E GRANT (report di dettaglio delle relazioni)             #
-- #############################################################################

-- -----------------------------------------------------------------------------
-- [R08] Assegnazioni utente -> profilo, con finestra di validita' e stato oggi.
--       time_status: ACTIVE (valida ora), FUTURE (non ancora partita),
--       EXPIRED (gia' scaduta).
-- -----------------------------------------------------------------------------
select u.username
     , u.full_name
     , u.is_active           as user_active
     , up.profile_code
     , p.name                as profile_name
     , up.valid_from
     , up.valid_to
     , case
          when up.valid_from is not null and up.valid_from > trunc(sysdate) then 'FUTURE'
          when up.valid_to   is not null and up.valid_to   < trunc(sysdate) then 'EXPIRED'
          else 'ACTIVE'
       end                   as time_status
  from adm_user_profiles   up
  join adm_users           u  on u.user_id      = up.user_id
  join adm_profiles        p  on p.profile_code = up.profile_code
 order by u.username, up.profile_code;


-- -----------------------------------------------------------------------------
-- [R09] Composizione profilo -> ruoli (relazione strutturale, atemporale).
-- -----------------------------------------------------------------------------
select p.profile_code
     , p.name                as profile_name
     , r.role_code
     , r.name                as role_name
     , r.is_system           as role_is_system
  from adm_profile_roles   pr
  join adm_profiles        p  on p.profile_code = pr.profile_code
  join adm_roles           r  on r.role_code    = pr.role_code
 order by p.profile_code, r.role_code;


-- -----------------------------------------------------------------------------
-- [R10] Grant funzionalita' -> profilo, con modi di accesso e finestra di validita'.
--       access_mode compatta i tre flag in una stringa leggibile (es. "R-W-").
-- -----------------------------------------------------------------------------
select p.profile_code
     , p.name                as profile_name
     , f.functionality_code
     , f.name                as functionality_name
     , k.mask_code
     , m.module_code
     , pf.can_read
     , pf.can_write
     , pf.can_execute
     , case when pf.can_read    = 'Y' then 'R' else '-' end ||
       case when pf.can_write   = 'Y' then 'W' else '-' end ||
       case when pf.can_execute = 'Y' then 'X' else '-' end  as access_mode
     , pf.valid_from
     , pf.valid_to
     , case
          when pf.valid_from is not null and pf.valid_from > trunc(sysdate) then 'FUTURE'
          when pf.valid_to   is not null and pf.valid_to   < trunc(sysdate) then 'EXPIRED'
          else 'ACTIVE'
       end                   as time_status
  from adm_profile_functionalities  pf
  join adm_profiles                 p  on p.profile_code       = pf.profile_code
  join adm_functionalities          f  on f.functionality_code = pf.functionality_code
  join adm_masks                    k  on k.mask_code          = f.mask_code
  join adm_modules                  m  on m.module_code        = k.module_code
 order by p.profile_code, m.module_code, k.mask_code, f.functionality_code;


-- -----------------------------------------------------------------------------
-- [R11] Eccezioni nominali: grant diretti utente -> funzionalita' (con motivazione).
--       E' il primo posto che un audit di sicurezza va a guardare: chi ha un
--       permesso extra rispetto ai suoi profili, con che modo, fino a quando e perche'.
-- -----------------------------------------------------------------------------
select u.username
     , u.full_name
     , uf.functionality_code
     , f.name                as functionality_name
     , k.mask_code
     , m.module_code
     , case when uf.can_read    = 'Y' then 'R' else '-' end ||
       case when uf.can_write   = 'Y' then 'W' else '-' end ||
       case when uf.can_execute = 'Y' then 'X' else '-' end  as access_mode
     , uf.valid_from
     , uf.valid_to
     , case
          when uf.valid_from is not null and uf.valid_from > trunc(sysdate) then 'FUTURE'
          when uf.valid_to   is not null and uf.valid_to   < trunc(sysdate) then 'EXPIRED'
          else 'ACTIVE'
       end                   as time_status
     , uf.reason
     , uf.created_by
     , uf.created_at
  from adm_user_functionalities  uf
  join adm_users                 u  on u.user_id            = uf.user_id
  join adm_functionalities       f  on f.functionality_code = uf.functionality_code
  join adm_masks                 k  on k.mask_code          = f.mask_code
  join adm_modules               m  on m.module_code        = k.module_code
 order by u.username, uf.functionality_code;


-- #############################################################################
-- # 3. PERMESSI EFFETTIVI (report per costruire il menu / rispondere "chi puo'")#
-- #############################################################################

-- -----------------------------------------------------------------------------
-- [R12] Permessi effettivi di UN utente (bind :user_id): profili OR eccezioni,
--       modi in OR, gia' filtrati per validita' oggi. E' cio' che vede lib_authz:
--       la MV (contributo dai profili) unita alle eccezioni nominali lette al volo.
-- -----------------------------------------------------------------------------
with from_profiles as
   ( select mv.user_id
          , mv.functionality_code
          , mv.can_read
          , mv.can_write
          , mv.can_execute
       from mv_user_effective_perms mv
      where mv.user_id = :user_id
   )
   , from_exceptions as
   ( select uf.user_id
          , uf.functionality_code
          , uf.can_read
          , uf.can_write
          , uf.can_execute
       from adm_user_functionalities uf
      where uf.user_id = :user_id
        and ( uf.valid_from is null or uf.valid_from <= trunc(sysdate) )
        and ( uf.valid_to   is null or uf.valid_to   >= trunc(sysdate) )
   )
   , unioned as
   ( select * from from_profiles
     union all
     select * from from_exceptions
   )
select f.functionality_code
     , f.name                as functionality_name
     , k.mask_code
     , k.name                as mask_name
     , m.module_code
     , m.name                as module_name
     , max(x.can_read)       as can_read
     , max(x.can_write)      as can_write
     , max(x.can_execute)    as can_execute
  from unioned              x
  join adm_functionalities  f  on f.functionality_code = x.functionality_code
  join adm_masks            k  on k.mask_code          = f.mask_code
  join adm_modules          m  on m.module_code        = k.module_code
 group by f.functionality_code, f.name, k.mask_code, k.name, m.module_code, m.name
 order by m.module_code, k.mask_code, f.functionality_code;


-- -----------------------------------------------------------------------------
-- [R13] "Chi puo' fare X": tutti gli utenti che hanno accesso a una funzionalita'
--       (bind :functionality_code), con il modo effettivo e la sorgente del permesso
--       (PROFILE, EXCEPTION o BOTH). Il rovescio di [R12].
-- -----------------------------------------------------------------------------
with from_profiles as
   ( select mv.user_id, mv.can_read, mv.can_write, mv.can_execute, 'PROFILE' as src
       from mv_user_effective_perms mv
      where mv.functionality_code = :functionality_code
   )
   , from_exceptions as
   ( select uf.user_id, uf.can_read, uf.can_write, uf.can_execute, 'EXCEPTION' as src
       from adm_user_functionalities uf
      where uf.functionality_code = :functionality_code
        and ( uf.valid_from is null or uf.valid_from <= trunc(sysdate) )
        and ( uf.valid_to   is null or uf.valid_to   >= trunc(sysdate) )
   )
   , unioned as
   ( select * from from_profiles
     union all
     select * from from_exceptions
   )
select u.username
     , u.full_name
     , u.is_active
     , max(x.can_read)     as can_read
     , max(x.can_write)    as can_write
     , max(x.can_execute)  as can_execute
     , listagg(distinct x.src, '+') within group (order by x.src) as source
  from unioned    x
  join adm_users  u  on u.user_id = x.user_id
 group by u.username, u.full_name, u.is_active
 order by u.username;


-- #############################################################################
-- # 4. CONTROLLI SULLA VISTA MATERIALIZZATA (coerenza e freschezza)           #
-- #############################################################################

-- -----------------------------------------------------------------------------
-- [C01] Stato di refresh della MV: freschezza e ultimo refresh dal dizionario dati.
--       Atteso: staleness = 'FRESH'. Se 'NEEDS_COMPILE'/'STALE'/'UNKNOWN' o l'ultimo
--       refresh e' vecchio (piu' di un giorno), il job schedulato o il refresh su
--       evento non stanno lavorando: da investigare.
-- -----------------------------------------------------------------------------
select mv_name
     , last_refresh_type
     , last_refresh_date
     , staleness
     , compile_state
     , round((sysdate - last_refresh_date) * 24, 1) as hours_since_refresh
  from user_mviews
 where mv_name = 'MV_USER_EFFECTIVE_PERMS';


-- -----------------------------------------------------------------------------
-- [C02] MV DISALLINEATA rispetto al ricalcolo dal vivo: atteso 0 righe.
--       Ricostruisce il contributo-da-profili "valido oggi" con la stessa logica
--       della vista e lo confronta con il contenuto materializzato. Ogni riga e' una
--       divergenza: presente solo nella MV (ONLY_IN_MV, tipicamente MV stantia da
--       finestra scaduta non ancora rinfrescata), solo nel ricalcolo (ONLY_IN_LIVE,
--       grant nuovo non ancora propagato) o con modi diversi (MODE_MISMATCH).
--       Se restituisce righe: forzare lib_authz.refresh_mv e verificare il job.
-- -----------------------------------------------------------------------------
with live as
   ( select up.user_id
          , pf.functionality_code
          , max(pf.can_read)     as can_read
          , max(pf.can_write)    as can_write
          , max(pf.can_execute)  as can_execute
       from adm_user_profiles            up
       join adm_profile_functionalities  pf  on pf.profile_code = up.profile_code
      where ( up.valid_from is null or up.valid_from <= trunc(sysdate) )
        and ( up.valid_to   is null or up.valid_to   >= trunc(sysdate) )
        and ( pf.valid_from is null or pf.valid_from <= trunc(sysdate) )
        and ( pf.valid_to   is null or pf.valid_to   >= trunc(sysdate) )
      group by up.user_id, pf.functionality_code
   )
select nvl(mv.user_id, l.user_id)                       as user_id
     , nvl(mv.functionality_code, l.functionality_code) as functionality_code
     , case
          when l.user_id  is null then 'ONLY_IN_MV'
          when mv.user_id is null then 'ONLY_IN_LIVE'
          else 'MODE_MISMATCH'
       end                                              as discrepancy
     , mv.can_read  as mv_read , mv.can_write  as mv_write , mv.can_execute  as mv_execute
     , l.can_read   as live_read, l.can_write  as live_write, l.can_execute  as live_execute
  from mv_user_effective_perms  mv
  full outer join live          l
    on l.user_id = mv.user_id
   and l.functionality_code = mv.functionality_code
 where mv.user_id is null
    or l.user_id  is null
    or mv.can_read    <> l.can_read
    or mv.can_write   <> l.can_write
    or mv.can_execute <> l.can_execute
 order by user_id, functionality_code;


-- -----------------------------------------------------------------------------
-- [C03] Righe della MV che puntano a un utente disattivato: atteso 0 righe.
--       La MV non filtra is_active (lo fa lib_authz a valle); qui si evidenziano
--       eventuali permessi materializzati per utenze spente, utile in revisione.
-- -----------------------------------------------------------------------------
select mv.user_id
     , u.username
     , u.is_active
     , count(*) as materialized_perms
  from mv_user_effective_perms  mv
  join adm_users                u  on u.user_id = mv.user_id
 where u.is_active = 'N'
 group by mv.user_id, u.username, u.is_active
 order by u.username;


-- #############################################################################
-- # 5. IGIENE DEL MODELLO RBAC (anomalie e catalogo incompleto)               #
-- #############################################################################

-- -----------------------------------------------------------------------------
-- [C04] Utenti ATTIVI senza alcun profilo valido oggi: atteso 0 righe.
--       Non possono fare nulla dai profili: o e' un errore di assegnazione o
--       l'utenza andrebbe disattivata. (Potrebbero avere solo eccezioni nominali.)
-- -----------------------------------------------------------------------------
select u.user_id
     , u.username
     , u.full_name
  from adm_users u
 where u.is_active = 'Y'
   and not exists
       ( select 1
           from adm_user_profiles up
          where up.user_id = u.user_id
            and ( up.valid_from is null or up.valid_from <= trunc(sysdate) )
            and ( up.valid_to   is null or up.valid_to   >= trunc(sysdate) )
       )
 order by u.username;


-- -----------------------------------------------------------------------------
-- [C05] Utenti DISATTIVATI che hanno ancora profili validi assegnati: atteso 0 righe.
--       Residui di assegnazione su utenze spente: da ripulire (igiene, non rischio,
--       perche' lib_authz blocca comunque l'utente inattivo).
-- -----------------------------------------------------------------------------
select u.username
     , u.full_name
     , up.profile_code
     , up.valid_from
     , up.valid_to
  from adm_users          u
  join adm_user_profiles  up  on up.user_id = u.user_id
 where u.is_active = 'N'
   and ( up.valid_from is null or up.valid_from <= trunc(sysdate) )
   and ( up.valid_to   is null or up.valid_to   >= trunc(sysdate) )
 order by u.username, up.profile_code;


-- -----------------------------------------------------------------------------
-- [C06] Profili senza alcuna funzionalita' grantata: atteso 0 righe.
--       Profili "vuoti" che non concedono nulla: assegnarli non da' alcun permesso.
-- -----------------------------------------------------------------------------
select p.profile_code
     , p.name
  from adm_profiles p
 where not exists
       ( select 1 from adm_profile_functionalities pf where pf.profile_code = p.profile_code )
 order by p.profile_code;


-- -----------------------------------------------------------------------------
-- [C07] Profili senza alcun ruolo: atteso 0 righe (profilo privo di tessuto organizzativo).
-- -----------------------------------------------------------------------------
select p.profile_code
     , p.name
  from adm_profiles p
 where not exists
       ( select 1 from adm_profile_roles pr where pr.profile_code = p.profile_code )
 order by p.profile_code;


-- -----------------------------------------------------------------------------
-- [C08] Ruoli non usati da alcun profilo: atteso 0 righe (ruoli orfani, candidati a dismissione).
-- -----------------------------------------------------------------------------
select r.role_code
     , r.name
     , r.is_system
  from adm_roles r
 where not exists
       ( select 1 from adm_profile_roles pr where pr.role_code = r.role_code )
 order by r.role_code;


-- -----------------------------------------------------------------------------
-- [C09] Funzionalita' non raggiungibili: non grantate ad alcun profilo NE' concesse
--       in eccezione a un utente. Atteso 0 righe: nessuno potra' mai usarle.
-- -----------------------------------------------------------------------------
select f.functionality_code
     , f.name
     , f.mask_code
  from adm_functionalities f
 where not exists
       ( select 1 from adm_profile_functionalities pf where pf.functionality_code = f.functionality_code )
   and not exists
       ( select 1 from adm_user_functionalities uf where uf.functionality_code = f.functionality_code )
 order by f.mask_code, f.functionality_code;


-- -----------------------------------------------------------------------------
-- [C10] Maschere senza funzionalita': atteso 0 righe (schermata a menu che non espone nulla).
-- -----------------------------------------------------------------------------
select k.mask_code
     , k.name
     , k.module_code
     , k.is_active
  from adm_masks k
 where not exists
       ( select 1 from adm_functionalities f where f.mask_code = k.mask_code )
 order by k.module_code, k.mask_code;


-- -----------------------------------------------------------------------------
-- [C11] Moduli senza maschere: atteso 0 righe (modulo a menu vuoto).
-- -----------------------------------------------------------------------------
select m.module_code
     , m.name
     , m.is_active
  from adm_modules m
 where not exists
       ( select 1 from adm_masks k where k.module_code = m.module_code )
 order by m.module_code;


-- -----------------------------------------------------------------------------
-- [C12] Grant di profilo con tutti e tre i modi a 'N': atteso 0 righe.
--       Riga che non concede alcun accesso: probabile errore di data entry.
-- -----------------------------------------------------------------------------
select pf.profile_code
     , pf.functionality_code
     , pf.valid_from
     , pf.valid_to
  from adm_profile_functionalities pf
 where pf.can_read    = 'N'
   and pf.can_write   = 'N'
   and pf.can_execute = 'N'
 order by pf.profile_code, pf.functionality_code;


-- -----------------------------------------------------------------------------
-- [C13] Eccezioni nominali con tutti i modi a 'N': atteso 0 righe.
--       Come [C12] ma sulle eccezioni: eccezione che non concede nulla.
-- -----------------------------------------------------------------------------
select uf.user_id
     , uf.functionality_code
     , uf.reason
  from adm_user_functionalities uf
 where uf.can_read    = 'N'
   and uf.can_write   = 'N'
   and uf.can_execute = 'N'
 order by uf.user_id, uf.functionality_code;


-- #############################################################################
-- # 6. SCADENZE E MANUTENZIONE TEMPORALE (finestre di validita')              #
-- #############################################################################

-- -----------------------------------------------------------------------------
-- [C14] Assegnazioni e grant SCADUTI ancora presenti (valid_to < oggi): atteso 0 righe.
--       Non concedono piu' nulla ma sporcano il quadro: candidati alla pulizia.
--       Unisce le tre relazioni con finestra in un solo elenco (colonna source).
-- -----------------------------------------------------------------------------
select 'USER_PROFILE'    as source
     , u.username        as subject
     , up.profile_code   as target
     , up.valid_to
  from adm_user_profiles up
  join adm_users u on u.user_id = up.user_id
 where up.valid_to < trunc(sysdate)
union all
select 'PROFILE_FUNC'
     , pf.profile_code
     , pf.functionality_code
     , pf.valid_to
  from adm_profile_functionalities pf
 where pf.valid_to < trunc(sysdate)
union all
select 'USER_FUNC_EXCEPTION'
     , to_char(uf.user_id)
     , uf.functionality_code
     , uf.valid_to
  from adm_user_functionalities uf
 where uf.valid_to < trunc(sysdate)
 order by valid_to desc, source;


-- -----------------------------------------------------------------------------
-- [C15] Assegnazioni e grant IN SCADENZA nei prossimi :days giorni (bind :days).
--       Report proattivo: da rivedere prima che l'accesso cada. Non "anomalia",
--       ma promemoria operativo; ordinato per scadenza piu' vicina.
-- -----------------------------------------------------------------------------
select 'USER_PROFILE'    as source
     , u.username        as subject
     , up.profile_code   as target
     , up.valid_to
     , up.valid_to - trunc(sysdate) as days_left
  from adm_user_profiles up
  join adm_users u on u.user_id = up.user_id
 where up.valid_to between trunc(sysdate) and trunc(sysdate) + :days
union all
select 'PROFILE_FUNC'
     , pf.profile_code
     , pf.functionality_code
     , pf.valid_to
     , pf.valid_to - trunc(sysdate)
  from adm_profile_functionalities pf
 where pf.valid_to between trunc(sysdate) and trunc(sysdate) + :days
union all
select 'USER_FUNC_EXCEPTION'
     , to_char(uf.user_id)
     , uf.functionality_code
     , uf.valid_to
     , uf.valid_to - trunc(sysdate)
  from adm_user_functionalities uf
 where uf.valid_to between trunc(sysdate) and trunc(sysdate) + :days
 order by valid_to, source;


-- -----------------------------------------------------------------------------
-- [C16] Assegnazioni/grant FUTURI (valid_from > oggi): non ancora attivi.
--       Non e' un'anomalia ma va tenuto d'occhio: diventeranno effettivi al
--       primo refresh della MV nel giorno di partenza.
-- -----------------------------------------------------------------------------
select 'USER_PROFILE'    as source
     , u.username        as subject
     , up.profile_code   as target
     , up.valid_from
  from adm_user_profiles up
  join adm_users u on u.user_id = up.user_id
 where up.valid_from > trunc(sysdate)
union all
select 'PROFILE_FUNC'
     , pf.profile_code
     , pf.functionality_code
     , pf.valid_from
  from adm_profile_functionalities pf
 where pf.valid_from > trunc(sysdate)
 order by valid_from, source;
