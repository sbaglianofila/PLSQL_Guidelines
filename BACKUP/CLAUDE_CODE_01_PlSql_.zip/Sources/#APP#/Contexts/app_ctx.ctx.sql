prompt File: app_ctx.ctx.sql <start>
-- =============================================================================
-- File:     app_ctx.ctx.sql
-- Object:   APP_CTX (application context)
-- Schema:   #APP#
-- Purpose:  Session-local application context that holds the application user
--           (attribute APP_USER) resolved by lib_session.current_actor. Bound to
--           #APP#.lib_session via the USING clause, so ONLY that package can set
--           or clear its attributes - no other code can forge the identity.
--           Reading is done with sys_context('APP_CTX', 'APP_USER'), which
--           returns null (never errors) when the context is unset, so callers
--           and the audit triggers degrade gracefully to proxy/session user.
-- Prereq.:  The owner must hold CREATE ANY CONTEXT (see schemi.md / the SYS
--           system-grant template). The context is session-local (not ACCESSED
--           GLOBALLY): under a connection pool it must be reset per request with
--           lib_session.clear_session.
-- -----------------------------------------------------------------------------
-- Changelog (authoritative history: version control)
--   Date      Aut  Change
--   20260708  AA   Creation
-- =============================================================================

prompt app_ctx: Creating application context
create or replace context APP_CTX using lib_session;

prompt File: app_ctx.ctx.sql <end>
