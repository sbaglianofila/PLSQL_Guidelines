prompt File: cfg_parameters.fky.sql <start>
-- =============================================================================
-- File:     cfg_parameters.fky.sql
-- Oggetto:  Foreign key di cfg_parameters
-- Schema:   #APP#
-- Scopo:    Vincolo referenziale da param_group verso la lista governata dei
--           gruppi cfg_parameter_groups: è ciò che impedisce ai raggruppamenti
--           di proliferare per refuso. In file separato perché va creato dopo
--           che entrambe le tabelle esistono (vedi Gestione_Sorgenti/sorgenti.md).
-- Nota:     Va creato PRIMA del seed dei parametri e DOPO il seed dei gruppi:
--           con il vincolo attivo, inserire un parametro il cui gruppo non è
--           ancora a catalogo fallisce. L'ordine è già cablato in install.ins.sql.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260720  AA   Creazione
-- =============================================================================

prompt -- Creating foreign key

alter table cfg_parameters
   add constraint cfg_parameters_fk_group
   foreign key ( param_group )
   references cfg_parameter_groups ( group_code );

prompt File: cfg_parameters.fky.sql <end>
