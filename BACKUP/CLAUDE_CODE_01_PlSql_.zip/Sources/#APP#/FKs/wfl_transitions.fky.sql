prompt File: wfl_transitions.fky.sql <start>
-- =============================================================================
-- File:     wfl_transitions.fky.sql
-- Oggetto:  Foreign key di wfl_transitions
-- Schema:   #APP#
-- Scopo:    Vincoli referenziali delle transizioni: verso la testata del workflow
--           e - due volte, per lo stato di partenza e per quello di arrivo - verso
--           gli stati wfl_statuses. Le due foreign key sugli stati sono composite
--           su (workflow_code, status_code): garantiscono che from_status e
--           to_status siano stati esistenti DELLO STESSO workflow, non di un altro.
--           In file separato perché van creati dopo le tabelle (vedi sorgenti.md).
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260723  AA   Creazione
-- =============================================================================

prompt -- Creating foreign keys

alter table wfl_transitions
   add constraint wfl_transitions_fk_workflow
   foreign key ( workflow_code )
   references wfl_workflows ( workflow_code );

alter table wfl_transitions
   add constraint wfl_transitions_fk_from
   foreign key ( workflow_code, from_status )
   references wfl_statuses ( workflow_code, status_code );

alter table wfl_transitions
   add constraint wfl_transitions_fk_to
   foreign key ( workflow_code, to_status )
   references wfl_statuses ( workflow_code, status_code );

prompt File: wfl_transitions.fky.sql <end>
