prompt File: adm_masks.fky.sql <start>
-- =============================================================================
-- File:     adm_masks.fky.sql
-- Oggetto:  Foreign key di adm_masks
-- Schema:   #APP#
-- Scopo:    Ogni maschera appartiene a un modulo applicativo: relazione
--           molti-a-uno verso adm_modules, che rende module_code un riferimento
--           governato invece che testo libero. In file separato perché va creata
--           dopo le tabelle (vedi sorgenti.md).
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260725  AA   Creazione
-- =============================================================================

prompt -- Creating foreign keys

alter table adm_masks
   add constraint adm_masks_fk_module
   foreign key ( module_code )
   references adm_modules ( module_code );

prompt File: adm_masks.fky.sql <end>
