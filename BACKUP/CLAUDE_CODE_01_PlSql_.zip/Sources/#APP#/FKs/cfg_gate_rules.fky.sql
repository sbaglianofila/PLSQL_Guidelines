prompt File: cfg_gate_rules.fky.sql <start>
-- =============================================================================
-- File:     cfg_gate_rules.fky.sql
-- Oggetto:  Foreign key di cfg_gate_rules
-- Schema:   #APP#
-- Scopo:    Vincolo referenziale dalla regola configurata verso il dominio chiuso
--           dei tipi. È la prima delle due difese contro la regola fantasma: qui
--           il database rifiuta un rule_code inesistente, e nel body di lib_gate
--           il ramo else del dispatch solleva comunque, così un tipo aggiunto a
--           catalogo ma non ancora implementato non passa in silenzio.
--           In file separato perché va creato dopo le tabelle (vedi sorgenti.md).
--           param_1 non ha foreign key verso cfg_parameters o cfg_gate_objects: il
--           suo significato dipende dal rule_code, quindi il vincolo non sarebbe
--           esprimibile in modo uniforme e lo verifica il check al momento della
--           valutazione.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260729  AA   Creazione
-- =============================================================================

prompt -- Creating foreign key

alter table cfg_gate_rules
   add constraint cfg_gate_rules_fk_rule_type
   foreign key ( rule_code )
   references cfg_gate_rule_types ( rule_code );

prompt File: cfg_gate_rules.fky.sql <end>
