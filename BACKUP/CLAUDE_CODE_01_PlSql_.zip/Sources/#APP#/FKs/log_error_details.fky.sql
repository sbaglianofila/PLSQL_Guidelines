prompt File: log_error_details.fky.sql <start>
-- =============================================================================
-- File:     log_error_details.fky.sql
-- Object:   Foreign keys for log_error_details
-- Schema:   #APP#
-- Purpose:  Foreign key constraints to log_events.
-- -----------------------------------------------------------------------------
-- Changelog (authoritative history: version control)
--   Date      Aut  Change
--   20260708  AA   Creation
-- =============================================================================

prompt LOG_ERROR_DETAILS: Creating foreign key <table_name>_fk_<referenced_table>

alter table log_error_details
  add constraint log_error_details_fk_event
  references log_events (event_id);

prompt File: log_error_details.fky.sql <end>
