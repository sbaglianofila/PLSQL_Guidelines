prompt File: adm_user_profiles.fky.sql <start>
-- =============================================================================
-- File:     adm_user_profiles.fky.sql
-- Oggetto:  Foreign key di adm_user_profiles
-- Schema:   #APP#
-- Scopo:    L'assegnazione referenzia l'utente (adm_users) e il profilo
--           (adm_profiles). In file separato perché va creata dopo le tabelle
--           (vedi sorgenti.md).
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260725  AA   Creazione
-- =============================================================================

prompt -- Creating foreign keys

alter table adm_user_profiles
   add constraint adm_user_profiles_fk_user
   foreign key ( user_id )
   references adm_users ( user_id );

alter table adm_user_profiles
   add constraint adm_user_profiles_fk_profile
   foreign key ( profile_code )
   references adm_profiles ( profile_code );

prompt File: adm_user_profiles.fky.sql <end>
