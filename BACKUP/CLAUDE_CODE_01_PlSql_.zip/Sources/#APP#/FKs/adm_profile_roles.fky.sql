prompt File: adm_profile_roles.fky.sql <start>
-- =============================================================================
-- File:     adm_profile_roles.fky.sql
-- Oggetto:  Foreign key di adm_profile_roles
-- Schema:   #APP#
-- Scopo:    La composizione profilo-ruolo referenzia entrambe le anagrafi: il
--           profilo (adm_profiles) e il ruolo (adm_roles). In file separato
--           perché va creata dopo le tabelle (vedi sorgenti.md).
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260725  AA   Creazione
-- =============================================================================

prompt -- Creating foreign keys

alter table adm_profile_roles
   add constraint adm_profile_roles_fk_profile
   foreign key ( profile_code )
   references adm_profiles ( profile_code );

alter table adm_profile_roles
   add constraint adm_profile_roles_fk_role
   foreign key ( role_code )
   references adm_roles ( role_code );

prompt File: adm_profile_roles.fky.sql <end>
