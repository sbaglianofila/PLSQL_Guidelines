prompt File: wfl_statuses.fky.sql <start>
-- =============================================================================
-- File:     wfl_statuses.fky.sql
-- Oggetto:  Foreign key di wfl_statuses
-- Schema:   #APP#
-- Scopo:    Vincolo referenziale dagli stati verso la testata del workflow.
--           In file separato perché va creato dopo che entrambe le tabelle
--           esistono (vedi Gestione_Sorgenti/sorgenti.md).
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260723  AA   Creazione
-- =============================================================================

prompt -- Creating foreign key

alter table wfl_statuses
   add constraint wfl_statuses_fk_workflow
   foreign key ( workflow_code )
   references wfl_workflows ( workflow_code );

prompt File: wfl_statuses.fky.sql <end>
