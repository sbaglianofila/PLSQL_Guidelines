prompt File: adm_user_functionalities.fky.sql <start>
-- =============================================================================
-- File:     adm_user_functionalities.fky.sql
-- Oggetto:  Foreign key di adm_user_functionalities
-- Schema:   #APP#
-- Scopo:    L'eccezione nominale referenzia l'utente (adm_users) e la funzionalità
--           concessa (adm_functionalities). In file separato perché va creata
--           dopo le tabelle (vedi sorgenti.md).
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260725  AA   Creazione
-- =============================================================================

prompt -- Creating foreign keys

alter table adm_user_functionalities
   add constraint adm_user_func_fk_user
   foreign key ( user_id )
   references adm_users ( user_id );

alter table adm_user_functionalities
   add constraint adm_user_func_fk_func
   foreign key ( functionality_code )
   references adm_functionalities ( functionality_code );

prompt File: adm_user_functionalities.fky.sql <end>
