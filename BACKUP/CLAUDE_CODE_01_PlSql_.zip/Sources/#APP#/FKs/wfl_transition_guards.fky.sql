prompt File: wfl_transition_guards.fky.sql <start>
-- =============================================================================
-- File:     wfl_transition_guards.fky.sql
-- Oggetto:  Foreign key di wfl_transition_guards
-- Schema:   #APP#
-- Scopo:    Vincolo referenziale dalle guardie verso la transizione di
--           appartenenza. Il deny_message_code punta a cfg_messages ma senza
--           foreign key: è una convenzione (come i *_msg_codes usati altrove),
--           non un vincolo, così le guardie non impongono un ordine di install
--           rispetto al seed dei messaggi di progetto.
--           In file separato perché va creato dopo le tabelle (vedi sorgenti.md).
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260725  AA   Creazione
-- =============================================================================

prompt -- Creating foreign key

alter table wfl_transition_guards
   add constraint wfl_transition_guards_fk_trans
   foreign key ( workflow_code, transition_code )
   references wfl_transitions ( workflow_code, transition_code );

prompt File: wfl_transition_guards.fky.sql <end>
