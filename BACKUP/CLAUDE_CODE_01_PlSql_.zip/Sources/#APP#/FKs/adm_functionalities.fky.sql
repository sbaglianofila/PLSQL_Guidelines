prompt File: adm_functionalities.fky.sql <start>
-- =============================================================================
-- File:     adm_functionalities.fky.sql
-- Oggetto:  Foreign key di adm_functionalities
-- Schema:   #APP#
-- Scopo:    Ogni funzionalità appartiene a una maschera: relazione molti-a-uno
--           verso adm_masks. In file separato perché va creata dopo le tabelle
--           (vedi sorgenti.md).
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260725  AA   Creazione
-- =============================================================================

prompt -- Creating foreign keys

alter table adm_functionalities
   add constraint adm_functionalities_fk_mask
   foreign key ( mask_code )
   references adm_masks ( mask_code );

prompt File: adm_functionalities.fky.sql <end>
