prompt File: adm_profile_functionalities.fky.sql <start>
-- =============================================================================
-- File:     adm_profile_functionalities.fky.sql
-- Oggetto:  Foreign key di adm_profile_functionalities
-- Schema:   #APP#
-- Scopo:    Il grant referenzia il profilo (adm_profiles) e la funzionalità
--           concessa (adm_functionalities). In file separato perché va creata
--           dopo le tabelle (vedi sorgenti.md).
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260725  AA   Creazione
-- =============================================================================

prompt -- Creating foreign keys

alter table adm_profile_functionalities
   add constraint adm_profile_func_fk_profile
   foreign key ( profile_code )
   references adm_profiles ( profile_code );

alter table adm_profile_functionalities
   add constraint adm_profile_func_fk_func
   foreign key ( functionality_code )
   references adm_functionalities ( functionality_code );

prompt File: adm_profile_functionalities.fky.sql <end>
