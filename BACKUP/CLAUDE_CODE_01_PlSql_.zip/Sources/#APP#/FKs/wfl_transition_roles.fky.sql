prompt File: wfl_transition_roles.fky.sql <start>
-- =============================================================================
-- File:     wfl_transition_roles.fky.sql
-- Oggetto:  Foreign key di wfl_transition_roles
-- Schema:   #APP#
-- Scopo:    Vincolo referenziale dai ruoli autorizzati verso la transizione di
--           appartenenza, e verso adm_roles del pillar RBAC a garantire che
--           role_code sia un ruolo aziendale esistente. Quest'ultima foreign key
--           era predisposta e commentata in attesa del pillar utenti/profili
--           (adm_*): ora che adm_roles esiste (vedi Architettura_DB/utenti_profili.md)
--           è abilitata. adm_roles è creata nella sezione Tables dell'orchestratore,
--           quindi è già in piedi quando questo file gira.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260723  AA   Creazione
--   20260725  AA   Abilitata la foreign key verso adm_roles (pillar RBAC realizzato)
-- =============================================================================

prompt -- Creating foreign keys

alter table wfl_transition_roles
   add constraint wfl_transition_roles_fk_trans
   foreign key ( workflow_code, transition_code )
   references wfl_transitions ( workflow_code, transition_code );

alter table wfl_transition_roles
   add constraint wfl_transition_roles_fk_role
   foreign key ( role_code )
   references adm_roles ( role_code );

prompt File: wfl_transition_roles.fky.sql <end>
