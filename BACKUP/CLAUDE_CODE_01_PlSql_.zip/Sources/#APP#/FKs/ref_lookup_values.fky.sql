prompt File: ref_lookup_values.fky.sql <start>
-- =============================================================================
-- File:     ref_lookup_values.fky.sql
-- Oggetto:  Foreign key di ref_lookup_values
-- Schema:   #APP#
-- Scopo:    Vincolo referenziale dal dettaglio dei valori verso la testata dei
--           set ref_lookups. In file separato perché va creato dopo che entrambe
--           le tabelle esistono (vedi Gestione_Sorgenti/sorgenti.md).
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260719  AA   Creazione
-- =============================================================================

prompt -- Creating foreign key

alter table ref_lookup_values
   add constraint ref_lookup_values_fk_lookup
   foreign key ( lookup_code )
   references ref_lookups ( lookup_code );

prompt File: ref_lookup_values.fky.sql <end>
