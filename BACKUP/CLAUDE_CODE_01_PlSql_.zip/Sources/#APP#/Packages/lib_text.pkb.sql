prompt File: lib_text.pkb.sql <start>
-- =============================================================================
-- File:     lib_text.pkb.sql
-- Oggetto:  lib_text (corpo del package)
-- Schema:   #APP#
-- Scopo:    Implementazione dell'insieme chiuso di helper di testo.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260705  AA   Creazione
--   20260730  AA   Aggiunte mask, to_bool e format_duration
-- =============================================================================

prompt lib_text: Creating package body

create or replace
package body lib_text
is
-- Costanti --------------------------------------------------------------------
-- Caratteri accentati ripiegati sul loro corrispondente ASCII semplice (from/to
-- devono avere la stessa lunghezza per translate).
k_ACCENTED  constant varchar2(64 char) := 'ÀÁÂÃÄÅÈÉÊËÌÍÎÏÒÓÔÕÖÙÚÛÜÇÑàáâãäåèéêëìíîïòóôõöùúûüçñ';
k_PLAIN     constant varchar2(64 char) := 'AAAAAAEEEEIIIIOOOOOUUUUCNAAAAAAEEEEIIIIOOOOOUUUUCN';

-- Moduli pubblici -------------------------------------------------------------
--------------------------------------------------------------------------------
function split(i_text in varchar2, i_separator in varchar2 default ',')
    return t_strings_type
-- Divide su un separatore; collezione vuota per input null, singolo elemento se
-- il separatore è assente.
is
    l_result  t_strings_type := t_strings_type();
    l_pos     pls_integer := 1;
    l_hit     pls_integer;
    l_seplen  pls_integer := length(i_separator);
begin
    if ( i_text is null )
    then
        return (l_result);
    end if;

    if ( i_separator is null or l_seplen = 0 )
    then
        l_result.extend;
        l_result(l_result.last) := i_text;
        return (l_result);
    end if;

    loop
        l_hit := instr(i_text, i_separator, l_pos);

        l_result.extend;

        if ( l_hit = 0 )
        then
            l_result(l_result.last) := substr(i_text, l_pos);
            exit;
        end if;

        l_result(l_result.last) := substr(i_text, l_pos, l_hit - l_pos);
        l_pos := l_hit + l_seplen;
    end loop;

    return (l_result);
end split;
--------------------------------------------------------------------------------
function join(i_strings in t_strings_type, i_separator in varchar2 default ',')
    return varchar2
-- Unisce i pezzi con un separatore.
is
    l_result  varchar2(32767 char);
begin
    if ( i_strings is null )
    then
        return (null);
    end if;

    for i in 1 .. i_strings.count
    loop
        if ( i > 1 )
        then
            l_result := l_result || i_separator;
        end if;

        l_result := l_result || i_strings(i);
    end loop;

    return (l_result);
end join;
--------------------------------------------------------------------------------
function format( i_template in varchar2
               , i_p1       in varchar2 default null
               , i_p2       in varchar2 default null
               , i_p3       in varchar2 default null
               , i_p4       in varchar2 default null
               , i_p5       in varchar2 default null
               )
    return varchar2
-- Sostituisce %1..%5 nel template.
is
    l_result  varchar2(32767 char) := i_template;
begin
    l_result := replace(l_result, '%1', i_p1);
    l_result := replace(l_result, '%2', i_p2);
    l_result := replace(l_result, '%3', i_p3);
    l_result := replace(l_result, '%4', i_p4);
    l_result := replace(l_result, '%5', i_p5);

    return (l_result);
end format;
--------------------------------------------------------------------------------
function normalize_code(i_text in varchar2)
    return varchar2
-- Maiuscolo, accenti ripiegati, non-alfanumerici ridotti a underscore e trim.
is
    l_result  varchar2(4000 char);
begin
    if ( i_text is null )
    then
        return (null);
    end if;

    l_result := upper(translate(i_text, k_ACCENTED, k_PLAIN));
    l_result := regexp_replace(l_result, '[^A-Z0-9]+', '_');
    l_result := trim('_' from l_result);

    return (l_result);
end normalize_code;
--------------------------------------------------------------------------------
function mask(i_text in varchar2, i_visible in number default 4, i_mask_char in varchar2 default '*')
    return varchar2
-- Ultime i_visible posizioni in chiaro, il resto sostituito; fail-safe sui corti.
is
    k_MASK   constant varchar2(10 char) := nvl(i_mask_char, '*');
    l_len             pls_integer;
    l_visible         pls_integer := nvl(i_visible, 4);
begin
    if ( i_text is null )
    then
        return (null);
    end if;

    l_len := length(i_text);

    if ( l_visible < 0 )
    then
        l_visible := 0;
    end if;

    -- Testo troppo corto o nessun carattere da esporre: maschera tutto. Copre
    -- anche il caso i_visible = 0, evitando che substr(i_text, -0) esponga per
    -- intero il valore (in Oracle substr con offset 0 equivale a offset 1).
    if ( l_visible = 0 or l_len <= l_visible )
    then
        return ( rpad(k_MASK, l_len, k_MASK) );
    end if;

    return ( rpad(k_MASK, l_len - l_visible, k_MASK) || substr(i_text, -l_visible) );
end mask;
--------------------------------------------------------------------------------
function to_bool(i_text in varchar2, i_default in boolean default null)
    return boolean
-- Testo -> booleano su un insieme chiuso di token, altrimenti i_default.
is
    l_norm  varchar2(10 char) := upper(trim(i_text));
begin
    if ( l_norm in ('Y', 'YES', 'S', 'SI', 'T', 'TRUE', '1', 'ON') )
    then
        return (true);

    elsif ( l_norm in ('N', 'NO', 'F', 'FALSE', '0', 'OFF') )
    then
        return (false);

    else
        return (i_default);

    end if;
end to_bool;
--------------------------------------------------------------------------------
function format_duration(i_seconds in number)
    return varchar2
-- Durata in secondi -> stringa leggibile, dall'unità più significativa in giù.
is
    l_sign     varchar2(1 char) := null;
    l_total    number;
    l_days     number;
    l_hours    number;
    l_minutes  number;
    l_seconds  number;
begin
    if ( i_seconds is null )
    then
        return (null);
    end if;

    if ( i_seconds < 0 )
    then
        l_sign := '-';
    end if;

    l_total   := trunc(abs(i_seconds));
    l_days    := trunc(l_total / 86400);
    l_hours   := trunc(mod(l_total, 86400) / 3600);
    l_minutes := trunc(mod(l_total, 3600) / 60);
    l_seconds := mod(l_total, 60);

    if ( l_days > 0 )
    then
        return ( l_sign || l_days || 'g '
                        || lpad(l_hours, 2, '0') || 'h '
                        || lpad(l_minutes, 2, '0') || 'm' );

    elsif ( l_hours > 0 )
    then
        return ( l_sign || l_hours || 'h '
                        || lpad(l_minutes, 2, '0') || 'm '
                        || lpad(l_seconds, 2, '0') || 's' );

    elsif ( l_minutes > 0 )
    then
        return ( l_sign || l_minutes || 'm '
                        || lpad(l_seconds, 2, '0') || 's' );

    else
        return ( l_sign || l_seconds || 's' );

    end if;
end format_duration;
--------------------------------------------------------------------------------

end lib_text;
/

show errors package body lib_text

prompt File: lib_text.pkb.sql <end>
