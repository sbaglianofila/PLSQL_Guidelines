prompt File: lib_constants.pks.sql <start>
-- =============================================================================
-- File:     lib_constants.pks.sql
-- Oggetto:  lib_constants (specifica del package)
-- Schema:   #APP#
-- Scopo:    Unico contenitore dei valori letterali trasversali, più le funzioni
--           deterministiche che espongono a SQL le costanti necessarie anche
--           nelle query. Tiene solo costanti davvero trasversali: i valori di
--           stato di una singola entità di business vivono nel package API di
--           quell'entità, non qui.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260705  AA   Creazione
--   20260708  AA   Aggiunti i limiti di lunghezza varchar2 e le sentinelle di
--                  data aperta (k_DATE_MIN/k_DATE_MAX) con accessori SQL
-- =============================================================================

prompt lib_constants: Creating package specification

create or replace
package lib_constants
is
-- Valori dei flag (varchar2 'Y'/'N', booleano pre-23ai).
k_YES               constant lib_types.flag_sbt := 'Y';
k_NO                constant lib_types.flag_sbt := 'N';

-- Valori di verità numerici, per la codifica booleana su number(1).
k_NUMERIC_TRUE      constant pls_integer := 1;
k_NUMERIC_FALSE     constant pls_integer := 0;

-- Formati di conversione canonici (FX impone il match esatto del formato).
k_DATE_FMT          constant lib_types.code_sbt := 'FXYYYY-MM-DD';
k_TIMESTAMP_FMT     constant lib_types.code_sbt := 'FXYYYY-MM-DD HH24:MI:SS';

-- Limiti fisici del varchar2 imposti dal motore, per evitare numeri magici nel
-- dimensionare i buffer o validare le lunghezze di input.
k_VC2_MAXLEN        constant pls_integer := 32767;   -- lunghezza max varchar2 (contesto PL/SQL)
k_VC2_SQL_MAXLEN    constant pls_integer := 4000;    -- lunghezza max varchar2 (contesto SQL)

-- Soglie e limiti condivisi.
k_BULK_LIMIT        constant pls_integer := 1000;     -- dimensione di default del fetch bulk
k_ONE_WEEK          constant pls_integer := 604800;   -- secondi; scadenza di default del lock
k_DEFAULT_LOCK_WAIT constant pls_integer := 5;        -- secondi; timeout di default della richiesta di lock
k_LOG_RETENTION     constant pls_integer := 90;       -- giorni; retention di default dei log

-- Sentinelle di validità aperta: limiti inferiore/superiore convenzionali per
-- gli intervalli valid_from / valid_to, così che una "fine dei tempi" non sia
-- mai un letterale sparso. Usare gli accessori qui sotto per riferirle da SQL.
k_DATE_MIN          constant date := date '0001-01-01';   -- "inizio dei tempi" convenzionale
k_DATE_MAX          constant date := date '9999-12-31';   -- "fine dei tempi" convenzionale / validità aperta

--------------------------------------------------------------------------------
-- Espone k_YES a SQL (es. where flag = lib_constants.yes).
-- return : il valore del flag 'Y'.
function yes
    return varchar2 deterministic;
--------------------------------------------------------------------------------
-- Espone k_NO a SQL.
-- return : il valore del flag 'N'.
function no
    return varchar2 deterministic;
--------------------------------------------------------------------------------
-- Espone k_DATE_MIN a SQL (es. where valid_from >= lib_constants.date_min).
-- return : il limite inferiore convenzionale di validità.
function date_min
    return date deterministic;
--------------------------------------------------------------------------------
-- Espone k_DATE_MAX a SQL (es. where valid_to = lib_constants.date_max).
-- return : il limite superiore convenzionale di validità (validità aperta).
function date_max
    return date deterministic;
--------------------------------------------------------------------------------

end lib_constants;
/

show errors package lib_constants

prompt File: lib_constants.pks.sql <end>
