prompt File: lib_batch.pkb.sql <start>
-- =============================================================================
-- File:     lib_batch.pkb.sql
-- Oggetto:  lib_batch (corpo del package)
-- Schema:   #APP#
-- Scopo:    Traccia i run batch su log_process_runs e collega la strumentazione
--           di sessione, il lock di istanza singola e le precondizioni di lib_gate.
-- Nota:     Le DML su log_process_runs sono isolate in tre moduli privati marcati
--           pragma autonomous_transaction, che fanno solo insert/update e commit.
--           Tenerle separate dai moduli pubblici non è pignoleria: una transazione
--           autonoma deve chiudersi prima di restituire il controllo, quindi tutto
--           ciò che non è quella DML - il lock, il logging, la strumentazione -
--           deve stare fuori, altrimenti finirebbe legato a una transazione che
--           non gli appartiene.
--           Il lock in particolare resta fuori di proposito: dbms_lock lavora a
--           livello di sessione con release_on_commit false, quindi il commit
--           autonomo non lo tocca, ma mescolare acquisizione di risorse e scrittura
--           del registro renderebbe illeggibile chi rilascia cosa.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260705  AA   Creazione
--   20260729  AA   DML isolate in moduli autonomi; aggiunte skip_run e check_gate
-- =============================================================================

prompt lib_batch: Creating package body

create or replace
package body lib_batch
is
-- Costanti --------------------------------------------------------------------
k_SCOPE           constant lib_types.scope_sbt := 'lib_batch';
k_STATUS_RUNNING  constant log_process_runs.status%type := 'RUNNING';
k_STATUS_SUCCESS  constant log_process_runs.status%type := 'SUCCESS';
k_STATUS_FAILED   constant log_process_runs.status%type := 'FAILED';
k_STATUS_SKIPPED  constant log_process_runs.status%type := 'SKIPPED';
k_ACTION_START    constant lib_types.code_sbt := 'START';
k_ACTION_GATE     constant lib_types.code_sbt := 'GATE';
k_NO_WAIT         constant pls_integer := 0;

-- Tipi ------------------------------------------------------------------------
-- Handle dei lock di istanza singola, con chiave l'id del run (come testo).
type t_locks_type is table of lib_types.lock_handle_sbt index by varchar2(40 char);

-- Globali ---------------------------------------------------------------------
g_locks  t_locks_type;

-- Moduli privati --------------------------------------------------------------
--------------------------------------------------------------------------------
function insert_run(i_process_name in varchar2)
    return number
-- Crea la riga del run e la committa, in transazione autonoma: da qui in poi
-- l'esistenza del run non dipende più dalle sorti dell'elaborazione che traccia.
-- i_process_name : nome logico del processo.
-- return         : il nuovo id del run.
is
    pragma autonomous_transaction;
    l_run_id  log_process_runs.run_id%type;
begin
    insert
      into log_process_runs (  process_name
                             , status
                             , previous_run_id
                             , actor
                            )
    values (  i_process_name
            , k_STATUS_RUNNING
            , ( select max(lpr.run_id)
                  from log_process_runs lpr
                 where lpr.process_name = i_process_name
              )
            , lib_session.current_actor
           )
    returning run_id into l_run_id;

    commit;

    return (l_run_id);
end insert_run;
--------------------------------------------------------------------------------
procedure close_run( i_run_id         in number
                   , i_status         in varchar2
                   , i_message        in varchar2 default null
                   , i_rows_processed in number default null
                   , i_rows_rejected  in number default null
                   )
-- Chiude la riga del run con l'esito indicato e la committa, in transazione
-- autonoma. Unico punto di scrittura della chiusura, condiviso da end_run,
-- skip_run e fail_run: i tre esiti differiscono per lo stato e per il messaggio,
-- non per il modo in cui si registrano.
-- I contatori si aggiornano solo se forniti (coalesce), così una chiusura che non
-- li passa non azzera quelli già scritti dai checkpoint.
-- i_run_id         : run da chiudere.
-- i_status         : stato finale.
-- i_message        : motivo dell'esito non riuscito (errore o precondizione).
-- i_rows_processed : righe elaborate, o null per lasciare il valore corrente.
-- i_rows_rejected  : righe scartate, o null per lasciare il valore corrente.
is
    pragma autonomous_transaction;
begin
    update log_process_runs lpr
       set lpr.status         = i_status
         , lpr.ended_at       = systimestamp
         , lpr.rows_processed = coalesce(i_rows_processed, lpr.rows_processed)
         , lpr.rows_rejected  = coalesce(i_rows_rejected, lpr.rows_rejected)
         , lpr.error_message  = coalesce(i_message, lpr.error_message)
     where lpr.run_id = i_run_id;

    commit;
end close_run;
--------------------------------------------------------------------------------
procedure update_counter(i_run_id in number, i_counter in number)
-- Aggiorna il contatore di avanzamento e committa, in transazione autonoma: è ciò
-- che rende il checkpoint utile, perché il progresso di un processo lungo si deve
-- poter leggere da un'altra sessione MENTRE il processo gira, non a fine corsa.
-- i_run_id  : run in avanzamento.
-- i_counter : conteggio progressivo delle righe elaborate.
is
    pragma autonomous_transaction;
begin
    update log_process_runs lpr
       set lpr.rows_processed = i_counter
     where lpr.run_id = i_run_id;

    commit;
end update_counter;
--------------------------------------------------------------------------------
procedure release_if_locked(i_run_id in number)
-- Rilascia il lock di istanza singola associato a un run, se presente.
-- i_run_id : run di cui si rilascia il lock.
is
    k_KEY  constant varchar2(40 char) := to_char(i_run_id);
begin
    if ( g_locks.exists(k_KEY) )
    then
        lib_lock.release_lock(i_lock_handle => g_locks(k_KEY));
        g_locks.delete(k_KEY);
    end if;
end release_if_locked;
--------------------------------------------------------------------------------

-- Moduli pubblici -------------------------------------------------------------
--------------------------------------------------------------------------------
function start_run( i_process_name    in varchar2
                  , i_single_instance in boolean default false
                  )
    return number
-- Apre il run, opzionalmente sotto lock di istanza singola, e strumenta la
-- sessione (module = nome del processo).
is
    l_run_id   log_process_runs.run_id%type;
    l_handle   lib_types.lock_handle_sbt;
begin
    -- Acquisisce il lock di istanza singola prima di creare il run, così un
    -- avvio bloccato non lascia un run spurio.
    if ( i_single_instance )
    then
        begin
            l_handle := lib_lock.request_lock( i_lock_name       => i_process_name
                                             , i_timeout_seconds => k_NO_WAIT
                                             );
        exception
            when lib_err.e_lock_request_failed
            then
                lib_err.raise(i_error => lib_err.k_ALREADY_RUNNING, i_p1 => i_process_name, i_scope => k_SCOPE || '.start_run');
        end;
    end if;

    l_run_id := insert_run(i_process_name => i_process_name);

    if ( i_single_instance )
    then
        g_locks(to_char(l_run_id)) := l_handle;
    end if;

    lib_session.set_step(i_module => i_process_name, i_action => k_ACTION_START);
    lib_logging.log_info(i_text => 'Run ' || l_run_id || ' started for ' || i_process_name, i_scope => k_SCOPE || '.start_run');

    return (l_run_id);
end start_run;
--------------------------------------------------------------------------------
function check_gate( i_run_id       in number
                   , i_process_name in varchar2
                   , i_ref_date     in date default sysdate
                   )
    return boolean
-- Applica il verdetto delle precondizioni al run appena aperto.
is
    l_verdict  lib_gate.t_verdict_rec;
begin
    lib_session.set_action(i_action => k_ACTION_GATE);

    l_verdict := lib_gate.evaluate(i_process_name => i_process_name, i_ref_date => i_ref_date);

    if ( l_verdict.decision = lib_gate.k_skip )
    then
        -- Uscita fisiologica: si logga a livello informativo, non come anomalia,
        -- perché è il processo che funziona - non che fallisce.
        lib_logging.log_info( i_text  => 'Run ' || i_run_id || ' skipped for ' || i_process_name || ': ' || l_verdict.message
                            , i_scope => k_SCOPE || '.check_gate'
                            );
        skip_run(i_run_id => i_run_id, i_reason => l_verdict.message);
        return (false);
    end if;

    if ( l_verdict.decision = lib_gate.k_abort )
    then
        -- Anomalia: si solleva e basta. Chiudere qui il run come FAILED
        -- duplicherebbe il lavoro dell'handler del chiamante, che deve esserci
        -- comunque per tutti gli altri errori.
        lib_err.raise( i_error => lib_err.k_PRECONDITION_FAILED
                     , i_p1    => i_process_name
                     , i_p2    => l_verdict.message
                     , i_scope => k_SCOPE || '.check_gate'
                     );
    end if;

    return (true);
end check_gate;
--------------------------------------------------------------------------------
procedure end_run( i_run_id         in number
                 , i_status         in varchar2 default 'SUCCESS'
                 , i_rows_processed in number default null
                 , i_rows_rejected  in number default null
                 )
-- Chiude il run con esito e statistiche e rilascia il lock di istanza singola.
is
begin
    close_run( i_run_id         => i_run_id
             , i_status         => i_status
             , i_rows_processed => i_rows_processed
             , i_rows_rejected  => i_rows_rejected
             );

    release_if_locked(i_run_id => i_run_id);

    lib_logging.log_info(i_text => 'Run ' || i_run_id || ' ended with status ' || i_status, i_scope => k_SCOPE || '.end_run');
end end_run;
--------------------------------------------------------------------------------
procedure skip_run(i_run_id in number, i_reason in varchar2 default null)
-- Chiude il run come SKIPPED registrando il motivo e rilascia il lock.
is
    k_REASON  constant varchar2(4000 char) := substrb(i_reason, 1, 4000);
begin
    close_run(i_run_id => i_run_id, i_status => k_STATUS_SKIPPED, i_message => k_REASON);

    release_if_locked(i_run_id => i_run_id);
end skip_run;
--------------------------------------------------------------------------------
procedure fail_run(i_run_id in number, i_error_message in varchar2 default null)
-- Chiude il run come FAILED registrando l'errore corrente e rilascia il lock.
is
    k_MESSAGE  constant varchar2(4000 char) := substrb(coalesce(i_error_message, sqlerrm), 1, 4000);
begin
    lib_logging.log_error(i_text => 'Run ' || i_run_id || ' failed: ' || k_MESSAGE, i_scope => k_SCOPE || '.fail_run');

    close_run(i_run_id => i_run_id, i_status => k_STATUS_FAILED, i_message => k_MESSAGE);

    release_if_locked(i_run_id => i_run_id);
end fail_run;
--------------------------------------------------------------------------------
procedure checkpoint(i_run_id in number, i_step in varchar2, i_counter in number default null)
-- Aggiorna l'action di sessione e, se fornito, il contatore delle righe.
is
begin
    lib_session.set_step(i_module => lib_session.current_module, i_action => i_step);

    if ( i_counter is not null )
    then
        update_counter(i_run_id => i_run_id, i_counter => i_counter);
    end if;
end checkpoint;
--------------------------------------------------------------------------------

end lib_batch;
/

show errors package body lib_batch

prompt File: lib_batch.pkb.sql <end>
