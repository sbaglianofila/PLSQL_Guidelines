prompt File: lib_logging.pkb.sql <start>
-- =============================================================================
-- File:     lib_logging.pkb.sql
-- Oggetto:  lib_logging (corpo del package)
-- Schema:   #APP#
-- Scopo:    Writer in transazione autonoma per l'unico stream log_events (più
--           log_error_details per gli errori), con livello minimo in cache e
--           configurabile. Il livello minimo è letto da lib_config con un default,
--           così il logging non solleva mai e non ricorre in lib_err. log_error
--           non è mai filtrato.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260705  AA   Creazione
--   20260708  AA   correlation_id propagato ai writer; aggiunto new_correlation_id
--   20260708  AA   log_entries/log_errors unificate in log_events + log_error_details
--   20260708  AA   Aggiunti start_proc/end_proc, message_type ed execution_id
--   20260708  AA   Aggiunti gli overload a catalogo cfg_messages (log per codice)
--   20260708  AA   Errori Oracle resi leggibili da cfg_error_messages (override
--                  ORACLE); sqlerrm grezzo conservato in log_error_details
--   20260708  AA   start_proc/end_proc strumentano l'ACTION di sessione
--                  (fire-and-forget), così non serve push/pop manuale
--   20260708  AA   start_proc rivendica anche il MODULE quando non è impostato
--                  (senza mai sovrascrivere un nome di processo batch/APEX)
--   20260708  AA   start_proc apre un frame di step ripristinato da end_proc/
--                  end_proc_error (save/restore preciso); aggiunta end_proc_error
--   20260708  AA   Popolati log_error_details.error_stack (format_error_stack) e
--                  session_data (via lib_session.session_info)
-- =============================================================================

prompt lib_logging: Creating package body

create or replace
package body lib_logging
is
-- Costanti --------------------------------------------------------------------
-- Nomi dei livelli e il loro ranking numerico di gravità.
k_LEVEL_DEBUG   constant log_events.log_level%type := 'DEBUG';
k_LEVEL_INFO    constant log_events.log_level%type := 'INFO';
k_LEVEL_WARN    constant log_events.log_level%type := 'WARN';
k_LEVEL_ERROR   constant log_events.log_level%type := 'ERROR';

-- Tipi di messaggio: la natura dell'evento, ortogonale alla gravità.
k_TYPE_START    constant log_events.message_type%type := 'START';
k_TYPE_END      constant log_events.message_type%type := 'END';
k_TYPE_LOG      constant log_events.message_type%type := 'LOG';
k_TYPE_ERROR    constant log_events.message_type%type := 'ERROR';

k_SEV_DEBUG     constant pls_integer := 10;
k_SEV_INFO      constant pls_integer := 20;
k_SEV_WARN      constant pls_integer := 30;

k_PARAM_MIN_LEVEL constant lib_types.name_sbt := 'LOG_MIN_LEVEL';
k_PARAM_RETENTION constant lib_types.name_sbt := 'LOG_RETENTION_DAYS';

-- Globali ---------------------------------------------------------------------
-- Gravità minima in cache; aggiornata su richiesta via refresh.
g_min_severity  pls_integer;

-- Moduli privati --------------------------------------------------------------
--------------------------------------------------------------------------------
function severity_of(i_level in varchar2)
    return pls_integer
-- Mappa un nome di livello sul suo ranking di gravità.
-- i_level : nome del livello.
-- return  : gravità numerica, o k_SEV_INFO per un nome sconosciuto.
is
begin
    return ( case upper(i_level)
                when k_LEVEL_DEBUG then k_SEV_DEBUG
                when k_LEVEL_INFO  then k_SEV_INFO
                when k_LEVEL_WARN  then k_SEV_WARN
                else k_SEV_INFO
             end
           );
end severity_of;
--------------------------------------------------------------------------------
function min_severity
    return pls_integer
-- Restituisce la gravità minima in cache, leggendola dalla configurazione alla
-- prima chiamata. Usa una lettura con default così un parametro mancante non può
-- sollevare.
-- return : la gravità minima sotto la quale le voci sono scartate.
is
begin
    if ( g_min_severity is null )
    then
        g_min_severity := severity_of( lib_config.get_string( i_name    => k_PARAM_MIN_LEVEL
                                                            , i_default => k_LEVEL_INFO
                                                            )
                                     );
    end if;

    return (g_min_severity);
end min_severity;
--------------------------------------------------------------------------------
procedure write_event( i_level          in varchar2
                     , i_message_type   in varchar2
                     , i_text           in varchar2
                     , i_correlation_id in varchar2
                     , i_execution_id   in varchar2
                     , i_scope          in varchar2
                     )
-- Inserisce una riga in log_events in transazione autonoma (eventi non-errore).
-- i_level          : DEBUG / INFO / WARN.
-- i_message_type   : START / END / LOG.
-- i_text           : messaggio.
-- i_correlation_id : correlation id di esecuzione/flusso (trace id); se nullo
--                    ripiega sul correlation id di sessione (lib_session).
-- i_execution_id   : id per singola invocazione (span id).
-- i_scope          : scope logico.
is
    pragma autonomous_transaction;
begin
    insert
      into log_events (  log_level
                       , message_type
                       , process_name
                       , scope
                       , message
                       , correlation_id
                       , execution_id
                       , actor
                      )
    values (  i_level
            , i_message_type
            , lib_session.current_module
            , i_scope
            , i_text
            , coalesce(i_correlation_id, lib_session.current_correlation)
            , i_execution_id
            , lib_session.current_actor
           );

    commit;
exception
    when others
    then
        -- Il logging non deve mai rompere il chiamante.
        rollback;
end write_event;
--------------------------------------------------------------------------------
function error_text( i_sqlcode in number
                   , i_sqlerrm in varchar2
                   )
    return varchar2
-- Risolve il testo d'errore da loggare. Un errore applicativo (sqlcode nella
-- banda riservata -20999..-20000) tiene il suo sqlerrm, perché lib_err ha già
-- composto il messaggio. Un errore Oracle nativo è cercato in cfg_error_messages:
-- se il codice è a catalogo come override ORACLE si usa il suo template
-- personalizzato, altrimenti l'sqlerrm grezzo. È l'unico punto in cui gli errori
-- Oracle sono resi leggibili, quindi vale per ogni errore loggato da chiunque.
-- lib_logging legge la tabella di catalogo direttamente (non deve dipendere da
-- lib_err, che dipende da lib_logging).
-- i_sqlcode : sqlcode dell'errore che si sta loggando.
-- i_sqlerrm : sqlerrm dell'errore che si sta loggando.
-- return    : il testo da appendere al contesto del chiamante in log_events.message.
is
    l_template  cfg_error_messages.message_template%type;
begin
    if ( i_sqlcode between -20999 and -20000 )
    then
        return (i_sqlerrm);
    end if;

    select cem.message_template
      into l_template
      from cfg_error_messages cem
     where cem.error_code = i_sqlcode
       and cem.error_kind = 'ORACLE';

    return (l_template);
exception
    when no_data_found
    then
        return (i_sqlerrm);
end error_text;
--------------------------------------------------------------------------------
procedure write_error( i_text           in varchar2
                     , i_correlation_id in varchar2
                     , i_execution_id   in varchar2
                     , i_scope          in varchar2
                     )
-- Inserisce una riga ERROR in log_events più la sua diagnostica in
-- log_error_details, in un'unica transazione autonoma, catturando il contesto
-- d'errore corrente (sqlcode, sqlerrm, backtrace, call stack, error stack) e uno
-- snapshot di sessione. Il messaggio mostra l'override ORACLE a catalogo quando
-- presente (altrimenti l'sqlerrm); l'sqlerrm grezzo è sempre conservato in
-- log_error_details così da non perderlo mai.
-- i_text           : messaggio di contesto fornito dal chiamante.
-- i_correlation_id : correlation id di esecuzione/flusso (trace id); se nullo
--                    ripiega sul correlation id di sessione (lib_session).
-- i_execution_id   : id per singola invocazione (span id).
-- i_scope          : scope logico.
is
    pragma autonomous_transaction;
    l_event_id     log_events.event_id%type;
    l_sqlcode      constant number             := sqlcode;
    l_sqlerrm      constant varchar2(4000 char) := sqlerrm;
    l_error_text   varchar2(4000 char);
    l_session_data varchar2(4000 char);
begin
    -- Risolto dentro il blocco protetto: qualsiasi fallimento qui deve fare
    -- rollback e restare silente, mai propagare al chiamante (le eccezioni della
    -- sezione dichiarativa sfuggirebbero a questo handler).
    l_error_text := error_text(l_sqlcode, l_sqlerrm);

    -- Snapshot di sessione per la forensics (costruito da lib_session, sua casa).
    l_session_data := substrb(lib_session.session_info, 1, 4000);

    insert
      into log_events (  log_level
                       , message_type
                       , process_name
                       , scope
                       , message
                       , error_code
                       , correlation_id
                       , execution_id
                       , actor
                      )
    values (  k_LEVEL_ERROR
            , k_TYPE_ERROR
            , lib_session.current_module
            , i_scope
            , substrb(i_text || case when l_error_text is not null then ' - ' || l_error_text end, 1, 4000)
            , l_sqlcode
            , coalesce(i_correlation_id, lib_session.current_correlation)
            , i_execution_id
            , lib_session.current_actor
           )
    returning event_id into l_event_id;

    insert
      into log_error_details (  event_id
                              , sqlerrm_text
                              , error_backtrace
                              , call_stack
                              , error_stack
                              , session_data
                             )
    values (  l_event_id
            , substrb(l_sqlerrm, 1, 4000)
            , substrb(sys.dbms_utility.format_error_backtrace, 1, 4000)
            , substrb(sys.dbms_utility.format_call_stack,      1, 4000)
            , substrb(sys.dbms_utility.format_error_stack,     1, 4000)
            , l_session_data
           );

    commit;
exception
    when others
    then
        rollback;
end write_error;
--------------------------------------------------------------------------------

-- Moduli pubblici -------------------------------------------------------------
--------------------------------------------------------------------------------
function message_of( i_message_code in varchar2
                   , i_p1  in varchar2
                   , i_p2  in varchar2
                   , i_p3  in varchar2
                   , i_p4  in varchar2
                   , i_p5  in varchar2
                   , i_p6  in varchar2
                   , i_p7  in varchar2
                   , i_p8  in varchar2
                   , i_p9  in varchar2
                   , i_p10 in varchar2
                   )
    return varchar2
-- Compone un messaggio a catalogo: legge il template di i_message_code da
-- cfg_messages e sostituisce %1..%10 (da %10 verso %1, così rimpiazzare %1 non
-- rovina mai %10). Un codice sconosciuto degrada a '[<code>]'. La sostituzione è
-- tenuta in-package (non condivisa con lib_err) perché lib_logging non può
-- dipendere da lib_err, che dipende da lib_logging.
is
    l_message  varchar2(4000 char);
begin
    begin
        select cme.message_template
          into l_message
          from cfg_messages cme
         where cme.message_code = i_message_code;
    exception
        when no_data_found
        then
            l_message := '[' || i_message_code || ']';
    end;

    l_message := replace(l_message, '%10', i_p10);
    l_message := replace(l_message, '%9',  i_p9);
    l_message := replace(l_message, '%8',  i_p8);
    l_message := replace(l_message, '%7',  i_p7);
    l_message := replace(l_message, '%6',  i_p6);
    l_message := replace(l_message, '%5',  i_p5);
    l_message := replace(l_message, '%4',  i_p4);
    l_message := replace(l_message, '%3',  i_p3);
    l_message := replace(l_message, '%2',  i_p2);
    l_message := replace(l_message, '%1',  i_p1);

    return (l_message);
end message_of;
--------------------------------------------------------------------------------
function new_correlation_id
    return lib_types.correlation_id_sbt
-- Genera un correlation id (token esadecimale casuale).
is
begin
    return (rawtohex(sys_guid()));
end new_correlation_id;
--------------------------------------------------------------------------------
function new_execution_id
    return lib_types.execution_id_sbt
-- Genera un execution id (token esadecimale casuale).
is
begin
    return (rawtohex(sys_guid()));
end new_execution_id;
--------------------------------------------------------------------------------
function start_proc( i_scope          in lib_types.scope_sbt
                   , i_correlation_id in lib_types.correlation_id_sbt default null
                   , i_message        in varchar2 default null
                   )
    return lib_types.execution_id_sbt
-- Apre lo span, strumenta la sessione e scrive l'evento START; restituisce
-- l'execution id generato.
is
    k_EXECUTION_ID  constant lib_types.execution_id_sbt := new_execution_id;
begin
    -- Apre un frame di step: salva module/action correnti e imposta l'ACTION a
    -- questo scope. La chiusura è fatta da end_proc (successo) o end_proc_error
    -- (errore), così module/action del chiamante sono sempre ripristinati;
    -- l'handler d'errore obbligatorio tiene lo stack bilanciato.
    lib_session.open_step(i_action => i_scope);

    -- Rivendica il MODULE solo quando non ne è ancora impostato uno: dà a una
    -- chiamata top-level senza contesto (una chiamata diretta) un nome di
    -- processo, ma non sovrascrive mai quello pubblicato da un run batch
    -- (lib_batch.start_run) o da una richiesta APEX, così log_events.process_name
    -- resta il processo proprietario. close_step lo ripristina.
    if ( lib_session.current_module is null )
    then
        lib_session.set_step(i_module => i_scope, i_action => i_scope);
    end if;

    -- START/END sono marcatori di ciclo di vita a livello INFO, filtrati come
    -- qualsiasi voce INFO.
    if ( k_SEV_INFO >= min_severity )
    then
        write_event( i_level          => k_LEVEL_INFO
                   , i_message_type   => k_TYPE_START
                   , i_text           => coalesce(i_message, 'START ' || i_scope)
                   , i_correlation_id => i_correlation_id
                   , i_execution_id   => k_EXECUTION_ID
                   , i_scope          => i_scope
                   );
    end if;

    return (k_EXECUTION_ID);
end start_proc;
--------------------------------------------------------------------------------
procedure end_proc( i_scope          in lib_types.scope_sbt
                  , i_execution_id   in lib_types.execution_id_sbt
                  , i_correlation_id in lib_types.correlation_id_sbt default null
                  , i_message        in varchar2 default null
                  )
-- Scrive l'evento END (percorso di successo) e chiude lo span.
is
begin
    if ( k_SEV_INFO >= min_severity )
    then
        write_event( i_level          => k_LEVEL_INFO
                   , i_message_type   => k_TYPE_END
                   , i_text           => coalesce(i_message, 'END ' || i_scope)
                   , i_correlation_id => i_correlation_id
                   , i_execution_id   => i_execution_id
                   , i_scope          => i_scope
                   );
    end if;

    -- Chiude il frame aperto da start_proc: ripristina module/action del chiamante.
    lib_session.close_step;
end end_proc;
--------------------------------------------------------------------------------
procedure end_proc_error( i_scope          in lib_types.scope_sbt
                        , i_execution_id   in lib_types.execution_id_sbt
                        , i_correlation_id in lib_types.correlation_id_sbt default null
                        , i_message        in varchar2 default null
                        )
-- Scrive l'evento END marcato come chiusura in errore e chiude lo span; NON logga
-- l'errore in sé - per quello chiama log_error o lib_err.reraise.
is
begin
    if ( k_SEV_INFO >= min_severity )
    then
        write_event( i_level          => k_LEVEL_INFO
                   , i_message_type   => k_TYPE_END
                   , i_text           => coalesce(i_message, 'END (error) ' || i_scope)
                   , i_correlation_id => i_correlation_id
                   , i_execution_id   => i_execution_id
                   , i_scope          => i_scope
                   );
    end if;

    lib_session.close_step;
end end_proc_error;
--------------------------------------------------------------------------------
procedure log( i_text           in varchar2
             , i_correlation_id in lib_types.correlation_id_sbt default null
             , i_execution_id   in lib_types.execution_id_sbt default null
             , i_scope          in lib_types.scope_sbt default null
             )
-- Alias di comodo di log_info.
is
begin
    log_info( i_text           => i_text
            , i_correlation_id => i_correlation_id
            , i_execution_id   => i_execution_id
            , i_scope          => i_scope
            );
end log;
--------------------------------------------------------------------------------
procedure log_error( i_text           in varchar2
                   , i_correlation_id in lib_types.correlation_id_sbt default null
                   , i_execution_id   in lib_types.execution_id_sbt default null
                   , i_scope          in lib_types.scope_sbt default null
                   )
-- Scrive sempre l'evento ERROR e il suo dettaglio (mai filtrato).
is
begin
    write_error( i_text           => i_text
               , i_correlation_id => i_correlation_id
               , i_execution_id   => i_execution_id
               , i_scope          => i_scope
               );
end log_error;
--------------------------------------------------------------------------------
procedure log_warn( i_text           in varchar2
                  , i_correlation_id in lib_types.correlation_id_sbt default null
                  , i_execution_id   in lib_types.execution_id_sbt default null
                  , i_scope          in lib_types.scope_sbt default null
                  )
-- Scrive se il livello minimo <= WARN.
is
begin
    if ( k_SEV_WARN >= min_severity )
    then
        write_event( i_level          => k_LEVEL_WARN
                   , i_message_type   => k_TYPE_LOG
                   , i_text           => i_text
                   , i_correlation_id => i_correlation_id
                   , i_execution_id   => i_execution_id
                   , i_scope          => i_scope
                   );
    end if;
end log_warn;
--------------------------------------------------------------------------------
procedure log_info( i_text           in varchar2
                  , i_correlation_id in lib_types.correlation_id_sbt default null
                  , i_execution_id   in lib_types.execution_id_sbt default null
                  , i_scope          in lib_types.scope_sbt default null
                  )
-- Scrive se il livello minimo <= INFO.
is
begin
    if ( k_SEV_INFO >= min_severity )
    then
        write_event( i_level          => k_LEVEL_INFO
                   , i_message_type   => k_TYPE_LOG
                   , i_text           => i_text
                   , i_correlation_id => i_correlation_id
                   , i_execution_id   => i_execution_id
                   , i_scope          => i_scope
                   );
    end if;
end log_info;
--------------------------------------------------------------------------------
procedure log_debug( i_text           in varchar2
                   , i_correlation_id in lib_types.correlation_id_sbt default null
                   , i_execution_id   in lib_types.execution_id_sbt default null
                   , i_scope          in lib_types.scope_sbt default null
                   )
-- Scrive se il livello minimo = DEBUG.
is
begin
    if ( k_SEV_DEBUG >= min_severity )
    then
        write_event( i_level          => k_LEVEL_DEBUG
                   , i_message_type   => k_TYPE_LOG
                   , i_text           => i_text
                   , i_correlation_id => i_correlation_id
                   , i_execution_id   => i_execution_id
                   , i_scope          => i_scope
                   );
    end if;
end log_debug;
--------------------------------------------------------------------------------
procedure log_info( i_message_code   in varchar2
                  , i_p1             in varchar2 default null
                  , i_p2             in varchar2 default null
                  , i_p3             in varchar2 default null
                  , i_p4             in varchar2 default null
                  , i_p5             in varchar2 default null
                  , i_p6             in varchar2 default null
                  , i_p7             in varchar2 default null
                  , i_p8             in varchar2 default null
                  , i_p9             in varchar2 default null
                  , i_p10            in varchar2 default null
                  , i_correlation_id in lib_types.correlation_id_sbt default null
                  , i_execution_id   in lib_types.execution_id_sbt default null
                  , i_scope          in lib_types.scope_sbt default null
                  )
-- Overload a catalogo: compone da cfg_messages e scrive a livello INFO.
is
begin
    if ( k_SEV_INFO >= min_severity )
    then
        write_event( i_level          => k_LEVEL_INFO
                   , i_message_type   => k_TYPE_LOG
                   , i_text           => message_of(i_message_code, i_p1, i_p2, i_p3, i_p4, i_p5, i_p6, i_p7, i_p8, i_p9, i_p10)
                   , i_correlation_id => i_correlation_id
                   , i_execution_id   => i_execution_id
                   , i_scope          => i_scope
                   );
    end if;
end log_info;
--------------------------------------------------------------------------------
procedure log_warn( i_message_code   in varchar2
                  , i_p1             in varchar2 default null
                  , i_p2             in varchar2 default null
                  , i_p3             in varchar2 default null
                  , i_p4             in varchar2 default null
                  , i_p5             in varchar2 default null
                  , i_p6             in varchar2 default null
                  , i_p7             in varchar2 default null
                  , i_p8             in varchar2 default null
                  , i_p9             in varchar2 default null
                  , i_p10            in varchar2 default null
                  , i_correlation_id in lib_types.correlation_id_sbt default null
                  , i_execution_id   in lib_types.execution_id_sbt default null
                  , i_scope          in lib_types.scope_sbt default null
                  )
-- Overload a catalogo: compone da cfg_messages e scrive a livello WARN.
is
begin
    if ( k_SEV_WARN >= min_severity )
    then
        write_event( i_level          => k_LEVEL_WARN
                   , i_message_type   => k_TYPE_LOG
                   , i_text           => message_of(i_message_code, i_p1, i_p2, i_p3, i_p4, i_p5, i_p6, i_p7, i_p8, i_p9, i_p10)
                   , i_correlation_id => i_correlation_id
                   , i_execution_id   => i_execution_id
                   , i_scope          => i_scope
                   );
    end if;
end log_warn;
--------------------------------------------------------------------------------
procedure log_debug( i_message_code   in varchar2
                   , i_p1             in varchar2 default null
                   , i_p2             in varchar2 default null
                   , i_p3             in varchar2 default null
                   , i_p4             in varchar2 default null
                   , i_p5             in varchar2 default null
                   , i_p6             in varchar2 default null
                   , i_p7             in varchar2 default null
                   , i_p8             in varchar2 default null
                   , i_p9             in varchar2 default null
                   , i_p10            in varchar2 default null
                   , i_correlation_id in lib_types.correlation_id_sbt default null
                   , i_execution_id   in lib_types.execution_id_sbt default null
                   , i_scope          in lib_types.scope_sbt default null
                   )
-- Overload a catalogo: compone da cfg_messages e scrive a livello DEBUG.
is
begin
    if ( k_SEV_DEBUG >= min_severity )
    then
        write_event( i_level          => k_LEVEL_DEBUG
                   , i_message_type   => k_TYPE_LOG
                   , i_text           => message_of(i_message_code, i_p1, i_p2, i_p3, i_p4, i_p5, i_p6, i_p7, i_p8, i_p9, i_p10)
                   , i_correlation_id => i_correlation_id
                   , i_execution_id   => i_execution_id
                   , i_scope          => i_scope
                   );
    end if;
end log_debug;
--------------------------------------------------------------------------------
procedure refresh
-- Svuota il livello minimo in cache: la chiamata successiva lo rilegge.
is
begin
    g_min_severity := null;
end refresh;
--------------------------------------------------------------------------------
procedure purge(i_retention_days in number default null)
-- Elimina le righe di log oltre la finestra di retention.
is
    k_RETENTION  constant number := coalesce( i_retention_days
                                            , lib_config.get_number( i_name    => k_PARAM_RETENTION
                                                                   , i_default => lib_constants.k_LOG_RETENTION
                                                                   )
                                            );
    k_CUTOFF     constant timestamp := systimestamp - numtodsinterval(k_RETENTION, 'DAY');
begin
    -- Elimina prima il dettaglio errori (figlio), poi gli eventi (padre).
    delete
      from log_error_details led
     where led.event_id in ( select lev.event_id
                               from log_events lev
                              where lev.logged_at < k_CUTOFF
                           );

    delete
      from log_events lev
     where lev.logged_at < k_CUTOFF;

    commit;
end purge;
--------------------------------------------------------------------------------

end lib_logging;
/

show errors package body lib_logging

prompt File: lib_logging.pkb.sql <end>
