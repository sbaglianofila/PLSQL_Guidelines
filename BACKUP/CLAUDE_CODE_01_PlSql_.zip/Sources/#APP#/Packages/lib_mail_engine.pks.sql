prompt File: lib_mail_engine.pks.sql <start>
-- =============================================================================
-- File:     lib_mail_engine.pks.sql
-- Oggetto:  lib_mail_engine (specifica del package)
-- Schema:   #APP#
-- Scopo:    Trasmissione mail di basso livello dietro lib_mail. È l'unico pezzo
--           che cambia tra i motori mail: si installa esattamente un body -
--           lib_mail_engine.utl_smtp.pkb.sql (SMTP diretto) OPPURE
--           lib_mail_engine.apex.pkb.sql (APEX_MAIL). Tutta la logica di più alto
--           livello (coda, guardia d'ambiente, template, logging) vive in lib_mail
--           ed è indipendente dal motore.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260705  AA   Creazione
-- =============================================================================

prompt lib_mail_engine: Creating package specification

create or replace
package lib_mail_engine
is
--------------------------------------------------------------------------------
-- Trasmette in modo sincrono un messaggio già composto e già filtrato dalla
-- guardia d'ambiente attraverso il motore configurato. Gli elenchi di destinatari
-- sono separati da virgola. Solleva lib_err.e_mail_send_failed su qualsiasi errore
-- di trasporto.
-- i_from    : indirizzo mittente.
-- i_to      : elenco destinatari (separati da virgola).
-- i_cc      : elenco cc (separati da virgola), o null.
-- i_bcc     : elenco bcc (separati da virgola), o null.
-- i_subject : oggetto del messaggio.
-- i_body    : corpo del messaggio (testo semplice o HTML secondo i_is_html).
-- i_is_html : true quando il corpo è HTML.
procedure deliver( i_from    in varchar2
                 , i_to      in varchar2
                 , i_cc      in varchar2
                 , i_bcc     in varchar2
                 , i_subject in varchar2
                 , i_body    in clob
                 , i_is_html in boolean
                 );
--------------------------------------------------------------------------------
-- Identificatore del motore, per la diagnostica ('UTL_SMTP' o 'APEX_MAIL').
function backend
    return varchar2;
--------------------------------------------------------------------------------

end lib_mail_engine;
/

show errors package lib_mail_engine

prompt File: lib_mail_engine.pks.sql <end>
