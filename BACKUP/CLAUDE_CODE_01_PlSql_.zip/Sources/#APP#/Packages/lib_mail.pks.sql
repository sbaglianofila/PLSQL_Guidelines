prompt File: lib_mail.pks.sql <start>
-- =============================================================================
-- File:     lib_mail.pks.sql
-- Oggetto:  lib_mail (specifica del package)
-- Schema:   #APP#
-- Scopo:    Package mail generico. Il suo valore non è "chiamare il motore" ma
--           tutto ciò che gli sta intorno: costruzione corretta del messaggio,
--           template, coda, e la guardia d'ambiente che impedisce l'invio di mail
--           reali fuori produzione. La trasmissione vera è delegata a
--           lib_mail_engine, così il motore (UTL_SMTP o APEX_MAIL) può essere
--           sostituito senza toccare questo package.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260705  AA   Creazione
-- =============================================================================

prompt lib_mail: Creating package specification

create or replace
package lib_mail
is
--------------------------------------------------------------------------------
-- Invia un messaggio. Accodato di default (scritto in wrk_mail_queue e consegnato
-- più tardi da process_queue); imposta i_immediate a true per consegnare in modo
-- sincrono. Fuori produzione i destinatari sono riscritti sulla casella di test e
-- l'oggetto è marcato - questa guardia non può essere aggirata dal chiamante.
-- i_to        : elenco destinatari (separati da virgola).
-- i_subject   : oggetto del messaggio.
-- i_body      : corpo del messaggio (testo semplice o HTML secondo i_is_html).
-- i_cc        : elenco cc (separati da virgola), o null.
-- i_bcc       : elenco bcc (separati da virgola), o null.
-- i_is_html   : true quando il corpo è HTML.
-- i_from      : indirizzo mittente; default dalla configurazione quando null.
-- i_immediate : true per inviare subito, false (default) per accodare.
procedure send( i_to        in varchar2
              , i_subject   in varchar2
              , i_body      in clob
              , i_cc        in varchar2 default null
              , i_bcc       in varchar2 default null
              , i_is_html   in boolean  default false
              , i_from      in varchar2 default null
              , i_immediate in boolean  default false
              );
--------------------------------------------------------------------------------
-- Invia un messaggio il cui oggetto e corpo vengono da cfg_email_templates, con i
-- segnaposto %1..%5 risolti. Stesso comportamento di coda e guardia di send.
-- i_template_code : template da usare.
-- i_to            : elenco destinatari (separati da virgola).
-- i_p1..5         : valori dei segnaposto.
-- i_cc            : elenco cc, o null.
-- i_bcc           : elenco bcc, o null.
-- i_immediate     : true per inviare subito, false (default) per accodare.
procedure send_template( i_template_code in varchar2
                       , i_to            in varchar2
                       , i_p1            in varchar2 default null
                       , i_p2            in varchar2 default null
                       , i_p3            in varchar2 default null
                       , i_p4            in varchar2 default null
                       , i_p5            in varchar2 default null
                       , i_cc            in varchar2 default null
                       , i_bcc           in varchar2 default null
                       , i_immediate     in boolean  default false
                       );
--------------------------------------------------------------------------------
-- Drena la coda: consegna i messaggi pendenti via lib_mail_engine con retry e
-- backoff, con commit per messaggio. Pensata per un job schedulato. Non fa nulla
-- quando il parametro MAIL_ENABLED è 'N'.
-- i_max_messages : massimo numero di messaggi da elaborare in questo run; null
--                  per una dimensione di batch di default.
procedure process_queue(i_max_messages in number default null);
--------------------------------------------------------------------------------

end lib_mail;
/

show errors package lib_mail

prompt File: lib_mail.pks.sql <end>
