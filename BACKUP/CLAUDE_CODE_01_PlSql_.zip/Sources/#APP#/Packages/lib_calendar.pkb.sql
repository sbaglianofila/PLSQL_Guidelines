prompt File: lib_calendar.pkb.sql <start>
-- =============================================================================
-- File:     lib_calendar.pkb.sql
-- Oggetto:  lib_calendar (corpo del package)
-- Schema:   #APP#
-- Scopo:    Aritmetica dei giorni lavorativi sopra la regola del weekend e
--           ref_holidays, più il calcolo delle date che Oracle non deduce da sé
--           (Pasqua e anno bisestile).
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260705  AA   Creazione
--   20260730  AA   Aggiunte is_holiday (estratta da is_working_day),
--                  get_easter_date, is_leap_year e dates_overlap
--   20260730  AA   Aggiunte days_between/working_days_in (table function) e
--                  nth_weekday_of_month
-- =============================================================================

prompt lib_calendar: Creating package body

create or replace
package body lib_calendar
is
-- Costanti --------------------------------------------------------------------
-- Indice del giorno della settimana relativo alla settimana ISO (0=lun .. 6=dom),
-- indipendente dalle impostazioni NLS. Sabato e domenica sono gli indici 5 e 6.
k_FIRST_WEEKEND_DOW  constant pls_integer := 5;

-- Estremi ammessi per l'anno di get_easter_date: il minimo è il primo anno pieno
-- dopo la riforma gregoriana, il massimo è l'ultimo anno rappresentabile in una
-- date di Oracle.
k_EASTER_MIN_YEAR    constant pls_integer := 1583;
k_MAX_YEAR           constant pls_integer := 9999;

-- Moduli pubblici -------------------------------------------------------------
--------------------------------------------------------------------------------
function is_working_day(i_date in date, i_calendar in varchar2 default 'DEFAULT')
    return boolean
-- Vero se la data non è weekend né festività.
is
    k_DAY   constant date := trunc(i_date);
    l_dow            pls_integer := k_DAY - trunc(k_DAY, 'IW');
begin
    if ( l_dow >= k_FIRST_WEEKEND_DOW )
    then
        return (false);
    end if;

    return ( not is_holiday(i_date => k_DAY, i_calendar => i_calendar) );
end is_working_day;
--------------------------------------------------------------------------------
function is_holiday(i_date in date, i_calendar in varchar2 default 'DEFAULT')
    return boolean
-- Vero se la data è a calendario in ref_holidays, weekend compreso.
is
    k_DAY   constant date := trunc(i_date);
    l_holidays       pls_integer;
begin
    select count(*)
      into l_holidays
      from ref_holidays rfh
     where rfh.calendar_code = i_calendar
       and rfh.holiday_date  = k_DAY;

    return (l_holidays > 0);
end is_holiday;
--------------------------------------------------------------------------------
function next_working_day(i_date in date, i_calendar in varchar2 default 'DEFAULT')
    return date
-- Primo giorno lavorativo dopo i_date.
is
    l_day  date := trunc(i_date) + 1;
begin
    while ( not is_working_day(i_date => l_day, i_calendar => i_calendar) )
    loop
        l_day := l_day + 1;
    end loop;

    return (l_day);
end next_working_day;
--------------------------------------------------------------------------------
function previous_working_day(i_date in date, i_calendar in varchar2 default 'DEFAULT')
    return date
-- Ultimo giorno lavorativo prima di i_date.
is
    l_day  date := trunc(i_date) - 1;
begin
    while ( not is_working_day(i_date => l_day, i_calendar => i_calendar) )
    loop
        l_day := l_day - 1;
    end loop;

    return (l_day);
end previous_working_day;
--------------------------------------------------------------------------------
function add_working_days(i_date in date, i_days in number, i_calendar in varchar2 default 'DEFAULT')
    return date
-- Aggiunge i_days giorni lavorativi (negativo per andare indietro).
is
    l_day        date := trunc(i_date);
    k_STEP       constant pls_integer := sign(i_days);
    l_remaining  pls_integer := abs(i_days);
begin
    while ( l_remaining > 0 )
    loop
        l_day := l_day + k_STEP;

        if ( is_working_day(i_date => l_day, i_calendar => i_calendar) )
        then
            l_remaining := l_remaining - 1;
        end if;
    end loop;

    return (l_day);
end add_working_days;
--------------------------------------------------------------------------------
function working_days_between(i_from in date, i_to in date, i_calendar in varchar2 default 'DEFAULT')
    return number
-- Conteggio con segno dei giorni lavorativi tra due date.
is
    k_LOW   constant date := trunc(least(i_from, i_to));
    k_HIGH  constant date := trunc(greatest(i_from, i_to));
    l_day            date := k_LOW;
    l_count          pls_integer := 0;
begin
    while ( l_day < k_HIGH )
    loop
        l_day := l_day + 1;

        if ( is_working_day(i_date => l_day, i_calendar => i_calendar) )
        then
            l_count := l_count + 1;
        end if;
    end loop;

    return ( case
                when trunc(i_to) < trunc(i_from) then -l_count
                else l_count
             end
           );
end working_days_between;
--------------------------------------------------------------------------------
function days_between(i_from in date, i_to in date)
    return t_dates pipelined
-- Serie delle date dell'intervallo, una per riga.
is
    l_day            date := trunc(i_from);
    k_LAST  constant date := trunc(i_to);
begin
    while ( l_day <= k_LAST )
    loop
        pipe row (l_day);
        l_day := l_day + 1;
    end loop;

    return;
end days_between;
--------------------------------------------------------------------------------
function working_days_in(i_from in date, i_to in date, i_calendar in varchar2 default 'DEFAULT')
    return t_dates pipelined
-- Serie dei soli giorni lavorativi dell'intervallo.
is
    l_day            date := trunc(i_from);
    k_LAST  constant date := trunc(i_to);
begin
    while ( l_day <= k_LAST )
    loop
        if ( is_working_day(i_date => l_day, i_calendar => i_calendar) )
        then
            pipe row (l_day);
        end if;

        l_day := l_day + 1;
    end loop;

    return;
end working_days_in;
--------------------------------------------------------------------------------
function dates_overlap( i_a_from in date
                      , i_a_to   in date
                      , i_b_from in date
                      , i_b_to   in date
                      , i_trunc  in boolean default true
                      )
    return boolean
-- Sovrapposizione di due intervalli a estremi inclusi, con null = aperto.
is
    -- Null risolto sui sentinelli di validità aperta: from mancante = da sempre,
    -- to mancante = per sempre.
    l_a1  date := coalesce(i_a_from, lib_constants.k_DATE_MIN);
    l_a2  date := coalesce(i_a_to,   lib_constants.k_DATE_MAX);
    l_b1  date := coalesce(i_b_from, lib_constants.k_DATE_MIN);
    l_b2  date := coalesce(i_b_to,   lib_constants.k_DATE_MAX);

    -- Estremi ordinati: una coppia invertita è trattata come l'intervallo tra le
    -- due date invece di falsare il confronto.
    l_a_from  date := least(l_a1, l_a2);
    l_a_to    date := greatest(l_a1, l_a2);
    l_b_from  date := least(l_b1, l_b2);
    l_b_to    date := greatest(l_b1, l_b2);
begin
    if ( i_trunc )
    then
        l_a_from := trunc(l_a_from);
        l_a_to   := trunc(l_a_to);
        l_b_from := trunc(l_b_from);
        l_b_to   := trunc(l_b_to);
    end if;

    return ( l_a_from <= l_b_to and l_b_from <= l_a_to );
end dates_overlap;
--------------------------------------------------------------------------------
function nth_weekday_of_month(i_year in number, i_month in number, i_weekday in number, i_n in number)
    return date
-- n-esima occorrenza di un giorno della settimana nel mese, contata dall'inizio
-- (n>0) o dalla fine (n<0). Il giorno della settimana ISO di una data si ricava
-- come d - trunc(d,'IW') + 1 (1=lunedì), senza dipendere da NLS.
is
    l_first          date;    -- primo giorno del mese
    l_anchor         date;    -- estremo da cui si conta (inizio o fine mese)
    l_anchor_dow     pls_integer;
    l_delta          pls_integer;
    l_result         date;
begin
    lib_assert.in_range(i_value => i_month,   i_min => 1, i_max => 12, i_param_name => 'i_month');
    lib_assert.in_range(i_value => i_weekday, i_min => 1, i_max => 7,  i_param_name => 'i_weekday');
    lib_assert.not_null(i_value => i_year, i_param_name => 'i_year');
    lib_assert.is_true(i_condition => (i_n is not null and i_n <> 0), i_message => 'i_n deve essere diverso da zero');

    l_first := to_date(  lpad(trunc(i_year), 4, '0')
                      || lpad(i_month, 2, '0')
                      || '01'
                      , 'YYYYMMDD'
                      );

    if ( i_n > 0 )
    then
        -- Dall'inizio: dal primo del mese si avanza al primo giorno-settimana
        -- richiesto, poi si aggiungono (n-1) settimane intere.
        l_anchor     := l_first;
        l_anchor_dow := l_anchor - trunc(l_anchor, 'IW') + 1;
        l_delta      := mod(i_weekday - l_anchor_dow + 7, 7);
        l_result     := l_anchor + l_delta + (i_n - 1) * 7;
    else
        -- Dalla fine: dall'ultimo del mese si arretra all'ultimo giorno-settimana
        -- richiesto, poi si tolgono (|n|-1) settimane intere.
        l_anchor     := last_day(l_first);
        l_anchor_dow := l_anchor - trunc(l_anchor, 'IW') + 1;
        l_delta      := mod(l_anchor_dow - i_weekday + 7, 7);
        l_result     := l_anchor - l_delta - (abs(i_n) - 1) * 7;
    end if;

    -- Fuori dal mese richiesto significa che quell'occorrenza non esiste.
    if ( trunc(l_result, 'MM') = l_first )
    then
        return (l_result);
    else
        return (null);
    end if;
end nth_weekday_of_month;
--------------------------------------------------------------------------------
function get_easter_date(i_year in number)
    return date
-- Domenica di Pasqua con l'algoritmo di Meeus/Jones/Butcher.
-- I nomi delle variabili intermedie seguono il significato astronomico dei termini
-- dell'algoritmo, non le lettere a..m con cui è pubblicato: il calcolo è opaco per
-- costruzione e le lettere non aiuterebbero a rileggerlo.
-- Nota sui mod: qui non serve normalizzare il resto, perché nella formulazione
-- dell'algoritmo l_epact e l_weekday_offset restano per costruzione non negativi -
-- il mod di Oracle, che segue il segno del dividendo, non li tocca.
is
    l_year                  pls_integer;

    l_golden_number         number; -- Posizione dell'anno nel ciclo metonico (19 anni)
    l_century               number; -- Secolo
    l_year_of_century       number; -- Anno all'interno del secolo
    l_leap_century          number; -- Numero di anni bisestili del secolo
    l_century_remainder     number; -- Resto della divisione del secolo per 4
    l_correction1           number; -- Prima correzione del calendario gregoriano
    l_correction2           number; -- Seconda correzione del calendario gregoriano
    l_epact                 number; -- Epatta (età della Luna al 1° gennaio)
    l_leap_years            number; -- Anni bisestili trascorsi nel secolo
    l_year_remainder        number; -- Resto della divisione dell'anno per 4
    l_weekday_offset        number; -- Correzione per il giorno della settimana
    l_month_correction      number; -- Correzione finale dell'algoritmo

    l_month                 number; -- Mese della Pasqua (3=marzo, 4=aprile)
    l_day                   number; -- Giorno della Pasqua
begin
    lib_assert.in_range( i_value      => i_year
                       , i_min        => k_EASTER_MIN_YEAR
                       , i_max        => k_MAX_YEAR
                       , i_param_name => 'i_year'
                       );

    l_year := trunc(i_year);

    -- Parametri intermedi ------------------------------------------------------
    l_golden_number     := mod(l_year, 19);

    l_century           := trunc(l_year / 100);
    l_year_of_century   := mod(l_year, 100);

    l_leap_century      := trunc(l_century / 4);
    l_century_remainder := mod(l_century, 4);

    l_correction1       := trunc((l_century + 8) / 25);
    l_correction2       := trunc((l_century - l_correction1 + 1) / 3);

    -- Epatta: fase della Luna all'inizio dell'anno
    l_epact := mod(  19 * l_golden_number
                        + l_century
                        - l_leap_century
                        - l_correction2
                        + 15
                   , 30);

    l_leap_years     := trunc(l_year_of_century / 4);
    l_year_remainder := mod(l_year_of_century, 4);

    -- Correzione legata al giorno della settimana
    l_weekday_offset := mod(  32 + 2 * l_century_remainder
                                 + 2 * l_leap_years
                                 - l_epact
                                 - l_year_remainder
                            , 7);

    -- Correzione finale
    l_month_correction := trunc(  ( l_golden_number
                                        + 11 * l_epact
                                        + 22 * l_weekday_offset
                                  ) / 451
                               );

    -- Mese e giorno ------------------------------------------------------------
    l_month := trunc( (l_epact + l_weekday_offset - 7 * l_month_correction + 114) / 31 );

    l_day := mod(  l_epact + l_weekday_offset
                        - 7 * l_month_correction
                        + 114
                 , 31
                ) + 1;

    -- Il format model è esplicito, quindi la composizione non dipende da NLS;
    -- l'anno è di quattro cifre per costruzione (il minimo ammesso è 1583).
    -- Su 23ai la stessa cosa si scriverebbe datefromparts(l_year, l_month, l_day).
    return ( to_date(    lpad(l_year, 4, '0')
                      || lpad(l_month, 2, '0')
                      || lpad(l_day, 2, '0')
                    , 'YYYYMMDD'
                    )
           );
end get_easter_date;
--------------------------------------------------------------------------------
function is_leap_year(i_year in number)
    return boolean
-- Regola gregoriana dell'anno bisestile.
is
begin
    lib_assert.not_null(i_value => i_year, i_param_name => 'i_year');

    if ( mod(i_year, 4) <> 0 )
    then
        return (false);

    elsif ( mod(i_year, 400) = 0 )
    then
        return (true);

    elsif ( mod(i_year, 100) = 0 )
    then
        return (false);

    else
        return (true);

    end if;
end is_leap_year;
--------------------------------------------------------------------------------

end lib_calendar;
/

show errors package body lib_calendar

prompt File: lib_calendar.pkb.sql <end>
