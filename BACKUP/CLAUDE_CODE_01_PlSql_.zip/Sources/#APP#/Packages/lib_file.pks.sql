prompt File: lib_file.pks.sql <start>
-- =============================================================================
-- File:     lib_file.pks.sql
-- Oggetto:  lib_file (specifica del package)
-- Schema:   #APP#
-- Scopo:    I/O su file sopra sys.utl_file, solo dove utl_file è scomodo o
--           rischioso da usare grezzo: lettura/scrittura dell'intero file da e
--           verso CLOB, errori parlanti, validazione del nome file (niente path
--           traversal). Le directory sono i nomi degli oggetti DIRECTORY di
--           Oracle; i chiamanti li risolvono dalla configurazione (lib_config)
--           invece di hardcodarli.
--           Prerequisiti: grant execute on sys.utl_file, e oggetti DIRECTORY con
--           read/write concessi all'owner.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260705  AA   Creazione
-- =============================================================================

prompt lib_file: Creating package specification

create or replace
package lib_file
is
--------------------------------------------------------------------------------
-- Legge un intero file di testo in un CLOB. Solleva lib_err.e_file_not_found
-- quando il file manca, lib_err.e_file_io_error su altri errori di I/O. Il CLOB
-- temporaneo restituito va liberato dal chiamante.
-- i_directory : nome dell'oggetto DIRECTORY di Oracle.
-- i_filename  : nome del file (nessun separatore di path).
-- return      : contenuto del file come CLOB.
function read_clob(i_directory in varchar2, i_filename in varchar2)
    return clob;
--------------------------------------------------------------------------------
-- Scrive un CLOB su un file di testo, sovrascrivendolo. Solleva
-- lib_err.e_file_io_error al fallimento; l'handle del file è chiuso anche in caso
-- di errore.
-- i_directory : nome dell'oggetto DIRECTORY di Oracle.
-- i_filename  : nome del file (nessun separatore di path).
-- i_content   : contenuto da scrivere.
procedure write_clob(i_directory in varchar2, i_filename in varchar2, i_content in clob);
--------------------------------------------------------------------------------
-- Vero quando il file esiste nella directory.
-- i_directory : nome dell'oggetto DIRECTORY di Oracle.
-- i_filename  : nome del file (nessun separatore di path).
-- return      : true quando il file esiste.
function file_exists(i_directory in varchar2, i_filename in varchar2)
    return boolean;
--------------------------------------------------------------------------------
-- Elimina un file. Solleva lib_err.e_file_io_error al fallimento.
-- i_directory : nome dell'oggetto DIRECTORY di Oracle.
-- i_filename  : nome del file (nessun separatore di path).
procedure remove_file(i_directory in varchar2, i_filename in varchar2);
--------------------------------------------------------------------------------
-- Rinomina/sposta un file. Solleva lib_err.e_file_io_error al fallimento.
-- i_src_directory : nome DIRECTORY sorgente.
-- i_src_filename  : nome file sorgente.
-- i_dst_directory : nome DIRECTORY destinazione.
-- i_dst_filename  : nome file destinazione.
-- i_overwrite     : true per sovrascrivere una destinazione esistente.
procedure rename_file( i_src_directory in varchar2
                     , i_src_filename  in varchar2
                     , i_dst_directory in varchar2
                     , i_dst_filename  in varchar2
                     , i_overwrite     in boolean default false
                     );
--------------------------------------------------------------------------------

end lib_file;
/

show errors package lib_file

prompt File: lib_file.pks.sql <end>
