prompt File: lib_lock.pks.sql <start>
-- =============================================================================
-- File:     lib_lock.pks.sql
-- Oggetto:  lib_lock (specifica del package)
-- Schema:   #APP#
-- Scopo:    Lock applicativi. Serializza i processi che non devono girare in
--           parallelo, appoggiandosi a sys.dbms_lock così che Oracle ne
--           garantisca il rilascio anche se la sessione cade. Le firme seguono il
--           pattern del capitolo 11 (request_lock / release_lock), estese con un
--           timeout di richiesta esplicito.
--           Prerequisito: grant execute on sys.dbms_lock (vedi
--           template_system_grant.grt.sql).
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260705  AA   Creazione
-- =============================================================================

prompt lib_lock: Creating package specification

create or replace
package lib_lock
is
--------------------------------------------------------------------------------
-- Acquisisce il lock esclusivo con il nome dato e ne restituisce l'handle.
-- Solleva lib_err.e_lock_request_failed se il lock non può essere ottenuto entro
-- i_timeout_seconds. Il nome del lock è risolto in un handle stabile con
-- allocate_unique, così i chiamanti trattano sempre e solo il nome logico.
-- i_lock_name         : nome logico del lock.
-- i_timeout_seconds   : secondi di attesa prima di rinunciare.
-- i_release_on_commit : true per rilasciare il lock al commit successivo;
--                       false (default) per tenerlo fino al rilascio esplicito
--                       o alla fine della sessione.
-- return              : l'handle del lock da passare a release_lock.
function request_lock( i_lock_name         in lib_types.lock_name_sbt
                     , i_timeout_seconds   in number  default lib_constants.k_DEFAULT_LOCK_WAIT
                     , i_release_on_commit in boolean default false
                     )
    return lib_types.lock_handle_sbt;
--------------------------------------------------------------------------------
-- Rilascia un lock acquisito in precedenza con request_lock.
-- i_lock_handle : handle restituito da request_lock.
procedure release_lock(i_lock_handle in lib_types.lock_handle_sbt);
--------------------------------------------------------------------------------

end lib_lock;
/

show errors package lib_lock

prompt File: lib_lock.pks.sql <end>
