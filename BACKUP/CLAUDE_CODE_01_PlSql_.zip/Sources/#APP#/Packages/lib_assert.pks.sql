prompt File: lib_assert.pks.sql <start>
-- =============================================================================
-- File:     lib_assert.pks.sql
-- Oggetto:  lib_assert (specifica del package)
-- Schema:   #APP#
-- Scopo:    Validazione degli argomenti - il complemento applicativo a
--           dbms_assert (che valida identificatori SQL, non argomenti di
--           business). Trasforma i controlli dei parametri all'ingresso delle API
--           in una riga leggibile invece di un if/raise scritto a mano. Piccolo
--           per costruzione: non deve crescere fino a duplicare i vincoli del
--           database - l'integrità dei dati resta ai vincoli; qui si validano gli
--           argomenti delle chiamate.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260705  AA   Creazione
-- =============================================================================

prompt lib_assert: Creating package specification

create or replace
package lib_assert
is
--------------------------------------------------------------------------------
-- Asserisce che un argomento testuale non sia null; altrimenti solleva
-- lib_err.e_invalid_parameter nominando il parametro.
-- i_value      : valore da controllare.
-- i_param_name : nome del parametro riportato nell'errore.
procedure not_null(i_value in varchar2, i_param_name in varchar2);
--------------------------------------------------------------------------------
-- Asserisce che un argomento numerico non sia null.
procedure not_null(i_value in number, i_param_name in varchar2);
--------------------------------------------------------------------------------
-- Asserisce che un argomento data non sia null.
procedure not_null(i_value in date, i_param_name in varchar2);
--------------------------------------------------------------------------------
-- Asserzione generica: solleva l'errore a catalogo dato quando la condizione è
-- falsa o null.
-- i_condition : condizione che deve valere.
-- i_error     : codice a catalogo da sollevare al fallimento.
-- i_message   : dettaglio opzionale sostituito nel messaggio d'errore.
procedure is_true( i_condition in boolean
                 , i_error     in pls_integer default lib_err.k_INVALID_PARAMETER
                 , i_message   in varchar2 default null
                 );
--------------------------------------------------------------------------------
-- Asserisce che un valore numerico stia in [i_min, i_max]; altrimenti solleva
-- lib_err.e_invalid_parameter.
-- i_value      : valore da controllare.
-- i_min        : limite inferiore incluso.
-- i_max        : limite superiore incluso.
-- i_param_name : nome del parametro riportato nell'errore.
procedure in_range(i_value in number, i_min in number, i_max in number, i_param_name in varchar2);
--------------------------------------------------------------------------------
-- Asserisce che un valore testuale non sia più lungo di i_max; altrimenti solleva
-- lib_err.e_param_too_large.
-- i_value      : valore da controllare.
-- i_max        : lunghezza massima in caratteri.
-- i_param_name : nome del parametro riportato nell'errore.
procedure max_length(i_value in varchar2, i_max in number, i_param_name in varchar2);
--------------------------------------------------------------------------------

end lib_assert;
/

show errors package lib_assert

prompt File: lib_assert.pks.sql <end>
