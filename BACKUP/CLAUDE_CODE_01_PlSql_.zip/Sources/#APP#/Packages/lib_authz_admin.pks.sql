prompt File: lib_authz_admin.pks.sql <start>
-- =============================================================================
-- File:     lib_authz_admin.pks.sql
-- Oggetto:  lib_authz_admin (specifica del package)
-- Schema:   #APP#
-- Scopo:    Table API di scrittura sulle tabelle adm_* del RBAC: il gemello di
--           scrittura di lib_authz (che legge). Incapsula le operazioni
--           amministrative sulla mappa dei permessi - assegnazioni, grant,
--           eccezioni, composizione dei profili, ciclo di vita degli utenti -
--           così che nessuno faccia DML sparsa sulle adm_* dimenticandosi audit e
--           refresh. Vedi Architettura_DB/utenti_profili.md.
--
--           ATTENZIONE - QUESTE PROCEDURE COMMITTANO. Ogni operazione possiede la
--           propria transazione (DML -> commit -> eventuale refresh della MV): è
--           una deroga DICHIARATA e circoscritta alla regola generale "il commit è
--           del chiamante", giustificata dalla natura amministrativa e fuori-banda
--           di queste operazioni e imposta dal vincolo "refresh dopo il commit"
--           (dbms_mview.refresh non gira a transazione aperta). NON invocarle
--           dentro una transazione applicativa aperta: il loro commit chiuderebbe
--           anche il lavoro in sospeso del chiamante.
--
--           REFRESH DELLA MV: solo le operazioni che toccano ciò che la vista
--           materializzata materializza - assegnazioni utente-profilo e grant
--           funzionalità-profilo - chiamano lib_authz.refresh_mv dopo il commit. Le
--           eccezioni nominali e lo stato dell'utente li legge al volo lib_authz, e
--           la composizione profilo-ruolo non gate le funzionalità: queste
--           committano soltanto (le altre sessioni si riallineano al TTL della loro
--           cache).
--
--           CARICAMENTO INIZIALE: il catalogo di base di un progetto (moduli,
--           maschere, funzionalità, ruoli, profili) si carica con gli script di
--           seed .dat.sql, non da questa API, così un setup di massa non genera un
--           commit e un refresh per riga. Qui vivono le modifiche a RUNTIME.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260725  AA   Creazione
-- =============================================================================

prompt lib_authz_admin: Creating package specification

create or replace
package lib_authz_admin
is
--------------------------------------------------------------------------------
-- ASSEGNAZIONI UTENTE-PROFILO (adm_user_profiles) - rinfrescano la MV.
--------------------------------------------------------------------------------
-- Assegna un profilo a un utente, con finestra di validità opzionale (grana
-- data). Se l'assegnazione esiste già ne aggiorna la finestra (upsert).
-- i_user_id      : utente destinatario.
-- i_profile_code : profilo assegnato.
-- i_valid_from   : inizio validità (incluso); null = da sempre.
-- i_valid_to     : fine validità (inclusa); null = senza scadenza.
procedure assign_profile( i_user_id      in adm_users.user_id%type
                        , i_profile_code in adm_profiles.profile_code%type
                        , i_valid_from   in date default null
                        , i_valid_to     in date default null
                        );
--------------------------------------------------------------------------------
-- Revoca a un utente un profilo assegnato. Nessun errore se non era assegnato.
-- i_user_id      : utente.
-- i_profile_code : profilo da revocare.
procedure revoke_profile( i_user_id      in adm_users.user_id%type
                        , i_profile_code in adm_profiles.profile_code%type
                        );
--------------------------------------------------------------------------------
-- GRANT FUNZIONALITA'-PROFILO (adm_profile_functionalities) - rinfrescano la MV.
--------------------------------------------------------------------------------
-- Concede una funzionalità a un profilo con i tre modi e una finestra opzionale.
-- Se il grant esiste già ne aggiorna modi e finestra (upsert).
-- i_profile_code       : profilo a cui si concede.
-- i_functionality_code : funzionalità concessa.
-- i_can_read/write/execute : i tre modi ('Y'/'N').
-- i_valid_from/to      : finestra di validità (grana data), null = aperta.
procedure grant_functionality( i_profile_code       in adm_profiles.profile_code%type
                             , i_functionality_code in adm_functionalities.functionality_code%type
                             , i_can_read           in varchar2 default lib_constants.k_NO
                             , i_can_write          in varchar2 default lib_constants.k_NO
                             , i_can_execute        in varchar2 default lib_constants.k_NO
                             , i_valid_from         in date default null
                             , i_valid_to           in date default null
                             );
--------------------------------------------------------------------------------
-- Revoca a un profilo una funzionalità concessa. Nessun errore se non c'era.
-- i_profile_code       : profilo.
-- i_functionality_code : funzionalità da revocare.
procedure revoke_functionality( i_profile_code       in adm_profiles.profile_code%type
                              , i_functionality_code in adm_functionalities.functionality_code%type
                              );
--------------------------------------------------------------------------------
-- COMPOSIZIONE PROFILO-RUOLO (adm_profile_roles) - NON rinfrescano la MV
-- (i ruoli compongono il profilo ma non gate direttamente le funzionalità).
--------------------------------------------------------------------------------
-- Aggiunge un ruolo alla composizione di un profilo. Idempotente.
-- i_profile_code : profilo.
-- i_role_code    : ruolo da includere.
procedure add_role_to_profile( i_profile_code in adm_profiles.profile_code%type
                             , i_role_code    in adm_roles.role_code%type
                             );
--------------------------------------------------------------------------------
-- Rimuove un ruolo dalla composizione di un profilo. Nessun errore se non c'era.
-- i_profile_code : profilo.
-- i_role_code    : ruolo da escludere.
procedure remove_role_from_profile( i_profile_code in adm_profiles.profile_code%type
                                  , i_role_code    in adm_roles.role_code%type
                                  );
--------------------------------------------------------------------------------
-- ECCEZIONI NOMINALI (adm_user_functionalities) - NON rinfrescano la MV
-- (lette al volo da lib_authz). Solo additive; la motivazione è obbligatoria.
--------------------------------------------------------------------------------
-- Concede un'eccezione nominale a un utente con motivazione obbligatoria, i tre
-- modi e una finestra opzionale. Se esiste già ne aggiorna modi/finestra/motivo.
-- i_user_id            : utente destinatario.
-- i_functionality_code : funzionalità concessa in eccezione.
-- i_reason             : motivazione (obbligatoria, per l'audit).
-- i_can_read/write/execute : i tre modi ('Y'/'N').
-- i_valid_from/to      : finestra di validità (grana data), null = aperta.
procedure grant_exception( i_user_id            in adm_users.user_id%type
                         , i_functionality_code in adm_functionalities.functionality_code%type
                         , i_reason             in adm_user_functionalities.reason%type
                         , i_can_read           in varchar2 default lib_constants.k_NO
                         , i_can_write          in varchar2 default lib_constants.k_NO
                         , i_can_execute        in varchar2 default lib_constants.k_NO
                         , i_valid_from         in date default null
                         , i_valid_to           in date default null
                         );
--------------------------------------------------------------------------------
-- Revoca a un utente un'eccezione nominale. Nessun errore se non c'era.
-- i_user_id            : utente.
-- i_functionality_code : funzionalità dell'eccezione da revocare.
procedure revoke_exception( i_user_id            in adm_users.user_id%type
                          , i_functionality_code in adm_functionalities.functionality_code%type
                          );
--------------------------------------------------------------------------------
-- UTENTI (adm_users) - NON rinfrescano la MV (risoluzione live in lib_authz).
--------------------------------------------------------------------------------
-- Crea un utente attivo e ne restituisce la chiave surrogata.
-- i_username  : login (unico).
-- i_full_name : nome per esteso.
-- i_email     : contatto (opzionale).
-- return      : user_id generato.
function create_user( i_username  in adm_users.username%type
                    , i_full_name in adm_users.full_name%type
                    , i_email     in adm_users.email%type default null
                    )
    return adm_users.user_id%type;
--------------------------------------------------------------------------------
-- Abilita o disabilita un utente. Un utente disattivato non risolve permessi
-- (fail-closed in lib_authz), ma le altre sessioni lo vedono al più al TTL.
-- i_user_id   : utente.
-- i_is_active : 'Y' abilitato, 'N' disattivato.
procedure set_user_active( i_user_id   in adm_users.user_id%type
                         , i_is_active in varchar2
                         );
--------------------------------------------------------------------------------

end lib_authz_admin;
/

show errors package lib_authz_admin

prompt File: lib_authz_admin.pks.sql <end>
