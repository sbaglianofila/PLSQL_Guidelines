prompt File: lib_workflow.pkb.sql <start>
-- =============================================================================
-- File:     lib_workflow.pkb.sql
-- Oggetto:  lib_workflow (corpo del package)
-- Schema:   #APP#
-- Scopo:    Lettura in cache e validazione della macchina a stati. Ogni workflow è
--           caricato una volta con i suoi stati, le sue transizioni valide e i
--           ruoli autorizzati, e servito dalla cache alle chiamate successive.
--           Nessuno SQL dinamico: la tabella delle transizioni è unica e nota.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260723  AA   Creazione
-- =============================================================================

prompt lib_workflow: Creating package body

create or replace
package body lib_workflow
is
-- Costanti --------------------------------------------------------------------
k_SCOPE  constant lib_types.scope_sbt := 'lib_workflow';

-- Tipi privati ----------------------------------------------------------------
-- Uno stato con i soli attributi che servono alla macchina a stati.
type t_status_rec is record
   ( status_code  wfl_statuses.status_code%type
   , is_initial   wfl_statuses.is_initial%type
   , is_final     wfl_statuses.is_final%type
   , is_valid     wfl_statuses.is_valid%type
   );
type t_statuses is table of t_status_rec;

-- Un'assegnazione ruolo->transizione, per la guardia di ruolo.
type t_role_rec is record
   ( transition_code  wfl_transition_roles.transition_code%type
   , role_code        wfl_transition_roles.role_code%type
   );
type t_roles is table of t_role_rec;

-- Una guardia di una transizione: il guard_code logico e il messaggio con cui
-- nega. Il codice di dispatch (guard_handler) vive su wfl_workflows.
type t_guard_rec is record
   ( transition_code    wfl_transition_guards.transition_code%type
   , guard_code         wfl_transition_guards.guard_code%type
   , deny_message_code  wfl_transition_guards.deny_message_code%type
   );
type t_guards is table of t_guard_rec;

-- Cache per workflow. La presenza della chiave marca il workflow come già
-- caricato (anche se privo di righe), così non viene riletto a ogni chiamata.
type t_status_cache  is table of t_statuses index by wfl_workflows.workflow_code%type;
type t_action_cache  is table of t_actions  index by wfl_workflows.workflow_code%type;
type t_role_cache    is table of t_roles    index by wfl_workflows.workflow_code%type;
type t_guard_cache   is table of t_guards   index by wfl_workflows.workflow_code%type;
type t_handler_cache is table of wfl_workflows.guard_handler%type index by wfl_workflows.workflow_code%type;

-- Globali ---------------------------------------------------------------------
g_status_cache   t_status_cache;
g_action_cache   t_action_cache;   -- solo transizioni valide (is_valid = 'Y')
g_role_cache     t_role_cache;
g_guard_cache    t_guard_cache;
g_handler_cache  t_handler_cache;

-- Moduli privati --------------------------------------------------------------
--------------------------------------------------------------------------------
procedure load_workflow(i_workflow_code in varchar2)
-- Carica in cache stati, transizioni valide, ruoli, guardie e il dispatcher del
-- workflow indicato.
is
    l_statuses  t_statuses;
    l_actions   t_actions;
    l_roles     t_roles;
    l_guards    t_guards;
    l_handler   wfl_workflows.guard_handler%type;
begin
    select s.status_code
         , s.is_initial
         , s.is_final
         , s.is_valid
      bulk collect into l_statuses
      from wfl_statuses s
     where s.workflow_code = i_workflow_code
     order by s.sort_order
            , s.status_code;

    select t.transition_code
         , t.label
         , t.from_status
         , t.to_status
         , t.requires_reason
      bulk collect into l_actions
      from wfl_transitions t
     where t.workflow_code = i_workflow_code
       and t.is_valid      = lib_constants.k_YES
     order by t.from_status
            , t.transition_code;

    select r.transition_code
         , r.role_code
      bulk collect into l_roles
      from wfl_transition_roles r
     where r.workflow_code = i_workflow_code;

    select g.transition_code
         , g.guard_code
         , g.deny_message_code
      bulk collect into l_guards
      from wfl_transition_guards g
     where g.workflow_code = i_workflow_code
     order by g.transition_code
            , g.sort_order;

    -- Il dispatcher delle guardie del workflow: può essere nullo (workflow senza
    -- guardie); no_data_found se il workflow non è a catalogo (cache a null).
    begin
        select w.guard_handler
          into l_handler
          from wfl_workflows w
         where w.workflow_code = i_workflow_code;
    exception
        when no_data_found then
            l_handler := null;
    end;

    g_status_cache(i_workflow_code)  := l_statuses;
    g_action_cache(i_workflow_code)  := l_actions;
    g_role_cache(i_workflow_code)    := l_roles;
    g_guard_cache(i_workflow_code)   := l_guards;
    g_handler_cache(i_workflow_code) := l_handler;
end load_workflow;
--------------------------------------------------------------------------------
procedure ensure_loaded(i_workflow_code in varchar2)
-- Garantisce che il workflow sia in cache, caricandolo alla prima richiesta.
is
begin
    if ( not g_action_cache.exists(i_workflow_code) )
    then
        load_workflow(i_workflow_code);
    end if;
end ensure_loaded;
--------------------------------------------------------------------------------
function has_role_guard(i_workflow_code in varchar2, i_transition_code in varchar2)
    return boolean
-- Vero se la transizione ha almeno un ruolo configurato (quindi è sotto guardia).
is
    l_roles  t_roles := g_role_cache(i_workflow_code);
begin
    for i in 1 .. l_roles.count
    loop
        if ( l_roles(i).transition_code = i_transition_code )
        then
            return (true);
        end if;
    end loop;

    return (false);
end has_role_guard;
--------------------------------------------------------------------------------
function role_permitted( i_workflow_code   in varchar2
                       , i_transition_code in varchar2
                       , i_role_code       in varchar2 )
    return boolean
-- Una transizione senza ruoli configurati è aperta a chiunque; altrimenti il ruolo
-- deve essere tra quelli configurati. Con i_role_code null la guardia non è valutata.
is
    l_roles  t_roles := g_role_cache(i_workflow_code);
begin
    if ( i_role_code is null )
    then
        return (true);
    end if;

    if ( not has_role_guard(i_workflow_code, i_transition_code) )
    then
        return (true);
    end if;

    for i in 1 .. l_roles.count
    loop
        if (     l_roles(i).transition_code = i_transition_code
             and l_roles(i).role_code       = i_role_code )
        then
            return (true);
        end if;
    end loop;

    return (false);
end role_permitted;
--------------------------------------------------------------------------------
function find_action( i_workflow_code   in varchar2
                    , i_from_status     in varchar2
                    , i_transition_code in varchar2
                    , o_action          out t_action_rec )
    return boolean
-- Cerca la transizione valida (from, codice azione) nel workflow. Restituisce
-- true e valorizza o_action se trovata.
is
    l_actions  t_actions := g_action_cache(i_workflow_code);
begin
    for i in 1 .. l_actions.count
    loop
        if (     l_actions(i).from_status     = i_from_status
             and l_actions(i).transition_code = i_transition_code )
        then
            o_action := l_actions(i);
            return (true);
        end if;
    end loop;

    return (false);
end find_action;
--------------------------------------------------------------------------------
function guards_of(i_workflow_code in varchar2, i_transition_code in varchar2)
    return t_guards
-- Le guardie di una transizione, nell'ordine di valutazione (già ordinate in cache
-- per transition_code, sort_order).
is
    l_all     t_guards := g_guard_cache(i_workflow_code);
    l_subset  t_guards := t_guards();
begin
    for i in 1 .. l_all.count
    loop
        if ( l_all(i).transition_code = i_transition_code )
        then
            l_subset.extend;
            l_subset(l_subset.last) := l_all(i);
        end if;
    end loop;

    return (l_subset);
end guards_of;
--------------------------------------------------------------------------------
function eval_guard( i_handler         in varchar2
                  , i_workflow_code   in varchar2
                  , i_transition_code in varchar2
                  , i_from_status     in varchar2
                  , i_to_status       in varchar2
                  , i_entity_pk       in varchar2
                  , i_guard_code      in varchar2 )
    return boolean
-- Chiama il dispatcher del workflow per nome (PL/SQL dinamico) passando il contesto
-- e il guard_code, e ne ritorna l'esito. Il nome è validato con dbms_assert prima
-- della concatenazione (difesa da injection: guard_handler è configurazione, ma la
-- difesa resta d'obbligo). Il boolean non è bindabile in SQL dinamico, quindi il
-- blocco lo converte a 0/1. La firma attesa del dispatcher è fissa:
--   (workflow_code, transition_code, from_status, to_status, entity_pk, guard_code)
--   return boolean.
is
    l_flag  pls_integer;
    l_stmt  varchar2(4000 char);
begin
    l_stmt := 'declare l boolean; begin l := '
           || sys.dbms_assert.qualified_sql_name(i_handler)
           || '(:1, :2, :3, :4, :5, :6); :7 := case when l then 1 else 0 end; end;';

    execute immediate l_stmt
        using in  i_workflow_code
            , in  i_transition_code
            , in  i_from_status
            , in  i_to_status
            , in  i_entity_pk
            , in  i_guard_code
            , out l_flag;

    return (l_flag = 1);
end eval_guard;
--------------------------------------------------------------------------------

-- Moduli pubblici -------------------------------------------------------------
--------------------------------------------------------------------------------
function status_exists(i_workflow_code in varchar2, i_status_code in varchar2)
    return boolean
is
    l_statuses  t_statuses;
begin
    ensure_loaded(i_workflow_code);
    l_statuses := g_status_cache(i_workflow_code);

    for i in 1 .. l_statuses.count
    loop
        if ( l_statuses(i).status_code = i_status_code )
        then
            return (true);
        end if;
    end loop;

    return (false);
end status_exists;
--------------------------------------------------------------------------------
function initial_status(i_workflow_code in varchar2)
    return varchar2
is
    l_statuses  t_statuses;
begin
    ensure_loaded(i_workflow_code);
    l_statuses := g_status_cache(i_workflow_code);

    for i in 1 .. l_statuses.count
    loop
        if ( l_statuses(i).is_initial = lib_constants.k_YES )
        then
            return (l_statuses(i).status_code);
        end if;
    end loop;

    return (null);
end initial_status;
--------------------------------------------------------------------------------
function is_final(i_workflow_code in varchar2, i_status_code in varchar2)
    return boolean
is
    l_statuses  t_statuses;
begin
    ensure_loaded(i_workflow_code);
    l_statuses := g_status_cache(i_workflow_code);

    for i in 1 .. l_statuses.count
    loop
        if ( l_statuses(i).status_code = i_status_code )
        then
            return (l_statuses(i).is_final = lib_constants.k_YES);
        end if;
    end loop;

    return (false);
end is_final;
--------------------------------------------------------------------------------
function can_transition( i_workflow_code in varchar2
                       , i_from_status   in varchar2
                       , i_to_status     in varchar2
                       , i_role_code     in varchar2 default null )
    return boolean
is
    l_actions  t_actions;
begin
    ensure_loaded(i_workflow_code);
    l_actions := g_action_cache(i_workflow_code);

    for i in 1 .. l_actions.count
    loop
        if (     l_actions(i).from_status = i_from_status
             and l_actions(i).to_status   = i_to_status
             and role_permitted(i_workflow_code, l_actions(i).transition_code, i_role_code) )
        then
            return (true);
        end if;
    end loop;

    return (false);
end can_transition;
--------------------------------------------------------------------------------
function target_status( i_workflow_code   in varchar2
                      , i_from_status     in varchar2
                      , i_transition_code in varchar2 )
    return varchar2
is
    l_action  t_action_rec;
begin
    ensure_loaded(i_workflow_code);

    if ( find_action(i_workflow_code, i_from_status, i_transition_code, l_action) )
    then
        return (l_action.to_status);
    end if;

    return (null);
end target_status;
--------------------------------------------------------------------------------
function available_actions( i_workflow_code in varchar2
                          , i_from_status   in varchar2
                          , i_role_code     in varchar2 default null )
    return t_actions
is
    l_all    t_actions;
    l_avail  t_actions := t_actions();
begin
    ensure_loaded(i_workflow_code);
    l_all := g_action_cache(i_workflow_code);

    for i in 1 .. l_all.count
    loop
        if (     l_all(i).from_status = i_from_status
             and role_permitted(i_workflow_code, l_all(i).transition_code, i_role_code) )
        then
            l_avail.extend;
            l_avail(l_avail.last) := l_all(i);
        end if;
    end loop;

    return (l_avail);
end available_actions;
--------------------------------------------------------------------------------
procedure assert_action( i_workflow_code   in varchar2
                       , i_from_status     in varchar2
                       , i_transition_code in varchar2
                       , i_role_code       in varchar2 default null
                       , i_reason          in varchar2 default null
                       , i_entity_pk       in varchar2 default null )
is
    l_action  t_action_rec;
    l_guards  t_guards;
    l_handler wfl_workflows.guard_handler%type;
begin
    ensure_loaded(i_workflow_code);

    -- L'azione deve essere una transizione valida a partire dallo stato attuale.
    if ( not find_action(i_workflow_code, i_from_status, i_transition_code, l_action) )
    then
        lib_err.raise_msg( i_message_code => k_msg_transition_not_allowed
                         , i_p1           => i_transition_code
                         , i_p2           => i_from_status
                         , i_p3           => i_workflow_code
                         , i_error        => lib_err.k_NOT_ALLOWED
                         , i_scope        => k_SCOPE || '.assert_action' );
    end if;

    -- Se un ruolo è indicato, deve essere autorizzato all'azione.
    if (     i_role_code is not null
         and not role_permitted(i_workflow_code, i_transition_code, i_role_code) )
    then
        lib_err.raise_msg( i_message_code => k_msg_role_not_allowed
                         , i_p1           => i_role_code
                         , i_p2           => i_transition_code
                         , i_p3           => i_workflow_code
                         , i_error        => lib_err.k_NOT_ALLOWED
                         , i_scope        => k_SCOPE || '.assert_action' );
    end if;

    -- La causale è obbligatoria per questa azione ma manca.
    if (     l_action.requires_reason = lib_constants.k_YES
         and i_reason is null )
    then
        lib_err.raise_msg( i_message_code => k_msg_reason_required
                         , i_p1           => i_transition_code
                         , i_error        => lib_err.k_NOT_ALLOWED
                         , i_scope        => k_SCOPE || '.assert_action' );
    end if;

    -- Le guardie della transizione: condizioni sui dati, valutate in AND nell'ordine
    -- di sort_order. Alla prima che nega si solleva il suo deny_message_code.
    l_guards := guards_of(i_workflow_code, i_transition_code);

    if ( l_guards.count > 0 )
    then
        l_handler := g_handler_cache(i_workflow_code);

        -- La transizione ha guardie ma il workflow non ha un dispatcher: setup errato.
        if ( l_handler is null )
        then
            lib_err.raise_msg( i_message_code => k_msg_guard_handler_missing
                             , i_p1           => i_workflow_code
                             , i_p2           => i_transition_code
                             , i_scope        => k_SCOPE || '.assert_action' );
        end if;

        for i in 1 .. l_guards.count
        loop
            if ( not eval_guard( i_handler         => l_handler
                               , i_workflow_code   => i_workflow_code
                               , i_transition_code => i_transition_code
                               , i_from_status     => i_from_status
                               , i_to_status       => l_action.to_status
                               , i_entity_pk       => i_entity_pk
                               , i_guard_code      => l_guards(i).guard_code ) )
            then
                lib_err.raise_msg( i_message_code => l_guards(i).deny_message_code
                                 , i_p1           => i_transition_code
                                 , i_p2           => i_from_status
                                 , i_error        => lib_err.k_NOT_ALLOWED
                                 , i_scope        => k_SCOPE || '.assert_action' );
            end if;
        end loop;
    end if;
end assert_action;
--------------------------------------------------------------------------------
procedure refresh(i_workflow_code in varchar2 default null)
is
begin
    if ( i_workflow_code is null )
    then
        g_status_cache.delete;
        g_action_cache.delete;
        g_role_cache.delete;
        g_guard_cache.delete;
        g_handler_cache.delete;
    else
        if ( g_status_cache.exists(i_workflow_code) )  then g_status_cache.delete(i_workflow_code);  end if;
        if ( g_action_cache.exists(i_workflow_code) )  then g_action_cache.delete(i_workflow_code);  end if;
        if ( g_role_cache.exists(i_workflow_code) )    then g_role_cache.delete(i_workflow_code);    end if;
        if ( g_guard_cache.exists(i_workflow_code) )   then g_guard_cache.delete(i_workflow_code);   end if;
        if ( g_handler_cache.exists(i_workflow_code) ) then g_handler_cache.delete(i_workflow_code); end if;
    end if;
end refresh;
--------------------------------------------------------------------------------

end lib_workflow;
/

show errors package body lib_workflow

prompt File: lib_workflow.pkb.sql <end>
