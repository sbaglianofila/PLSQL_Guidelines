prompt File: lib_authz_admin.pkb.sql <start>
-- =============================================================================
-- File:     lib_authz_admin.pkb.sql
-- Oggetto:  lib_authz_admin (corpo del package)
-- Schema:   #APP#
-- Scopo:    Implementazione della Table API di scrittura sulle adm_*. Ogni
--           operazione valida gli argomenti, esegue la DML (upsert via merge per
--           le concessioni, delete per le revoche), committa, e - dove tocca ciò
--           che la MV materializza - chiama lib_authz.refresh_mv. Le colonne
--           amministrative e row_version sono popolate dai trigger di audit delle
--           tabelle, non qui. Vedi l'header della specifica per il contratto
--           transazionale (queste procedure committano).
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260725  AA   Creazione
-- =============================================================================

prompt lib_authz_admin: Creating package body

create or replace
package body lib_authz_admin
is

-- Moduli pubblici -------------------------------------------------------------
--------------------------------------------------------------------------------
procedure assign_profile( i_user_id      in adm_users.user_id%type
                        , i_profile_code in adm_profiles.profile_code%type
                        , i_valid_from   in date default null
                        , i_valid_to     in date default null
                        )
-- Upsert dell'assegnazione utente-profilo, poi commit e refresh della MV.
is
begin
    lib_assert.not_null(i_user_id, 'i_user_id');
    lib_assert.not_null(i_profile_code, 'i_profile_code');

    merge into adm_user_profiles t
    using ( select i_user_id      as user_id
                 , i_profile_code as profile_code
              from dual
          ) s
       on ( t.user_id = s.user_id and t.profile_code = s.profile_code )
     when matched then
        update set t.valid_from = i_valid_from
                 , t.valid_to   = i_valid_to
     when not matched then
        insert ( user_id, profile_code, valid_from, valid_to )
        values ( i_user_id, i_profile_code, i_valid_from, i_valid_to );

    commit;
    lib_authz.refresh_mv;
end assign_profile;
--------------------------------------------------------------------------------
procedure revoke_profile( i_user_id      in adm_users.user_id%type
                        , i_profile_code in adm_profiles.profile_code%type
                        )
-- Rimuove l'assegnazione, poi commit e refresh della MV.
is
begin
    lib_assert.not_null(i_user_id, 'i_user_id');
    lib_assert.not_null(i_profile_code, 'i_profile_code');

    delete from adm_user_profiles
     where user_id = i_user_id
       and profile_code = i_profile_code;

    commit;
    lib_authz.refresh_mv;
end revoke_profile;
--------------------------------------------------------------------------------
procedure grant_functionality( i_profile_code       in adm_profiles.profile_code%type
                             , i_functionality_code in adm_functionalities.functionality_code%type
                             , i_can_read           in varchar2 default lib_constants.k_NO
                             , i_can_write          in varchar2 default lib_constants.k_NO
                             , i_can_execute        in varchar2 default lib_constants.k_NO
                             , i_valid_from         in date default null
                             , i_valid_to           in date default null
                             )
-- Upsert del grant funzionalità-profilo, poi commit e refresh della MV.
is
begin
    lib_assert.not_null(i_profile_code, 'i_profile_code');
    lib_assert.not_null(i_functionality_code, 'i_functionality_code');

    merge into adm_profile_functionalities t
    using ( select i_profile_code       as profile_code
                 , i_functionality_code as functionality_code
              from dual
          ) s
       on ( t.profile_code = s.profile_code
            and t.functionality_code = s.functionality_code )
     when matched then
        update set t.can_read    = i_can_read
                 , t.can_write   = i_can_write
                 , t.can_execute = i_can_execute
                 , t.valid_from  = i_valid_from
                 , t.valid_to    = i_valid_to
     when not matched then
        insert ( profile_code, functionality_code
               , can_read, can_write, can_execute
               , valid_from, valid_to )
        values ( i_profile_code, i_functionality_code
               , i_can_read, i_can_write, i_can_execute
               , i_valid_from, i_valid_to );

    commit;
    lib_authz.refresh_mv;
end grant_functionality;
--------------------------------------------------------------------------------
procedure revoke_functionality( i_profile_code       in adm_profiles.profile_code%type
                              , i_functionality_code in adm_functionalities.functionality_code%type
                              )
-- Rimuove il grant, poi commit e refresh della MV.
is
begin
    lib_assert.not_null(i_profile_code, 'i_profile_code');
    lib_assert.not_null(i_functionality_code, 'i_functionality_code');

    delete from adm_profile_functionalities
     where profile_code = i_profile_code
       and functionality_code = i_functionality_code;

    commit;
    lib_authz.refresh_mv;
end revoke_functionality;
--------------------------------------------------------------------------------
procedure add_role_to_profile( i_profile_code in adm_profiles.profile_code%type
                             , i_role_code    in adm_roles.role_code%type
                             )
-- Aggiunge il ruolo alla composizione del profilo (idempotente), poi commit.
-- Nessun refresh: la composizione non entra nella MV (i ruoli non gate).
is
begin
    lib_assert.not_null(i_profile_code, 'i_profile_code');
    lib_assert.not_null(i_role_code, 'i_role_code');

    merge into adm_profile_roles t
    using ( select i_profile_code as profile_code
                 , i_role_code    as role_code
              from dual
          ) s
       on ( t.profile_code = s.profile_code and t.role_code = s.role_code )
     when not matched then
        insert ( profile_code, role_code )
        values ( i_profile_code, i_role_code );

    commit;
end add_role_to_profile;
--------------------------------------------------------------------------------
procedure remove_role_from_profile( i_profile_code in adm_profiles.profile_code%type
                                  , i_role_code    in adm_roles.role_code%type
                                  )
-- Rimuove il ruolo dalla composizione, poi commit. Nessun refresh.
is
begin
    lib_assert.not_null(i_profile_code, 'i_profile_code');
    lib_assert.not_null(i_role_code, 'i_role_code');

    delete from adm_profile_roles
     where profile_code = i_profile_code
       and role_code = i_role_code;

    commit;
end remove_role_from_profile;
--------------------------------------------------------------------------------
procedure grant_exception( i_user_id            in adm_users.user_id%type
                         , i_functionality_code in adm_functionalities.functionality_code%type
                         , i_reason             in adm_user_functionalities.reason%type
                         , i_can_read           in varchar2 default lib_constants.k_NO
                         , i_can_write          in varchar2 default lib_constants.k_NO
                         , i_can_execute        in varchar2 default lib_constants.k_NO
                         , i_valid_from         in date default null
                         , i_valid_to           in date default null
                         )
-- Upsert dell'eccezione nominale, poi commit. Nessun refresh: le eccezioni le
-- legge al volo lib_authz. La motivazione è obbligatoria (anche da vincolo).
is
begin
    lib_assert.not_null(i_user_id, 'i_user_id');
    lib_assert.not_null(i_functionality_code, 'i_functionality_code');
    lib_assert.not_null(i_reason, 'i_reason');

    merge into adm_user_functionalities t
    using ( select i_user_id            as user_id
                 , i_functionality_code as functionality_code
              from dual
          ) s
       on ( t.user_id = s.user_id
            and t.functionality_code = s.functionality_code )
     when matched then
        update set t.can_read    = i_can_read
                 , t.can_write   = i_can_write
                 , t.can_execute = i_can_execute
                 , t.valid_from  = i_valid_from
                 , t.valid_to    = i_valid_to
                 , t.reason      = i_reason
     when not matched then
        insert ( user_id, functionality_code
               , can_read, can_write, can_execute
               , valid_from, valid_to, reason )
        values ( i_user_id, i_functionality_code
               , i_can_read, i_can_write, i_can_execute
               , i_valid_from, i_valid_to, i_reason );

    commit;
end grant_exception;
--------------------------------------------------------------------------------
procedure revoke_exception( i_user_id            in adm_users.user_id%type
                          , i_functionality_code in adm_functionalities.functionality_code%type
                          )
-- Rimuove l'eccezione, poi commit. Nessun refresh.
is
begin
    lib_assert.not_null(i_user_id, 'i_user_id');
    lib_assert.not_null(i_functionality_code, 'i_functionality_code');

    delete from adm_user_functionalities
     where user_id = i_user_id
       and functionality_code = i_functionality_code;

    commit;
end revoke_exception;
--------------------------------------------------------------------------------
function create_user( i_username  in adm_users.username%type
                    , i_full_name in adm_users.full_name%type
                    , i_email     in adm_users.email%type default null
                    )
    return adm_users.user_id%type
-- Crea un utente attivo e ne restituisce la chiave surrogata, poi commit.
is
    l_user_id  adm_users.user_id%type;
begin
    lib_assert.not_null(i_username, 'i_username');
    lib_assert.not_null(i_full_name, 'i_full_name');

    insert into adm_users ( username, full_name, email, is_active )
    values ( i_username, i_full_name, i_email, lib_constants.k_YES )
    returning user_id into l_user_id;

    commit;
    return (l_user_id);
end create_user;
--------------------------------------------------------------------------------
procedure set_user_active( i_user_id   in adm_users.user_id%type
                         , i_is_active in varchar2
                         )
-- Abilita/disabilita l'utente, poi commit. Nessun refresh (risoluzione live).
is
begin
    lib_assert.not_null(i_user_id, 'i_user_id');
    lib_assert.not_null(i_is_active, 'i_is_active');

    update adm_users
       set is_active = i_is_active
     where user_id = i_user_id;

    commit;
end set_user_active;
--------------------------------------------------------------------------------

end lib_authz_admin;
/

show errors package body lib_authz_admin

prompt File: lib_authz_admin.pkb.sql <end>
