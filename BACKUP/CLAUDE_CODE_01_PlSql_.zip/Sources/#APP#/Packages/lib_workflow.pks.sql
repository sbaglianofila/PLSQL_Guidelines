prompt File: lib_workflow.pks.sql <start>
-- =============================================================================
-- File:     lib_workflow.pks.sql
-- Oggetto:  lib_workflow (specifica del package)
-- Schema:   #APP#
-- Scopo:    Motore di validazione e interrogazione della macchina a stati definita
--           in wfl_workflows / wfl_statuses / wfl_transitions / wfl_transition_roles.
--           È un package STATICO scritto una volta per tutti i workflow: la tabella
--           delle transizioni è unica, quindi la validazione è una select su una
--           tabella nota, senza SQL dinamico. Concentra qui il controllo delle
--           transizioni così che nessuna entità lo reimplementi.
--           NON scrive la storia dei cambi di stato: l'audit è per-entità
--           (wfl_<entità>_status_log, vedi stati_workflow.md), quindi la INSERT
--           nel log vive nella Table API dell'entità, generata da template. Il
--           contratto è: la Table API chiama assert_action per validare, poi scrive
--           lo stato sulla riga di business e una riga nel proprio log, nella stessa
--           transazione. In lettura, gemello di lib_lookup: tiene in cache per
--           workflow stati e transizioni, che cambiano di rado.
--           Convenzione: le interrogazioni non sollevano (tornano false/null/vuoto);
--           l'unico punto che solleva è assert_action, con e_not_allowed
--           (intercettabile) e i message_code qui sotto.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260723  AA   Creazione
-- =============================================================================

prompt lib_workflow: Creating package specification

create or replace
package lib_workflow
is
-- Codici dei messaggi di dominio (catalogo cfg_messages) sollevati da assert_action.
-- Sono i *_msg_codes di questo pillar; il testo vive come dato in cfg_messages.
k_msg_transition_not_allowed  constant varchar2(100 char) := 'WFL_TRANSITION_NOT_ALLOWED';
k_msg_role_not_allowed        constant varchar2(100 char) := 'WFL_ROLE_NOT_ALLOWED';
k_msg_reason_required         constant varchar2(100 char) := 'WFL_REASON_REQUIRED';
-- Errore di configurazione: la transizione ha guardie ma il workflow non ha un
-- guard_handler che le valuti. Sollevato sotto k_BUSINESS_ERROR (non è un diniego
-- di permesso ma un difetto di setup, da correggere).
k_msg_guard_handler_missing   constant varchar2(100 char) := 'WFL_GUARD_HANDLER_MISSING';

-- Un'azione disponibile da uno stato: ciò che serve a disegnare un bottone e a
-- sapere dove porta. Rispecchia una riga valida di wfl_transitions.
type t_action_rec is record
   ( transition_code  wfl_transitions.transition_code%type
   , label            wfl_transitions.label%type
   , from_status      wfl_transitions.from_status%type
   , to_status        wfl_transitions.to_status%type
   , requires_reason  wfl_transitions.requires_reason%type
   );

-- Elenco di azioni. Collezione PL/SQL (non SQL): da SQL si interroga direttamente
-- wfl_transitions.
type t_actions is table of t_action_rec;

--------------------------------------------------------------------------------
-- Vero se lo stato esiste (a qualunque validità) nel workflow indicato.
-- i_workflow_code : mnemonico del workflow (es. 'ORDER').
-- i_status_code   : codice dello stato.
function status_exists(i_workflow_code in varchar2, i_status_code in varchar2)
    return boolean;
--------------------------------------------------------------------------------
-- Lo stato iniziale del workflow (is_initial = 'Y'), quello in cui l'entità nasce;
-- null se il workflow non ne definisce uno.
-- i_workflow_code : mnemonico del workflow.
function initial_status(i_workflow_code in varchar2)
    return varchar2;
--------------------------------------------------------------------------------
-- Vero se lo stato è terminale (is_final = 'Y'): nessuna transizione ne esce.
-- i_workflow_code : mnemonico del workflow.
-- i_status_code   : codice dello stato.
function is_final(i_workflow_code in varchar2, i_status_code in varchar2)
    return boolean;
--------------------------------------------------------------------------------
-- Vero se esiste una transizione VALIDA da i_from_status a i_to_status nel
-- workflow. Se i_role_code è valorizzato, la transizione deve anche essere
-- permessa a quel ruolo (una transizione senza ruoli configurati è aperta a
-- chiunque). Con i_role_code null la guardia di ruolo non è valutata (solo la
-- struttura della macchina a stati). Non solleva.
-- i_workflow_code : mnemonico del workflow.
-- i_from_status   : stato di partenza.
-- i_to_status     : stato di arrivo.
-- i_role_code     : ruolo aziendale che compie l'azione, o null per non valutarlo.
function can_transition( i_workflow_code in varchar2
                       , i_from_status   in varchar2
                       , i_to_status     in varchar2
                       , i_role_code     in varchar2 default null )
    return boolean;
--------------------------------------------------------------------------------
-- Lo stato di arrivo di un'azione a partire da uno stato, o null se da quello
-- stato non parte una transizione valida con quel codice azione. È il modo
-- naturale di lavorare dall'interfaccia, dove l'utente sceglie un'azione.
-- i_workflow_code   : mnemonico del workflow.
-- i_from_status     : stato di partenza.
-- i_transition_code : codice dell'azione (es. 'APPROVE').
function target_status( i_workflow_code   in varchar2
                      , i_from_status     in varchar2
                      , i_transition_code in varchar2 )
    return varchar2;
--------------------------------------------------------------------------------
-- Le azioni disponibili da uno stato, per popolare i bottoni. Se i_role_code è
-- valorizzato, sono filtrate a quelle permesse a quel ruolo. Collezione vuota se
-- lo stato è terminale o non ha uscite. Non solleva.
-- i_workflow_code : mnemonico del workflow.
-- i_from_status   : stato di partenza.
-- i_role_code     : ruolo aziendale, o null per non filtrare sul ruolo.
function available_actions( i_workflow_code in varchar2
                          , i_from_status   in varchar2
                          , i_role_code     in varchar2 default null )
    return t_actions;
--------------------------------------------------------------------------------
-- Punto di applicazione: valida in sequenza che l'azione sia ammessa da quello
-- stato, per quel ruolo, con la causale se richiesta, e che tutte le GUARDIE
-- della transizione passino; solleva alla prima condizione non soddisfatta.
-- NON muta nulla - non tocca la riga di business né scrive la storia - ma è ciò che
-- la Table API dell'entità chiama PRIMA di scrivere lo stato e la riga di log.
-- Solleva e_not_allowed (via lib_err.raise_msg) con:
--   k_msg_transition_not_allowed  se l'azione non è valida da quello stato,
--   k_msg_role_not_allowed        se il ruolo non è autorizzato all'azione,
--   k_msg_reason_required         se la causale è obbligatoria e manca,
--   il deny_message_code della guardia  se una guardia nega (in AND, alla prima).
-- Solleva k_msg_guard_handler_missing (business error) se la transizione ha guardie
-- ma il workflow non ha un guard_handler configurato (errore di setup).
-- Le guardie sono valutate dal dispatcher wfl_workflows.guard_handler, chiamato per
-- nome (dinamico) con firma fissa; i_entity_pk è ciò che ricevono per caricare la
-- riga. Se la transizione non ha guardie, i_entity_pk è ininfluente.
-- i_workflow_code   : mnemonico del workflow.
-- i_from_status     : stato di partenza (lo stato attuale della riga di business).
-- i_transition_code : codice dell'azione richiesta.
-- i_role_code       : ruolo aziendale che compie l'azione, o null per non validarlo.
-- i_reason          : causale fornita, se prevista.
-- i_entity_pk       : chiave (come stringa) della riga coinvolta, passata alle guardie.
procedure assert_action( i_workflow_code   in varchar2
                       , i_from_status     in varchar2
                       , i_transition_code in varchar2
                       , i_role_code       in varchar2 default null
                       , i_reason          in varchar2 default null
                       , i_entity_pk       in varchar2 default null );
--------------------------------------------------------------------------------
-- Svuota la cache così che la lettura successiva ricarichi da database. Con
-- i_workflow_code valorizzato invalida il solo workflow; con null (default)
-- invalida tutto. Da chiamare dopo aver modificato le tabelle di definizione.
-- i_workflow_code : workflow da invalidare, oppure null per tutti.
procedure refresh(i_workflow_code in varchar2 default null);
--------------------------------------------------------------------------------

end lib_workflow;
/

show errors package lib_workflow

prompt File: lib_workflow.pks.sql <end>
