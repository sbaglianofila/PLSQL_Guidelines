prompt File: lib_err.pks.sql <start>
-- =============================================================================
-- File:     lib_err.pks.sql
-- Oggetto:  lib_err (specifica del package)
-- Schema:   #APP#
-- Scopo:    Catalogo e motore degli errori. Un codice -20xxx è trattato come un
--           MECCANISMO di segnalazione, non come l'identità di un messaggio, così
--           i codici restano pochi:
--           * Un piccolo insieme di codici DEDICATI con eccezioni con nome vive
--             qui nella specifica, uno per condizione che un chiamante può dover
--             intercettare e gestire programmaticamente (INVALID_PARAMETER,
--             STALE_DATA, i codici di lock, NOT_ALLOWED, ...). Il testo fisso dei
--             loro messaggi vive come dato in cfg_error_messages (righe APP),
--             correggibile a runtime.
--           * Tutto il resto - i tanti messaggi di dominio/business - è sollevato
--             sotto il singolo codice generico BUSINESS_ERROR via raise_msg, che
--             compone il testo dal catalogo cfg_messages per message_code (così
--             un'applicazione può avere messaggi illimitati senza consumare lo
--             scarso spazio dei -20xxx). raise_msg può anche puntare a uno dei
--             codici dedicati quando un messaggio specifico deve restare
--             intercettabile.
--           Il body è il motore (raise / raise_msg / reraise / message_of). Gli
--           errori Oracle nativi sono resi leggibili separatamente da lib_logging
--           tramite le righe ORACLE di cfg_error_messages.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260705  AA   Creazione
--   20260708  AA   Testi dei messaggi spostati in cfg_error_messages; segnaposto
--                  estesi a %1..%10; correlation_id propagato al log
--   20260708  AA   execution_id (span id) propagato al log
--   20260708  AA   Aggiunti NOT_ALLOWED e il generico BUSINESS_ERROR; aggiunta
--                  raise_msg (solleva un messaggio di dominio per message_code)
--   20260729  AA   Aggiunto PRECONDITION_FAILED (precondizione di esecuzione non
--                  soddisfatta con severity ABORT, sollevata da lib_gate)
-- =============================================================================

prompt lib_err: Creating package specification

create or replace
package lib_err
is
-- Codici d'errore dedicati (pochi, intercettabili per nome) --------------------
-- Assegna un codice dedicato solo a una condizione che un chiamante può dover
-- intercettare e gestire; tutto il resto è un messaggio di dominio sollevato
-- sotto k_BUSINESS_ERROR.
k_INVALID_PARAMETER      constant pls_integer := -20000;
k_STALE_DATA             constant pls_integer := -20001;
k_LOCK_REQUEST_FAILED    constant pls_integer := -20002;
k_ALREADY_RUNNING        constant pls_integer := -20003;
k_CONFIG_PARAM_MISSING   constant pls_integer := -20004;
k_CONFIG_PARAM_INVALID   constant pls_integer := -20005;
k_INVALID_TABLE_NAME     constant pls_integer := -20006;
k_PARAM_TOO_LARGE        constant pls_integer := -20007;
k_INVALID_FILENAME       constant pls_integer := -20008;
k_FILE_NOT_FOUND         constant pls_integer := -20009;
k_MAIL_SEND_FAILED       constant pls_integer := -20010;
k_MAIL_TEMPLATE_MISSING  constant pls_integer := -20011;
k_FILE_IO_ERROR          constant pls_integer := -20012;
k_REPORT_NOT_FOUND       constant pls_integer := -20013;
k_NOT_ALLOWED            constant pls_integer := -20014;
k_PRECONDITION_FAILED    constant pls_integer := -20015;
k_UNEXPECTED             constant pls_integer := -20099;

-- Errore di business generico (i tanti messaggi di dominio) --------------------
-- Codice vettore per ogni messaggio di dominio sollevato via raise_msg.
-- L'identità del messaggio è il message_code (cfg_messages), non questo numero.
k_BUSINESS_ERROR         constant pls_integer := -20999;

-- Eccezioni con nome ----------------------------------------------------------
-- I letterali nelle pragma devono coincidere con le costanti qui sopra; vanno
-- tenuti sincronizzati (Oracle richiede un letterale numerico in exception_init).
e_invalid_parameter      exception;
e_stale_data             exception;
e_lock_request_failed    exception;
e_already_running        exception;
e_config_param_missing   exception;
e_config_param_invalid   exception;
e_param_too_large        exception;
e_invalid_filename       exception;
e_file_not_found         exception;
e_mail_send_failed       exception;
e_mail_template_missing  exception;
e_file_io_error          exception;
e_report_not_found       exception;
e_not_allowed            exception;
e_precondition_failed    exception;
e_business_error         exception;

pragma exception_init(e_invalid_parameter,     -20000);
pragma exception_init(e_stale_data,            -20001);
pragma exception_init(e_lock_request_failed,   -20002);
pragma exception_init(e_already_running,       -20003);
pragma exception_init(e_config_param_missing,  -20004);
pragma exception_init(e_config_param_invalid,  -20005);
pragma exception_init(e_param_too_large,       -20007);
pragma exception_init(e_invalid_filename,      -20008);
pragma exception_init(e_file_not_found,        -20009);
pragma exception_init(e_mail_send_failed,      -20010);
pragma exception_init(e_mail_template_missing, -20011);
pragma exception_init(e_file_io_error,         -20012);
pragma exception_init(e_report_not_found,      -20013);
pragma exception_init(e_not_allowed,           -20014);
pragma exception_init(e_precondition_failed,   -20015);
pragma exception_init(e_business_error,        -20999);

-- Moduli pubblici -------------------------------------------------------------
--------------------------------------------------------------------------------
-- Solleva un errore a catalogo, sostituendo i segnaposto %1..%10 nel suo
-- messaggio e loggandolo (con il codice reale e il backtrace) prima di segnalare.
-- È l'unico punto del progetto che chiama raise_application_error.
-- i_error          : uno dei codici k_ qui sopra.
-- i_p1..10         : valori sostituiti a %1..%10 nel messaggio.
-- i_correlation_id : id opzionale che lega questo errore alle altre righe di log
--                    della stessa esecuzione/flusso (trace id).
-- i_execution_id   : id opzionale per singola invocazione (span id).
-- i_scope          : scope logico per la voce di log.
procedure raise( i_error in pls_integer
               , i_p1    in varchar2 default null
               , i_p2    in varchar2 default null
               , i_p3    in varchar2 default null
               , i_p4    in varchar2 default null
               , i_p5    in varchar2 default null
               , i_p6    in varchar2 default null
               , i_p7    in varchar2 default null
               , i_p8    in varchar2 default null
               , i_p9    in varchar2 default null
               , i_p10   in varchar2 default null
               , i_correlation_id in lib_types.correlation_id_sbt default null
               , i_execution_id   in lib_types.execution_id_sbt default null
               , i_scope in lib_types.scope_sbt default null
               );
--------------------------------------------------------------------------------
-- Solleva un messaggio di dominio identificato dal suo message_code: compone il
-- testo dal catalogo cfg_messages (sostituendo %1..%10) e lo segnala, loggandolo
-- prima. Per default il codice vettore è il generico k_BUSINESS_ERROR, così un
-- progetto può definire messaggi illimitati senza consumare i codici -20xxx;
-- passa i_error per sollevare invece uno dei codici dedicati quando la condizione
-- specifica deve restare intercettabile per nome (es. k_NOT_ALLOWED).
-- i_message_code   : chiave cfg_messages (tienila come costante *_msg_codes).
-- i_p1..10         : valori sostituiti a %1..%10 nel template.
-- i_error          : codice vettore -20xxx; default k_BUSINESS_ERROR.
-- i_correlation_id : trace id opzionale.
-- i_execution_id   : span id opzionale.
-- i_scope          : scope logico per la voce di log.
procedure raise_msg( i_message_code   in varchar2
                   , i_p1             in varchar2 default null
                   , i_p2             in varchar2 default null
                   , i_p3             in varchar2 default null
                   , i_p4             in varchar2 default null
                   , i_p5             in varchar2 default null
                   , i_p6             in varchar2 default null
                   , i_p7             in varchar2 default null
                   , i_p8             in varchar2 default null
                   , i_p9             in varchar2 default null
                   , i_p10            in varchar2 default null
                   , i_error          in pls_integer default k_BUSINESS_ERROR
                   , i_correlation_id in lib_types.correlation_id_sbt default null
                   , i_execution_id   in lib_types.execution_id_sbt default null
                   , i_scope          in lib_types.scope_sbt default null
                   );
--------------------------------------------------------------------------------
-- Ripropaga l'eccezione attualmente in gestione dopo averla loggata. Va chiamata
-- dall'interno di un exception handler. Gli errori a catalogo sono preservati
-- verbatim; qualsiasi altro errore Oracle è avvolto come k_UNEXPECTED mantenendo
-- l'errore originale sullo stack.
-- i_correlation_id : id opzionale che lega questo errore alla stessa esecuzione/flusso.
-- i_execution_id   : id opzionale per singola invocazione (span id).
-- i_scope          : scope logico per la voce di log.
procedure reraise( i_correlation_id in lib_types.correlation_id_sbt default null
                 , i_execution_id   in lib_types.execution_id_sbt default null
                 , i_scope          in lib_types.scope_sbt default null
                 );
--------------------------------------------------------------------------------
-- Restituisce il messaggio composto di un errore a catalogo senza sollevarlo, per
-- i chiamanti che devono mostrarlo.
-- i_error  : uno dei codici k_ qui sopra.
-- i_p1..10 : valori sostituiti a %1..%10.
-- return   : il messaggio composto.
function message_of( i_error in pls_integer
                   , i_p1    in varchar2 default null
                   , i_p2    in varchar2 default null
                   , i_p3    in varchar2 default null
                   , i_p4    in varchar2 default null
                   , i_p5    in varchar2 default null
                   , i_p6    in varchar2 default null
                   , i_p7    in varchar2 default null
                   , i_p8    in varchar2 default null
                   , i_p9    in varchar2 default null
                   , i_p10   in varchar2 default null
                   )
    return varchar2;
--------------------------------------------------------------------------------

end lib_err;
/

show errors package lib_err

prompt File: lib_err.pks.sql <end>
