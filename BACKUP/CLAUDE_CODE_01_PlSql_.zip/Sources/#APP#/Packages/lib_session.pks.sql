prompt File: lib_session.pks.sql <start>
-- =============================================================================
-- File:     lib_session.pks.sql
-- Oggetto:  lib_session (specifica del package)
-- Schema:   #APP#
-- Scopo:    Identità, contesto e strumentazione di sessione. Risponde a "chi sta
--           operando", "quale chiamata è questa" e "cosa sta facendo la sessione",
--           centralizzando l'uso di sys_context, dbms_session e
--           dbms_application_info.
--           Due informazioni di contesto sono tenute deliberatamente separate:
--           * CHI - l'utente applicativo - vive nel contesto applicativo APP_CTX
--             (attributo APP_USER), impostato solo da questo package, ed è
--             specchiato in CLIENT_INFO così da restare visibile in v$session. È
--             il valore che popola created_by / modified_by.
--           * QUALE CHIAMATA - il correlation id della richiesta corrente - vive
--             in CLIENT_IDENTIFIER, così una singola richiesta è visibile in
--             v$session e tracciabile con DBMS_MONITOR attraverso le sessioni di
--             un pool.
--           Questa separazione permette di distinguere insieme utenti e chiamate
--           concorrenti. Impostare APP_CTX richiede che il contesto esista (vedi
--           app_ctx.ctx.sql) e che l'owner abbia CREATE ANY CONTEXT.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260705  AA   Creazione
--   20260708  AA   Utente applicativo spostato nel contesto APP_CTX (specchiato in
--                  CLIENT_INFO); CLIENT_IDENTIFIER riconvertito a correlation id
--                  della chiamata. set_client -> set_actor + set_correlation;
--                  aggiunte current_correlation e clear_session
--   20260708  AA   Aggiunte set_action e push_step/pop_step (salvataggio e
--                  ripristino annidato di module/action); clear_session ora azzera
--                  anche module/action
--   20260708  AA   push_step/pop_step sostituiti da uno stack interno bilanciato
--                  (open_step/close_step), tenuto bilanciato dall'handler d'errore
--                  obbligatorio; clear_session lo svuota
--   20260708  AA   Aggiunta session_info (snapshot di sessione usato da lib_logging)
-- =============================================================================

prompt lib_session: Creating package specification

create or replace
package lib_session
is
--------------------------------------------------------------------------------
-- Identità effettiva secondo la convenzione di progetto: l'utente applicativo
-- pubblicato nel contesto APP_CTX, altrimenti il proxy_user quando si è connessi
-- tramite proxy, altrimenti il session_user. È il valore che popolerà
-- created_by / modified_by. Non legge più CLIENT_IDENTIFIER (che ora porta il
-- correlation id della chiamata). Il valore è troncato a 64 caratteri, la
-- larghezza delle colonne di audit e di log_events.actor: il cap è centralizzato
-- qui così i trigger di audit non devono ripeterlo.
-- return : l'attore effettivo, mai nullo, lungo al più 64 caratteri.
function current_actor
    return varchar2;
--------------------------------------------------------------------------------
-- Il correlation id della chiamata/richiesta corrente, letto da CLIENT_IDENTIFIER
-- (come impostato da set_correlation). Nullo quando nessuna chiamata è in corso.
-- return : il correlation id corrente, o null.
function current_correlation
    return varchar2;
--------------------------------------------------------------------------------
-- Il module corrente di dbms_application_info della sessione (nullo se non
-- impostato). Usato da lib_logging e lib_batch per marcare le voci con il
-- processo in esecuzione.
-- return : il nome del module corrente.
function current_module
    return varchar2;
--------------------------------------------------------------------------------
-- L'action corrente di dbms_application_info della sessione (nulla se non
-- impostata).
-- return : il nome dell'action corrente.
function current_action
    return varchar2;
--------------------------------------------------------------------------------
-- Uno snapshot forense della sessione corrente, come coppie chiave=valore: gli
-- attributi USERENV utili alla diagnosi e non già riportati altrove nel log
-- (session_user, proxy_user, os_user, host, ip_address, sid, instance, service,
-- action, e le impostazioni NLS che contano per le conversioni), più l'utente
-- applicativo di APP_CTX. Letto da lib_logging.write_error e riutilizzabile
-- ovunque serva il "chi/dove/come" di una sessione. Non solleva mai eccezioni.
-- return : lo snapshot della sessione.
function session_info
    return varchar2;
--------------------------------------------------------------------------------
-- Dichiara l'utente applicativo che la connessione sta servendo. Lo pubblica nel
-- contesto APP_CTX (attributo APP_USER, la fonte di current_actor) e lo specchia
-- in CLIENT_INFO così da renderlo visibile in v$session.client_info. Va chiamata
-- all'inizio di una richiesta, e clear_session alla fine (disciplina del pool).
-- i_user : identificatore dell'utente applicativo.
procedure set_actor(i_user in varchar2);
--------------------------------------------------------------------------------
-- Dichiara il correlation id della chiamata corrente, pubblicandolo in
-- CLIENT_IDENTIFIER (visibile in v$session, usabile da DBMS_MONITOR). Il
-- correlation id passato esplicitamente alle procedure di lib_logging resta la
-- fonte di verità per il log; questa lo specchia soltanto sulla sessione per il
-- monitoraggio.
-- i_correlation_id : correlation id della chiamata/richiesta.
procedure set_correlation(i_correlation_id in varchar2);
--------------------------------------------------------------------------------
-- Strumenta la sessione via dbms_application_info con troncamento sicuro ai
-- limiti Oracle (module 48 / action 32 byte). Sovrascrive sia module sia action;
-- usarla in testa a una chiamata, oppure open_step dentro una chiamata annidata.
-- i_module : nome logico del module / processo.
-- i_action : passo corrente dentro il module.
procedure set_step(i_module in varchar2, i_action in varchar2 default null);
--------------------------------------------------------------------------------
-- Aggiorna solo l'action (il passo corrente), lasciando invariato il module.
-- Comoda per segnare l'avanzamento dentro un sottoprogramma senza ripetere il
-- module.
-- i_action : nome del passo corrente (troncato a 32 byte).
procedure set_action(i_action in varchar2);
--------------------------------------------------------------------------------
-- Impila il module/action correnti su uno stack interno e imposta l'action a
-- i_action (il module resta com'è). La close_step corrispondente li estrae e li
-- ripristina. È il meccanismo di strumentazione annidata usato da
-- lib_logging.start_proc / end_proc; raramente la si chiama direttamente. Lo
-- stack è tenuto bilanciato dall'handler d'errore obbligatorio (a ogni start_proc
-- corrisponde end_proc sul successo o end_proc_error sull'errore), quindi non
-- perde mai; una voce orfana è comunque svuotata da clear_session al confine
-- della richiesta.
-- i_action : action da impostare per questo frame.
procedure open_step(i_action in varchar2);
--------------------------------------------------------------------------------
-- Estrae la cima dello stack dei passi e ripristina quel module/action. Non fa
-- nulla quando lo stack è vuoto (difensivo: una close spaiata non dà mai errore).
procedure close_step;
--------------------------------------------------------------------------------
-- Reimposta lo stato di sessione per-richiesta: azzera l'utente APP_CTX, il
-- correlation id di CLIENT_IDENTIFIER, CLIENT_INFO, il module/action e lo stack
-- dei passi. Va chiamata quando una connessione del pool viene restituita, così
-- che la richiesta successiva non erediti l'identità o la strumentazione della
-- precedente.
procedure clear_session;
--------------------------------------------------------------------------------

end lib_session;
/

show errors package lib_session

prompt File: lib_session.pks.sql <end>
