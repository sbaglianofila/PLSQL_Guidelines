prompt File: lib_text.pks.sql <start>
-- =============================================================================
-- File:     lib_text.pks.sql
-- Oggetto:  lib_text (specifica del package)
-- Schema:   #APP#
-- Scopo:    Helper di testo - solo ciò che Oracle non offre, o offre in modo
--           scomodo. Il package più a rischio di essere una brutta copia, da qui
--           l'elenco chiuso più severo. Esplicitamente fuori scope: wrapper di
--           upper/trim/lpad, is_number/is_date (esiste validate_conversion),
--           replace banali.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260705  AA   Creazione
--   20260730  AA   Aggiunte mask (mascheramento di dati sensibili nei log),
--                  to_bool (parsing di booleano da testo) e format_duration
-- =============================================================================

prompt lib_text: Creating package specification

create or replace
package lib_text
is
-- Collezione di stringhe, tipo di ritorno di split e input di join.
type t_strings_type is table of varchar2(4000 char);
--------------------------------------------------------------------------------
-- Divide una stringa in una collezione su un separatore (l'inverso di listagg,
-- che non ha una controparte nativa prima di APEX). Restituisce una collezione
-- vuota per input null; un singolo elemento quando il separatore è assente.
-- i_text      : stringa da dividere.
-- i_separator : separatore; default virgola.
-- return      : i pezzi, in ordine.
function split(i_text in varchar2, i_separator in varchar2 default ',')
    return t_strings_type;
--------------------------------------------------------------------------------
-- Unisce una collezione in una stringa con un separatore, per i casi in cui il
-- dato non è già in una query.
-- i_strings   : pezzi da unire.
-- i_separator : separatore; default virgola.
-- return      : la stringa unita.
function join(i_strings in t_strings_type, i_separator in varchar2 default ',')
    return varchar2;
--------------------------------------------------------------------------------
-- Sostituisce i segnaposto %1..%5 in un template. La primitiva generica dietro i
-- template dei messaggi.
-- i_template : template con segnaposto %1..%5.
-- i_p1..5    : valori di sostituzione.
-- return     : la stringa composta.
function format( i_template in varchar2
               , i_p1       in varchar2 default null
               , i_p2       in varchar2 default null
               , i_p3       in varchar2 default null
               , i_p4       in varchar2 default null
               , i_p5       in varchar2 default null
               )
    return varchar2;
--------------------------------------------------------------------------------
-- Normalizza il testo in un codice mnemonico: maiuscolo, accenti ripiegati,
-- sequenze di caratteri non alfanumerici ridotte a un singolo underscore e
-- trimmate.
-- i_text : testo da normalizzare.
-- return : il codice normalizzato.
function normalize_code(i_text in varchar2)
    return varchar2;
--------------------------------------------------------------------------------
-- Maschera un valore sensibile lasciando in chiaro solo le ultime i_visible
-- posizioni, per non far comparire il dato per intero nei log (IBAN, carte, codici
-- fiscali, email) pur mantenendo le ultime cifre che lo rendono riconoscibile.
-- Fail-safe: se il testo non è più lungo di i_visible - o se i_visible è zero o
-- negativo - viene mascherato per intero, così non si espone mai più di quanto
-- richiesto. null in ingresso restituisce null.
-- i_text      : valore da mascherare.
-- i_visible   : numero di caratteri finali da lasciare in chiaro; default 4.
-- i_mask_char : carattere di mascheramento; default '*'.
-- return      : il valore mascherato.
function mask(i_text in varchar2, i_visible in number default 4, i_mask_char in varchar2 default '*')
    return varchar2;
--------------------------------------------------------------------------------
-- Interpreta un testo come booleano - il parsing che Oracle non offre. Riconosce,
-- senza distinzione di maiuscole e con gli spazi ai lati ignorati, i valori veri
-- ('Y','YES','S','SI','T','TRUE','1','ON') e falsi ('N','NO','F','FALSE','0',
-- 'OFF'). Un testo null o non riconosciuto restituisce i_default.
-- i_text    : testo da interpretare.
-- i_default : valore reso quando il testo è null o non riconosciuto; default null.
-- return    : true, false, oppure i_default.
function to_bool(i_text in varchar2, i_default in boolean default null)
    return boolean;
--------------------------------------------------------------------------------
-- Formatta una durata in secondi in una stringa leggibile per log e report
-- ("45s", "12m 05s", "2h 15m 03s", "3g 04h 05m" oltre le 24 ore) - complemento
-- alla formattazione scomoda degli interval. Mostra dall'unità più significativa
-- non nulla in giù, con secondi omessi quando la durata supera il giorno. Le
-- frazioni di secondo sono troncate; un valore negativo è reso col segno; null
-- restituisce null.
-- i_seconds : durata in secondi.
-- return    : la durata formattata.
function format_duration(i_seconds in number)
    return varchar2;
--------------------------------------------------------------------------------

end lib_text;
/

show errors package lib_text

prompt File: lib_text.pks.sql <end>
