prompt File: lib_constants.pkb.sql <start>
-- =============================================================================
-- File:     lib_constants.pkb.sql
-- Oggetto:  lib_constants (corpo del package)
-- Schema:   #APP#
-- Scopo:    Implementa gli accessori deterministici che espongono a SQL le
--           costanti dei flag. Nessuno stato.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260705  AA   Creazione
--   20260708  AA   Aggiunti gli accessori SQL date_min/date_max
-- =============================================================================

prompt lib_constants: Creating package body

create or replace
package body lib_constants
is
-- La proprietà DETERMINISTIC è dichiarata nella specifica; il body non deve ripeterla.

-- Moduli pubblici -------------------------------------------------------------
--------------------------------------------------------------------------------
function yes
    return varchar2
-- Espone k_YES a SQL.
is
begin
    return (k_YES);
end yes;
--------------------------------------------------------------------------------
function no
    return varchar2
-- Espone k_NO a SQL.
is
begin
    return (k_NO);
end no;
--------------------------------------------------------------------------------
function date_min
    return date
-- Espone k_DATE_MIN a SQL.
is
begin
    return (k_DATE_MIN);
end date_min;
--------------------------------------------------------------------------------
function date_max
    return date
-- Espone k_DATE_MAX a SQL.
is
begin
    return (k_DATE_MAX);
end date_max;
--------------------------------------------------------------------------------

end lib_constants;
/

show errors package body lib_constants

prompt File: lib_constants.pkb.sql <end>
