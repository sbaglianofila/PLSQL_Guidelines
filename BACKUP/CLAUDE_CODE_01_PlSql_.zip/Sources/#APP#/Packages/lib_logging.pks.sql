prompt File: lib_logging.pks.sql <start>
-- =============================================================================
-- File:     lib_logging.pks.sql
-- Oggetto:  lib_logging (specifica del package)
-- Schema:   #APP#
-- Scopo:    Motore di logging strutturato alla base della diagnosi e delle query
--           di controllo dell'AM. Scrive ogni evento nell'unica tabella
--           log_events (con backtrace/call stack degli errori in
--           log_error_details) in una TRANSAZIONE AUTONOMA così che il log
--           sopravviva a un rollback della transazione applicativa. Il livello
--           minimo è configurabile a runtime (via lib_config) così che il debug
--           si possa accendere in produzione senza ricompilare.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260705  AA   Creazione
--   20260708  AA   correlation_id propagato ai writer; aggiunto il generatore
--                  new_correlation_id
--   20260708  AA   Aggiunti il tracciamento del ciclo di vita start_proc/end_proc,
--                  message_type ed execution_id (span id) per invocazione
--   20260708  AA   Aggiunti gli overload a catalogo cfg_messages (log per codice
--                  messaggio con segnaposto %1..%10)
--   20260708  AA   Errori Oracle loggati con l'override ORACLE di
--                  cfg_error_messages quando a catalogo, altrimenti l'sqlerrm grezzo
--   20260708  AA   Esposta message_of (compone un messaggio cfg_messages), usata
--                  anche da lib_err.raise_msg
--   20260708  AA   start_proc apre un frame di step (save/restore preciso); aggiunta
--                  end_proc_error per l'handler d'errore obbligatorio
-- =============================================================================

prompt lib_logging: Creating package specification

create or replace
package lib_logging
is
--------------------------------------------------------------------------------
-- Genera un nuovo correlation id (un token esadecimale casuale) che il chiamante
-- conserva e passa alle procedure log_*, così tutte le voci di una
-- esecuzione/flusso condividono lo stesso identificatore - il trace id. Tenuto
-- lato chiamante (non nello stato di sessione) per restare corretto sotto
-- connection pool.
-- return : un nuovo correlation id.
function new_correlation_id
    return lib_types.correlation_id_sbt;
--------------------------------------------------------------------------------
-- Genera un nuovo execution id (lo span id) per una singola invocazione di
-- sottoprogramma. Di norma ottenuto implicitamente da start_proc; esposto per i
-- chiamanti che gestiscono lo span da sé.
-- return : un nuovo execution id.
function new_execution_id
    return lib_types.execution_id_sbt;
--------------------------------------------------------------------------------
-- Compone un messaggio a catalogo da cfg_messages: sostituisce %1..%10 nel
-- template di i_message_code. Un codice sconosciuto degrada a '[<code>]'. Esposto
-- così che i chiamanti (e lib_err.raise_msg) possano ottenere il testo senza
-- loggarlo, es. per mostrarlo nella UI.
-- i_message_code : chiave cfg_messages.
-- i_p1..10       : valori sostituiti a %1..%10.
-- return         : il messaggio composto.
function message_of( i_message_code in varchar2
                   , i_p1  in varchar2 default null
                   , i_p2  in varchar2 default null
                   , i_p3  in varchar2 default null
                   , i_p4  in varchar2 default null
                   , i_p5  in varchar2 default null
                   , i_p6  in varchar2 default null
                   , i_p7  in varchar2 default null
                   , i_p8  in varchar2 default null
                   , i_p9  in varchar2 default null
                   , i_p10 in varchar2 default null
                   )
    return varchar2;
--------------------------------------------------------------------------------
-- Registra un evento START (message_type START, livello INFO) che marca l'inizio
-- dell'esecuzione di un sottoprogramma, generando e restituendo un nuovo execution
-- id. Conserva l'id restituito e passalo alle log_* intermedie e a end_proc /
-- end_proc_error, così l'intera invocazione è ricucita insieme e il suo START/END
-- si appaiano anche quando lo stesso scope gira più volte in un flusso. Come
-- effetto collaterale strumenta anche la sessione: apre un frame di step (salvando
-- il module/action correnti e impostando l'ACTION a i_scope) e rivendica il MODULE
-- solo quando non ne è ancora impostato uno (senza mai sovrascrivere un nome di
-- processo batch/APEX). Il frame è ripristinato dalla end_proc / end_proc_error
-- corrispondente - vanno sempre appaiate.
-- i_scope          : scope logico (package.subprogram) in cui si entra.
-- i_correlation_id : correlation id di flusso opzionale, condiviso dall'intero flusso.
-- i_message        : testo custom opzionale; se null se ne compone uno di default.
-- return           : l'execution id generato per questa invocazione.
function start_proc( i_scope          in lib_types.scope_sbt
                   , i_correlation_id in lib_types.correlation_id_sbt default null
                   , i_message        in varchar2 default null
                   )
    return lib_types.execution_id_sbt;
--------------------------------------------------------------------------------
-- Registra un evento END (message_type END, livello INFO) che chiude, sul
-- percorso di SUCCESSO, l'invocazione aperta da start_proc, e ripristina il frame
-- di step (il module/action del chiamante). Passa l'execution id restituito da
-- start_proc.
-- i_scope          : scope logico (package.subprogram) che si sta lasciando.
-- i_execution_id   : l'id restituito dalla start_proc corrispondente.
-- i_correlation_id : correlation id di flusso opzionale.
-- i_message        : testo custom opzionale; se null se ne compone uno di default.
procedure end_proc( i_scope          in lib_types.scope_sbt
                  , i_execution_id   in lib_types.execution_id_sbt
                  , i_correlation_id in lib_types.correlation_id_sbt default null
                  , i_message        in varchar2 default null
                  );
--------------------------------------------------------------------------------
-- La controparte sul percorso d'ERRORE di end_proc, per l'handler when-others
-- obbligatorio: scrive un END marcato come chiusura in errore e ripristina il
-- frame di step, così lo span è chiuso e il module/action del chiamante sono
-- ripristinati anche sul percorso d'errore. NON logga l'errore in sé - se lo vuoi
-- loggato qui, chiama anche log_error o lib_err.reraise; poi ripropaga. Stessi
-- parametri di end_proc.
procedure end_proc_error( i_scope          in lib_types.scope_sbt
                        , i_execution_id   in lib_types.execution_id_sbt
                        , i_correlation_id in lib_types.correlation_id_sbt default null
                        , i_message        in varchar2 default null
                        );
--------------------------------------------------------------------------------
-- Registra una voce di livello INFO. Alias di comodo di log_info, usato dal
-- pattern di tracciamento start/end.
-- i_text           : messaggio da registrare.
-- i_correlation_id : correlation id di esecuzione/flusso opzionale (trace id).
-- i_execution_id   : id per singola invocazione opzionale (span id).
-- i_scope          : scope logico (package.subprogram); opzionale.
procedure log( i_text           in varchar2
             , i_correlation_id in lib_types.correlation_id_sbt default null
             , i_execution_id   in lib_types.execution_id_sbt default null
             , i_scope          in lib_types.scope_sbt default null
             );
--------------------------------------------------------------------------------
-- Registra un evento ERROR in log_events, più l'sqlerrm grezzo, il backtrace e il
-- call stack in log_error_details. Sempre scritto (mai filtrato). Pensato per
-- essere chiamato da un exception handler. Per un errore Oracle nativo presente a
-- catalogo come override ORACLE in cfg_error_messages, il messaggio loggato mostra
-- il testo personalizzato; altrimenti mostra l'sqlerrm. L'sqlerrm grezzo è sempre
-- conservato nella riga di dettaglio.
-- i_text           : messaggio di contesto fornito dal chiamante.
-- i_correlation_id : correlation id di esecuzione/flusso opzionale (trace id).
-- i_execution_id   : id per singola invocazione opzionale (span id).
-- i_scope          : scope logico (package.subprogram); opzionale.
procedure log_error( i_text           in varchar2
                   , i_correlation_id in lib_types.correlation_id_sbt default null
                   , i_execution_id   in lib_types.execution_id_sbt default null
                   , i_scope          in lib_types.scope_sbt default null
                   );
--------------------------------------------------------------------------------
-- Registra una voce di livello WARN (scritta quando il livello minimo <= WARN).
procedure log_warn( i_text           in varchar2
                  , i_correlation_id in lib_types.correlation_id_sbt default null
                  , i_execution_id   in lib_types.execution_id_sbt default null
                  , i_scope          in lib_types.scope_sbt default null
                  );
--------------------------------------------------------------------------------
-- Registra una voce di livello INFO (scritta quando il livello minimo <= INFO).
procedure log_info( i_text           in varchar2
                  , i_correlation_id in lib_types.correlation_id_sbt default null
                  , i_execution_id   in lib_types.execution_id_sbt default null
                  , i_scope          in lib_types.scope_sbt default null
                  );
--------------------------------------------------------------------------------
-- Registra una voce di livello DEBUG (scritta solo quando il livello minimo = DEBUG).
procedure log_debug( i_text           in varchar2
                   , i_correlation_id in lib_types.correlation_id_sbt default null
                   , i_execution_id   in lib_types.execution_id_sbt default null
                   , i_scope          in lib_types.scope_sbt default null
                   );
--------------------------------------------------------------------------------

-- Overload a catalogo ---------------------------------------------------------
-- Gli stessi tre livelli, ma il messaggio è composto da un template memorizzato
-- in cfg_messages, con chiave i_message_code e %1..%10 sostituiti da i_p1..i_p10.
-- Un codice sconosciuto degrada a '[<code>]' così una riga mancante non nasconde
-- mai l'evento. Tieni i codici come costanti in un package *_msg_codes per-dominio
-- (es. ord_msg_codes.c_inf_import_completed), mai come letterali sparsi. Questi
-- overload richiedono la notazione con nome per disambiguare da quelli a testo
-- libero qui sopra (già regola del progetto).
-- i_message_code   : chiave a catalogo.
-- i_p1..10         : valori sostituiti a %1..%10 nel template.
-- i_correlation_id : trace id opzionale.
-- i_execution_id   : span id opzionale.
-- i_scope          : scope logico.
--------------------------------------------------------------------------------
procedure log_info( i_message_code   in varchar2
                  , i_p1             in varchar2 default null
                  , i_p2             in varchar2 default null
                  , i_p3             in varchar2 default null
                  , i_p4             in varchar2 default null
                  , i_p5             in varchar2 default null
                  , i_p6             in varchar2 default null
                  , i_p7             in varchar2 default null
                  , i_p8             in varchar2 default null
                  , i_p9             in varchar2 default null
                  , i_p10            in varchar2 default null
                  , i_correlation_id in lib_types.correlation_id_sbt default null
                  , i_execution_id   in lib_types.execution_id_sbt default null
                  , i_scope          in lib_types.scope_sbt default null
                  );
--------------------------------------------------------------------------------
procedure log_warn( i_message_code   in varchar2
                  , i_p1             in varchar2 default null
                  , i_p2             in varchar2 default null
                  , i_p3             in varchar2 default null
                  , i_p4             in varchar2 default null
                  , i_p5             in varchar2 default null
                  , i_p6             in varchar2 default null
                  , i_p7             in varchar2 default null
                  , i_p8             in varchar2 default null
                  , i_p9             in varchar2 default null
                  , i_p10            in varchar2 default null
                  , i_correlation_id in lib_types.correlation_id_sbt default null
                  , i_execution_id   in lib_types.execution_id_sbt default null
                  , i_scope          in lib_types.scope_sbt default null
                  );
--------------------------------------------------------------------------------
procedure log_debug( i_message_code   in varchar2
                   , i_p1             in varchar2 default null
                   , i_p2             in varchar2 default null
                   , i_p3             in varchar2 default null
                   , i_p4             in varchar2 default null
                   , i_p5             in varchar2 default null
                   , i_p6             in varchar2 default null
                   , i_p7             in varchar2 default null
                   , i_p8             in varchar2 default null
                   , i_p9             in varchar2 default null
                   , i_p10            in varchar2 default null
                   , i_correlation_id in lib_types.correlation_id_sbt default null
                   , i_execution_id   in lib_types.execution_id_sbt default null
                   , i_scope          in lib_types.scope_sbt default null
                   );
--------------------------------------------------------------------------------
-- Svuota il livello minimo in cache così che la chiamata successiva lo rilegga da
-- lib_config. Permette a un operatore di cambiare la verbosità in produzione e
-- farla avere effetto senza ricompilare.
procedure refresh;
--------------------------------------------------------------------------------
-- Elimina le righe di log più vecchie della finestra di retention. Pensata per un
-- job schedulato. Quando i_retention_days è null il valore viene dalla
-- configurazione (parametro LOG_RETENTION_DAYS, con default
-- lib_constants.k_LOG_RETENTION).
-- i_retention_days : età in giorni oltre la quale le righe sono eliminate.
procedure purge(i_retention_days in number default null);
--------------------------------------------------------------------------------

end lib_logging;
/

show errors package lib_logging

prompt File: lib_logging.pks.sql <end>
