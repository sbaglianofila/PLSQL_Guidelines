prompt File: lib_lookup.pkb.sql <start>
-- =============================================================================
-- File:     lib_lookup.pkb.sql
-- Oggetto:  lib_lookup (corpo del package)
-- Schema:   #APP#
-- Scopo:    Lettura in cache delle lookup ref_lookups / ref_lookup_values. Ogni
--           set è caricato una volta con tutti i suoi valori (validi e ritirati)
--           ordinati, e servito dalla cache alle chiamate successive.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260719  AA   Creazione
-- =============================================================================

prompt lib_lookup: Creating package body

create or replace
package body lib_lookup
is
-- Costanti --------------------------------------------------------------------
k_SCOPE  constant lib_types.scope_sbt := 'lib_lookup';

-- Tipi ------------------------------------------------------------------------
-- Cache dei set: per ciascun lookup_code, tutti i suoi valori ordinati. La
-- presenza della chiave nella cache marca il set come già caricato (anche se ha
-- zero valori), così un set vuoto non viene riletto a ogni chiamata.
type t_cache_type is table of t_values
    index by ref_lookups.lookup_code%type;

-- Globali ---------------------------------------------------------------------
g_cache  t_cache_type;

-- Moduli privati --------------------------------------------------------------
--------------------------------------------------------------------------------
procedure load_set(i_lookup_code in varchar2)
-- Carica in cache tutti i valori del set indicato, ordinati per sort_order e
-- value_code. L'ordine dei campi del select rispecchia t_value_rec.
is
    l_values  t_values;
begin
    select rlv.value_code
         , rlv.label
         , rlv.description
         , rlv.sort_order
         , rlv.is_valid
         , rlv.is_default
         , rlv.num_value
         , rlv.char_value
         , rlv.date_value
      bulk collect into l_values
      from ref_lookup_values rlv
     where rlv.lookup_code = i_lookup_code
     order by rlv.sort_order
            , rlv.value_code;

    g_cache(i_lookup_code) := l_values;
end load_set;
--------------------------------------------------------------------------------
function get_set(i_lookup_code in varchar2)
    return t_values
-- Restituisce i valori del set dalla cache, caricandoli alla prima richiesta.
is
begin
    if ( not g_cache.exists(i_lookup_code) )
    then
        load_set(i_lookup_code);
    end if;

    return (g_cache(i_lookup_code));
end get_set;
--------------------------------------------------------------------------------

-- Moduli pubblici -------------------------------------------------------------
--------------------------------------------------------------------------------
function values_of(i_lookup_code in varchar2)
    return t_values
-- Filtra i soli valori validi dal set in cache, preservandone l'ordine.
is
    l_all    t_values := get_set(i_lookup_code);
    l_valid  t_values := t_values();
begin
    for i in 1 .. l_all.count
    loop
        if ( l_all(i).is_valid = lib_constants.k_YES )
        then
            l_valid.extend;
            l_valid(l_valid.last) := l_all(i);
        end if;
    end loop;

    return (l_valid);
end values_of;
--------------------------------------------------------------------------------
function label_of(i_lookup_code in varchar2, i_value_code in varchar2)
    return varchar2
-- Etichetta del codice, anche se ritirato; null se il codice non è nel set.
is
    l_all  t_values := get_set(i_lookup_code);
begin
    for i in 1 .. l_all.count
    loop
        if ( l_all(i).value_code = i_value_code )
        then
            return (l_all(i).label);
        end if;
    end loop;

    return (null);
end label_of;
--------------------------------------------------------------------------------
function is_valid(i_lookup_code in varchar2, i_value_code in varchar2)
    return boolean
-- Vero se il codice è nel set ed è attualmente valido.
is
    l_all  t_values := get_set(i_lookup_code);
begin
    for i in 1 .. l_all.count
    loop
        if ( l_all(i).value_code = i_value_code )
        then
            return (l_all(i).is_valid = lib_constants.k_YES);
        end if;
    end loop;

    return (false);
end is_valid;
--------------------------------------------------------------------------------
function default_of(i_lookup_code in varchar2)
    return varchar2
-- Codice del valore predefinito del set; null se non ce n'è uno.
is
    l_all  t_values := get_set(i_lookup_code);
begin
    for i in 1 .. l_all.count
    loop
        if ( l_all(i).is_default = lib_constants.k_YES )
        then
            return (l_all(i).value_code);
        end if;
    end loop;

    return (null);
end default_of;
--------------------------------------------------------------------------------
procedure refresh(i_lookup_code in varchar2 default null)
-- Invalida un set (i_lookup_code valorizzato) o l'intera cache (null).
is
begin
    if ( i_lookup_code is null )
    then
        g_cache.delete;
    elsif ( g_cache.exists(i_lookup_code) )
    then
        g_cache.delete(i_lookup_code);
    end if;
end refresh;
--------------------------------------------------------------------------------

end lib_lookup;
/

show errors package body lib_lookup

prompt File: lib_lookup.pkb.sql <end>
