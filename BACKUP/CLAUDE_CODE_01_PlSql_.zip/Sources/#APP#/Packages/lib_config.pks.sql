prompt File: lib_config.pks.sql <start>
-- =============================================================================
-- File:     lib_config.pks.sql
-- Oggetto:  lib_config (specifica del package)
-- Schema:   #APP#
-- Scopo:    Accesso disciplinato a cfg_parameters: getter tipizzati, default
--           espliciti, cache. Evita le due derive classiche - parametri letti con
--           select sparse nel codice, e valori "temporaneamente" hardcoded.
--           Espone anche l'identità dell'ambiente usata come guardia da lib_mail,
--           dai job e dal tooling.
--           Convenzione: quando un parametro è assente si restituisce i_default;
--           un i_default nullo marca il parametro come obbligatorio, così la sua
--           assenza solleva lib_err.e_config_param_missing.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260705  AA   Creazione
-- =============================================================================

prompt lib_config: Creating package specification

create or replace
package lib_config
is
--------------------------------------------------------------------------------
-- Restituisce un parametro stringa (vedi la convenzione obbligatorio/default
-- sopra).
-- i_name    : nome del parametro.
-- i_default : valore restituito quando il parametro è assente.
function get_string(i_name in varchar2, i_default in varchar2 default null)
    return varchar2;
--------------------------------------------------------------------------------
-- Restituisce un parametro numerico, convertito dal testo memorizzato. Solleva
-- lib_err.e_config_param_invalid se il valore memorizzato non è un numero.
function get_number(i_name in varchar2, i_default in number default null)
    return number;
--------------------------------------------------------------------------------
-- Restituisce un parametro data, convertito con lib_constants.k_DATE_FMT. Solleva
-- lib_err.e_config_param_invalid se il valore memorizzato non è una data valida.
function get_date(i_name in varchar2, i_default in date default null)
    return date;
--------------------------------------------------------------------------------
-- Restituisce un parametro flag ('Y'/'N'). Solleva lib_err.e_config_param_invalid
-- se il valore memorizzato non è né l'uno né l'altro.
function get_flag(i_name in varchar2, i_default in varchar2 default null)
    return varchar2;
--------------------------------------------------------------------------------
-- L'unica via di scrittura. Aggiorna un parametro modificabile, registra la
-- modifica nel log (chi, quando) e invalida la cache. Non fa commit: la
-- transazione è controllata dal chiamante.
-- i_name  : parametro da aggiornare.
-- i_value : nuovo valore testuale.
procedure set_value(i_name in varchar2, i_value in varchar2);
--------------------------------------------------------------------------------
-- Identità dell'ambiente (DEV / TEST / PROD), dal parametro ENVIRONMENT impostato
-- in provisioning; default DEV quando non impostato.
-- return : il codice dell'ambiente.
function environment
    return varchar2;
--------------------------------------------------------------------------------
-- Vero solo in produzione. La guardia usata da lib_mail, dai job e dal tooling
-- per comportarsi diversamente fuori produzione.
-- return : true quando environment = 'PROD'.
function is_production
    return boolean;
--------------------------------------------------------------------------------
-- Svuota la cache così che la lettura successiva ricarichi da cfg_parameters.
procedure refresh;
--------------------------------------------------------------------------------

end lib_config;
/

show errors package lib_config

prompt File: lib_config.pks.sql <end>
