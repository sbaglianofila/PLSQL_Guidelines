prompt File: lib_gate.pkb.sql <start>
-- =============================================================================
-- File:     lib_gate.pkb.sql
-- Oggetto:  lib_gate (corpo del package)
-- Schema:   #APP#
-- Scopo:    Il motore delle precondizioni: legge le regole attive del processo da
--           cfg_gate_rules e le smista, una per una, alle funzioni di check
--           private tramite un case compilato.
-- Nota:     Ogni chk_* è un'INTERROGAZIONE PURA: nessuna DML, nessun commit,
--           nessuna transazione autonoma, nessuna chiamata a servizi esterni.
--           Chiamare evaluate due volte di seguito deve dare lo stesso verdetto
--           senza lasciare traccia. Un check che "avrebbe bisogno" di scrivere
--           qualcosa è un requisito mal posto: quella scrittura appartiene al
--           chiamante.
--           I check delegano ai package base invece di reimplementarne la logica:
--           l'ambiente lo sa lib_config, i giorni lavorativi e le festività
--           lib_calendar, e le esecuzioni precedenti stanno in log_process_runs
--           dove le scrive lib_batch. Questa è la ragione per cui il gate ha senso
--           dentro questo framework e non come libreria a sé.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260729  AA   Creazione
-- =============================================================================

prompt lib_gate: Creating package body

create or replace
package body lib_gate
is
-- Costanti --------------------------------------------------------------------
k_SCOPE          constant lib_types.scope_sbt := 'lib_gate';
k_ACTION_GATE    constant lib_types.code_sbt  := 'GATE';
k_STATUS_SUCCESS constant log_process_runs.status%type := 'SUCCESS';
k_FLAG_YES       constant lib_types.flag_sbt := 'Y';
k_SEP            constant varchar2(2 char) := '; ';
k_LIST_SEP       constant varchar2(1 char) := ',';
k_DEF_CALENDAR   constant lib_types.code_sbt := 'DEFAULT';
-- FX impone il match esatto in lettura ma non ha senso in scrittura: si toglie,
-- come già fa lib_config quando formatta una data per un messaggio.
k_DATE_OUT_FMT   constant lib_types.code_sbt := replace(lib_constants.k_DATE_FMT, 'FX');

-- Moduli privati --------------------------------------------------------------
--------------------------------------------------------------------------------
procedure assert_param( i_value      in varchar2
                      , i_rule_code  in varchar2
                      , i_param_name in varchar2
                      )
-- Pretende che un parametro obbligatorio della regola sia valorizzato. Una regola
-- configurata senza il parametro che le serve non è "una regola che non passa": è
-- una regola che non si può nemmeno valutare, quindi un difetto di configurazione
-- da correggere, non un verdetto da restituire.
-- i_value      : valore configurato.
-- i_rule_code  : tipo di regola, per il messaggio.
-- i_param_name : nome del parametro mancante, per il messaggio.
is
begin
    if ( i_value is null )
    then
        lib_err.raise_msg( i_message_code => k_msg_param_missing
                         , i_p1           => i_param_name
                         , i_p2           => i_rule_code
                         , i_scope        => k_SCOPE || '.assert_param'
                         );
    end if;
end assert_param;
--------------------------------------------------------------------------------
function contains_item( i_list in varchar2
                      , i_item in varchar2
                      )
    return boolean
-- Vero se un elenco separato da virgole contiene l'elemento indicato, confrontato
-- in maiuscolo. Gli spazi sono rimossi dall'elenco prima del confronto, così una
-- configurazione scritta 'TEST, PROD' funziona come 'TEST,PROD'; è lecito perché i
-- valori ammessi dalle regole che la usano (codici ambiente, numeri di giorno) non
-- contengono spazi al loro interno. Serve alle regole che ammettono più valori.
-- i_list : elenco separato da virgole, come configurato.
-- i_item : elemento cercato.
is
    k_PADDED_LIST  constant lib_types.big_string_sbt :=
                       k_LIST_SEP || upper(replace(i_list, ' ')) || k_LIST_SEP;
    k_PADDED_ITEM  constant lib_types.big_string_sbt :=
                       k_LIST_SEP || upper(trim(i_item)) || k_LIST_SEP;
begin
    return (instr(k_PADDED_LIST, k_PADDED_ITEM) > 0);
end contains_item;
--------------------------------------------------------------------------------

-- Funzioni di check -----------------------------------------------------------
-- Ciascuna restituisce true quando la precondizione è soddisfatta, e valorizza
-- o_message SOLO in caso negativo, spiegando che cosa non va in modo che il
-- messaggio finisca leggibile nel registro dei run.
--------------------------------------------------------------------------------
function chk_enabled( i_param_name in varchar2
                    , o_message    out varchar2
                    )
    return boolean
-- ENABLED: il processo risulta abilitato dal flag di configurazione indicato.
-- È l'interruttore che permette di fermare un processo senza toccare lo scheduler
-- né il codice. Un parametro inesistente NON vale come "disabilitato": lib_config
-- solleva e_config_param_missing, perché un interruttore che non si trova è un
-- difetto di setup, non un no.
-- i_param_name : nome del parametro cfg_parameters che abilita il processo.
-- o_message    : spiegazione, valorizzata solo se il processo è disabilitato.
is
    l_flag  lib_types.flag_sbt;
begin
    assert_param(i_value => i_param_name, i_rule_code => 'ENABLED', i_param_name => 'param_1');

    l_flag := lib_config.get_flag(i_name => i_param_name);

    if ( l_flag = k_FLAG_YES )
    then
        return (true);
    end if;

    o_message := 'processo disabilitato dal parametro ' || i_param_name;
    return (false);
end chk_enabled;
--------------------------------------------------------------------------------
function chk_environment( i_env_list in varchar2
                        , o_message  out varchar2
                        )
    return boolean
-- ENVIRONMENT: l'ambiente corrente è fra quelli ammessi. L'identità dell'ambiente
-- la dà lib_config.environment (parametro ENVIRONMENT) e non il nome del database:
-- il nome fisico cambia con le migrazioni e i cloni, il parametro no, ed è già la
-- guardia che usano lib_mail e il tooling. Tipicamente ABORT: girare sull'ambiente
-- sbagliato non è mai fisiologico.
-- i_env_list : elenco di ambienti ammessi separati da virgola (es. 'TEST,PROD').
-- o_message  : spiegazione, valorizzata solo se l'ambiente non è ammesso.
is
    k_CURRENT  constant lib_types.code_sbt := lib_config.environment;
begin
    assert_param(i_value => i_env_list, i_rule_code => 'ENVIRONMENT', i_param_name => 'param_1');

    if ( contains_item(i_list => i_env_list, i_item => k_CURRENT) )
    then
        return (true);
    end if;

    o_message := 'ambiente corrente ' || k_CURRENT || ' non ammesso (ammessi: ' || i_env_list || ')';
    return (false);
end chk_environment;
--------------------------------------------------------------------------------
function chk_time_window( i_from     in varchar2
                        , i_to       in varchar2
                        , i_ref_date in date
                        , o_message  out varchar2
                        )
    return boolean
-- TIME_WINDOW: l'ora di riferimento ricade nella finestra ammessa. La finestra può
-- scavalcare la mezzanotte (22:00-05:00), caso normale per i batch notturni e per
-- questo trattato esplicitamente invece di lasciarlo al confronto ingenuo, che
-- darebbe sempre falso.
-- i_from     : ora di inizio in formato HH24:MI.
-- i_to       : ora di fine in formato HH24:MI.
-- i_ref_date : istante di riferimento.
-- o_message  : spiegazione, valorizzata solo se si è fuori finestra.
is
    k_NOW   constant varchar2(4 char) := to_char(i_ref_date, 'HH24MI');
    k_FROM  constant varchar2(4 char) := replace(i_from, ':');
    k_TO    constant varchar2(4 char) := replace(i_to,   ':');
    l_ok    boolean;
begin
    assert_param(i_value => i_from, i_rule_code => 'TIME_WINDOW', i_param_name => 'param_1');
    assert_param(i_value => i_to,   i_rule_code => 'TIME_WINDOW', i_param_name => 'param_2');

    if ( k_FROM <= k_TO )
    then
        l_ok := k_NOW between k_FROM and k_TO;
    else
        -- Finestra a cavallo della mezzanotte: si è dentro se si è dopo l'inizio
        -- oppure prima della fine, non fra i due.
        l_ok := (k_NOW >= k_FROM) or (k_NOW <= k_TO);
    end if;

    if ( not l_ok )
    then
        o_message := 'fuori finestra oraria ' || i_from || '-' || i_to ||
                     ' (ora di riferimento ' || to_char(i_ref_date, 'HH24:MI') || ')';
    end if;

    return (l_ok);
end chk_time_window;
--------------------------------------------------------------------------------
function chk_day_of_week( i_day_list in varchar2
                        , i_ref_date in date
                        , o_message  out varchar2
                        )
    return boolean
-- DAY_OF_WEEK: il giorno della settimana è fra quelli ammessi, numerati ISO da 1
-- (lunedì) a 7 (domenica). Il numero si ricava dalla distanza dall'inizio della
-- settimana ISO e non da to_char(d,'D'), che dipende da NLS_TERRITORY e darebbe
-- risultati diversi a seconda di chi lancia il processo.
-- i_day_list : elenco di giorni ammessi separati da virgola (es. '1,2,3,4,5').
-- i_ref_date : data di riferimento.
-- o_message  : spiegazione, valorizzata solo se il giorno non è ammesso.
is
    k_DOW  constant varchar2(1 char) :=
               to_char(trunc(i_ref_date) - trunc(i_ref_date, 'IW') + 1);
begin
    assert_param(i_value => i_day_list, i_rule_code => 'DAY_OF_WEEK', i_param_name => 'param_1');

    if ( contains_item(i_list => i_day_list, i_item => k_DOW) )
    then
        return (true);
    end if;

    o_message := 'giorno della settimana ' || k_DOW || ' non ammesso (ammessi: ' || i_day_list || ')';
    return (false);
end chk_day_of_week;
--------------------------------------------------------------------------------
function chk_working_day( i_calendar in varchar2
                        , i_ref_date in date
                        , o_message  out varchar2
                        )
    return boolean
-- WORKING_DAY: la data di riferimento è un giorno lavorativo secondo il calendario
-- indicato. Delega interamente a lib_calendar, che possiede la definizione del fine
-- settimana e la tabella delle festività: qui non si reimplementa nulla, altrimenti
-- ci si troverebbe con due nozioni di "festivo" che prima o poi divergono.
-- i_calendar : calendario da usare; null vale come calendario DEFAULT.
-- i_ref_date : data di riferimento.
-- o_message  : spiegazione, valorizzata solo se il giorno non è lavorativo.
is
    k_CALENDAR  constant lib_types.code_sbt := coalesce(i_calendar, k_DEF_CALENDAR);
begin
    if ( lib_calendar.is_working_day(i_date => i_ref_date, i_calendar => k_CALENDAR) )
    then
        return (true);
    end if;

    o_message := to_char(i_ref_date, k_DATE_OUT_FMT) ||
                 ' non è un giorno lavorativo sul calendario ' || k_CALENDAR;
    return (false);
end chk_working_day;
--------------------------------------------------------------------------------
function chk_dependency( i_dep_process   in varchar2
                       , i_max_age_hours in varchar2
                       , i_ref_date      in date
                       , o_message       out varchar2
                       )
    return boolean
-- DEPENDENCY: il processo predecessore è terminato con successo. La sorgente è
-- log_process_runs, cioè il registro che lib_batch popola comunque: la dipendenza
-- si legge dai fatti già tracciati e non da un flag che qualcuno deve ricordarsi di
-- alzare.
-- Due semantiche, scelte dalla presenza di param_2. Senza, vale la giornata:
-- il predecessore deve essere finito bene nella stessa data di i_ref_date. Con,
-- vale una finestra mobile: finito bene nelle ultime N ore. La seconda è quella da
-- usare per le catene che scavalcano la mezzanotte, dove "stessa data" è ambiguo.
-- i_dep_process   : nome del processo predecessore.
-- i_max_age_hours : validità in ore come testo, oppure null per la stessa data.
-- i_ref_date      : data di riferimento.
-- o_message       : spiegazione, valorizzata solo se la dipendenza non è soddisfatta.
is
    l_count  pls_integer;
begin
    assert_param(i_value => i_dep_process, i_rule_code => 'DEPENDENCY', i_param_name => 'param_1');

    if ( i_max_age_hours is null )
    then
        select count(*)
          into l_count
          from log_process_runs lpr
         where lpr.process_name = i_dep_process
           and lpr.status       = k_STATUS_SUCCESS
           and trunc(lpr.ended_at) = trunc(i_ref_date);
    else
        if ( validate_conversion(i_max_age_hours as number) = 0 )
        then
            lib_err.raise_msg( i_message_code => k_msg_param_missing
                             , i_p1           => 'param_2 (' || i_max_age_hours || ' non è un numero di ore)'
                             , i_p2           => 'DEPENDENCY'
                             , i_scope        => k_SCOPE || '.chk_dependency'
                             );
        end if;

        select count(*)
          into l_count
          from log_process_runs lpr
         where lpr.process_name = i_dep_process
           and lpr.status       = k_STATUS_SUCCESS
           and lpr.ended_at    >= systimestamp - numtodsinterval(to_number(i_max_age_hours), 'HOUR');
    end if;

    if ( l_count > 0 )
    then
        return (true);
    end if;

    o_message := 'dipendenza non soddisfatta: ' || i_dep_process || ' senza esecuzione riuscita' ||
                 case
                     when i_max_age_hours is null
                     then ' in data ' || to_char(i_ref_date, k_DATE_OUT_FMT)
                     else ' nelle ultime ' || i_max_age_hours || ' ore'
                 end;
    return (false);
end chk_dependency;
--------------------------------------------------------------------------------
function chk_data_ready( i_object_name in varchar2
                       , o_message     out varchar2
                       )
    return boolean
-- DATA_READY: l'oggetto indicato contiene almeno una riga da elaborare. È l'unico
-- check che usa SQL dinamico, e per questo il solo protetto da due controlli
-- indipendenti: l'oggetto deve essere in cfg_gate_objects (lista bianca: senza,
-- chi scrive su cfg_gate_rules eseguirebbe SQL arbitrario) e il suo nome deve
-- superare dbms_assert.sql_object_name, che verifica sia un identificatore valido
-- e per giunta esistente.
-- La query si ferma alla prima riga: interessa "c'è o non c'è", non quante ce ne
-- sono, e su una tabella di staging grande la differenza non è trascurabile.
-- i_object_name : nome dell'oggetto da interrogare.
-- o_message     : spiegazione, valorizzata solo se l'oggetto è vuoto.
is
    l_listed     pls_integer;
    l_count      pls_integer;
    l_safe_name  lib_types.object_name_sbt;
begin
    assert_param(i_value => i_object_name, i_rule_code => 'DATA_READY', i_param_name => 'param_1');

    select count(*)
      into l_listed
      from cfg_gate_objects cgo
     where cgo.object_name = upper(trim(i_object_name));

    if ( l_listed = 0 )
    then
        lib_err.raise_msg( i_message_code => k_msg_object_not_listed
                         , i_p1           => i_object_name
                         , i_scope        => k_SCOPE || '.chk_data_ready'
                         );
    end if;

    l_safe_name := sys.dbms_assert.sql_object_name(upper(trim(i_object_name)));

    execute immediate 'select count(*) from (select 1 from ' || l_safe_name || ' where rownum = 1)'
       into l_count;

    if ( l_count > 0 )
    then
        return (true);
    end if;

    o_message := 'nessun dato da elaborare su ' || i_object_name;
    return (false);
end chk_data_ready;
--------------------------------------------------------------------------------

-- Moduli pubblici -------------------------------------------------------------
--------------------------------------------------------------------------------
function evaluate( i_process_name  in varchar2
                 , i_ref_date      in date default sysdate
                 )
    return t_verdict_rec
-- Smista ogni regola attiva al proprio check e compone il verdetto. La strumentazione
-- di sessione pubblica il rule_code in corso come action: su un check che pende,
-- v$session dice esattamente su quale regola si è fermato.
is
    l_verdict  t_verdict_rec;
    l_ok       boolean;
    l_message  lib_types.text_sbt;
    l_abort    boolean := false;
    l_skip     boolean := false;
begin
    l_verdict.decision := k_run;

    lib_session.open_step(i_action => k_ACTION_GATE);

    for r_rule in ( select cgr.rule_seq
                         , cgr.rule_code
                         , cgr.severity
                         , cgr.param_1
                         , cgr.param_2
                      from cfg_gate_rules cgr
                     where cgr.process_name = i_process_name
                       and cgr.is_active    = k_FLAG_YES
                     order by cgr.rule_seq
                  )
    loop
        lib_session.set_action(i_action => r_rule.rule_code);
        l_message := null;

        case r_rule.rule_code
            when 'ENABLED'
            then l_ok := chk_enabled(r_rule.param_1, l_message);
            when 'ENVIRONMENT'
            then l_ok := chk_environment(r_rule.param_1, l_message);
            when 'TIME_WINDOW'
            then l_ok := chk_time_window(r_rule.param_1, r_rule.param_2, i_ref_date, l_message);
            when 'DAY_OF_WEEK'
            then l_ok := chk_day_of_week(r_rule.param_1, i_ref_date, l_message);
            when 'WORKING_DAY'
            then l_ok := chk_working_day(r_rule.param_1, i_ref_date, l_message);
            when 'DEPENDENCY'
            then l_ok := chk_dependency(r_rule.param_1, r_rule.param_2, i_ref_date, l_message);
            when 'DATA_READY'
            then l_ok := chk_data_ready(r_rule.param_1, l_message);
            else
                -- La foreign key verso cfg_gate_rule_types copre già questo caso: qui
                -- si difende dal tipo aggiunto a catalogo ma non ancora implementato.
                -- Si solleva invece di ignorare perché una regola fantasma - configurata,
                -- visibile, e che non blocca nulla - è peggio dell'assenza di regole:
                -- produce falsa sicurezza.
                lib_err.raise_msg( i_message_code => k_msg_rule_unknown
                                 , i_p1           => r_rule.rule_code
                                 , i_p2           => i_process_name
                                 , i_p3           => to_char(r_rule.rule_seq)
                                 , i_scope        => k_SCOPE || '.evaluate'
                                 );
        end case;

        if ( not l_ok )
        then
            if ( r_rule.severity = k_sev_abort )
            then
                l_abort := true;
            else
                l_skip := true;
            end if;

            l_verdict.failed_rules := substrb( ltrim(l_verdict.failed_rules || k_LIST_SEP || r_rule.rule_code, k_LIST_SEP)
                                             , 1
                                             , 4000
                                             );
            l_verdict.message := substrb( l_verdict.message
                                          || case when l_verdict.message is not null then k_SEP end
                                          || '[' || r_rule.severity || '/' || r_rule.rule_code || '] '
                                          || l_message
                                        , 1
                                        , 4000
                                        );
        end if;
    end loop;

    if ( l_abort )
    then
        l_verdict.decision := k_abort;
    elsif ( l_skip )
    then
        l_verdict.decision := k_skip;
    end if;

    lib_session.close_step;

    return (l_verdict);
exception
    when others
    then
        -- Lo stack dei passi va richiuso anche sull'errore, altrimenti la sessione
        -- resta strumentata su una regola che non è più in corso.
        lib_session.close_step;
        raise;
end evaluate;
--------------------------------------------------------------------------------
procedure assert_can_run( i_process_name  in varchar2
                        , i_ref_date      in date default sysdate
                        )
-- Riduce il verdetto a "passa o solleva", per i processi che non hanno una politica
-- da applicare. Anche uno SKIP diventa un errore qui: è il senso della variante, e
-- se la distinzione serve va usata evaluate.
is
    l_verdict  t_verdict_rec;
begin
    l_verdict := evaluate(i_process_name => i_process_name, i_ref_date => i_ref_date);

    if ( l_verdict.decision <> k_run )
    then
        lib_err.raise( i_error => lib_err.k_PRECONDITION_FAILED
                     , i_p1    => i_process_name
                     , i_p2    => '[' || l_verdict.decision || '] ' || l_verdict.message
                     , i_scope => k_SCOPE || '.assert_can_run'
                     );
    end if;
end assert_can_run;
--------------------------------------------------------------------------------
function describe(i_process_name in varchar2)
    return varchar2
-- Elenca la configurazione così com'è, senza valutarla: risponde a "che cosa è
-- configurato su questo processo?", che è la prima domanda quando un batch non parte
-- e nessuno ricorda perché. Include le regole disattivate, marcandole: una regola
-- spenta è spesso proprio la risposta.
is
    l_out  lib_types.big_string_sbt;
begin
    for r_rule in ( select cgr.rule_seq
                         , cgr.rule_code
                         , cgr.severity
                         , cgr.param_1
                         , cgr.param_2
                         , cgr.is_active
                      from cfg_gate_rules cgr
                     where cgr.process_name = i_process_name
                     order by cgr.rule_seq
                  )
    loop
        l_out := substrb( l_out
                          || lpad(to_char(r_rule.rule_seq), 3) || '. '
                          || rpad(r_rule.rule_code, 12) || ' (' || r_rule.severity || ')'
                          || case when r_rule.is_active <> k_FLAG_YES then ' [DISATTIVA]' end
                          || ' p1=' || nvl(r_rule.param_1, '-')
                          || ' p2=' || nvl(r_rule.param_2, '-')
                          || chr(10)
                        , 1
                        , 32767
                        );
    end loop;

    return (nvl(l_out, 'Nessuna regola configurata per ' || i_process_name));
end describe;
--------------------------------------------------------------------------------

end lib_gate;
/

show errors package body lib_gate

prompt File: lib_gate.pkb.sql <end>
