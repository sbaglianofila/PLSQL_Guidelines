prompt File: lib_calendar.pks.sql <start>
-- =============================================================================
-- File:     lib_calendar.pks.sql
-- Oggetto:  lib_calendar (specifica del package)
-- Schema:   #APP#
-- Scopo:    Calendario di business - un complemento genuino: Oracle non sa nulla
--           di giorni lavorativi e festività. Serve qualsiasi progetto con
--           scadenze, SLA o elaborazioni tipo "primo giorno lavorativo del mese".
--           Il weekend è sabato e domenica (indipendente dal locale); le festività
--           vengono da ref_holidays, opzionalmente per calendario. Al calcolo dei
--           giorni lavorativi si aggiunge quello delle date che Oracle non sa
--           dedurre da sé: la Pasqua (perno di tutte le feste mobili) e l'anno
--           bisestile.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260705  AA   Creazione
--   20260730  AA   Aggiunte is_holiday, get_easter_date e is_leap_year, più le
--                  costanti di scarto delle feste mobili; aggiunta dates_overlap
--   20260730  AA   Aggiunte le table function di serie days_between/working_days_in
--                  (tipo collezione t_dates) e nth_weekday_of_month
-- =============================================================================

prompt lib_calendar: Creating package specification

create or replace
package lib_calendar
is
-- Tipi ------------------------------------------------------------------------
-- Collezione di date, tipo di ritorno delle table function di serie
-- (days_between, working_days_in). È una nested table di package: utilizzabile
-- con l'operatore TABLE in SQL su Oracle 12.1+ (quindi sulla baseline 19c).
type t_dates is table of date;

-- Costanti --------------------------------------------------------------------
-- Scarto in giorni delle feste mobili rispetto alla domenica di Pasqua, che è il
-- perno da cui l'intero calendario mobile discende. Esistono per far scrivere
-- get_easter_date(l_year) + lib_calendar.k_EASTER_MONDAY invece di un "+ 1" che
-- non dice nulla a chi legge. Come ogni costante di package non sono visibili da
-- SQL: da SQL si somma il letterale, citando in commento la costante.
-- Quali di queste feste siano civilmente festive è una decisione di paese e di
-- progetto: la libreria fornisce il calcolo, ref_holidays il calendario adottato.
k_CARNIVAL_TUESDAY   constant pls_integer := -47;  -- Martedì Grasso (Carnevale)
k_ASH_WEDNESDAY      constant pls_integer := -46;  -- Mercoledì delle Ceneri
k_PALM_SUNDAY        constant pls_integer :=  -7;  -- Domenica delle Palme
k_EASTER_MONDAY      constant pls_integer :=   1;  -- Lunedì dell'Angelo (Pasquetta)
k_ASCENSION          constant pls_integer :=  39;  -- Ascensione
k_PENTECOST          constant pls_integer :=  49;  -- Pentecoste
k_CORPUS_CHRISTI     constant pls_integer :=  60;  -- Corpus Domini

-- Moduli pubblici -------------------------------------------------------------
--------------------------------------------------------------------------------
-- Vero quando la data non è né un weekend né una festività del calendario.
-- i_date     : data da testare (componente orario ignorata).
-- i_calendar : codice del calendario; default 'DEFAULT'.
-- return     : true quando è un giorno lavorativo.
function is_working_day(i_date in date, i_calendar in varchar2 default 'DEFAULT')
    return boolean;
--------------------------------------------------------------------------------
-- Vero quando la data è a calendario in ref_holidays, che cada in settimana o nel
-- weekend. Complementa is_working_day rispondendo alla domanda che quello
-- comprime: un giorno non lavorativo lo è perché è sabato o perché è festivo?
-- La distinzione conta a chi diagnostica un caso in esercizio, che altrimenti
-- interroga ref_holidays a mano.
-- i_date     : data da testare (componente orario ignorata).
-- i_calendar : codice del calendario; default 'DEFAULT'.
-- return     : true quando la data è una festività del calendario.
function is_holiday(i_date in date, i_calendar in varchar2 default 'DEFAULT')
    return boolean;
--------------------------------------------------------------------------------
-- Primo giorno lavorativo strettamente dopo i_date.
function next_working_day(i_date in date, i_calendar in varchar2 default 'DEFAULT')
    return date;
--------------------------------------------------------------------------------
-- Ultimo giorno lavorativo strettamente prima di i_date.
function previous_working_day(i_date in date, i_calendar in varchar2 default 'DEFAULT')
    return date;
--------------------------------------------------------------------------------
-- Aggiunge i_days giorni lavorativi a i_date (negativo per andare indietro).
-- Weekend e festività sono saltati; un offset zero restituisce la data troncata
-- invariata.
-- i_date     : data di partenza.
-- i_days     : numero di giorni lavorativi da aggiungere (può essere negativo).
-- i_calendar : codice del calendario; default 'DEFAULT'.
-- return     : la data lavorativa risultante.
function add_working_days(i_date in date, i_days in number, i_calendar in varchar2 default 'DEFAULT')
    return date;
--------------------------------------------------------------------------------
-- Conteggio dei giorni lavorativi tra due date, esclusa la più vecchia e inclusa
-- la più recente; negativo quando i_to precede i_from.
-- i_from     : prima data.
-- i_to       : seconda data.
-- i_calendar : codice del calendario; default 'DEFAULT'.
-- return     : conteggio con segno dei giorni lavorativi.
function working_days_between(i_from in date, i_to in date, i_calendar in varchar2 default 'DEFAULT')
    return number;
--------------------------------------------------------------------------------
-- Serie delle date da i_from a i_to inclusi, una per riga, in ordine crescente.
-- Complemento al trucco "connect by level" per generare un intervallo di date:
-- si joina in una query con l'operatore TABLE invece di riscriverlo ogni volta.
-- Componente orario ignorata; i_from > i_to produce nessuna riga (non solleva).
-- i_from : prima data della serie.
-- i_to   : ultima data della serie (inclusa).
-- return : le date dell'intervallo.
function days_between(i_from in date, i_to in date)
    return t_dates pipelined;
--------------------------------------------------------------------------------
-- Come days_between, ma solo i giorni lavorativi dell'intervallo (weekend e
-- festività esclusi secondo is_working_day e il calendario dato).
-- i_from     : prima data della serie.
-- i_to       : ultima data della serie (inclusa).
-- i_calendar : codice del calendario; default 'DEFAULT'.
-- return     : i soli giorni lavorativi dell'intervallo.
function working_days_in(i_from in date, i_to in date, i_calendar in varchar2 default 'DEFAULT')
    return t_dates pipelined;
--------------------------------------------------------------------------------
-- Vero quando due intervalli di date si sovrappongono, cioè condividono almeno un
-- giorno (o un istante, con i_trunc a false). Standardizza l'idioma
-- "a_from <= b_to and b_from <= a_to" che tutti riscrivono e in cui è facile
-- sbagliare l'inclusività di un estremo o dimenticare il trunc. Estremi INCLUSI,
-- come le finestre valid_from/valid_to del framework. Un estremo null vale
-- "aperto": i_a_from null è "da sempre", i_a_to null è "per sempre", risolti sui
-- sentinelli lib_constants.k_DATE_MIN/k_DATE_MAX. Gli estremi di ciascuna coppia
-- sono normalizzati, quindi una coppia invertita è trattata come l'intervallo tra
-- le due date invece di dare un risultato falsato.
-- i_a_from : inizio del primo intervallo (null = aperto a sinistra).
-- i_a_to   : fine del primo intervallo (null = aperto a destra).
-- i_b_from : inizio del secondo intervallo (null = aperto a sinistra).
-- i_b_to   : fine del secondo intervallo (null = aperto a destra).
-- i_trunc  : quando true (default) confronta a granularità giorno, coerente col
--            resto del package; false per confrontare fino al secondo.
-- return   : true quando i due intervalli si sovrappongono.
function dates_overlap( i_a_from in date
                      , i_a_to   in date
                      , i_b_from in date
                      , i_b_to   in date
                      , i_trunc  in boolean default true
                      )
    return boolean;
--------------------------------------------------------------------------------
-- L'n-esima occorrenza di un giorno della settimana in un mese: per esempio "il
-- terzo venerdì di marzo" o "l'ultimo lunedì di maggio", ricorrenze che Oracle non
-- sa esprimere direttamente. Il giorno è numerato ISO (1=lunedì .. 7=domenica),
-- indipendente da NLS. i_n conta dall'inizio se positivo (1 = prima occorrenza) o
-- dalla fine se negativo (-1 = ultima). Restituisce null quando quell'occorrenza
-- non cade nel mese (per esempio un quinto lunedì che quel mese non ha), così il
-- chiamante distingue "non esiste" senza calcolare i limiti a mano.
-- i_year    : anno.
-- i_month   : mese, 1..12.
-- i_weekday : giorno della settimana ISO, 1..7.
-- i_n       : occorrenza; positiva dall'inizio, negativa dalla fine, diversa da 0.
-- return    : la data dell'occorrenza, o null se non esiste nel mese.
function nth_weekday_of_month(i_year in number, i_month in number, i_weekday in number, i_n in number)
    return date;
--------------------------------------------------------------------------------
-- Data della domenica di Pasqua secondo il rito cattolico sul calendario
-- gregoriano, con l'algoritmo di Meeus/Jones/Butcher. È il perno delle feste
-- mobili: sommando le costanti k_* di questa specifica si ricavano le altre.
-- Valida dal 1583, primo anno pieno dopo la riforma gregoriana: prima di allora la
-- Pasqua seguiva il computo giuliano e il risultato non avrebbe significato, per
-- questo un anno precedente è rifiutato invece di essere calcolato comunque.
-- La parte frazionaria di i_year è ignorata.
-- i_year : anno compreso tra 1583 e 9999.
-- return : la data della domenica di Pasqua dell'anno dato.
function get_easter_date(i_year in number)
    return date deterministic;
--------------------------------------------------------------------------------
-- Vero quando l'anno è bisestile secondo la regola gregoriana: divisibile per 4,
-- eccetto gli anni secolari che non sono divisibili per 400.
-- Da SQL esiste già l'idioma nativo sul giorno di febbraio con last_day; questa
-- funzione esiste per la leggibilità del PL/SQL, dove dichiara l'intenzione al
-- posto di farla dedurre.
-- i_year : anno da testare; non può essere null.
-- return : true quando l'anno è bisestile.
function is_leap_year(i_year in number)
    return boolean deterministic;
--------------------------------------------------------------------------------

end lib_calendar;
/

show errors package lib_calendar

prompt File: lib_calendar.pks.sql <end>
