prompt File: lib_assert.pkb.sql <start>
-- =============================================================================
-- File:     lib_assert.pkb.sql
-- Oggetto:  lib_assert (corpo del package)
-- Schema:   #APP#
-- Scopo:    Asserzioni sugli argomenti costruite sul catalogo lib_err.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260705  AA   Creazione
-- =============================================================================

prompt lib_assert: Creating package body

create or replace
package body lib_assert
is
-- Costanti --------------------------------------------------------------------
k_SCOPE      constant lib_types.scope_sbt := 'lib_assert';
k_NULL_MSG   constant lib_types.name_sbt  := 'must not be null';

-- Moduli pubblici -------------------------------------------------------------
--------------------------------------------------------------------------------
procedure not_null(i_value in varchar2, i_param_name in varchar2)
-- Asserisce che un argomento testuale non sia null.
is
begin
    if ( i_value is null )
    then
        lib_err.raise(i_error => lib_err.k_INVALID_PARAMETER, i_p1 => i_param_name, i_p2 => k_NULL_MSG, i_scope => k_SCOPE || '.not_null');
    end if;
end not_null;
--------------------------------------------------------------------------------
procedure not_null(i_value in number, i_param_name in varchar2)
-- Overload numerico.
is
begin
    if ( i_value is null )
    then
        lib_err.raise(i_error => lib_err.k_INVALID_PARAMETER, i_p1 => i_param_name, i_p2 => k_NULL_MSG, i_scope => k_SCOPE || '.not_null');
    end if;
end not_null;
--------------------------------------------------------------------------------
procedure not_null(i_value in date, i_param_name in varchar2)
-- Overload data.
is
begin
    if ( i_value is null )
    then
        lib_err.raise(i_error => lib_err.k_INVALID_PARAMETER, i_p1 => i_param_name, i_p2 => k_NULL_MSG, i_scope => k_SCOPE || '.not_null');
    end if;
end not_null;
--------------------------------------------------------------------------------
procedure is_true( i_condition in boolean
                 , i_error     in pls_integer default lib_err.k_INVALID_PARAMETER
                 , i_message   in varchar2 default null
                 )
-- Asserzione generica: solleva l'errore dato quando la condizione è falsa o null.
is
begin
    -- Una condizione null è trattata come asserzione fallita.
    if ( not nvl(i_condition, false) )
    then
        lib_err.raise(i_error => i_error, i_p1 => i_message, i_scope => k_SCOPE || '.is_true');
    end if;
end is_true;
--------------------------------------------------------------------------------
procedure in_range(i_value in number, i_min in number, i_max in number, i_param_name in varchar2)
-- Asserisce che il valore stia in [i_min, i_max].
is
begin
    if (    i_value is null
         or i_value < i_min
         or i_value > i_max
       )
    then
        lib_err.raise( i_error => lib_err.k_INVALID_PARAMETER
                     , i_p1    => i_param_name
                     , i_p2    => 'out of range [' || i_min || '..' || i_max || ']'
                     , i_scope => k_SCOPE || '.in_range'
                     );
    end if;
end in_range;
--------------------------------------------------------------------------------
procedure max_length(i_value in varchar2, i_max in number, i_param_name in varchar2)
-- Asserisce che il valore non superi i_max caratteri.
is
begin
    if ( length(i_value) > i_max )
    then
        lib_err.raise(i_error => lib_err.k_PARAM_TOO_LARGE, i_p1 => i_param_name, i_scope => k_SCOPE || '.max_length');
    end if;
end max_length;
--------------------------------------------------------------------------------

end lib_assert;
/

show errors package body lib_assert

prompt File: lib_assert.pkb.sql <end>
