prompt File: lib_report.pks.sql <start>
-- =============================================================================
-- File:     lib_report.pks.sql
-- Oggetto:  lib_report (specifica del package)
-- Schema:   #APP#
-- Scopo:    Report tabellari automatici. Lega insieme query di controllo,
--           scheduler e recapito: trasforma qualsiasi cursore in CSV o HTML e lo
--           recapita via lib_mail o lib_file, così il reporting non richiede
--           sviluppo ad-hoc. Il caso d'uso principale è il monitoraggio dell'AM:
--           eseguire periodicamente le query di controllo e farsi sentire solo
--           quando c'è qualcosa da guardare.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260705  AA   Creazione
-- =============================================================================

prompt lib_report: Creating package specification

create or replace
package lib_report
is
--------------------------------------------------------------------------------
-- Renderizza qualsiasi cursore come CSV, descrivendone le colonne dinamicamente
-- (funziona con qualsiasi query). Consuma il cursore.
-- i_cursor : cursore aperto da renderizzare.
-- return   : documento CSV.
function render_csv(i_cursor in sys_refcursor)
    return clob;
--------------------------------------------------------------------------------
-- Renderizza qualsiasi cursore come tabella HTML. Consuma il cursore.
-- i_cursor : cursore aperto da renderizzare.
-- return   : documento HTML.
function render_html(i_cursor in sys_refcursor)
    return clob;
--------------------------------------------------------------------------------
-- Esegue un report registrato: legge la sua definizione da cfg_reports, esegue la
-- query, la formatta e la recapita via mail e/o file. Ogni run è tracciato tramite
-- lib_batch. Per i report "solo anomalie", il recapito avviene unicamente quando
-- la query restituisce righe. Solleva lib_err.e_report_not_found per un codice
-- sconosciuto.
-- i_report_code : report da eseguire.
procedure run_report(i_report_code in varchar2);
--------------------------------------------------------------------------------

end lib_report;
/

show errors package lib_report

prompt File: lib_report.pks.sql <end>
