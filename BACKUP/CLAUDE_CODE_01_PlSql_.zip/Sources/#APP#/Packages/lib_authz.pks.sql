prompt File: lib_authz.pks.sql <start>
-- =============================================================================
-- File:     lib_authz.pks.sql
-- Oggetto:  lib_authz (specifica del package)
-- Schema:   #APP#
-- Scopo:    Risoluzione dell'autorizzazione funzionale: risponde a "questo utente
--           puo' fare questa cosa su questa funzionalita'?" e fornisce l'elenco
--           delle funzionalita' con i modi effettivi (per costruire il menu).
--           Il permesso effettivo e' l'UNIONE (OR) di due contributi:
--             - dai profili, letti dalla vista materializzata aggregata
--               mv_user_effective_perms (gia' filtrata a "valida oggi");
--             - dalle eccezioni nominali adm_user_functionalities, lette al volo
--               e filtrate per validita' temporale al momento della domanda.
--           has_access = MV(profilo) OR live(eccezione valida ora).
--           Come lib_lookup / lib_config tiene in cache i permessi risolti, ma la
--           cache e' PER UTENTE E PER SESSIONE con freschezza limitata (giorno +
--           TTL breve): i permessi hanno finestre temporali a grana data, quindi
--           una cache che non scada rischierebbe di non "vedere" una scadenza a
--           mezzanotte o una revoca amministrativa. Dopo aver modificato la mappa
--           dei permessi chiamare refresh (o attendere il TTL).
--           Convenzione LASCA in lettura, FAIL-CLOSED per sicurezza: un utente
--           sconosciuto/disattivato, una funzionalita' non concessa o un modo non
--           riconosciuto tornano semplicemente "no" (has_access = false,
--           functionalities_of = vuoto); assert_access invece SOLLEVA.
--           Vedi Architettura_DB/utenti_profili.md.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260725  AA   Creazione
-- =============================================================================

prompt lib_authz: Creating package specification

create or replace
package lib_authz
is
-- Modi di accesso: i valori ammessi per il parametro i_mode, uno per flag del
-- grant. Esposti come costanti per non spargere letterali nei chiamanti.
k_mode_read     constant varchar2(10 char) := 'READ';
k_mode_write    constant varchar2(10 char) := 'WRITE';
k_mode_execute  constant varchar2(10 char) := 'EXECUTE';

-- Message code del diniego sollevato da assert_access (testo in cfg_messages,
-- seed in Data/authz_messages.dat.sql). Tenuto come costante, sul modello dei
-- k_msg_* di lib_workflow.
k_msg_access_denied  constant varchar2(100 char) := 'AUTHZ_ACCESS_DENIED';

-- Un permesso effettivo su una funzionalita': i tre modi gia' aggregati in OR
-- (profili + eccezioni), con la maschera e il modulo di appartenenza per
-- costruire il menu senza tornare sulle tabelle base.
type t_perm_rec is record
   ( functionality_code  adm_functionalities.functionality_code%type
   , mask_code           adm_masks.mask_code%type
   , module_code         adm_masks.module_code%type
   , can_read            lib_types.flag_sbt
   , can_write           lib_types.flag_sbt
   , can_execute         lib_types.flag_sbt
   );

-- Elenco di permessi effettivi. Collezione PL/SQL (non SQL).
type t_perms is table of t_perm_rec;

--------------------------------------------------------------------------------
-- Vero se l'utente ha accesso alla funzionalita' nel modo indicato, considerando
-- sia i grant da profilo (validi oggi) sia le eccezioni nominali (valide ora).
-- Fail-closed: torna false se l'utente non esiste o e' disattivato, se la
-- funzionalita' non gli e' concessa, o se il modo non e' riconosciuto.
-- i_username           : login dell'utente (come propagato in APP_CTX).
-- i_functionality_code : codice della funzionalita' (es. 'ORDERS_VIEW').
-- i_mode               : uno tra k_mode_read / k_mode_write / k_mode_execute.
function has_access( i_username           in varchar2
                   , i_functionality_code in varchar2
                   , i_mode               in varchar2
                   )
    return boolean;
--------------------------------------------------------------------------------
-- Come sopra, ma per l'utente della sessione corrente (lib_session.current_actor).
-- i_functionality_code : codice della funzionalita'.
-- i_mode               : uno tra k_mode_read / k_mode_write / k_mode_execute.
function has_access( i_functionality_code in varchar2
                   , i_mode               in varchar2
                   )
    return boolean;
--------------------------------------------------------------------------------
-- Punto di applicazione: non fa nulla se l'accesso e' concesso, solleva
-- k_msg_access_denied sotto lib_err.k_NOT_ALLOWED se non lo e'. Da usare per
-- proteggere un'azione (a differenza di has_access, che risponde soltanto).
-- i_username           : login dell'utente.
-- i_functionality_code : codice della funzionalita'.
-- i_mode               : uno tra k_mode_read / k_mode_write / k_mode_execute.
procedure assert_access( i_username           in varchar2
                       , i_functionality_code in varchar2
                       , i_mode               in varchar2
                       );
--------------------------------------------------------------------------------
-- Come sopra, ma per l'utente della sessione corrente.
-- i_functionality_code : codice della funzionalita'.
-- i_mode               : uno tra k_mode_read / k_mode_write / k_mode_execute.
procedure assert_access( i_functionality_code in varchar2
                       , i_mode               in varchar2
                       );
--------------------------------------------------------------------------------
-- Elenco delle funzionalita' cui l'utente ha accesso, con i modi effettivi gia'
-- aggregati in OR (profili + eccezioni), tipicamente per costruire il menu
-- all'accesso. Vuoto se l'utente non esiste o non ha alcun permesso.
-- i_username : login dell'utente.
function functionalities_of(i_username in varchar2)
    return t_perms;
--------------------------------------------------------------------------------
-- Come sopra, ma per l'utente della sessione corrente.
function functionalities_of
    return t_perms;
--------------------------------------------------------------------------------
-- Svuota la cache di sessione così che la lettura successiva ricalcoli i permessi.
-- Con i_username valorizzato invalida il solo utente indicato; con null (default)
-- l'intera cache. Da chiamare dopo aver modificato la mappa dei permessi
-- dell'utente nella stessa sessione (le altre sessioni si riallineano al TTL).
-- i_username : utente da invalidare, oppure null per tutti.
procedure refresh(i_username in varchar2 default null);
--------------------------------------------------------------------------------
-- Rinfresca la vista materializzata mv_user_effective_perms (refresh completo,
-- atomico). È il PUNTO UNICO di refresh della MV, condiviso dai due innescatori
-- previsti: il job schedulato giornaliero (Jobs/authz_refresh_mv) e l'invocazione
-- "su evento" che l'admin API chiamerà dopo aver modificato la mappa dei permessi.
-- Distinto da refresh (che svuota la cache di sessione): qui si ricalcola il dato
-- materializzato, là si invalida solo la copia in memoria. Vedi la politica di
-- refresh in Architettura_DB/utenti_profili.md.
procedure refresh_mv;
--------------------------------------------------------------------------------

end lib_authz;
/

show errors package lib_authz

prompt File: lib_authz.pks.sql <end>
