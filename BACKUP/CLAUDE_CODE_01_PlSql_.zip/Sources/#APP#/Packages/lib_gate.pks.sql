prompt File: lib_gate.pks.sql <start>
-- =============================================================================
-- File:     lib_gate.pks.sql
-- Oggetto:  lib_gate (specifica del package)
-- Schema:   #APP#
-- Scopo:    Valutazione centralizzata delle PRECONDIZIONI DI ESECUZIONE di un
--           processo: risponde a "ha senso che questo processo parta adesso, qui,
--           in questo stato del mondo?". Le regole di un processo stanno a
--           configurazione in cfg_gate_rules; come si valuta una regola sta nel
--           dispatch compilato del body.
--
--           Tre idee reggono l'intero meccanismo, ed è su queste che è facile
--           sbagliare rifacendolo a mano:
--
--           1. SEPARAZIONE FRA VALUTARE, DECIDERE E AGIRE. Questo package valuta e
--              restituisce un verdetto. Non scrive sul registro dei run, non
--              notifica nessuno, non fa return al posto del chiamante. È il
--              chiamante che, ricevuto il verdetto, decide se uscire in silenzio o
--              esplodere - ed è ciò che rende lo stesso identico check riusabile
--              fra processi con politiche diverse.
--           2. VERDETTO TERNARIO, MAI BOOLEANO. RUN / SKIP / ABORT. "Non c'è nulla
--              da elaborare" e "sto girando sul database sbagliato" non sono la
--              stessa cosa: comprimendole in un booleano si finisce sempre in uno
--              dei due fossi, o si soffocano gli errori veri o si inonda di falsi
--              allarmi chi presidia i batch di notte.
--           3. DISPATCH STATICO. Il tipo di regola è un codice di un dominio
--              chiuso (cfg_gate_rule_types) mappato da un case a una funzione
--              privata compilata. Non si mettono nomi di funzione in tabella da
--              eseguire dinamicamente: si perderebbero le dipendenze nel dizionario
--              dati e la compilazione smetterebbe di segnalare cosa si rompe.
--
--           Da qui una regola non negoziabile: NESSUN CHECK HA EFFETTI COLLATERALI.
--           Niente commit, niente rollback, niente DML, niente transazioni
--           autonome. Un check è un'interrogazione pura, richiamabile un numero
--           arbitrario di volte con lo stesso esito; se questa invarianza salta, il
--           gate diventa esso stesso una sorgente di stato e non ci si può più
--           ragionare sopra.
--
-- Nota:     COSA NON È. Non è il controllo dei permessi: quello risponde a "CHI" e
--           lo fa lib_authz, dove un diniego è sempre un errore. Non è la mutua
--           esclusione: quella ACQUISISCE una risorsa invece di interrogare, e la
--           tengono lib_lock e lib_batch.start_run(i_single_instance => true). Non
--           sono le guardie di workflow (wfl_transition_guards), che valutano se
--           una singola ENTITÀ può cambiare stato, non se un processo può partire.
--           Le quattro domande restano quattro chiamate distinte e leggibili.
--
--           ORDINE DI CHIAMATA. Il gate si valuta DENTRO il run, non prima: si apre
--           il run con lib_batch.start_run, poi si valuta. Così anche un processo
--           che non parte lascia una riga in log_process_runs, e "ha deciso di non
--           partire" resta distinguibile da "non è mai stato lanciato". Il modo
--           più breve di applicarne il verdetto è lib_batch.check_gate; chi ha
--           bisogno di distinguere lo SKIP dall'ABORT usa evaluate direttamente.
--           Vedi Pacchetti_Base/precondizioni_esecuzione.md.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260729  AA   Creazione
-- =============================================================================

prompt lib_gate: Creating package specification

create or replace
package lib_gate
is
-- Decisioni possibili del verdetto. Esposte come costanti perché il chiamante le
-- confronta a ogni invocazione e non deve spargere letterali.
k_run    constant varchar2(10 char) := 'RUN';
k_skip   constant varchar2(10 char) := 'SKIP';
k_abort  constant varchar2(10 char) := 'ABORT';

-- Gravità configurabili su cfg_gate_rules.severity: che cosa comporta il
-- fallimento di una regola. Stessi valori del check constraint.
k_sev_skip   constant varchar2(10 char) := 'SKIP';
k_sev_abort  constant varchar2(10 char) := 'ABORT';

-- Codici dei messaggi di dominio (catalogo cfg_messages) sollevati da questo
-- package. Sono i *_msg_codes di questo pillar; il testo vive come dato.
-- Difetti di CONFIGURAZIONE, non di opportunità: sollevati sotto k_BUSINESS_ERROR
-- perché vanno corretti, non gestiti.
k_msg_rule_unknown      constant varchar2(100 char) := 'GATE_RULE_UNKNOWN';
k_msg_object_not_listed constant varchar2(100 char) := 'GATE_OBJECT_NOT_LISTED';
k_msg_param_missing     constant varchar2(100 char) := 'GATE_PARAM_MISSING';

-- Il verdetto composto su un processo: la decisione, l'elenco delle regole che
-- non sono passate e il testo che le spiega. failed_rules serve a chi filtra
-- programmaticamente (è un elenco di rule_code separati da virgola), message a
-- chi legge.
type t_verdict_rec is record
   ( decision      varchar2(10 char)
   , failed_rules  lib_types.text_sbt
   , message       lib_types.text_sbt
   );

--------------------------------------------------------------------------------
-- Valuta TUTTE le regole attive del processo e restituisce il verdetto composto:
-- ABORT se almeno una regola con severity ABORT è fallita, altrimenti SKIP se ne è
-- fallita almeno una con severity SKIP, altrimenti RUN. Un processo senza regole
-- configurate ottiene RUN.
-- Le regole sono valutate tutte, non fino al primo fallimento: costa qualche
-- millisecondo e risparmia il gioco a rimbalzo in cui si sistema una precondizione,
-- si rilancia, se ne scopre un'altra, e così per tre giri.
-- Non solleva per le condizioni che valuta - è il verdetto a dirle - ma solleva sui
-- difetti di configurazione (regola non gestita dal dispatch, oggetto DATA_READY
-- fuori lista bianca, parametro obbligatorio mancante) e propaga gli errori di
-- lib_config su un parametro assente o malformato.
-- i_process_name : nome logico del processo, lo stesso usato con lib_batch.
-- i_ref_date     : istante di riferimento per le regole temporali; default sysdate.
--                  Va passato esplicitamente quando il processo ha una data di
--                  business diversa da oggi: un check non se la va a cercare da sé.
-- return         : il verdetto composto.
function evaluate( i_process_name  in varchar2
                 , i_ref_date      in date default sysdate
                 )
    return t_verdict_rec;
--------------------------------------------------------------------------------
-- Variante che solleva lib_err.e_precondition_failed se la decisione non è RUN, e
-- non fa nulla se lo è. Da usare nei processi in cui QUALUNQUE precondizione non
-- soddisfatta è un errore e non c'è niente da decidere: risparmia il boilerplate
-- del verdetto. Se il processo distingue SKIP da ABORT, usa evaluate.
-- i_process_name : nome logico del processo.
-- i_ref_date     : istante di riferimento per le regole temporali; default sysdate.
procedure assert_can_run( i_process_name  in varchar2
                        , i_ref_date      in date default sysdate
                        );
--------------------------------------------------------------------------------
-- Restituisce la descrizione testuale delle regole configurate su un processo,
-- attive e non, una per riga. Serve in diagnostica ("perché questo processo non
-- parte?") e nei test. Non valuta nulla e non solleva.
-- i_process_name : nome logico del processo.
-- return         : il testo delle regole, o un messaggio se non ce ne sono.
function describe(i_process_name in varchar2)
    return varchar2;
--------------------------------------------------------------------------------

end lib_gate;
/

show errors package lib_gate

prompt File: lib_gate.pks.sql <end>
