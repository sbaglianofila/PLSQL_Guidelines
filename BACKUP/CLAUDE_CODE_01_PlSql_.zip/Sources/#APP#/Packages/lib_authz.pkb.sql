prompt File: lib_authz.pkb.sql <start>
-- =============================================================================
-- File:     lib_authz.pkb.sql
-- Oggetto:  lib_authz (corpo del package)
-- Schema:   #APP#
-- Scopo:    Risoluzione in cache dei permessi effettivi. Per ogni utente il set
--           completo (funzionalita' + modi in OR) e' calcolato una volta unendo
--           la vista materializzata dei permessi da profilo e le eccezioni
--           nominali valide, e servito dalla cache di sessione fino alla scadenza
--           (cambio di giorno o TTL). has_access e functionalities_of leggono
--           entrambe da questo set.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260725  AA   Creazione
-- =============================================================================

prompt lib_authz: Creating package body

create or replace
package body lib_authz
is
-- Costanti --------------------------------------------------------------------
k_SCOPE              constant lib_types.scope_sbt := 'lib_authz';
-- Freschezza massima della cache di sessione. Oltre questo tempo (o al cambio di
-- giorno) il set viene ricalcolato, così una revoca amministrativa o una scadenza
-- a mezzanotte non restano invisibili per l'intera sessione. Valore volutamente
-- breve; un progetto lo taratura secondo la propria tolleranza.
k_CACHE_TTL_SECONDS  constant pls_integer := 300;

-- Tipi ------------------------------------------------------------------------
-- Voce di cache: il set di permessi risolto più i marcatori di freschezza (il
-- giorno di caricamento, per il confine di mezzanotte, e l'istante, per il TTL).
type t_cache_entry is record
   ( perms       t_perms
   , loaded_day  date
   , loaded_ts   timestamp
   );

-- Cache per utente. La presenza della chiave marca l'utente come già risolto,
-- anche se il set è vuoto (utente senza permessi o sconosciuto).
type t_cache_type is table of t_cache_entry
    index by adm_users.username%type;

-- Globali ---------------------------------------------------------------------
g_cache  t_cache_type;

-- Moduli privati --------------------------------------------------------------
--------------------------------------------------------------------------------
function resolve_user_id(i_username in varchar2)
    return adm_users.user_id%type
-- user_id dell'utente ATTIVO con quello username, o null se sconosciuto o
-- disattivato (fail-closed: un utente non risolvibile non ha permessi).
is
    l_user_id  adm_users.user_id%type;
begin
    if ( i_username is null )
    then
        return (null);
    end if;

    select u.user_id
      into l_user_id
      from adm_users u
     where u.username = i_username
       and u.is_active = lib_constants.k_YES;

    return (l_user_id);
exception
    when no_data_found
    then
        return (null);
end resolve_user_id;
--------------------------------------------------------------------------------
function load_perms(i_username in varchar2)
    return t_perms
-- Calcola il set di permessi effettivi dell'utente: unione del contributo dai
-- profili (mv_user_effective_perms, già valida oggi) e delle eccezioni nominali
-- valide ora, aggregando i modi in OR (max su 'Y'/'N': 'Y' > 'N'). L'ordine dei
-- campi del select rispecchia t_perm_rec.
is
    l_user_id  adm_users.user_id%type := resolve_user_id(i_username);
    l_perms    t_perms := t_perms();
begin
    if ( l_user_id is null )
    then
        return (l_perms);
    end if;

    select x.functionality_code
         , max(x.mask_code)    as mask_code
         , max(x.module_code)  as module_code
         , max(x.can_read)     as can_read
         , max(x.can_write)    as can_write
         , max(x.can_execute)  as can_execute
      bulk collect into l_perms
      from ( -- Contributo dai profili: già aggregato e valido oggi nella MV.
             select mv.functionality_code
                  , mv.mask_code
                  , mv.module_code
                  , mv.can_read
                  , mv.can_write
                  , mv.can_execute
               from mv_user_effective_perms mv
              where mv.user_id = l_user_id
             union all
             -- Contributo dalle eccezioni nominali, filtrate per validità ora.
             select uf.functionality_code
                  , f.mask_code
                  , m.module_code
                  , uf.can_read
                  , uf.can_write
                  , uf.can_execute
               from adm_user_functionalities uf
               join adm_functionalities f  on f.functionality_code = uf.functionality_code
               join adm_masks m            on m.mask_code = f.mask_code
              where uf.user_id = l_user_id
                and ( uf.valid_from is null or uf.valid_from <= trunc(sysdate) )
                and ( uf.valid_to   is null or uf.valid_to   >= trunc(sysdate) )
           ) x
     group by x.functionality_code;

    return (l_perms);
end load_perms;
--------------------------------------------------------------------------------
function is_fresh(i_entry in t_cache_entry)
    return boolean
-- Vero se la voce di cache è ancora valida: stesso giorno del caricamento (per il
-- confine di mezzanotte delle finestre temporali) ed entro il TTL.
is
begin
    return ( i_entry.loaded_day = trunc(sysdate)
             and systimestamp < i_entry.loaded_ts
                                + numtodsinterval(k_CACHE_TTL_SECONDS, 'SECOND') );
end is_fresh;
--------------------------------------------------------------------------------
function get_perms(i_username in varchar2)
    return t_perms
-- Restituisce il set di permessi dell'utente dalla cache, ricalcolandolo alla
-- prima richiesta o quando la voce non è più fresca.
is
    l_entry  t_cache_entry;
begin
    if ( g_cache.exists(i_username)
         and is_fresh(g_cache(i_username)) )
    then
        return (g_cache(i_username).perms);
    end if;

    l_entry.perms      := load_perms(i_username);
    l_entry.loaded_day := trunc(sysdate);
    l_entry.loaded_ts  := systimestamp;
    g_cache(i_username) := l_entry;

    return (l_entry.perms);
end get_perms;
--------------------------------------------------------------------------------
function mode_granted(i_perm in t_perm_rec, i_mode in varchar2)
    return boolean
-- Vero se il permesso concede il modo richiesto. Un modo non riconosciuto torna
-- false (fail-closed).
is
begin
    case i_mode
        when k_mode_read
        then
            return (i_perm.can_read = lib_constants.k_YES);
        when k_mode_write
        then
            return (i_perm.can_write = lib_constants.k_YES);
        when k_mode_execute
        then
            return (i_perm.can_execute = lib_constants.k_YES);
        else
            return (false);
    end case;
end mode_granted;
--------------------------------------------------------------------------------

-- Moduli pubblici -------------------------------------------------------------
--------------------------------------------------------------------------------
function has_access( i_username           in varchar2
                   , i_functionality_code in varchar2
                   , i_mode               in varchar2
                   )
    return boolean
-- Cerca la funzionalità nel set risolto dell'utente e verifica il modo.
is
    l_perms  t_perms := get_perms(i_username);
begin
    for i in 1 .. l_perms.count
    loop
        if ( l_perms(i).functionality_code = i_functionality_code )
        then
            return (mode_granted(l_perms(i), i_mode));
        end if;
    end loop;

    return (false);
end has_access;
--------------------------------------------------------------------------------
function has_access( i_functionality_code in varchar2
                   , i_mode               in varchar2
                   )
    return boolean
-- Variante sull'utente della sessione corrente.
is
begin
    return ( has_access( i_username           => lib_session.current_actor
                       , i_functionality_code => i_functionality_code
                       , i_mode               => i_mode
                       ) );
end has_access;
--------------------------------------------------------------------------------
procedure assert_access( i_username           in varchar2
                       , i_functionality_code in varchar2
                       , i_mode               in varchar2
                       )
-- Punto di applicazione: solleva il diniego se l'accesso non è concesso.
is
begin
    if ( not has_access( i_username           => i_username
                       , i_functionality_code => i_functionality_code
                       , i_mode               => i_mode
                       ) )
    then
        lib_err.raise_msg( i_message_code => k_msg_access_denied
                         , i_p1           => i_username
                         , i_p2           => i_mode
                         , i_p3           => i_functionality_code
                         , i_error        => lib_err.k_NOT_ALLOWED
                         , i_scope        => k_SCOPE || '.assert_access'
                         );
    end if;
end assert_access;
--------------------------------------------------------------------------------
procedure assert_access( i_functionality_code in varchar2
                       , i_mode               in varchar2
                       )
-- Variante sull'utente della sessione corrente.
is
begin
    assert_access( i_username           => lib_session.current_actor
                 , i_functionality_code => i_functionality_code
                 , i_mode               => i_mode
                 );
end assert_access;
--------------------------------------------------------------------------------
function functionalities_of(i_username in varchar2)
    return t_perms
-- L'intero set di permessi effettivi dell'utente, dalla cache.
is
begin
    return (get_perms(i_username));
end functionalities_of;
--------------------------------------------------------------------------------
function functionalities_of
    return t_perms
-- Variante sull'utente della sessione corrente.
is
begin
    return (get_perms(lib_session.current_actor));
end functionalities_of;
--------------------------------------------------------------------------------
procedure refresh(i_username in varchar2 default null)
-- Invalida un utente (i_username valorizzato) o l'intera cache (null).
is
begin
    if ( i_username is null )
    then
        g_cache.delete;
    elsif ( g_cache.exists(i_username) )
    then
        g_cache.delete(i_username);
    end if;
end refresh;
--------------------------------------------------------------------------------
procedure refresh_mv
-- Refresh completo e atomico della MV. 'C' = complete; atomic_refresh => true
-- (default) esegue delete+insert in transazione, così la MV non è mai vuota o
-- parziale durante il refresh - che, su una tabella di permessi, negherebbe
-- l'accesso a tutti. L'esito del job è comunque tracciato da DBMS_SCHEDULER.
is
begin
    sys.dbms_snapshot.refresh( list          => 'MV_USER_EFFECTIVE_PERMS'
                             , method        => 'C'
                             , atomic_refresh => true
                             );
end refresh_mv;
--------------------------------------------------------------------------------

end lib_authz;
/

show errors package body lib_authz

prompt File: lib_authz.pkb.sql <end>
