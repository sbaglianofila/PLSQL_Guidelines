prompt File: lib_err.pkb.sql <start>
-- =============================================================================
-- File:     lib_err.pkb.sql
-- Oggetto:  lib_err (corpo del package)
-- Schema:   #APP#
-- Scopo:    Il motore degli errori: compone i messaggi a catalogo, logga e
--           segnala. Il template del messaggio è letto da cfg_error_messages
--           (dato), mentre i codici e le eccezioni con nome restano nella
--           specifica (codice). La sostituzione dei segnaposto è fatta in-package
--           (nessuna dipendenza da lib_text) così che le fondamenta restino
--           autoconsistenti.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260705  AA   Creazione
--   20260708  AA   Template letti da cfg_error_messages; segnaposto %1..%10;
--                  correlation_id propagato al log
--   20260708  AA   execution_id (span id) propagato al log
--   20260708  AA   Aggiunta raise_msg (solleva un messaggio di dominio per
--                  message_code sotto il generico BUSINESS_ERROR, o un dedicato)
-- =============================================================================

prompt lib_err: Creating package body

create or replace
package body lib_err
is
-- Costanti --------------------------------------------------------------------
k_SCOPE  constant lib_types.scope_sbt := 'lib_err';

-- Moduli privati --------------------------------------------------------------
--------------------------------------------------------------------------------
function template_of(i_error in pls_integer)
    return varchar2
-- Restituisce il template del messaggio per un codice a catalogo, letto da
-- cfg_error_messages. Un codice sconosciuto degrada a un template generico che
-- riporta comunque il codice numerico, così una riga mancante non blocca mai la
-- segnalazione.
-- i_error : codice a catalogo.
-- return  : template con segnaposto %1..%10.
is
    l_template  cfg_error_messages.message_template%type;
begin
    select cem.message_template
      into l_template
      from cfg_error_messages cem
     where cem.error_code = i_error;

    return (l_template);
exception
    when no_data_found
    then
        return ('Application error ' || to_char(i_error));
end template_of;
--------------------------------------------------------------------------------
function format_message( i_template in varchar2
                       , i_p1       in varchar2
                       , i_p2       in varchar2
                       , i_p3       in varchar2
                       , i_p4       in varchar2
                       , i_p5       in varchar2
                       , i_p6       in varchar2
                       , i_p7       in varchar2
                       , i_p8       in varchar2
                       , i_p9       in varchar2
                       , i_p10      in varchar2
                       )
    return varchar2
-- Sostituisce %1..%10 in un template con i valori forniti. La sostituzione va da
-- %10 verso %1 così che rimpiazzare %1 non rovini mai %10.
-- i_template : template del messaggio.
-- i_p1..10   : valori di sostituzione.
-- return     : il messaggio composto.
is
    l_message  varchar2(4000 char) := i_template;
begin
    l_message := replace(l_message, '%10', i_p10);
    l_message := replace(l_message, '%9',  i_p9);
    l_message := replace(l_message, '%8',  i_p8);
    l_message := replace(l_message, '%7',  i_p7);
    l_message := replace(l_message, '%6',  i_p6);
    l_message := replace(l_message, '%5',  i_p5);
    l_message := replace(l_message, '%4',  i_p4);
    l_message := replace(l_message, '%3',  i_p3);
    l_message := replace(l_message, '%2',  i_p2);
    l_message := replace(l_message, '%1',  i_p1);

    return (l_message);
end format_message;
--------------------------------------------------------------------------------

-- Moduli pubblici -------------------------------------------------------------
--------------------------------------------------------------------------------
function message_of( i_error in pls_integer
                   , i_p1    in varchar2 default null
                   , i_p2    in varchar2 default null
                   , i_p3    in varchar2 default null
                   , i_p4    in varchar2 default null
                   , i_p5    in varchar2 default null
                   , i_p6    in varchar2 default null
                   , i_p7    in varchar2 default null
                   , i_p8    in varchar2 default null
                   , i_p9    in varchar2 default null
                   , i_p10   in varchar2 default null
                   )
    return varchar2
-- Compone il messaggio a catalogo del codice dato senza sollevarlo.
is
    k_TEMPLATE  constant varchar2(4000 char) := template_of(i_error);
begin
    return ( format_message( i_template => k_TEMPLATE
                           , i_p1       => i_p1
                           , i_p2       => i_p2
                           , i_p3       => i_p3
                           , i_p4       => i_p4
                           , i_p5       => i_p5
                           , i_p6       => i_p6
                           , i_p7       => i_p7
                           , i_p8       => i_p8
                           , i_p9       => i_p9
                           , i_p10      => i_p10
                           )
           );
end message_of;
--------------------------------------------------------------------------------
procedure raise( i_error in pls_integer
               , i_p1    in varchar2 default null
               , i_p2    in varchar2 default null
               , i_p3    in varchar2 default null
               , i_p4    in varchar2 default null
               , i_p5    in varchar2 default null
               , i_p6    in varchar2 default null
               , i_p7    in varchar2 default null
               , i_p8    in varchar2 default null
               , i_p9    in varchar2 default null
               , i_p10   in varchar2 default null
               , i_correlation_id in lib_types.correlation_id_sbt default null
               , i_execution_id   in lib_types.execution_id_sbt default null
               , i_scope in lib_types.scope_sbt default null
               )
-- Compone il messaggio, lo segnala con raise_application_error, lo logga con il
-- codice reale e il backtrace, poi lo ripropaga preservando lo stack.
is
    k_MESSAGE  constant varchar2(4000 char) := message_of( i_error => i_error
                                                         , i_p1    => i_p1
                                                         , i_p2    => i_p2
                                                         , i_p3    => i_p3
                                                         , i_p4    => i_p4
                                                         , i_p5    => i_p5
                                                         , i_p6    => i_p6
                                                         , i_p7    => i_p7
                                                         , i_p8    => i_p8
                                                         , i_p9    => i_p9
                                                         , i_p10   => i_p10
                                                         );
begin
    -- Segnala dentro un sotto-blocco così l'errore è loggato con il suo codice
    -- reale e il backtrace, poi ripropagato preservando lo stack.
    raise_application_error(i_error, k_MESSAGE, true);
exception
    when others
    then
        lib_logging.log_error( i_text           => k_MESSAGE
                             , i_correlation_id => i_correlation_id
                             , i_execution_id   => i_execution_id
                             , i_scope          => coalesce(i_scope, k_SCOPE)
                             );
        raise;
end raise;
--------------------------------------------------------------------------------
procedure raise_msg( i_message_code   in varchar2
                   , i_p1             in varchar2 default null
                   , i_p2             in varchar2 default null
                   , i_p3             in varchar2 default null
                   , i_p4             in varchar2 default null
                   , i_p5             in varchar2 default null
                   , i_p6             in varchar2 default null
                   , i_p7             in varchar2 default null
                   , i_p8             in varchar2 default null
                   , i_p9             in varchar2 default null
                   , i_p10            in varchar2 default null
                   , i_error          in pls_integer default k_BUSINESS_ERROR
                   , i_correlation_id in lib_types.correlation_id_sbt default null
                   , i_execution_id   in lib_types.execution_id_sbt default null
                   , i_scope          in lib_types.scope_sbt default null
                   )
-- Compone il messaggio dal catalogo, poi segnala sotto il codice vettore così che
-- l'errore sia loggato con il testo composto prima di essere ripropagato.
-- Composto nel body (non nella dichiarazione) così un errore di catalogo resta
-- dentro l'handler.
is
    l_message  varchar2(4000 char);
begin
    l_message := lib_logging.message_of( i_message_code => i_message_code
                                       , i_p1  => i_p1
                                       , i_p2  => i_p2
                                       , i_p3  => i_p3
                                       , i_p4  => i_p4
                                       , i_p5  => i_p5
                                       , i_p6  => i_p6
                                       , i_p7  => i_p7
                                       , i_p8  => i_p8
                                       , i_p9  => i_p9
                                       , i_p10 => i_p10
                                       );

    raise_application_error(i_error, l_message, true);
exception
    when others
    then
        lib_logging.log_error( i_text           => coalesce(l_message, i_message_code)
                             , i_correlation_id => i_correlation_id
                             , i_execution_id   => i_execution_id
                             , i_scope          => coalesce(i_scope, k_SCOPE)
                             );
        raise;
end raise_msg;
--------------------------------------------------------------------------------
procedure reraise( i_correlation_id in lib_types.correlation_id_sbt default null
                 , i_execution_id   in lib_types.execution_id_sbt default null
                 , i_scope          in lib_types.scope_sbt default null
                 )
-- Ripropaga l'eccezione in gestione dopo averla loggata: gli errori a catalogo
-- verbatim, gli altri avvolti come k_UNEXPECTED mantenendo l'originale sullo stack.
is
    k_CODE  constant pls_integer := sqlcode;
    k_MSG   constant varchar2(4000 char) := sqlerrm;
begin
    lib_logging.log_error( i_text           => k_MSG
                         , i_correlation_id => i_correlation_id
                         , i_execution_id   => i_execution_id
                         , i_scope          => coalesce(i_scope, k_SCOPE)
                         );

    if ( k_CODE between -20999 and -20000 )
    then
        -- Preserva i nostri errori applicativi verbatim (togliendo il prefisso
        -- ORA- che sqlerrm aggiunge, perché raise_application_error lo riaggiunge).
        raise_application_error(k_CODE, regexp_replace(k_MSG, '^ORA-[0-9]{5}: ', ''), true);
    else
        -- Avvolge un errore Oracle inatteso, mantenendo l'originale sullo stack.
        raise_application_error(k_UNEXPECTED, k_MSG, true);
    end if;
end reraise;
--------------------------------------------------------------------------------

end lib_err;
/

show errors package body lib_err

prompt File: lib_err.pkb.sql <end>
