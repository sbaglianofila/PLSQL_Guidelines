prompt File: lib_session.pkb.sql <start>
-- =============================================================================
-- File:     lib_session.pkb.sql
-- Oggetto:  lib_session (corpo del package)
-- Schema:   #APP#
-- Scopo:    Risolve l'identità effettiva e strumenta la sessione appoggiandosi a
--           sys_context, dbms_session e dbms_application_info. L'utente
--           applicativo vive nel contesto APP_CTX (specchiato in CLIENT_INFO); il
--           correlation id della chiamata vive in CLIENT_IDENTIFIER.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260705  AA   Creazione
--   20260708  AA   Attore dal contesto APP_CTX; CLIENT_IDENTIFIER porta il
--                  correlation id; set_actor / set_correlation / clear_session
--   20260708  AA   Aggiunte set_action e push_step/pop_step; clear_session azzera
--                  anche module/action
--   20260708  AA   push_step/pop_step sostituiti dallo stack interno bilanciato
--                  (open_step/close_step); clear_session lo svuota
--   20260708  AA   Aggiunta session_info (snapshot di sessione; NLS letti da USERENV)
-- =============================================================================

prompt lib_session: Creating package body

create or replace
package body lib_session
is
-- Costanti --------------------------------------------------------------------
k_USERENV       constant varchar2(7 char)   := 'USERENV';
k_CTX_NAMESPACE constant varchar2(30 char)  := 'APP_CTX';    -- namespace del contesto applicativo
k_CTX_APP_USER  constant varchar2(30 char)  := 'APP_USER';   -- attributo che contiene l'utente applicativo
k_MODULE_LIMIT  constant pls_integer        := 48;   -- max module dbms_application_info
k_ACTION_LIMIT  constant pls_integer        := 32;   -- max action dbms_application_info
k_ACTOR_LIMIT   constant pls_integer        := 64;   -- larghezza delle colonne di audit created_by/modified_by e di log_events.actor

-- Tipi ------------------------------------------------------------------------
-- Stack interno dei passi: una voce (module + action) salvata per ogni open_step,
-- ripristinata da close_step. Stato a livello di sessione; tenuto bilanciato
-- dall'handler d'errore obbligatorio e, come rete di sicurezza, svuotato da
-- clear_session al confine della richiesta.
type t_step is record
    ( module  varchar2(48 char)
    , action  varchar2(32 char)
    );
type t_step_stack is table of t_step index by pls_integer;

-- Globali ---------------------------------------------------------------------
g_steps  t_step_stack;

-- Moduli pubblici -------------------------------------------------------------
--------------------------------------------------------------------------------
function current_actor
    return varchar2
-- Vince l'identità più specifica: utente applicativo, poi account proxy, poi
-- schema. CLIENT_IDENTIFIER non è consultato di proposito (ora porta il
-- correlation id della chiamata, non l'utente). Il risultato è troncato a
-- k_ACTOR_LIMIT (64) caratteri, la larghezza delle colonne di audit created_by/
-- modified_by e di log_events.actor: così il cap vive qui, in un unico punto, e
-- i trigger che chiamano questa funzione non devono ripeterlo. APP_CTX.APP_USER
-- è impostato da set_actor senza limite, quindi il cap qui è una rete reale
-- contro un ORA-12899 al momento della scrittura dell'audit.
is
begin
    return ( substr( coalesce( sys_context(k_CTX_NAMESPACE, k_CTX_APP_USER)
                             , sys_context(k_USERENV, 'PROXY_USER')
                             , sys_context(k_USERENV, 'SESSION_USER')
                             )
                   , 1, k_ACTOR_LIMIT )
           );
end current_actor;
--------------------------------------------------------------------------------
function current_correlation
    return varchar2
-- Legge il correlation id della chiamata da CLIENT_IDENTIFIER.
is
begin
    return (sys_context(k_USERENV, 'CLIENT_IDENTIFIER'));
end current_correlation;
--------------------------------------------------------------------------------
function current_module
    return varchar2
-- Legge il module corrente della sessione.
is
begin
    return (sys_context(k_USERENV, 'MODULE'));
end current_module;
--------------------------------------------------------------------------------
function current_action
    return varchar2
-- Legge l'action corrente della sessione.
is
begin
    return (sys_context(k_USERENV, 'ACTION'));
end current_action;
--------------------------------------------------------------------------------
function session_info
    return varchar2
-- Tutte le letture sono sys_context, che non solleva mai; gli attributi
-- sconosciuti/non impostati tornano null. Gli attributi NLS vivono in USERENV
-- (non in APP_CTX).
is
begin
    return (
          'session_user='   || sys_context(k_USERENV, 'SESSION_USER')
       || '; proxy_user='   || sys_context(k_USERENV, 'PROXY_USER')
       || '; os_user='      || sys_context(k_USERENV, 'OS_USER')
       || '; host='         || sys_context(k_USERENV, 'HOST')
       || '; ip_address='   || sys_context(k_USERENV, 'IP_ADDRESS')
       || '; sid='          || sys_context(k_USERENV, 'SID')
       || '; instance='     || sys_context(k_USERENV, 'INSTANCE')
       || '; service='      || sys_context(k_USERENV, 'SERVICE_NAME')
       || '; action='       || sys_context(k_USERENV, 'ACTION')
       || '; app_user='     || sys_context(k_CTX_NAMESPACE, k_CTX_APP_USER)
       || '; nls_date_fmt=' || sys_context(k_USERENV, 'NLS_DATE_FORMAT')
       || '; nls_date_lang='|| sys_context(k_USERENV, 'NLS_DATE_LANGUAGE')
       || '; nls_calendar=' || sys_context(k_USERENV, 'NLS_CALENDAR')
       || '; nls_territory='|| sys_context(k_USERENV, 'NLS_TERRITORY')
    );
end session_info;
--------------------------------------------------------------------------------
procedure set_actor(i_user in varchar2)
-- Imposta APP_CTX (fonte autorevole di current_actor) e specchia l'utente in
-- CLIENT_INFO così da renderlo visibile in v$session.
is
begin
    sys.dbms_session.set_context( namespace => k_CTX_NAMESPACE
                                , attribute => k_CTX_APP_USER
                                , value     => i_user
                                );
    sys.dbms_application_info.set_client_info(client_info => i_user);
end set_actor;
--------------------------------------------------------------------------------
procedure set_correlation(i_correlation_id in varchar2)
-- Pubblica il correlation id della chiamata in CLIENT_IDENTIFIER.
is
begin
    sys.dbms_session.set_identifier(i_correlation_id);
end set_correlation;
--------------------------------------------------------------------------------
procedure set_step(i_module in varchar2, i_action in varchar2 default null)
-- Sovrascrive module e action con troncamento sicuro ai limiti Oracle.
is
begin
    sys.dbms_application_info.set_module( module_name => substrb(i_module, 1, k_MODULE_LIMIT)
                                        , action_name => substrb(i_action, 1, k_ACTION_LIMIT)
                                        );
end set_step;
--------------------------------------------------------------------------------
procedure set_action(i_action in varchar2)
-- Aggiorna solo l'action, con troncamento sicuro al limite Oracle.
is
begin
    sys.dbms_application_info.set_action(action_name => substrb(i_action, 1, k_ACTION_LIMIT));
end set_action;
--------------------------------------------------------------------------------
procedure open_step(i_action in varchar2)
-- Salva module/action correnti sullo stack interno e sposta l'action a questo
-- frame.
is
    l_top  t_step;
begin
    sys.dbms_application_info.read_module( module_name => l_top.module
                                         , action_name => l_top.action
                                         );
    g_steps(g_steps.count + 1) := l_top;

    set_action(i_action => i_action);
end open_step;
--------------------------------------------------------------------------------
procedure close_step
-- Estrae la cima dello stack e ripristina quel module/action.
is
    l_top  t_step;
begin
    if ( g_steps.count = 0 )
    then
        return;   -- close spaiata: niente da ripristinare
    end if;

    l_top := g_steps(g_steps.count);
    g_steps.delete(g_steps.count);

    -- i valori erano entro i limiti Oracle alla lettura; ripristino verbatim.
    sys.dbms_application_info.set_module( module_name => l_top.module
                                        , action_name => l_top.action
                                        );
end close_step;
--------------------------------------------------------------------------------
procedure clear_session
-- Azzera lo stato di sessione per-richiesta: utente APP_CTX, correlation id,
-- CLIENT_INFO, module/action e stack dei passi.
is
begin
    sys.dbms_session.clear_context(namespace => k_CTX_NAMESPACE, attribute => k_CTX_APP_USER);
    sys.dbms_session.clear_identifier;
    sys.dbms_application_info.set_client_info(client_info => null);
    sys.dbms_application_info.set_module(module_name => null, action_name => null);
    g_steps.delete;
end clear_session;
--------------------------------------------------------------------------------

end lib_session;
/

show errors package body lib_session

prompt File: lib_session.pkb.sql <end>
