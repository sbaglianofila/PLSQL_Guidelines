prompt File: lib_types.pks.sql <start>
-- =============================================================================
-- File:     lib_types.pks.sql
-- Oggetto:  lib_types (specifica del package)
-- Schema:   #APP#
-- Scopo:    Sottotipi PL/SQL condivisi, allineati ai domini in Catalogo/domini.md.
--           Solo specifica, nessun body. Volutamente piccolo: un sottotipo sta
--           qui solo se rappresenta un concetto ricorrente, mai "per completezza".
--           È il package base più citato.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260705  AA   Creazione
--   20260708  AA   Aggiunti correlation_id_sbt (correlation id del flusso di
--                  esecuzione) e object_name_sbt (identificatore Oracle)
--   20260708  AA   Aggiunto execution_id_sbt (span id per singola invocazione)
-- =============================================================================

prompt lib_types: Creating package specification

create or replace
package lib_types
is
-- Sottotipi testuali per dimensione, allineati ai domini di testo (code, name,
-- description, note). big_string_sbt è il buffer grande solo-PL/SQL.
subtype code_sbt                is varchar2(32 char);       -- dominio: code
subtype name_sbt                is varchar2(128 char);      -- dominio: name
subtype short_text_sbt          is varchar2(512 char);      -- dominio: description
subtype text_sbt                is varchar2(4000 char);     -- dominio: note
subtype big_string_sbt          is varchar2(32767 char);    -- buffer grande PL/SQL

-- Sottotipi tecnici usati dai package base.
subtype flag_sbt                is varchar2(1 char);        -- dominio: flag ('Y'/'N')
subtype scope_sbt               is varchar2(128 char);      -- scope di logging (package.subprogram)
subtype correlation_id_sbt      is varchar2(64 char);       -- correlation id del flusso (pool-safe)
subtype execution_id_sbt        is varchar2(64 char);       -- span id per invocazione (appaiamento start/end)
subtype object_name_sbt         is varchar2(128 char);      -- nome di oggetto/identificatore Oracle (12.2+)
subtype lock_name_sbt           is varchar2(128 char);      -- nome del lock sys.dbms_lock
subtype lock_handle_sbt         is varchar2(128 char);      -- handle del lock sys.dbms_lock

-- Sottotipo di dominio numerico.
subtype percentage_sbt          is number(5,2);             -- dominio: percentage (0..100)

-- Nota: i sottotipi di dominio numerico come amount_sbt / quantity_sbt si
-- aggiungono qui solo quando un progetto li adotta davvero, non a priori.

end lib_types;
/

show errors package lib_types

prompt File: lib_types.pks.sql <end>
