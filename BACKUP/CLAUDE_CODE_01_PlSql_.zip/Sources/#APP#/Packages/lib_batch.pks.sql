prompt File: lib_batch.pks.sql <start>
-- =============================================================================
-- File:     lib_batch.pks.sql
-- Oggetto:  lib_batch (specifica del package)
-- Schema:   #APP#
-- Scopo:    Ciclo di vita dei processi batch. Dà a ogni run un'identità tracciata
--           su log_process_runs (inizio, fine, esito, contatori), così l'AM può
--           rispondere a "com'è andato il batch di stanotte?" con una query.
--           Imposta il module/action di sessione via lib_session, può tenere un
--           lock di istanza singola via lib_lock, e applica il verdetto delle
--           precondizioni di lib_gate.
--
--           SEQUENZA CANONICA DI UN MAIN PROCESS. L'ordine non è indifferente e va
--           rispettato (il template template_main_process.prc.sql lo materializza):
--
--             1. start_run       apre il run - e prende il lock, se richiesto
--             2. lib_authz       CHI sta lanciando, se c'è un chiamante da verificare
--             3. check_gate      SE HA SENSO partire adesso, qui, in questo stato
--             4. corpo del processo, con checkpoint per l'avanzamento
--             5. end_run sul successo, fail_run nell'handler
--
--           Il gate si valuta DENTRO il run e non prima, così anche un processo che
--           decide di non partire lascia la sua riga: "ha deciso di non partire" e
--           "non è mai stato lanciato" devono restare distinguibili, ed è
--           esattamente l'indagine che questo package esiste per evitare.
--
-- Nota:     CONTRATTO TRANSAZIONALE. Tutte le scritture su log_process_runs
--           avvengono in TRANSAZIONE AUTONOMA e sono quindi già committate al
--           ritorno. È una deroga dichiarata e circoscritta alla regola "commit al
--           chiamante", imposta dalla natura di ciò che si scrive: un registro di
--           esecuzioni che il rollback dell'elaborazione può cancellare non è un
--           registro. Senza questa scelta, un processo che esplode e viene
--           annullato dal chiamante sparirebbe anche dal tracciamento - proprio il
--           caso in cui serve di più. Stessa disciplina di lib_logging.
--           La conseguenza pratica: le righe di run non si ripuliscono con un
--           rollback, quindi un test che ne crea deve cancellarle da sé.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260705  AA   Creazione
--   20260729  AA   Scritture su log_process_runs in transazione autonoma; aggiunte
--                  skip_run e check_gate (applicazione del verdetto di lib_gate)
-- =============================================================================

prompt lib_batch: Creating package specification

create or replace
package lib_batch
is
--------------------------------------------------------------------------------
-- Apre un run su log_process_runs e ne restituisce l'id. Strumenta la sessione
-- (module = nome del processo) e, quando i_single_instance è true, acquisisce un
-- lock non bloccante sul nome del processo, sollevando lib_err.e_already_running
-- se un altro run lo detiene.
-- Il lock è preso PRIMA di creare il run, così un avvio bloccato non lascia una
-- riga spuria: un'istanza che non parte perché ce n'è già una in corso non è un
-- run, è un non-evento.
-- i_process_name    : nome logico del processo.
-- i_single_instance : true per vietare run concorrenti dello stesso processo.
-- return            : il nuovo id del run.
function start_run( i_process_name    in varchar2
                  , i_single_instance in boolean default false
                  )
    return number;
--------------------------------------------------------------------------------
-- Valuta le precondizioni del processo con lib_gate e ne APPLICA il verdetto,
-- riducendolo a "vai avanti oppure no". È lo zucchero per il caso normale: il
-- gate resta pura valutazione, la decisione e l'azione stanno qui, dove c'è il run
-- su cui agire.
--   RUN   -> ritorna true, il chiamante prosegue;
--   SKIP  -> chiude il run come SKIPPED con il motivo, logga e ritorna false;
--   ABORT -> solleva lib_err.e_precondition_failed (il run lo chiuderà fail_run
--            dall'handler del chiamante, come per qualunque altro errore).
-- Chi deve trattare SKIP e ABORT in modo diverso da così chiami lib_gate.evaluate
-- direttamente e decida da sé.
-- i_run_id       : run aperto da start_run, quello che verrà chiuso su SKIP.
-- i_process_name : nome logico del processo, la chiave delle regole in cfg_gate_rules.
-- i_ref_date     : istante di riferimento per le regole temporali; default sysdate.
--                  Da valorizzare quando il processo lavora su una data di business
--                  diversa da oggi.
-- return         : true se il processo deve proseguire, false se è stato saltato.
function check_gate( i_run_id       in number
                   , i_process_name in varchar2
                   , i_ref_date     in date default sysdate
                   )
    return boolean;
--------------------------------------------------------------------------------
-- Chiude un run con un esito e delle statistiche, rilasciando il lock di istanza
-- singola se detenuto.
-- i_run_id         : run da chiudere.
-- i_status         : stato finale (SUCCESS di default).
-- i_rows_processed : righe elaborate con successo.
-- i_rows_rejected  : righe scartate.
procedure end_run( i_run_id         in number
                 , i_status         in varchar2 default 'SUCCESS'
                 , i_rows_processed in number default null
                 , i_rows_rejected  in number default null
                 );
--------------------------------------------------------------------------------
-- Chiude un run come SKIPPED registrando il motivo, e rilascia il lock di istanza
-- singola se detenuto. Lo SKIP non è un fallimento: è un processo che ha
-- funzionato correttamente e ha concluso che non c'era da fare nulla. Merita una
-- riga - senza, l'assenza di run sarebbe indistinguibile da un lancio mancato - ma
-- non un allarme.
-- i_run_id : run da chiudere.
-- i_reason : perché il processo non ha lavorato; finisce in error_message.
procedure skip_run(i_run_id in number, i_reason in varchar2 default null);
--------------------------------------------------------------------------------
-- Chiude un run come FAILED, registrando l'errore corrente, e rilascia il lock di
-- istanza singola se detenuto. Pensata per essere chiamata da un exception
-- handler.
-- i_run_id        : run da chiudere.
-- i_error_message : testo dell'errore; default sqlerrm.
procedure fail_run(i_run_id in number, i_error_message in varchar2 default null);
--------------------------------------------------------------------------------
-- Registra l'avanzamento intermedio di un processo lungo: aggiorna l'action di
-- sessione e, quando fornito, il contatore delle righe elaborate.
-- i_run_id  : run in avanzamento.
-- i_step    : etichetta del passo corrente (pubblicata come action di sessione).
-- i_counter : conteggio progressivo delle righe elaborate, se tracciato.
procedure checkpoint(i_run_id in number, i_step in varchar2, i_counter in number default null);
--------------------------------------------------------------------------------

end lib_batch;
/

show errors package lib_batch

prompt File: lib_batch.pks.sql <end>
