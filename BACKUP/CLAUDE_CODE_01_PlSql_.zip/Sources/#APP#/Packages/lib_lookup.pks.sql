prompt File: lib_lookup.pks.sql <start>
-- =============================================================================
-- File:     lib_lookup.pks.sql
-- Oggetto:  lib_lookup (specifica del package)
-- Schema:   #APP#
-- Scopo:    Accesso disciplinato alle lookup generiche ref_lookups /
--           ref_lookup_values: elenco ordinato dei valori validi di un set,
--           etichetta di un codice, verifica di validità, valore predefinito.
--           Gemello di lib_config sul versante dei dati di riferimento: come lui
--           tiene in cache i set letti, dato che le lookup cambiano di rado ed è
--           uno spreco rileggerle a ogni chiamata (vedi Architettura_DB/lookups.md).
--           Convenzione lasca (dati di riferimento, non configurazione critica):
--           un set o un codice assente non solleva - values_of torna vuoto,
--           label_of e default_of tornano null, is_valid torna false - così le
--           tendine e i decode restano robusti anche di fronte a un dato mancante.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260719  AA   Creazione
-- =============================================================================

prompt lib_lookup: Creating package specification

create or replace
package lib_lookup
is
-- Un valore di lookup con la sua anagrafica e i tre slot tipizzati. Rispecchia
-- una riga di ref_lookup_values, senza le colonne tecniche/amministrative.
type t_value_rec is record
   ( value_code   ref_lookup_values.value_code%type
   , label        ref_lookup_values.label%type
   , description  ref_lookup_values.description%type
   , sort_order   ref_lookup_values.sort_order%type
   , is_valid     ref_lookup_values.is_valid%type
   , is_default   ref_lookup_values.is_default%type
   , num_value    ref_lookup_values.num_value%type
   , char_value   ref_lookup_values.char_value%type
   , date_value   ref_lookup_values.date_value%type
   );

-- Elenco di valori, nell'ordine di sort_order. Collezione PL/SQL (non SQL): per
-- l'accesso da SQL si interroga direttamente ref_lookup_values.
type t_values is table of t_value_rec;

--------------------------------------------------------------------------------
-- Elenco ordinato dei soli valori VALIDI di un set (is_valid = 'Y'), da usare
-- per popolare una tendina. Un set inesistente o senza valori validi torna una
-- collezione vuota.
-- i_lookup_code : mnemonico del set (es. 'CONTACT_TYPE').
-- return        : i valori validi ordinati per sort_order, poi value_code.
function values_of(i_lookup_code in varchar2)
    return t_values;
--------------------------------------------------------------------------------
-- Etichetta di un valore dato il suo codice. Restituisce l'etichetta anche di un
-- valore ritirato (is_valid = 'N'), così i dati storici restano leggibili a
-- video; null se il set o il codice non esistono.
-- i_lookup_code : mnemonico del set.
-- i_value_code  : codice del valore (es. 'MOBILE').
function label_of(i_lookup_code in varchar2, i_value_code in varchar2)
    return varchar2;
--------------------------------------------------------------------------------
-- Vero se il codice appartiene al set ed è attualmente valido (is_valid = 'Y').
-- Da usare per validare un valore in scrittura quando non c'è la foreign key
-- composita. Falso se il set o il codice non esistono, o se il valore è ritirato.
-- i_lookup_code : mnemonico del set.
-- i_value_code  : codice del valore.
function is_valid(i_lookup_code in varchar2, i_value_code in varchar2)
    return boolean;
--------------------------------------------------------------------------------
-- Codice del valore predefinito del set (is_default = 'Y'), o null se il set non
-- ne ha uno. Evita di cablare la scelta del preselezionato nell'applicazione.
-- i_lookup_code : mnemonico del set.
function default_of(i_lookup_code in varchar2)
    return varchar2;
--------------------------------------------------------------------------------
-- Svuota la cache così che la lettura successiva ricarichi da database. Con
-- i_lookup_code valorizzato invalida il solo set indicato; con null (default)
-- invalida tutti i set. Da chiamare dopo aver modificato le lookup.
-- i_lookup_code : set da invalidare, oppure null per tutti.
procedure refresh(i_lookup_code in varchar2 default null);
--------------------------------------------------------------------------------

end lib_lookup;
/

show errors package lib_lookup

prompt File: lib_lookup.pks.sql <end>
