prompt File: install.ins.sql <start>
-- =============================================================================
-- File:     install.ins.sql
-- Object:   Install orchestrator for schema #APP# (base packages)
-- Schema:   #APP#
-- Purpose:  Runs the base-package object scripts in dependency order. Execute
--           while connected as the target schema (directly or through the
--           proxy). The order of the sections below is the canonical install
--           order. Test suites are installed separately by install_tests.ins.sql
--           in dev/test environments only.
-- -----------------------------------------------------------------------------
-- Changelog (authoritative history: version control)
--   Date      Aut  Change
--   20260705  AA   Creation
-- =============================================================================

whenever sqlerror exit failure rollback
whenever oserror  exit failure
set echo        off
set feedback     on
set define       off
set serveroutput on size unlimited

prompt ============================================================
prompt Install #APP# base packages: start
prompt ============================================================

prompt #APP#: Tables
@@../Tables/log_events.tab.sql
@@../Tables/log_error_details.tab.sql
@@../Tables/cfg_parameter_groups.tab.sql
@@../Tables/cfg_parameters.tab.sql
@@../Tables/cfg_error_messages.tab.sql
@@../Tables/cfg_messages.tab.sql
@@../Tables/log_process_runs.tab.sql
-- Precondizioni di esecuzione: il dominio dei tipi prima delle regole che lo
-- referenziano (vedi Pacchetti_Base/precondizioni_esecuzione.md).
@@../Tables/cfg_gate_rule_types.tab.sql
@@../Tables/cfg_gate_rules.tab.sql
@@../Tables/cfg_gate_objects.tab.sql
@@../Tables/ref_lookups.tab.sql
@@../Tables/ref_lookup_values.tab.sql
@@../Tables/ref_holidays.tab.sql
@@../Tables/cfg_email_templates.tab.sql
@@../Tables/wrk_mail_queue.tab.sql
@@../Tables/cfg_reports.tab.sql
@@../Tables/wfl_workflows.tab.sql
@@../Tables/wfl_statuses.tab.sql
@@../Tables/wfl_transitions.tab.sql
@@../Tables/wfl_transition_roles.tab.sql
@@../Tables/wfl_transition_guards.tab.sql
-- RBAC applicativo: entità prima, poi le tabelle di associazione.
@@../Tables/adm_users.tab.sql
@@../Tables/adm_roles.tab.sql
@@../Tables/adm_profiles.tab.sql
@@../Tables/adm_modules.tab.sql
@@../Tables/adm_masks.tab.sql
@@../Tables/adm_functionalities.tab.sql
@@../Tables/adm_profile_roles.tab.sql
@@../Tables/adm_user_profiles.tab.sql
@@../Tables/adm_profile_functionalities.tab.sql
@@../Tables/adm_user_functionalities.tab.sql

prompt #APP#: Materialized views
-- Dipende solo dalle tabelle adm_* (create sopra), non da FK/trigger. Creata qui,
-- prima dei package, così il body di lib_authz compila contro una MV esistente.
-- build immediate su tabelle vuote dà una MV vuota, che il primo refresh (evento
-- o schedulato) popolerà. Vedi header del file e utenti_profili.md.
@@../MaterializedViews/mv_user_effective_perms.mvw.sql

prompt #APP#: Application context (requires CREATE ANY CONTEXT on the owner)
@@../Contexts/app_ctx.ctx.sql

prompt #APP#: Package specifications (foundations first)
@@../Packages/lib_types.pks.sql
@@../Packages/lib_constants.pks.sql
@@../Packages/lib_session.pks.sql
@@../Packages/lib_err.pks.sql
@@../Packages/lib_config.pks.sql
@@../Packages/lib_lookup.pks.sql
@@../Packages/lib_logging.pks.sql
@@../Packages/lib_lock.pks.sql
-- lib_gate prima di lib_batch: il body di lib_batch (check_gate) usa il tipo
-- t_verdict_rec e le costanti della sua specifica.
@@../Packages/lib_gate.pks.sql
@@../Packages/lib_batch.pks.sql
@@../Packages/lib_assert.pks.sql
@@../Packages/lib_text.pks.sql
@@../Packages/lib_calendar.pks.sql
@@../Packages/lib_mail_engine.pks.sql
@@../Packages/lib_mail.pks.sql
@@../Packages/lib_file.pks.sql
@@../Packages/lib_report.pks.sql
@@../Packages/lib_workflow.pks.sql
@@../Packages/lib_authz.pks.sql
@@../Packages/lib_authz_admin.pks.sql

prompt #APP#: Package bodies
@@../Packages/lib_constants.pkb.sql
@@../Packages/lib_session.pkb.sql
@@../Packages/lib_logging.pkb.sql
@@../Packages/lib_err.pkb.sql
@@../Packages/lib_config.pkb.sql
@@../Packages/lib_lookup.pkb.sql
@@../Packages/lib_lock.pkb.sql
-- Il body di lib_gate compila contro le specifiche di lib_config e lib_calendar,
-- entrambe già installate nella sezione precedente.
@@../Packages/lib_gate.pkb.sql
@@../Packages/lib_batch.pkb.sql
@@../Packages/lib_assert.pkb.sql
@@../Packages/lib_text.pkb.sql
@@../Packages/lib_calendar.pkb.sql
-- Mail engine: install EXACTLY ONE backend body (comment/uncomment to switch).
@@../Packages/lib_mail_engine.utl_smtp.pkb.sql
-- @@../Packages/lib_mail_engine.apex.pkb.sql
@@../Packages/lib_mail.pkb.sql
@@../Packages/lib_file.pkb.sql
@@../Packages/lib_report.pkb.sql
@@../Packages/lib_workflow.pkb.sql
@@../Packages/lib_authz.pkb.sql
@@../Packages/lib_authz_admin.pkb.sql

-- Triggers come AFTER the packages: they resolve the actor and program through
-- lib_session (current_actor / current_module), so they must compile against its
-- spec. The bodies are already in place above, before the seed DML fires them.
prompt #APP#: Triggers (audit of administrative columns)
@@../Triggers/cfg_parameter_groups_audit_trg.trg.sql
@@../Triggers/cfg_parameters_audit_trg.trg.sql
@@../Triggers/cfg_error_messages_audit_trg.trg.sql
@@../Triggers/cfg_messages_audit_trg.trg.sql
@@../Triggers/cfg_gate_rule_types_audit_trg.trg.sql
@@../Triggers/cfg_gate_rules_audit_trg.trg.sql
@@../Triggers/cfg_gate_objects_audit_trg.trg.sql
@@../Triggers/ref_lookups_audit_trg.trg.sql
@@../Triggers/ref_lookup_values_audit_trg.trg.sql
@@../Triggers/wfl_workflows_audit_trg.trg.sql
@@../Triggers/wfl_statuses_audit_trg.trg.sql
@@../Triggers/wfl_transitions_audit_trg.trg.sql
@@../Triggers/wfl_transition_roles_audit_trg.trg.sql
@@../Triggers/wfl_transition_guards_audit_trg.trg.sql
@@../Triggers/adm_users_audit_trg.trg.sql
@@../Triggers/adm_roles_audit_trg.trg.sql
@@../Triggers/adm_profiles_audit_trg.trg.sql
@@../Triggers/adm_modules_audit_trg.trg.sql
@@../Triggers/adm_masks_audit_trg.trg.sql
@@../Triggers/adm_functionalities_audit_trg.trg.sql
@@../Triggers/adm_profile_roles_audit_trg.trg.sql
@@../Triggers/adm_user_profiles_audit_trg.trg.sql
@@../Triggers/adm_profile_functionalities_audit_trg.trg.sql
@@../Triggers/adm_user_functionalities_audit_trg.trg.sql

prompt #APP#: Foreign Keys
@@../FKs/log_error_details.fky.sql
@@../FKs/cfg_parameters.fky.sql
@@../FKs/cfg_gate_rules.fky.sql
@@../FKs/ref_lookup_values.fky.sql
-- Workflow: la testata prima degli stati, gli stati prima delle transizioni.
@@../FKs/wfl_statuses.fky.sql
@@../FKs/wfl_transitions.fky.sql
@@../FKs/wfl_transition_roles.fky.sql
@@../FKs/wfl_transition_guards.fky.sql
-- RBAC applicativo: le tabelle referenziate sono tutte create sopra.
@@../FKs/adm_masks.fky.sql
@@../FKs/adm_functionalities.fky.sql
@@../FKs/adm_profile_roles.fky.sql
@@../FKs/adm_user_profiles.fky.sql
@@../FKs/adm_profile_functionalities.fky.sql
@@../FKs/adm_user_functionalities.fky.sql

prompt #APP#: Seed and configuration data
-- The groups must be seeded before the parameters: cfg_parameters_fk_group is
-- already in place at this point and rejects a parameter whose group is unknown.
@@../Data/cfg_parameter_groups.dat.sql
@@../Data/cfg_parameters.dat.sql
@@../Data/cfg_error_messages.dat.sql
@@../Data/wfl_messages.dat.sql
@@../Data/authz_messages.dat.sql
-- Gate rule types are framework code expressed as data: they must match the case
-- statement in lib_gate.evaluate one to one. A project seeds cfg_gate_rules (its
-- own processes) and cfg_gate_objects (its own DATA_READY sources) separately.
@@../Data/cfg_gate_rule_types.dat.sql
@@../Data/gate_messages.dat.sql

prompt #APP#: Scheduler jobs
-- Dopo i package (il job_action invoca lib_authz.refresh_mv, già compilato).
-- Richiede il privilegio CREATE JOB sull'owner (Sources/SYS/Grants).
@@../Jobs/authz_refresh_mv.job.sql

prompt ============================================================
prompt Install #APP# base packages: completed
prompt ============================================================
prompt File: install.ins.sql <end>
