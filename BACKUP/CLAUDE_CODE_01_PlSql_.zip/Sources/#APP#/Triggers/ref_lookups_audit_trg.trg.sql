prompt File: ref_lookups_audit_trg.trg.sql <start>
-- =============================================================================
-- File:     ref_lookups_audit_trg.trg.sql
-- Oggetto:  ref_lookups_audit_trg (trigger)
-- Schema:   #APP#
-- Scopo:    Mantiene le colonne amministrative standard di ref_lookups: audit di
--           creazione (insert), audit di modifica (update) e la versione di riga
--           per il locking ottimistico. Vedi colonne_amministrative.md.
-- Nota:     Le colonne di creazione sono immutabili negli update; row_version è
--           autorità del server e ignora qualsiasi valore fornito dal client.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260719  AA   Creazione
-- =============================================================================

prompt ref_lookups_audit_trg: Creating trigger

create or replace trigger ref_lookups_audit_trg
   before insert or update on ref_lookups
   for each row
begin

    -- Attore e programma sono risolti da lib_session (current_actor /
    -- current_module): fallback e cap di lunghezza vivono lì, in un unico punto,
    -- così i trigger non li duplicano. CLIENT_IDENTIFIER non è l'attore (porta il
    -- correlation id). Il trigger dipende quindi da lib_session, installato dopo
    -- i package base.
    if (inserting)
    then

        :new.created_by   := lib_session.current_actor;
        :new.created_at   := systimestamp;
        :new.created_app  := lib_session.current_module;
        -- le colonne di aggiornamento sono forzate a NULL
        :new.modified_by  := null;
        :new.modified_at  := null;
        :new.modified_app := null;

        :new.row_version  := 1;

    elsif (updating)
    then
        -- le colonne di creazione sono immutabili: si riportano intatte da :old
        :new.created_by   := :old.created_by;
        :new.created_at   := :old.created_at;
        :new.created_app  := :old.created_app;
        --
        :new.modified_by  := lib_session.current_actor;
        :new.modified_at  := systimestamp;
        :new.modified_app := lib_session.current_module;

        :new.row_version  := nvl(:old.row_version, 0) + 1;

    end if;

end ref_lookups_audit_trg;
/
show errors trigger ref_lookups_audit_trg

prompt File: ref_lookups_audit_trg.trg.sql <end>
