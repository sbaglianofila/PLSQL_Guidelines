prompt File: cfg_gate_rules_audit_trg.trg.sql <start>
-- =============================================================================
-- File:     cfg_gate_rules_audit_trg.trg.sql
-- Oggetto:  cfg_gate_rules_audit_trg (trigger)
-- Schema:   #APP#
-- Scopo:    Mantiene le colonne amministrative standard di cfg_gate_rules: audit
--           di creazione (insert), audit di modifica (update) e la versione di
--           riga per il locking ottimistico. Vedi colonne_amministrative.md.
--           Qui l'audit conta più che altrove: cambiare la severity di una regola
--           o disattivarla cambia il comportamento di un processo in produzione,
--           e queste colonne sono l'unica traccia di chi l'ha fatto e quando.
-- Nota:     Le colonne di creazione sono immutabili negli update; row_version è
--           autorità del server e ignora qualsiasi valore fornito dal client.
--           Attore e programma sono risolti da lib_session (current_actor /
--           current_module), unico punto per fallback e cap: il trigger dipende
--           quindi da lib_session, installato dopo i package base.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260729  AA   Creazione
-- =============================================================================

prompt cfg_gate_rules_audit_trg: Creating trigger

create or replace trigger cfg_gate_rules_audit_trg
   before insert or update on cfg_gate_rules
   for each row
begin

    if (inserting)
    then

        :new.created_by   := lib_session.current_actor;
        :new.created_at   := systimestamp;
        :new.created_app  := lib_session.current_module;
        :new.modified_by  := null;
        :new.modified_at  := null;
        :new.modified_app := null;

        :new.row_version  := 1;

    elsif (updating)
    then

        :new.created_by   := :old.created_by;
        :new.created_at   := :old.created_at;
        :new.created_app  := :old.created_app;
        --
        :new.modified_by  := lib_session.current_actor;
        :new.modified_at  := systimestamp;
        :new.modified_app := lib_session.current_module;

        :new.row_version  := nvl(:old.row_version, 0) + 1;

    end if;

end cfg_gate_rules_audit_trg;
/
show errors trigger cfg_gate_rules_audit_trg

prompt File: cfg_gate_rules_audit_trg.trg.sql <end>
