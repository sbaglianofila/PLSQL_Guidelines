prompt File: wfl_statuses_audit_trg.trg.sql <start>
-- =============================================================================
-- File:     wfl_statuses_audit_trg.trg.sql
-- Oggetto:  wfl_statuses_audit_trg (trigger)
-- Schema:   #APP#
-- Scopo:    Mantiene le colonne amministrative standard di wfl_statuses: audit di
--           creazione (insert), audit di modifica (update) e la versione di riga
--           per il locking ottimistico. Vedi colonne_amministrative.md.
-- Nota:     Le colonne di creazione sono immutabili negli update; row_version è
--           autorità del server e ignora qualsiasi valore fornito dal client.
--           Attore e programma sono risolti da lib_session (current_actor /
--           current_module), unico punto per fallback e cap: il trigger dipende
--           quindi da lib_session, installato dopo i package base.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260723  AA   Creazione
-- =============================================================================

prompt wfl_statuses_audit_trg: Creating trigger

create or replace trigger wfl_statuses_audit_trg
   before insert or update on wfl_statuses
   for each row
begin

    if (inserting)
    then

        :new.created_by   := lib_session.current_actor;
        :new.created_at   := systimestamp;
        :new.created_app  := lib_session.current_module;
        :new.modified_by  := null;
        :new.modified_at  := null;
        :new.modified_app := null;

        :new.row_version  := 1;

    elsif (updating)
    then

        :new.created_by   := :old.created_by;
        :new.created_at   := :old.created_at;
        :new.created_app  := :old.created_app;
        --
        :new.modified_by  := lib_session.current_actor;
        :new.modified_at  := systimestamp;
        :new.modified_app := lib_session.current_module;

        :new.row_version  := nvl(:old.row_version, 0) + 1;

    end if;

end wfl_statuses_audit_trg;
/
show errors trigger wfl_statuses_audit_trg

prompt File: wfl_statuses_audit_trg.trg.sql <end>
