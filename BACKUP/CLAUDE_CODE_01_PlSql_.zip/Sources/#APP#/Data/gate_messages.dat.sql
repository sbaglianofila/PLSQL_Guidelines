prompt File: gate_messages.dat.sql <start>
-- =============================================================================
-- File:     gate_messages.dat.sql
-- Object:   Seed data for cfg_messages (lib_gate configuration-defect messages)
-- Schema:   #APP#
-- Purpose:  The message templates raised by lib_gate. One per k_msg_* constant
--           declared in the lib_gate specification: the code and the constant live
--           in the package, the text lives here so it can be corrected at runtime.
--           Placeholders %1..%n are substituted by lib_err when raising.
-- Note:     These are all CONFIGURATION DEFECTS, not verdicts. A rule that cannot
--           run - unknown type, object outside the whitelist, missing mandatory
--           parameter - is not "a precondition that failed": it is a setup error
--           to be fixed, so it is raised rather than folded into the verdict.
--           Uses MERGE so the script is idempotent and safe to re-run: it does not
--           overwrite an existing template, only inserts missing rows.
-- -----------------------------------------------------------------------------
-- Changelog (authoritative history: version control)
--   Date      Aut  Change
--   20260729  AA   Creation
-- =============================================================================

whenever sqlerror exit failure rollback

prompt cfg_messages: Seeding gate rows
merge into cfg_messages t
using ( select 'GATE_RULE_UNKNOWN' as message_code
             , 'Gate rule type %1 is not handled by the dispatch (process %2, sequence %3).' as message_template
          from dual
        union all
        select 'GATE_OBJECT_NOT_LISTED'
             , 'Object %1 is not listed in cfg_gate_objects and cannot be used by a DATA_READY rule.'
          from dual
        union all
        select 'GATE_PARAM_MISSING'
             , 'Gate rule parameter %1 is required by rule type %2 but is not configured.'
          from dual
      ) s
   on (t.message_code = s.message_code)
 when not matched then
    insert (  t.message_code
            , t.message_template
           )
    values (  s.message_code
            , s.message_template
           );

prompt cfg_messages: Committing gate seed data
commit;

prompt File: gate_messages.dat.sql <end>
