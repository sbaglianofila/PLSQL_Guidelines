prompt File: cfg_gate_rule_types.dat.sql <start>
-- =============================================================================
-- File:     cfg_gate_rule_types.dat.sql
-- Object:   Seed data for cfg_gate_rule_types (lib_gate rule catalogue)
-- Schema:   #APP#
-- Purpose:  The closed domain of rule types lib_gate can evaluate. One row per
--           branch of the case statement in lib_gate.evaluate: this file and that
--           case statement are two views of the same list and must be changed
--           together. Adding a row here without writing the branch produces a
--           configurable rule that guards nothing - which is why evaluate raises
--           instead of ignoring an unknown rule_code.
-- Note:     Uses MERGE so the script is idempotent and safe to re-run. The merge
--           does not overwrite existing descriptions, only inserts missing rows,
--           so runtime corrections are preserved on re-run.
--           Descriptions are in English like the other seed files, for consistency
--           of the generated documentation that lists them together.
-- -----------------------------------------------------------------------------
-- Changelog (authoritative history: version control)
--   Date      Aut  Change
--   20260729  AA   Creation
-- =============================================================================

whenever sqlerror exit failure rollback

prompt cfg_gate_rule_types: Seeding rows
merge into cfg_gate_rule_types t
using ( select 'ENABLED' as rule_code
             , 'The process is enabled by its configuration flag.' as description
             , 'cfg_parameters name of the enabling flag (Y/N)' as param_1_usage
             , cast(null as varchar2(512 char)) as param_2_usage
          from dual
        union all
        select 'ENVIRONMENT'
             , 'The current environment is among the allowed ones.'
             , 'comma-separated environment codes, e.g. TEST,PROD'
             , null
          from dual
        union all
        select 'TIME_WINDOW'
             , 'The reference time falls inside the allowed window (midnight-crossing windows supported).'
             , 'window start as HH24:MI'
             , 'window end as HH24:MI'
          from dual
        union all
        select 'DAY_OF_WEEK'
             , 'The reference day is among the allowed ones, ISO numbering.'
             , 'comma-separated days 1-7, 1 = Monday'
             , null
          from dual
        union all
        select 'WORKING_DAY'
             , 'The reference date is a working day according to lib_calendar (weekends and holidays excluded).'
             , 'calendar code; null means DEFAULT'
             , null
          from dual
        union all
        select 'DEPENDENCY'
             , 'The predecessor process completed successfully.'
             , 'process_name of the predecessor'
             , 'validity in hours; null means same date as the reference date'
          from dual
        union all
        select 'DATA_READY'
             , 'The given object holds at least one row to process.'
             , 'object name; must be listed in cfg_gate_objects'
             , null
          from dual
      ) s
   on (t.rule_code = s.rule_code)
 when not matched then
    insert (  t.rule_code
            , t.description
            , t.param_1_usage
            , t.param_2_usage
           )
    values (  s.rule_code
            , s.description
            , s.param_1_usage
            , s.param_2_usage
           );

prompt cfg_gate_rule_types: Committing seed data
commit;

prompt File: cfg_gate_rule_types.dat.sql <end>
