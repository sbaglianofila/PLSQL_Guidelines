prompt File: cfg_parameter_groups.dat.sql <start>
-- =============================================================================
-- File:     cfg_parameter_groups.dat.sql
-- Oggetto:  Dati di seed per cfg_parameter_groups
-- Schema:   #APP#
-- Scopo:    I raggruppamenti di parametri usati dai package di libreria. Un
--           progetto aggiunge qui i propri gruppi (con il loro sort_order) prima
--           di riferirli da cfg_parameters: la foreign key cfg_parameters_fk_group
--           impedisce di usare un gruppo non a catalogo.
-- Nota:     Va eseguito PRIMA di cfg_parameters.dat.sql, che referenzia questi
--           codici. Usa MERGE così lo script è idempotente e rieseguibile: non
--           sovrascrive le righe esistenti, inserisce solo quelle mancanti, così
--           etichette e ordinamenti ritoccati per ambiente sono preservati.
--           I testi sono in inglese come negli altri file di seed, per coerenza
--           della documentazione generata che li espone insieme.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260720  AA   Creazione
-- =============================================================================

whenever sqlerror exit failure rollback

prompt cfg_parameter_groups: Seeding rows
merge into cfg_parameter_groups t
using ( select 'GENERAL'  as group_code
             , 'General'  as name
             , 'Cross-cutting settings that do not belong to a specific area, such as the environment identity.' as description
             , 10         as sort_order
          from dual
        union all
        select 'LOGGING'
             , 'Logging and diagnostics'
             , 'Verbosity and retention of the application log written by lib_logging.'
             , 20
          from dual
        union all
        select 'MAIL'
             , 'Mail delivery'
             , 'Sender, transport and retry policy used by lib_mail and its engine.'
             , 30
          from dual
      ) s
   on (t.group_code = s.group_code)
 when not matched then
    insert (  t.group_code
            , t.name
            , t.description
            , t.sort_order
           )
    values (  s.group_code
            , s.name
            , s.description
            , s.sort_order
           );

prompt cfg_parameter_groups: Committing seed data
commit;

prompt File: cfg_parameter_groups.dat.sql <end>
