prompt File: wfl_messages.dat.sql <start>
-- =============================================================================
-- File:     wfl_messages.dat.sql
-- Oggetto:  Dati di seed per cfg_messages (messaggi del pillar workflow)
-- Schema:   #APP#
-- Scopo:    I template dei messaggi di dominio sollevati da lib_workflow.assert_action.
--           Uno per costante k_msg_* dichiarata nella specifica di lib_workflow: il
--           codice e la costante vivono nel package, il testo qui come dato così è
--           correggibile a runtime. I segnaposto %1..%n sono sostituiti da lib_err
--           al momento del raise. I testi sono in inglese come negli altri file di
--           seed, per coerenza della documentazione generata che li espone insieme.
-- Nota:     Usa MERGE così lo script è idempotente e rieseguibile: non sovrascrive
--           un template esistente, inserisce solo quelli mancanti, così le
--           correzioni a runtime sono preservate.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260723  AA   Creazione
-- =============================================================================

whenever sqlerror exit failure rollback

prompt cfg_messages: Seeding workflow rows
merge into cfg_messages t
using ( select 'WFL_TRANSITION_NOT_ALLOWED' as message_code
             , 'Action %1 is not allowed from status %2 in workflow %3.' as message_template
          from dual
        union all
        select 'WFL_ROLE_NOT_ALLOWED'
             , 'Role %1 is not authorized to perform action %2 in workflow %3.'
          from dual
        union all
        select 'WFL_REASON_REQUIRED'
             , 'A reason is required to perform action %1.'
          from dual
        union all
        select 'WFL_GUARD_HANDLER_MISSING'
             , 'Workflow %1 has guards on action %2 but no guard_handler configured.'
          from dual
      ) s
   on (t.message_code = s.message_code)
 when not matched then
    insert (  t.message_code
            , t.message_template
           )
    values (  s.message_code
            , s.message_template
           );

prompt cfg_messages: Committing workflow seed data
commit;

prompt File: wfl_messages.dat.sql <end>
