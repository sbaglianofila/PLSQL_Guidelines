prompt File: authz_messages.dat.sql <start>
-- =============================================================================
-- File:     authz_messages.dat.sql
-- Oggetto:  Dati di seed per cfg_messages (messaggi del pillar autorizzazioni)
-- Schema:   #APP#
-- Scopo:    Il template del messaggio sollevato da lib_authz.assert_access. Uno per
--           costante k_msg_* dichiarata nella specifica di lib_authz: il codice e la
--           costante vivono nel package, il testo qui come dato così è correggibile
--           a runtime. I segnaposto %1..%n sono sostituiti da lib_err al momento del
--           raise (%1 = utente, %2 = modo, %3 = funzionalità). I testi sono in
--           inglese come negli altri file di seed, per coerenza della documentazione
--           generata che li espone insieme.
-- Nota:     Usa MERGE così lo script è idempotente e rieseguibile: non sovrascrive
--           un template esistente, inserisce solo quelli mancanti, così le
--           correzioni a runtime sono preservate.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260725  AA   Creazione
-- =============================================================================

whenever sqlerror exit failure rollback

prompt cfg_messages: Seeding authorization rows
merge into cfg_messages t
using ( select 'AUTHZ_ACCESS_DENIED' as message_code
             , 'User %1 is not allowed to %2 functionality %3.' as message_template
          from dual
      ) s
   on (t.message_code = s.message_code)
 when not matched then
    insert (  t.message_code
            , t.message_template
           )
    values (  s.message_code
            , s.message_template
           );

prompt cfg_messages: Committing authorization seed data
commit;

prompt File: authz_messages.dat.sql <end>
