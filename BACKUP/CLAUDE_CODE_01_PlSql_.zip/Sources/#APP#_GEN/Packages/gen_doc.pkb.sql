prompt File: gen_doc.pkb.sql <start>
-- =============================================================================
-- File:     gen_doc.pkb.sql
-- Oggetto:  gen_doc (corpo del package)
-- Schema:   #APP#_GEN (SOLO DEV/TEST)
-- Scopo:    Estrae i metadati di una tabella dal dizionario (viste DBA_*) e rende
--           la pagina HTML di documentazione, con la struttura congelata in
--           Templates/. Il rendering (table_page, funzione pura) è separato dalla
--           scrittura su file (generate_*). Prima ondata: le tabelle.
-- Dipendenze runtime: sys.utl_file (scrittura DIRETTA dei file, EXECUTE a
--           #APP#_GEN) e #APP#.lib_err (segnalazione della tabella non trovata,
--           EXECUTE a #APP#_GEN). L'output va in una DIRECTORY grantata a
--           #APP#_GEN (dev/test only): NON passa da lib_file, così le directory di
--           generazione restano confinate allo schema dev/test. Oltre alle grant
--           DBA_* in SYS/Grants/#APP#_gen.grt.sql.
-- Nota:     codice scritto e NON ancora compilato su istanza (come il resto della
--           base). Punti da verificare in fase di compilazione: la resa del tipo
--           in format_type sui casi meno comuni, la fetch scalare del DATA_DEFAULT
--           (LONG) e l'ordinamento delle colonne invisibili (column_id nullo).
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260731  AA   Creazione (corpo; prima ondata: tabelle)
--   20260801  AA   Scrittura via sys.utl_file diretto (opzione B) al posto di
--                  lib_file: le directory di generazione restano su #APP#_GEN
-- =============================================================================

prompt gen_doc: Creating package body

create or replace
package body gen_doc
is

-- Costanti --------------------------------------------------------------------
k_SCOPE     constant varchar2(30 char) := 'gen_doc';
-- Percorso relativo del foglio di stile da una pagina di oggetto (sottocartella
-- <schema>/<tipo>s/) verso files/gen_doc.css nella forma pubblicata ad albero.
k_CSS_HREF  constant varchar2(64 char) := '../../files/gen_doc.css';
k_NBSP      constant varchar2(1 char)  := '—';

-- Helper: escape HTML ---------------------------------------------------------
--------------------------------------------------------------------------------
function esc(i_s in varchar2)
    return varchar2
-- Rende sicuro un testo per l'inserimento in HTML. Un input nullo diventa stringa
-- vuota, così i chiamanti non devono gestire il null.
is
begin
    if i_s is null
    then
        return '';
    end if;
    return replace(replace(replace(replace(i_s
             , '&', '&amp;')
             , '<', '&lt;')
             , '>', '&gt;')
             , '"', '&quot;');
end esc;
--------------------------------------------------------------------------------
procedure app(io_html in out nocopy clob, i_text in varchar2)
-- Appende un frammento di testo al CLOB in costruzione, seguito da un a-capo: così
-- ogni frammento è una "riga" corta e write_file può scrivere il CLOB con utl_file
-- senza sforare il limite di lunghezza riga, coi newline solo ai confini dei
-- frammenti (mai dentro un tag o il testo). Ignora i frammenti nulli.
is
    l_line  varchar2(32767 char);
begin
    if i_text is not null
    then
        l_line := i_text || chr(10);
        dbms_lob.writeappend(io_html, length(l_line), l_line);
    end if;
end app;
--------------------------------------------------------------------------------
function n_int(i_n in number)
    return varchar2
-- Formatta un intero con separatore delle migliaia '.', o l'em dash se nullo.
is
begin
    if i_n is null
    then
        return k_NBSP;
    end if;
    return trim(to_char(i_n, 'FM999G999G999G999G990', 'NLS_NUMERIC_CHARACTERS='',.'''));
end n_int;
--------------------------------------------------------------------------------
function n_dec(i_n in number)
    return varchar2
-- Formatta un decimale (es. densità) con la virgola decimale, o l'em dash se nullo.
is
begin
    if i_n is null
    then
        return k_NBSP;
    end if;
    return trim(to_char(i_n, 'FM999G990D0000000', 'NLS_NUMERIC_CHARACTERS='',.'''));
end n_dec;
--------------------------------------------------------------------------------
function fmt_dt(i_d in date)
    return varchar2
-- Data/ora in forma ISO compatta, o l'em dash se nulla.
is
begin
    if i_d is null
    then
        return k_NBSP;
    end if;
    return to_char(i_d, 'YYYY-MM-DD HH24:MI');
end fmt_dt;
--------------------------------------------------------------------------------
function format_type( i_data_type      in varchar2
                    , i_char_length    in number
                    , i_char_used      in varchar2
                    , i_data_precision in number
                    , i_data_scale     in number
                    , i_data_length    in number
                    )
    return varchar2
-- Compone la resa testuale del tipo di una colonna (es. 'VARCHAR2(32 CHAR)',
-- 'NUMBER(14,2)', 'NUMBER', 'DATE'). I tipi non gestiti esplicitamente (DATE,
-- TIMESTAMP, CLOB, ...) tornano dal dizionario già completi.
is
    l_unit  varchar2(6 char);
begin
    case
        when i_data_type in ('VARCHAR2', 'NVARCHAR2', 'CHAR', 'NCHAR')
        then
            l_unit := case i_char_used when 'C' then ' CHAR' when 'B' then ' BYTE' else null end;
            return i_data_type || '(' || to_char(nvl(i_char_length, i_data_length)) || l_unit || ')';
        when i_data_type = 'RAW'
        then
            return 'RAW(' || to_char(i_data_length) || ')';
        when i_data_type = 'NUMBER'
        then
            if i_data_precision is null
            then
                return 'NUMBER';
            elsif nvl(i_data_scale, 0) = 0
            then
                return 'NUMBER(' || to_char(i_data_precision) || ')';
            else
                return 'NUMBER(' || to_char(i_data_precision) || ',' || to_char(i_data_scale) || ')';
            end if;
        when i_data_type = 'FLOAT'
        then
            return 'FLOAT(' || to_char(i_data_precision) || ')';
        else
            return i_data_type;
    end case;
end format_type;
--------------------------------------------------------------------------------
function col_default(i_owner in varchar2, i_table in varchar2, i_column in varchar2)
    return varchar2
-- Legge il DATA_DEFAULT (tipo LONG) di una colonna con una select scalare, l'unico
-- modo affidabile per portare un LONG in un VARCHAR2 in PL/SQL. Restituisce il
-- testo ripulito da a capo, o null se assente o troppo lungo per il buffer.
is
    l_default  varchar2(4000 char);
begin
    select data_default
      into l_default
      from dba_tab_cols
     where owner = i_owner
       and table_name = i_table
       and column_name = i_column;

    return trim(replace(replace(l_default, chr(10), ' '), chr(13), ' '));
exception
    when others
    then
        return null;
end col_default;
--------------------------------------------------------------------------------
procedure write_file(i_directory in varchar2, i_filename in varchar2, i_content in clob)
-- Scrive un CLOB su file con sys.utl_file, riga per riga (il CLOB è già delimitato
-- da a-capo dalla app). Scrittura DIRETTA, non via lib_file, così la DIRECTORY di
-- output resta grantata al solo schema dev/test #APP#_GEN. L'handle è chiuso anche
-- in caso di errore. Il nome file è prodotto da object_file_name (nessun separatore
-- di path), quindi non serve validazione anti-traversal aggiuntiva.
is
    l_file    utl_file.file_type;
    l_len     integer := dbms_lob.getlength(i_content);
    l_pos     integer := 1;
    l_nl      integer;
    l_amount  integer;
begin
    l_file := utl_file.fopen(i_directory, i_filename, 'w', 32767);

    while l_pos <= l_len
    loop
        l_nl := dbms_lob.instr(i_content, chr(10), l_pos);
        if l_nl = 0
        then
            l_amount := l_len - l_pos + 1;      -- ultima riga, senza a-capo finale
        else
            l_amount := l_nl - l_pos;           -- testo prima dell'a-capo
        end if;

        if l_amount > 0
        then
            utl_file.put_line(l_file, dbms_lob.substr(i_content, l_amount, l_pos));
        else
            utl_file.new_line(l_file);          -- riga vuota
        end if;

        exit when l_nl = 0;
        l_pos := l_nl + 1;
    end loop;

    utl_file.fflush(l_file);
    utl_file.fclose(l_file);
exception
    when others
    then
        if utl_file.is_open(l_file)
        then
            utl_file.fclose(l_file);
        end if;
        raise;
end write_file;
--------------------------------------------------------------------------------

-- Membri pubblici =============================================================

function object_file_name( i_owner       in varchar2
                         , i_object_type in varchar2
                         , i_object_name in varchar2
                         )
    return varchar2
is
begin
    return lower(i_owner) || '_' || lower(i_object_type) || '_' || lower(i_object_name) || '.html';
end object_file_name;

-- Render delle sezioni (privato) ==============================================

--------------------------------------------------------------------------------
procedure render_head(io_html in out nocopy clob, i_owner in varchar2, i_table in varchar2)
-- Testa del documento, top bar con breadcrumb e apertura di shell e indice.
is
begin
    app(io_html, '<!doctype html>' || chr(10)
        || '<html lang="it">' || chr(10)
        || '<head>' || chr(10)
        || '  <meta charset="utf-8">' || chr(10)
        || '  <meta name="viewport" content="width=device-width, initial-scale=1">' || chr(10)
        || '  <title>' || esc(lower(i_table)) || ' — Tabella — ' || esc(i_owner) || '</title>' || chr(10)
        || '  <link rel="stylesheet" href="' || k_CSS_HREF || '">' || chr(10)
        || '</head>' || chr(10)
        || '<body>' || chr(10));

    app(io_html, '<div class="topbar"><div class="topbar-inner"><div class="crumb">'
        || '<span class="schema-badge">' || esc(i_owner) || '</span>'
        || '<span class="sep">&rsaquo;</span>'
        || '<a href="../index.html#tabelle">Tabelle</a>'
        || '<span class="sep">&rsaquo;</span>'
        || '<span class="here">' || esc(lower(i_table)) || '</span>'
        || '</div><span class="spacer"></span>'
        || '<button class="theme-toggle" id="themeToggle" aria-label="Cambia tema">'
        || '<span id="themeIcon">&#9680;</span><span id="themeLabel">Tema</span></button>'
        || '</div></div>' || chr(10));

    app(io_html, '<div class="shell"><nav class="toc" aria-label="Sezioni della pagina">'
        || '<p class="toc-label">In questa pagina</p><ul>'
        || '<li><a href="#panoramica">Panoramica</a></li>'
        || '<li><a href="#colonne">Colonne</a></li>'
        || '<li><a href="#dettaglio">Dettaglio colonne</a></li>'
        || '<li><a href="#constraint">Constraint</a></li>'
        || '<li><a href="#indici">Indici</a></li>'
        || '<li><a href="#partizionamento">Partizionamento</a></li>'
        || '<li><a href="#trigger">Trigger</a></li>'
        || '<li><a href="#dipendenze">Dipendenze</a></li>'
        || '<li><a href="#sinonimi">Sinonimi</a></li>'
        || '<li><a href="#grant">Grant</a></li>'
        || '<li><a href="#statistiche">Statistiche</a></li>'
        || '</ul></nav><main>' || chr(10));
end render_head;
--------------------------------------------------------------------------------
procedure render_header(io_html in out nocopy clob, i_owner in varchar2, i_table in varchar2, i_comment in varchar2)
-- Intestazione della pagina: eyebrow, nome tabella e commento come sottotitolo.
is
begin
    app(io_html, '<header class="page"><p class="eyebrow"><span class="obj-mark">TABLE</span> Schema '
        || esc(i_owner) || '</p><h1 class="title">' || esc(lower(i_table)) || '</h1>'
        || '<p class="subtitle">' || esc(i_comment) || '</p></header>' || chr(10));
end render_header;
--------------------------------------------------------------------------------
procedure spec_cell(io_html in out nocopy clob, i_k in varchar2, i_v in varchar2, i_muted in boolean default false)
-- Una cella chiave/valore della scheda Panoramica o Statistiche.
is
begin
    app(io_html, '<div class="cell"><div class="k">' || esc(i_k) || '</div><div class="v'
        || case when i_muted then ' muted' end || '">' || esc(i_v) || '</div></div>');
end spec_cell;
--------------------------------------------------------------------------------
procedure render_panoramica(io_html in out nocopy clob, i_owner in varchar2, i_table in varchar2)
-- Scheda degli attributi strutturali da DBA_TABLES + DBA_OBJECTS (niente statistiche).
is
    l_temporary   dba_tables.temporary%type;
    l_duration    dba_tables.duration%type;
    l_iot_type    dba_tables.iot_type%type;
    l_cluster     dba_tables.cluster_name%type;
    l_compress    dba_tables.compression%type;
    l_partitioned dba_tables.partitioned%type;
    l_tablespace  dba_tables.tablespace_name%type;
    l_status      dba_objects.status%type;
    l_created     dba_objects.created%type;
    l_last_ddl    dba_objects.last_ddl_time%type;
begin
    select t.temporary, t.duration, t.iot_type, t.cluster_name, t.compression,
           t.partitioned, t.tablespace_name, o.status, o.created, o.last_ddl_time
      into l_temporary, l_duration, l_iot_type, l_cluster, l_compress,
           l_partitioned, l_tablespace, l_status, l_created, l_last_ddl
      from dba_tables t
      join dba_objects o
        on o.owner = t.owner and o.object_name = t.table_name and o.object_type = 'TABLE'
     where t.owner = i_owner and t.table_name = i_table;

    app(io_html, '<section id="panoramica"><h2 class="sect">Panoramica</h2>'
        || '<p class="sect-note">Attributi strutturali della tabella dal dizionario dati. Le statistiche di cardinalità sono in fondo, non qui.</p>'
        || '<div class="spec">');

    spec_cell(io_html, 'Tipo', case when l_iot_type is not null then 'Index-organized' else 'Heap (relazionale)' end);
    spec_cell(io_html, 'Temporanea', case l_temporary when 'Y' then 'Sì (' || nvl(l_duration, 'GTT') || ')' else 'No' end, l_temporary = 'N');
    spec_cell(io_html, 'Index-organized', case when l_iot_type is not null then l_iot_type else 'No' end, l_iot_type is null);
    spec_cell(io_html, 'Cluster', nvl(l_cluster, k_NBSP), l_cluster is null);
    spec_cell(io_html, 'Compressione', case when l_compress = 'ENABLED' then 'Abilitata' else 'Disabilitata' end, nvl(l_compress, 'DISABLED') <> 'ENABLED');
    spec_cell(io_html, 'Partizionata', case l_partitioned when 'YES' then 'Sì' else 'No' end, l_partitioned <> 'YES');
    spec_cell(io_html, 'Tablespace', nvl(l_tablespace, k_NBSP), l_tablespace is null);
    spec_cell(io_html, 'Stato', l_status, l_status <> 'VALID');
    spec_cell(io_html, 'Ultimo DDL', fmt_dt(l_last_ddl));
    spec_cell(io_html, 'Creata', to_char(l_created, 'YYYY-MM-DD'));

    app(io_html, '</div></section>' || chr(10));
end render_panoramica;
--------------------------------------------------------------------------------
procedure render_colonne(io_html in out nocopy clob, i_owner in varchar2, i_table in varchar2)
-- Tabella delle colonne: numero, nome (con tag virtuale/invisibile), tipo, nullità,
-- default, chiave (chip PK/FK) e commento. Le righe invisibili sono attenuate.
is
    l_i        pls_integer := 0;
    l_count    pls_integer;
    l_name     varchar2(4000 char);
    l_default  varchar2(4000 char);
    l_chips    varchar2(400 char);
    l_virtual  boolean;
    l_invis    boolean;

    cursor c_cols is
        select c.column_name, c.data_type, c.data_length, c.data_precision, c.data_scale,
               c.char_length, c.char_used, c.nullable, c.hidden_column, c.virtual_column,
               cc.comments,
               case when exists (
                    select 1 from dba_cons_columns pcc
                      join dba_constraints pc on pc.owner = pcc.owner and pc.constraint_name = pcc.constraint_name
                     where pc.owner = c.owner and pc.table_name = c.table_name
                       and pc.constraint_type = 'P' and pcc.column_name = c.column_name)
                    then 'Y' else 'N' end as is_pk,
               case when exists (
                    select 1 from dba_cons_columns fcc
                      join dba_constraints fc on fc.owner = fcc.owner and fc.constraint_name = fcc.constraint_name
                     where fc.owner = c.owner and fc.table_name = c.table_name
                       and fc.constraint_type = 'R' and fcc.column_name = c.column_name)
                    then 'Y' else 'N' end as is_fk
          from dba_tab_cols c
          left join dba_col_comments cc
                 on cc.owner = c.owner and cc.table_name = c.table_name and cc.column_name = c.column_name
         where c.owner = i_owner and c.table_name = i_table and c.user_generated = 'YES'
         order by c.column_id nulls last, c.internal_column_id;
begin
    select count(*)
      into l_count
      from dba_tab_cols
     where owner = i_owner and table_name = i_table and user_generated = 'YES';

    app(io_html, '<section id="colonne"><h2 class="sect">Colonne <span class="count">' || to_char(l_count) || '</span></h2>'
        || '<p class="sect-note">Le colonne amministrative invisibili (blocco di audit) sono attenuate. I tratti aggiuntivi sono dettagliati nella sezione successiva.</p>'
        || '<div class="table-wrap"><table><thead><tr>'
        || '<th>#</th><th>Colonna</th><th>Tipo</th><th>Null</th><th>Default</th><th>Chiave</th><th>Commento</th>'
        || '</tr></thead><tbody>');

    for r in c_cols
    loop
        l_i := l_i + 1;
        l_virtual := (r.virtual_column = 'YES');
        l_invis   := (r.hidden_column = 'YES' and r.virtual_column = 'NO');

        -- Nome colonna con eventuali tag di tratto
        l_name := esc(lower(r.column_name));
        if l_virtual
        then
            l_name := l_name || ' <span class="tag tag-virtual">virtuale</span>';
        end if;
        if l_invis
        then
            l_name := l_name || ' <span class="tag">invisibile</span>';
        end if;

        -- Default: mostrato solo per le colonne non virtuali (per la virtuale
        -- l'espressione sta nel Dettaglio, non qui)
        if l_virtual
        then
            l_default := null;
        else
            l_default := col_default(i_owner, i_table, r.column_name);
        end if;

        -- Chip di chiave
        l_chips := '';
        if r.is_pk = 'Y'
        then
            l_chips := l_chips || '<span class="chip chip-pk">PK</span>';
        end if;
        if r.is_fk = 'Y'
        then
            l_chips := l_chips || '<span class="chip chip-fk">FK</span>';
        end if;

        app(io_html, '<tr' || case when l_invis then ' class="invisible"' end || '>'
            || '<td class="num">' || to_char(l_i) || '</td>'
            || '<td class="ident">' || l_name || '</td>'
            || '<td class="type">' || esc(format_type(r.data_type, r.char_length, r.char_used, r.data_precision, r.data_scale, r.data_length)) || '</td>'
            || '<td>' || case when r.nullable = 'N' then '<span class="nn">NOT NULL</span>' else '<span class="nullable">NULL</span>' end || '</td>'
            || '<td class="' || case when l_default is not null then 'type' else 'nullable' end || '">' || case when l_default is not null then esc(l_default) else k_NBSP end || '</td>'
            || '<td>' || case when l_chips is not null and length(l_chips) > 0 then '<span class="cellchips">' || l_chips || '</span>' end || '</td>'
            || '<td class="desc">' || esc(r.comments) || '</td>'
            || '</tr>');
    end loop;

    app(io_html, '</tbody></table></div></section>' || chr(10));
end render_colonne;
--------------------------------------------------------------------------------
procedure render_dettaglio(io_html in out nocopy clob, i_owner in varchar2, i_table in varchar2)
-- Solo fatti dal dizionario: per le colonne con tratti aggiuntivi (virtuale con
-- espressione, invisibile, redaction con funzione) nome, tratti e valore concreto.
is
    l_rows     pls_integer := 0;
    l_traits   varchar2(600 char);
    l_value    varchar2(4000 char);
    l_redact   varchar2(200 char);
    l_virtual  boolean;
    l_invis    boolean;

    cursor c_cols is
        select c.column_name, c.hidden_column, c.virtual_column
          from dba_tab_cols c
         where c.owner = i_owner and c.table_name = i_table and c.user_generated = 'YES'
         order by c.column_id nulls last, c.internal_column_id;
begin
    app(io_html, '<section id="dettaglio"><h2 class="sect">Dettaglio colonne</h2>'
        || '<p class="sect-note">Solo colonne con tratti aggiuntivi, e solo fatti dal dizionario: virtualità con espressione, visibilità, redaction con funzione e parametri. Nessuna prosa interpretativa; il testo descrittivo della colonna è il commento, mostrato nella tabella Colonne.</p>'
        || '<div class="table-wrap"><table><thead><tr><th>Colonna</th><th>Tratti</th><th>Valore</th></tr></thead><tbody>');

    for r in c_cols
    loop
        l_virtual := (r.virtual_column = 'YES');
        l_invis   := (r.hidden_column = 'YES' and r.virtual_column = 'NO');

        -- Redaction (Advanced Security): assente su gran parte degli schemi
        begin
            select rc.function_type
              into l_redact
              from dba_redaction_columns rc
             where rc.object_owner = i_owner and rc.object_name = i_table and rc.column_name = r.column_name;
        exception
            when no_data_found then l_redact := null;
            when others        then l_redact := null;
        end;

        if not l_virtual and not l_invis and l_redact is null
        then
            continue;
        end if;

        l_traits := '';
        l_value  := null;

        if l_virtual
        then
            l_traits := l_traits || '<span class="tag tag-virtual">virtuale</span><span class="tag">generated always</span>';
            l_value  := col_default(i_owner, i_table, r.column_name);
        end if;
        if l_invis
        then
            l_traits := l_traits || '<span class="tag">invisibile</span>';
        end if;
        if l_redact is not null
        then
            l_traits := l_traits || '<span class="tag">redaction</span>';
            l_value  := nvl(l_value, l_redact);
        end if;

        l_rows := l_rows + 1;
        app(io_html, '<tr><td class="ident">' || esc(lower(r.column_name)) || '</td>'
            || '<td><span class="cellchips">' || l_traits || '</span></td>'
            || '<td class="' || case when l_value is not null then 'type' else 'nullable' end || '">'
            || case when l_value is not null then esc(l_value) else k_NBSP end || '</td></tr>');
    end loop;

    if l_rows = 0
    then
        app(io_html, '<tr><td colspan="3" class="desc">Nessuna colonna con tratti aggiuntivi.</td></tr>');
    end if;

    app(io_html, '</tbody></table></div></section>' || chr(10));
end render_dettaglio;
--------------------------------------------------------------------------------
procedure cons_group( io_html    in out nocopy clob
                    , i_owner    in varchar2
                    , i_table    in varchar2
                    , i_type     in varchar2       -- 'P' | 'U'
                    , i_label    in varchar2
                    )
-- Un gruppo di constraint semplici (primary key / unique): nome, colonne, stato,
-- deferrable, indice.
is
    l_count  pls_integer;
    l_cols   varchar2(4000 char);
begin
    select count(*)
      into l_count
      from dba_constraints
     where owner = i_owner and table_name = i_table and constraint_type = i_type;

    app(io_html, '<h3 class="group">' || esc(i_label) || ' <span class="g-kind">' || to_char(l_count) || '</span></h3>');

    if l_count = 0
    then
        app(io_html, '<div class="empty">Nessun vincolo di questo tipo.</div>');
        return;
    end if;

    app(io_html, '<div class="table-wrap"><table><thead><tr>'
        || '<th>Nome</th><th>Colonne</th><th>Stato</th><th>Deferrable</th><th>Indice</th></tr></thead><tbody>');

    for c in ( select constraint_name, status, deferrable, index_name
                 from dba_constraints
                where owner = i_owner and table_name = i_table and constraint_type = i_type
                order by constraint_name )
    loop
        select listagg(lower(column_name), ', ') within group (order by position)
          into l_cols
          from dba_cons_columns
         where owner = i_owner and constraint_name = c.constraint_name;

        app(io_html, '<tr><td class="ident">' || esc(lower(c.constraint_name)) || '</td>'
            || '<td class="ident">(' || esc(l_cols) || ')</td>'
            || '<td><span class="pill pill-ok">' || esc(c.status) || '</span></td>'
            || '<td class="nullable">' || esc(c.deferrable) || '</td>'
            || '<td class="ident">' || case when c.index_name is not null then esc(lower(c.index_name)) else k_NBSP end || '</td></tr>');
    end loop;

    app(io_html, '</tbody></table></div>');
end cons_group;
--------------------------------------------------------------------------------
procedure render_constraint(io_html in out nocopy clob, i_owner in varchar2, i_table in varchar2)
-- Constraint raggruppati per tipo. I NOT NULL (check di nullità) sono esclusi: la
-- nullità è già un flag nella tabella colonne.
is
    l_fk_count  pls_integer;
    l_ck_count  pls_integer;
    l_cols      varchar2(4000 char);
    l_rcols     varchar2(4000 char);
begin
    app(io_html, '<section id="constraint"><h2 class="sect">Constraint</h2>'
        || '<p class="sect-note">Raggruppati per tipo. I NOT NULL non compaiono qui: sono resi come flag nella tabella colonne, per non affollare la sezione con i check che Oracle genera per la nullità.</p>');

    -- Primary key e Unique
    cons_group(io_html, i_owner, i_table, 'P', 'Primary key');
    cons_group(io_html, i_owner, i_table, 'U', 'Unique');

    -- Foreign key
    select count(*)
      into l_fk_count
      from dba_constraints
     where owner = i_owner and table_name = i_table and constraint_type = 'R';

    app(io_html, '<h3 class="group">Foreign key <span class="g-kind">' || to_char(l_fk_count) || '</span></h3>');

    if l_fk_count = 0
    then
        app(io_html, '<div class="empty">Nessuna foreign key.</div>');
    else
        app(io_html, '<div class="table-wrap"><table><thead><tr>'
            || '<th>Nome</th><th>Colonne</th><th>Riferimento</th><th>Delete rule</th><th>Stato</th><th>Deferrable</th><th>Indice</th></tr></thead><tbody>');

        for c in ( select c.constraint_name, c.status, c.deferrable, c.delete_rule,
                          c.index_name, rc.owner as ref_owner, rc.table_name as ref_table,
                          rc.constraint_name as ref_cons
                     from dba_constraints c
                     join dba_constraints rc on rc.owner = c.r_owner and rc.constraint_name = c.r_constraint_name
                    where c.owner = i_owner and c.table_name = i_table and c.constraint_type = 'R'
                    order by c.constraint_name )
        loop
            select listagg(lower(column_name), ', ') within group (order by position)
              into l_cols
              from dba_cons_columns
             where owner = i_owner and constraint_name = c.constraint_name;

            -- Colonne referenziate: dal vincolo padre (PK/UK) nel suo schema
            select listagg(lower(column_name), ', ') within group (order by position)
              into l_rcols
              from dba_cons_columns
             where owner = c.ref_owner and constraint_name = c.ref_cons;

            app(io_html, '<tr><td class="ident">' || esc(lower(c.constraint_name)) || '</td>'
                || '<td class="ident">(' || esc(l_cols) || ')</td>'
                || '<td class="ident">' || esc(lower(c.ref_table)) || ' <span class="arrow">&rarr;</span> (' || esc(l_rcols) || ')</td>'
                || '<td class="nullable">' || esc(c.delete_rule) || '</td>'
                || '<td><span class="pill pill-ok">' || esc(c.status) || '</span></td>'
                || '<td class="nullable">' || esc(c.deferrable) || '</td>'
                || '<td class="ident">' || case when c.index_name is not null then esc(lower(c.index_name)) else k_NBSP end || '</td></tr>');
        end loop;

        app(io_html, '</tbody></table></div>');
    end if;

    -- Check (esclusi i NOT NULL, che Oracle marca come generated 'GENERATED NAME'
    -- con condizione '"COL" IS NOT NULL'); si escludono per search_condition.
    select count(*)
      into l_ck_count
      from dba_constraints
     where owner = i_owner and table_name = i_table and constraint_type = 'C'
       and nvl(search_condition_vc, ' ') not like '%IS NOT NULL';

    app(io_html, '<h3 class="group">Check <span class="g-kind">' || to_char(l_ck_count) || '</span></h3>');

    if l_ck_count = 0
    then
        app(io_html, '<div class="empty">Nessun check applicativo (i NOT NULL sono resi come flag nella tabella colonne).</div>');
    else
        app(io_html, '<div class="table-wrap"><table><thead><tr>'
            || '<th>Nome</th><th>Condizione</th><th>Stato</th><th>Deferrable</th></tr></thead><tbody>');

        for c in ( select constraint_name, search_condition_vc, status, deferrable
                     from dba_constraints
                    where owner = i_owner and table_name = i_table and constraint_type = 'C'
                      and nvl(search_condition_vc, ' ') not like '%IS NOT NULL'
                    order by constraint_name )
        loop
            app(io_html, '<tr><td class="ident">' || esc(lower(c.constraint_name)) || '</td>'
                || '<td class="type">' || esc(c.search_condition_vc) || '</td>'
                || '<td><span class="pill pill-ok">' || esc(c.status) || '</span></td>'
                || '<td class="nullable">' || esc(c.deferrable) || '</td></tr>');
        end loop;

        app(io_html, '</tbody></table></div>');
    end if;

    app(io_html, '</section>' || chr(10));
end render_constraint;
--------------------------------------------------------------------------------
procedure render_indici(io_html in out nocopy clob, i_owner in varchar2, i_table in varchar2)
-- Indici: nome (con tag partizionato quando lo è), unicità, colonne, tipo,
-- tablespace, stato.
is
    l_count  pls_integer;
    l_cols   varchar2(4000 char);
begin
    select count(*)
      into l_count
      from dba_indexes
     where table_owner = i_owner and table_name = i_table;

    app(io_html, '<section id="indici"><h2 class="sect">Indici <span class="count">' || to_char(l_count) || '</span></h2>'
        || '<p class="sect-note">Un indice partizionato è segnalato da un tag partizionato accanto al nome, senza i dettagli delle partizioni.</p>');

    if l_count = 0
    then
        app(io_html, '<div class="empty">Nessun indice.</div></section>' || chr(10));
        return;
    end if;

    app(io_html, '<div class="table-wrap"><table><thead><tr>'
        || '<th>Nome</th><th>Unicità</th><th>Colonne</th><th>Tipo</th><th>Tablespace</th><th>Stato</th></tr></thead><tbody>');

    for i in ( select index_name, uniqueness, index_type, tablespace_name, status, partitioned
                 from dba_indexes
                where table_owner = i_owner and table_name = i_table
                order by index_name )
    loop
        select listagg(lower(column_name) || case when descend = 'DESC' then ' DESC' end, ', ')
                   within group (order by column_position)
          into l_cols
          from dba_ind_columns
         where index_owner = i_owner and index_name = i.index_name;

        app(io_html, '<tr><td class="ident">' || esc(lower(i.index_name))
            || case when i.partitioned = 'YES' then ' <span class="tag">partizionato</span>' end || '</td>'
            || '<td class="' || case when i.uniqueness = 'UNIQUE' then 'nn' else 'nullable' end || '">'
            || case when i.uniqueness = 'UNIQUE' then 'UNIQUE' else 'NON UNIQUE' end || '</td>'
            || '<td class="ident">' || esc(l_cols) || '</td>'
            || '<td class="type">' || esc(i.index_type) || '</td>'
            || '<td class="ident">' || esc(nvl(i.tablespace_name, k_NBSP)) || '</td>'
            || '<td><span class="pill pill-ok">' || esc(i.status) || '</span></td></tr>');
    end loop;

    app(io_html, '</tbody></table></div></section>' || chr(10));
end render_indici;
--------------------------------------------------------------------------------
procedure render_partizionamento(io_html in out nocopy clob, i_owner in varchar2, i_table in varchar2)
-- Sezione opzionale: presente sempre, ma con contenuto solo per le tabelle
-- partizionate (metodo, chiave, numero di partizioni).
is
    l_method    dba_part_tables.partitioning_type%type;
    l_pcount    dba_part_tables.partition_count%type;
    l_key       varchar2(4000 char);
begin
    app(io_html, '<section id="partizionamento"><h2 class="sect">Partizionamento</h2>');

    begin
        select partitioning_type, partition_count
          into l_method, l_pcount
          from dba_part_tables
         where owner = i_owner and table_name = i_table;
    exception
        when no_data_found
        then
            app(io_html, '<div class="empty">La tabella non è partizionata.</div></section>' || chr(10));
            return;
    end;

    select listagg(lower(column_name), ', ') within group (order by column_position)
      into l_key
      from dba_part_key_columns
     where owner = i_owner and name = i_table;

    app(io_html, '<div class="spec">');
    spec_cell(io_html, 'Metodo', l_method);
    spec_cell(io_html, 'Chiave', l_key);
    spec_cell(io_html, 'Partizioni', to_char(l_pcount));
    app(io_html, '</div></section>' || chr(10));
end render_partizionamento;
--------------------------------------------------------------------------------
procedure render_trigger(io_html in out nocopy clob, i_owner in varchar2, i_table in varchar2)
-- Anagrafica dei trigger, senza corpo e senza commento (a dizionario i trigger non
-- hanno un COMMENT ON): nome, timing, evento, livello, stato.
is
    l_count  pls_integer;
begin
    select count(*)
      into l_count
      from dba_triggers
     where table_owner = i_owner and table_name = i_table;

    app(io_html, '<section id="trigger"><h2 class="sect">Trigger <span class="count">' || to_char(l_count) || '</span></h2>'
        || '<p class="sect-note">Anagrafica dei trigger, senza corpo. Il codice si consulta nei sorgenti.</p>');

    if l_count = 0
    then
        app(io_html, '<div class="empty">Nessun trigger.</div></section>' || chr(10));
        return;
    end if;

    app(io_html, '<div class="table-wrap"><table><thead><tr>'
        || '<th>Nome</th><th>Timing</th><th>Evento</th><th>Livello</th><th>Stato</th></tr></thead><tbody>');

    for t in ( select trigger_name, trigger_type, triggering_event, status
                 from dba_triggers
                where table_owner = i_owner and table_name = i_table
                order by trigger_name )
    loop
        app(io_html, '<tr><td class="ident">' || esc(lower(t.trigger_name)) || '</td>'
            || '<td class="nn">' || esc(case when t.trigger_type like 'BEFORE%' then 'BEFORE' when t.trigger_type like 'AFTER%' then 'AFTER' when t.trigger_type like 'INSTEAD%' then 'INSTEAD OF' else t.trigger_type end) || '</td>'
            || '<td class="nn">' || esc(t.triggering_event) || '</td>'
            || '<td class="nullable">' || case when t.trigger_type like '%EACH ROW' then 'FOR EACH ROW' else 'STATEMENT' end || '</td>'
            || '<td><span class="pill ' || case when t.status = 'ENABLED' then 'pill-ok' else 'pill-off' end || '">' || esc(t.status) || '</span></td></tr>');
    end loop;

    app(io_html, '</tbody></table></div></section>' || chr(10));
end render_trigger;
--------------------------------------------------------------------------------
procedure dep_card(io_html in out nocopy clob, i_title in varchar2)
is
begin
    app(io_html, '<div class="dep-card"><h4>' || esc(i_title) || '</h4><div class="dep-list">');
end dep_card;
--------------------------------------------------------------------------------
procedure render_dipendenze(io_html in out nocopy clob, i_owner in varchar2, i_table in varchar2)
-- Tre elenchi: tabelle figlie (FK entranti), tabelle da cui dipende (FK uscenti),
-- oggetti che la referenziano (DBA_DEPENDENCIES).
is
    l_any  boolean;
begin
    app(io_html, '<section id="dipendenze"><h2 class="sect">Dipendenze</h2>'
        || '<p class="sect-note">Chi punta a questa tabella, da cosa dipende e quali oggetti la referenziano nel codice.</p>'
        || '<div class="dep-grid">');

    -- Figlie: FK di altre tabelle che referenziano un vincolo di questa
    dep_card(io_html, 'Tabelle figlie (FK entranti)');
    l_any := false;
    for d in ( select c.table_name, c.constraint_name
                 from dba_constraints c
                 join dba_constraints rc on rc.owner = c.r_owner and rc.constraint_name = c.r_constraint_name
                where c.constraint_type = 'R' and rc.owner = i_owner and rc.table_name = i_table
                order by c.table_name )
    loop
        l_any := true;
        app(io_html, '<div class="dep-item"><span class="kind">tab</span> ' || esc(lower(d.table_name))
            || ' <span class="via">via ' || esc(lower(d.constraint_name)) || '</span></div>');
    end loop;
    if not l_any then app(io_html, '<div class="dep-item via">Nessuna.</div>'); end if;
    app(io_html, '</div></div>');

    -- Padri: tabelle referenziate dalle FK di questa
    dep_card(io_html, 'Tabelle da cui dipende (FK uscenti)');
    l_any := false;
    for d in ( select distinct rc.table_name
                 from dba_constraints c
                 join dba_constraints rc on rc.owner = c.r_owner and rc.constraint_name = c.r_constraint_name
                where c.owner = i_owner and c.table_name = i_table and c.constraint_type = 'R'
                order by rc.table_name )
    loop
        l_any := true;
        app(io_html, '<div class="dep-item"><span class="kind">tab</span> ' || esc(lower(d.table_name)) || '</div>');
    end loop;
    if not l_any then app(io_html, '<div class="dep-item via">Nessuna.</div>'); end if;
    app(io_html, '</div></div>');

    -- Oggetti che la referenziano nel codice
    dep_card(io_html, 'Oggetti che la referenziano');
    l_any := false;
    for d in ( select name, type
                 from dba_dependencies
                where referenced_owner = i_owner and referenced_name = i_table and referenced_type = 'TABLE'
                order by type, name )
    loop
        l_any := true;
        app(io_html, '<div class="dep-item"><span class="kind">' || esc(lower(substr(d.type, 1, 3))) || '</span> ' || esc(lower(d.name)) || '</div>');
    end loop;
    if not l_any then app(io_html, '<div class="dep-item via">Nessuno.</div>'); end if;
    app(io_html, '</div></div>');

    app(io_html, '</div></section>' || chr(10));
end render_dipendenze;
--------------------------------------------------------------------------------
procedure render_sinonimi(io_html in out nocopy clob, i_owner in varchar2, i_table in varchar2)
-- Sinonimi che puntano a questa tabella: nome, schema, tipo (privato/pubblico), target.
is
    l_count  pls_integer;
begin
    select count(*)
      into l_count
      from dba_synonyms
     where table_owner = i_owner and table_name = i_table;

    app(io_html, '<section id="sinonimi"><h2 class="sect">Sinonimi <span class="count">' || to_char(l_count) || '</span></h2>');

    if l_count = 0
    then
        app(io_html, '<div class="empty">Nessun sinonimo.</div></section>' || chr(10));
        return;
    end if;

    app(io_html, '<div class="table-wrap"><table><thead><tr>'
        || '<th>Sinonimo</th><th>Schema</th><th>Tipo</th><th>Punta a</th></tr></thead><tbody>');

    for s in ( select synonym_name, owner
                 from dba_synonyms
                where table_owner = i_owner and table_name = i_table
                order by owner, synonym_name )
    loop
        app(io_html, '<tr><td class="ident">' || esc(lower(s.synonym_name)) || '</td>'
            || '<td class="ident">' || esc(s.owner) || '</td>'
            || '<td class="nullable">' || case when s.owner = 'PUBLIC' then 'pubblico' else 'privato' end || '</td>'
            || '<td class="ident">' || esc(i_owner) || '.' || esc(lower(i_table)) || '</td></tr>');
    end loop;

    app(io_html, '</tbody></table></div></section>' || chr(10));
end render_sinonimi;
--------------------------------------------------------------------------------
procedure render_grant(io_html in out nocopy clob, i_owner in varchar2, i_table in varchar2)
-- Privilegi di oggetto concessi sulla tabella: privilegio, grantee, con opzione.
is
    l_count  pls_integer;
begin
    select count(*)
      into l_count
      from dba_tab_privs
     where owner = i_owner and table_name = i_table;

    app(io_html, '<section id="grant"><h2 class="sect">Grant <span class="count">' || to_char(l_count) || '</span></h2>'
        || '<p class="sect-note">Privilegi di oggetto concessi ai ruoli di profilo, non utente per utente.</p>');

    if l_count = 0
    then
        app(io_html, '<div class="empty">Nessuna grant.</div></section>' || chr(10));
        return;
    end if;

    app(io_html, '<div class="table-wrap"><table><thead><tr>'
        || '<th>Privilegio</th><th>Grantee</th><th>Con opzione</th></tr></thead><tbody>');

    for g in ( select privilege, grantee, grantable
                 from dba_tab_privs
                where owner = i_owner and table_name = i_table
                order by grantee, privilege )
    loop
        app(io_html, '<tr><td class="nn">' || esc(g.privilege) || '</td>'
            || '<td class="ident">' || esc(g.grantee) || '</td>'
            || '<td class="nullable">' || case when g.grantable = 'YES' then 'SÌ' else 'NO' end || '</td></tr>');
    end loop;

    app(io_html, '</tbody></table></div></section>' || chr(10));
end render_grant;
--------------------------------------------------------------------------------
procedure render_statistiche(io_html in out nocopy clob, i_owner in varchar2, i_table in varchar2)
-- Sezione opzionale: i dati principali dell'ottimizzatore per tabella e colonne,
-- come all'ultimo calcolo. Presente solo se le statistiche di tabella esistono.
is
    l_num_rows    dba_tables.num_rows%type;
    l_blocks      dba_tables.blocks%type;
    l_avg_len     dba_tables.avg_row_len%type;
    l_sample      dba_tables.sample_size%type;
    l_analyzed    dba_tables.last_analyzed%type;
begin
    select num_rows, blocks, avg_row_len, sample_size, last_analyzed
      into l_num_rows, l_blocks, l_avg_len, l_sample, l_analyzed
      from dba_tables
     where owner = i_owner and table_name = i_table;

    app(io_html, '<section id="statistiche"><h2 class="sect">Statistiche <span class="count">opzionale</span></h2>');

    if l_analyzed is null
    then
        app(io_html, '<div class="empty">Statistiche non calcolate.</div></section>' || chr(10));
        return;
    end if;

    app(io_html, '<p class="sect-note">Solo i dati principali dell''ottimizzatore, come fotografati all''ultimo calcolo.</p>'
        || '<h3 class="group">Tabella <span class="g-kind">cardinalità</span></h3><div class="spec">');
    spec_cell(io_html, 'Righe', n_int(l_num_rows));
    spec_cell(io_html, 'Blocchi', n_int(l_blocks));
    spec_cell(io_html, 'Lungh. media riga', case when l_avg_len is null then k_NBSP else n_int(l_avg_len) || ' byte' end);
    spec_cell(io_html, 'Campione', n_int(l_sample));
    spec_cell(io_html, 'Ultimo calcolo', fmt_dt(l_analyzed));
    app(io_html, '</div>');

    app(io_html, '<h3 class="group">Colonne <span class="g-kind">principali</span></h3>'
        || '<div class="table-wrap"><table><thead><tr>'
        || '<th>Colonna</th><th>Valori distinti</th><th>Nulli</th><th>Densità</th><th>Ultimo calcolo</th></tr></thead><tbody>');

    for s in ( select column_name, num_distinct, num_nulls, density, last_analyzed
                 from dba_tab_col_statistics
                where owner = i_owner and table_name = i_table
                order by column_name )
    loop
        app(io_html, '<tr><td class="ident">' || esc(lower(s.column_name)) || '</td>'
            || '<td class="ident">' || n_int(s.num_distinct) || '</td>'
            || '<td class="ident">' || n_int(s.num_nulls) || '</td>'
            || '<td class="ident">' || n_dec(s.density) || '</td>'
            || '<td class="ident">' || case when s.last_analyzed is null then k_NBSP else to_char(s.last_analyzed, 'YYYY-MM-DD') end || '</td></tr>');
    end loop;

    app(io_html, '</tbody></table></div></section>' || chr(10));
end render_statistiche;
--------------------------------------------------------------------------------
procedure render_foot(io_html in out nocopy clob, i_owner in varchar2)
-- Chiusura di main e shell, footer con provenienza e script (tema + scrollspy).
is
begin
    app(io_html, '</main></div>' || chr(10));
    app(io_html, '<footer class="page">Generato da <span class="mono">gen_doc</span> &middot; schema <span class="mono">'
        || esc(i_owner) || '</span> &middot; <span class="mono">' || to_char(sysdate, 'YYYY-MM-DD HH24:MI') || '</span></footer>' || chr(10));
    app(io_html, q'~<script>
  (function () {
    var root = document.documentElement;
    var btn = document.getElementById('themeToggle');
    var icon = document.getElementById('themeIcon');
    var label = document.getElementById('themeLabel');
    function apply(t) {
      root.setAttribute('data-theme', t);
      icon.textContent = t === 'dark' ? '☾' : '☀';
      label.textContent = t === 'dark' ? 'Scuro' : 'Chiaro';
    }
    var prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    apply(prefersDark ? 'dark' : 'light');
    btn.addEventListener('click', function () {
      apply(root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark');
    });
    var links = Array.prototype.slice.call(document.querySelectorAll('nav.toc a'));
    var map = {};
    links.forEach(function (a) { map[a.getAttribute('href').slice(1)] = a; });
    var obs = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) {
          links.forEach(function (l) { l.classList.remove('active'); });
          if (map[e.target.id]) map[e.target.id].classList.add('active');
        }
      });
    }, { rootMargin: '-10% 0px -80% 0px', threshold: 0 });
    document.querySelectorAll('main section[id]').forEach(function (s) { obs.observe(s); });
  })();
</script>
</body>
</html>~');
end render_foot;
--------------------------------------------------------------------------------

-- table_page ==================================================================
function table_page( i_owner      in varchar2
                   , i_table_name in varchar2
                   )
    return clob
is
    l_owner    varchar2(128 char) := upper(trim(i_owner));
    l_table    varchar2(128 char) := upper(trim(i_table_name));
    l_html     clob;
    l_comment  dba_tab_comments.comments%type;
    l_exists   pls_integer;
begin
    -- Esistenza della tabella nello schema
    select count(*)
      into l_exists
      from dba_tables
     where owner = l_owner and table_name = l_table;

    if l_exists = 0
    then
        lib_err.raise(lib_err.k_INVALID_PARAMETER, l_owner || '.' || l_table, i_scope => k_SCOPE);
    end if;

    -- Commento di tabella (può mancare)
    begin
        select comments
          into l_comment
          from dba_tab_comments
         where owner = l_owner and table_name = l_table;
    exception
        when no_data_found then l_comment := null;
    end;

    dbms_lob.createtemporary(l_html, true);

    render_head(l_html, l_owner, l_table);
    render_header(l_html, l_owner, l_table, l_comment);
    render_panoramica(l_html, l_owner, l_table);
    render_colonne(l_html, l_owner, l_table);
    render_dettaglio(l_html, l_owner, l_table);
    render_constraint(l_html, l_owner, l_table);
    render_indici(l_html, l_owner, l_table);
    render_partizionamento(l_html, l_owner, l_table);
    render_trigger(l_html, l_owner, l_table);
    render_dipendenze(l_html, l_owner, l_table);
    render_sinonimi(l_html, l_owner, l_table);
    render_grant(l_html, l_owner, l_table);
    render_statistiche(l_html, l_owner, l_table);
    render_foot(l_html, l_owner);

    return l_html;
end table_page;
--------------------------------------------------------------------------------
procedure generate_table( i_owner      in varchar2
                        , i_table_name in varchar2
                        , i_directory  in varchar2
                        )
is
    l_owner  varchar2(128 char) := upper(trim(i_owner));
    l_table  varchar2(128 char) := upper(trim(i_table_name));
    l_html   clob;
    l_file   varchar2(512 char);
begin
    l_html := table_page(l_owner, l_table);
    l_file := object_file_name(l_owner, k_TYPE_TABLE, l_table);

    write_file(i_directory => i_directory, i_filename => l_file, i_content => l_html);

    if dbms_lob.istemporary(l_html) = 1
    then
        dbms_lob.freetemporary(l_html);
    end if;
exception
    when others
    then
        if l_html is not null and dbms_lob.istemporary(l_html) = 1
        then
            dbms_lob.freetemporary(l_html);
        end if;
        raise;
end generate_table;
--------------------------------------------------------------------------------
procedure generate_schema_tables( i_owner     in varchar2
                                , i_directory in varchar2
                                )
is
    l_owner  varchar2(128 char) := upper(trim(i_owner));
begin
    for t in ( select table_name
                 from dba_tables
                where owner = l_owner
                  and nested = 'NO'
                  and secondary = 'N'
                  and (iot_type is null or iot_type = 'IOT')
                  and table_name not like 'BIN$%'
                order by table_name )
    loop
        generate_table(l_owner, t.table_name, i_directory);
    end loop;
end generate_schema_tables;
--------------------------------------------------------------------------------

end gen_doc;
/

show errors package body gen_doc

prompt File: gen_doc.pkb.sql <end>
