prompt File: gen_doc.pks.sql <start>
-- =============================================================================
-- File:     gen_doc.pks.sql
-- Oggetto:  gen_doc (specifica del package)
-- Schema:   #APP#_GEN (SOLO DEV/TEST)
-- Scopo:    Genera la documentazione HTML degli oggetti di uno schema a partire
--           dal dizionario dati. Il disegno separa il RENDERING dalla SCRITTURA:
--           la funzione *_page legge i metadati e restituisce un CLOB HTML senza
--           effetti collaterali (testabile senza una DIRECTORY), le procedure
--           generate_* lo scrivono su file. Prima ondata: le TABELLE; gli altri
--           tipi di oggetto e l'indice di schema arrivano dopo.
-- Naming:   in generazione i file escono PIATTI in un'unica DIRECTORY con nomi
--           <schema>_<tipo>_<nome>.html (minuscolo). L'unicità dei nomi, non le
--           cartelle, evita le sovrascritture; l'alberatura di pubblicazione si
--           ottiene poi spostando i file (vedi Templates/README.md). I link nelle
--           pagine sono già scritti per l'alberatura, quindi nella dir piatta non
--           risolvono: è normale, la dir piatta è solo trasporto.
-- Lettura:  viste DBA_* (grant mirate a #APP#_GEN in SYS/Grants/#APP#_gen.grt.sql).
-- Scrittura: sys.utl_file diretto (richiede execute su sys.utl_file e una
--           DIRECTORY di output grantata a #APP#_gen, dev/test only). NON passa da
--           lib_file, così le directory di generazione restano confinate allo
--           schema dev/test.
-- Nota:     il foglio di stile gen_doc.css NON è emesso da qui: è un asset statico
--           mantenuto nel repo (Templates/files/) e deployato alla pubblicazione.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260731  AA   Creazione (specifica; prima ondata: tabelle)
-- =============================================================================

prompt gen_doc: Creating package specification

create or replace
package gen_doc
is

-- Tipi di oggetto documentati, usati nella convenzione di naming dei file.
-- Prima ondata: solo le tabelle. Le costanti evitano stringhe magiche nei
-- chiamanti e fissano il token che finisce nel nome file (<schema>_<tipo>_<nome>).
k_TYPE_TABLE  constant varchar2(30 char) := 'table';

--------------------------------------------------------------------------------
-- Nome file flat di un oggetto, secondo la convenzione <schema>_<tipo>_<nome>.html
-- (tutto minuscolo). È la stessa convenzione che la riorganizzazione verso
-- l'alberatura dà per scontata, quindi è esposta come contratto e non nascosta
-- nel body. Non applica ancora il ripiego sulla lunghezza massima del nome file.
-- i_owner       : schema proprietario dell'oggetto (es. 'GOLD').
-- i_object_type : tipo dell'oggetto (una delle costanti k_TYPE_*).
-- i_object_name : nome dell'oggetto (es. 'ORDERS').
-- return        : nome file, es. 'gold_table_orders.html'.
function object_file_name( i_owner       in varchar2
                         , i_object_type in varchar2
                         , i_object_name in varchar2
                         )
    return varchar2;
--------------------------------------------------------------------------------
-- Rende la pagina HTML completa di una tabella come CLOB. Funzione pura: legge il
-- dizionario e restituisce il markup, senza scrivere nulla. Il CLOB temporaneo
-- restituito va liberato dal chiamante. Solleva un errore applicativo quando la
-- tabella non esiste nello schema indicato.
-- i_owner      : schema proprietario della tabella (es. 'GOLD').
-- i_table_name : nome della tabella (es. 'ORDERS').
-- return       : documento HTML completo della pagina Tabella.
function table_page( i_owner      in varchar2
                   , i_table_name in varchar2
                   )
    return clob;
--------------------------------------------------------------------------------
-- Genera il file HTML di una tabella nella DIRECTORY di output, con nome flat.
-- Rende la pagina con table_page e la scrive con lib_file.write_clob.
-- i_owner      : schema proprietario della tabella (es. 'GOLD').
-- i_table_name : nome della tabella (es. 'ORDERS').
-- i_directory  : nome dell'oggetto DIRECTORY di Oracle in cui scrivere.
procedure generate_table( i_owner      in varchar2
                        , i_table_name in varchar2
                        , i_directory  in varchar2
                        );
--------------------------------------------------------------------------------
-- Genera i file HTML di tutte le tabelle dello schema nella DIRECTORY di output.
-- Itera le tabelle dell'owner e chiama generate_table per ciascuna.
-- i_owner     : schema di cui documentare le tabelle (es. 'GOLD').
-- i_directory : nome dell'oggetto DIRECTORY di Oracle in cui scrivere.
procedure generate_schema_tables( i_owner     in varchar2
                                , i_directory in varchar2
                                );
--------------------------------------------------------------------------------

end gen_doc;
/

show errors package gen_doc

prompt File: gen_doc.pks.sql <end>
