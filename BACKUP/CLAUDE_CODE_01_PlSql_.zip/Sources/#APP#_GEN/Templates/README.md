# Template di output di `gen_doc`

Questa cartella congela la **forma di riferimento** della documentazione HTML che il generatore `gen_doc` (schema `#APP#_GEN`) produce a partire dal dizionario dati. Non è codice PL/SQL: è il *bersaglio* — il markup e lo stile che il body di `gen_doc` deve riprodurre fedelmente. Congelarlo qui separa una decisione di **design** (come si legge la pagina) da una di **implementazione** (come il PL/SQL la emette), così l'una si rivede senza toccare l'altra.

Il contenuto è al tempo stesso un **esempio funzionante**: l'alberatura sotto questa cartella rispecchia la forma pubblicata, quindi la pagina HTML si apre nel browser e carica il proprio foglio di stile senza montare nulla.

## Due fasi: generazione flat, pubblicazione ad albero

C'è una distinzione portante fra **come** i file vengono generati e **come** vengono pubblicati, e le due cose non coincidono per una ragione tecnica.

Il generatore gira nello schema `#APP#_GEN`, che scrive in **un solo oggetto `DIRECTORY`** di Oracle. Le `DIRECTORY` non gestiscono sottocartelle e `lib_file`/`utl_file` vietano i separatori di path nel nome file. Quindi in **generazione** tutto esce **piatto** in quell'unica directory, e a evitare che i file si sovrascrivano non sono le cartelle ma i **nomi**. La directory piatta è uno *staging di trasporto*: non è la forma in cui si consulta la documentazione.

La forma **pubblicata** — quella che l'AM mette a disposizione e quella che si consegna al cliente — è invece l'**alberatura** qui congelata. Il passaggio dall'una all'altra è un semplice **spostamento manuale** (o scriptato) dei file, che si fa comunque quando li si estrae dalla directory del server. È l'appunto qui sotto.

```
Forma pubblicata (alberatura):
<root>/
  files/
    gen_doc.css                        foglio di stile UNICO, condiviso da tutte le pagine
  <SCHEMA>/                            una cartella per schema (qui: GOLD)
    index.html                        indice dello schema, oggetti per tipo (qui: index.html)
    tables/
      table_<nome>.html               una pagina per tabella (qui: table_orders.html)
    views/ packages/ ...              gli altri tipi (da fare)
```

## Appunto: dalla directory flat all'alberatura

In generazione i file escono piatti, con questi nomi (tutto minuscolo):

- foglio di stile: `gen_doc.css`
- indice di schema: `index_<schema>.html`
- pagina di oggetto: `<schema>_<tipo>_<nome>.html`

Il prefisso di schema fa sì che due oggetti omonimi in schemi diversi (`gold.orders` e `sgc.orders`) non collidano; il `tipo` disambigua anche il caso raro di oggetti omonimi di tipo diverso nello stesso schema (una tabella e un package `orders`). Rigenerare riscrive gli stessi nomi in modo deterministico, quindi una riesecuzione **aggiorna** i file senza lasciarne di orfani.

La riorganizzazione verso l'albero è una mappatura fissa:

| Flat (staging) | Albero (pubblicato) |
|---|---|
| `gen_doc.css` | `files/gen_doc.css` |
| `index_<schema>.html` | `<SCHEMA>/index.html` |
| `<schema>_<tipo>_<nome>.html` | `<SCHEMA>/<tipo>s/<nome>.html` |

Esempio: `gold_table_orders.html` → `GOLD/tables/table_orders.html`.

Due punti da tenere presenti nell'implementazione del generatore:

1. **I link nelle pagine sono già scritti per l'albero.** `gen_doc` emette gli `href` relativi alla forma pubblicata (il foglio di stile come `../files/gen_doc.css` dall'indice o `../../files/gen_doc.css` da una pagina in sottocartella; i link incrociati verso altri oggetti come `../tables/table_x.html`). Di conseguenza, nella directory flat i link **non risolvono** — è normale, perché la directory flat è solo trasporto: i link diventano validi dopo lo spostamento. Il nome del file (piatto) e i suoi link interni (ad albero) sono due cose distinte, entrambe note al generatore dal dizionario.
2. **Lunghezza del nome file.** Se `<schema>_<tipo>_<nome>` supera il limite del filesystem, serve un ripiego deterministico (troncamento con suffisso di hash) — da presidiare nel generatore.

## La pagina Tabella (`GOLD/tables/table_orders.html`)

Esempio lavorato sulla tabella `orders` dello schema `GOLD` (la stessa dell'esempio workflow in `Gestione_Sorgenti/Templates/Esempi/`), scelta perché mette in mostra quasi tutti i casi limite: colonna **virtuale** (`status_wfl`), blocco di **audit invisibile**, **foreign key composita** verso `wfl_statuses`, primary key, indice e trigger.

Le sezioni, nell'ordine: intestazione (nome + commento della tabella), **Panoramica** (attributi strutturali da `*_tables`/`*_objects`, senza statistiche), **Colonne** (nome, tipo, nullità, default, chiave, commento), **Dettaglio colonne** (solo colonne con tratti aggiuntivi), **Constraint** (raggruppati per tipo: PK, FK, unique, check), **Indici**, **Partizionamento** (opzionale), **Trigger** (anagrafica, senza corpo), **Dipendenze** (figlie via FK entranti, padri via FK uscenti, oggetti referenzianti da `*_dependencies`), **Sinonimi**, **Grant** e **Statistiche** (opzionale, solo i dati principali dell'ottimizzatore).

## L'indice di schema (`GOLD/index.html`)

La porta d'ingresso di uno schema: elenca gli oggetti **per tipo**, con il menu laterale che ripete i tipi nell'ordine dell'albero di SQL Developer (Tabelle → Viste → Viste materializzate → Package → Trigger → Job, ...), **non alfabetico**, e con i soli tipi effettivamente presenti. In cima una **Panoramica** con i conteggi per tipo. Tabelle, viste e viste materializzate mostrano **nome + descrizione** (il commento a dizionario); i tipi senza commento (package, trigger, job) mostrano **nome + stato** (`VALID`/`INVALID`, `ENABLED`/`DISABLED`) — utile a chi mantiene, perché un oggetto `INVALID` salta all'occhio in rosso. Ogni voce è un link alla pagina dell'oggetto (`tables/table_orders.html`, `packages/package_lib_config.html`, ...); il breadcrumb di una pagina di oggetto rientra all'indice sull'ancora del proprio tipo (`../index.html#tabelle`).

## Il foglio di stile condiviso (`gen_doc.css`)

Un unico `gen_doc.css` in `files/`, linkato da ogni pagina con il prefisso relativo adeguato alla propria profondità. Un solo file da ridisegnare, look identico su tutte le pagine. Larghezza del contenuto al 95% della pagina; sottotitolo e note di sezione seguono la larghezza della colonna (nessun cap sulla riga, per non andare a capo a metà pagina su schermi larghi). Tema chiaro/scuro via `prefers-color-scheme` con override su `:root[data-theme]`, layout responsive. Lo stato degli oggetti è reso con le pill `pill-ok` (verde), `pill-off` (grigio) e `pill-crit` (rosso, per gli oggetti INVALID).

## Principi di design incisi nel template

- **Due voci tipografiche** che rispecchiano la regola dei due assi del framework: **monospace** per gli identificatori (i nomi inglesi: tabelle, colonne, tipi) e **sans** per la prosa (i commenti italiani). Il documento rende visibile il principio linguistico.
- **Solo fatti dal dizionario**: la sezione Dettaglio colonne mostra valori estraibili (espressione della colonna virtuale, visibilità, funzione e parametri di redaction) e **nessuna prosa interpretativa**. L'unico testo descrittivo per colonna è il commento (`*_col_comments`), già mostrato nella tabella Colonne.
- **Stato codificato nella forma**: chip `PK`/`FK`, tag `virtuale`/`invisibile`/`partizionato`, pill di stato dei constraint.
- **Niente NOT NULL fra i check**: la nullità è resa come flag nella tabella colonne, così la sezione Check resta pulita e mostra solo i check applicativi veri.

## Stato

Congelati l'**indice di schema**, la pagina **Tabella** e il foglio di stile condiviso, in forma ad albero. Restano da produrre, come pagine, gli **altri tipi di oggetto** (viste, package, trigger, job, ...), e — come codice — il completamento del body di `gen_doc` (per ora rende solo le tabelle; l'indice e gli altri tipi vanno aggiunti), il provisioning/install dello schema `#APP#_GEN` e la `DIRECTORY` di output.
