prompt File: install.ins.sql <start>
-- =============================================================================
-- File:     install.ins.sql
-- Oggetto:  Orchestratore di install dello schema #APP#_GEN (tooling di generazione)
-- Schema:   #APP#_GEN (solo ambienti di sviluppo/test)
-- Scopo:    Installa i package di generazione nell'ordine di dipendenza (prima le
--           specifiche, poi i corpi). Eseguire connessi come #APP#_GEN, dopo che
--           #APP# è installato e dopo il provisioning (utente e grant di sistema in
--           SYS, grant di oggetto dall'owner, sinonimi privati). MAI in produzione,
--           MAI in un pacchetto di release.
-- Prereq.:  un oggetto DIRECTORY di output scrivibile dall'owner #APP# (deciso a
--           parte); non è creato qui.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260801  AA   Creazione (prima ondata: gen_doc)
-- =============================================================================

whenever sqlerror exit failure rollback
whenever oserror  exit failure
set echo        off
set feedback     on
set define       off
set serveroutput on size unlimited

prompt ============================================================
prompt Install #APP#_GEN tooling di generazione: start
prompt ============================================================

prompt #APP#_GEN: Specifiche dei package
@@../Packages/gen_doc.pks.sql

prompt #APP#_GEN: Corpi dei package
@@../Packages/gen_doc.pkb.sql

prompt ============================================================
prompt Install #APP#_GEN tooling di generazione: completed
prompt Esempio d'uso (la DIRECTORY di output e creata in SYS/Directories/):
prompt   begin gen_doc.generate_table('GOLD', 'ORDERS', '#APP#_OUTPUT_DOCGEN'); end;
prompt   begin gen_doc.generate_schema_tables('GOLD', '#APP#_OUTPUT_DOCGEN'); end;
prompt I file escono flat; per la forma pubblicata ad albero vedi Templates/README.md
prompt ============================================================
prompt File: install.ins.sql <end>
