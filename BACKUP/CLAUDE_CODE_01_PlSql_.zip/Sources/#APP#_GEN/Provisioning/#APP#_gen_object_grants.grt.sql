prompt File: #APP#_gen_object_grants.grt.sql <start>
-- =============================================================================
-- File:     #APP#_gen_object_grants.grt.sql
-- Oggetto:  Grant di oggetto da #APP# a #APP#_gen
-- Schema:   eseguire come owner #APP#
-- Scopo:    Concede al tooling di generazione l'EXECUTE su #APP#.lib_err, usato per
--           segnalare (es. la tabella non trovata). La SCRITTURA dei file NON passa
--           da lib_file: gen_doc usa sys.utl_file diretto (opzione B), così le
--           directory di generazione restano grantate a #APP#_gen e non all'owner
--           #APP#, e non compaiono nei grant di uno schema di produzione. L'EXECUTE
--           su sys.utl_file e i READ/WRITE sulle DIRECTORY sono in
--           SYS/Grants/#APP#_gen.grt.sql (lato privilegiato).
--
--           GRANT DIRETTE ALL'UTENTE, non a un ruolo - da leggere. I package gen_*
--           sono a diritti del definer, e i privilegi concessi tramite ruolo NON
--           sono visibili né in esecuzione né in COMPILAZIONE di un'unità PL/SQL.
--           Un EXECUTE dato via ruolo lascerebbe gen_doc non compilabile pur
--           funzionando in SQL interattivo. Stesso principio delle grant di
--           dizionario in SYS/Grants/#APP#_gen.grt.sql (soluzione A).
--
--           ECCEZIONE ALL'INVARIANTE DEL GUSCIO. Come per #APP#_TST: si granta la
--           logica dal nome pulito (lib_err), non il guscio _shell. Non è una
--           violazione ma il confine dell'invariante - il guscio protegge dai
--           CONSUMATORI IN PRODUZIONE, e #APP#_GEN in produzione NON ESISTE. Vedi
--           Architettura_DB/schemi.md.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260801  AA   Creazione (provisioning gen_doc)
--   20260801  AA   Opzione B: rimosso il grant su lib_file (scrittura via utl_file)
-- =============================================================================

prompt #APP#_gen: EXECUTE diretto su lib_err (segnalazione)

grant execute on lib_err to #APP#_gen;   -- segnalazione (tabella non trovata, ...)

prompt File: #APP#_gen_object_grants.grt.sql <end>
