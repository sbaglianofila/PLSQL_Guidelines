prompt File: #APP#_gen_synonyms.syn.sql <start>
-- =============================================================================
-- File:     #APP#_gen_synonyms.syn.sql
-- Oggetto:  Sinonimi privati di #APP#_GEN verso l'owner #APP#
-- Schema:   eseguire in fase di provisioning da un'utenza con CREATE ANY SYNONYM
-- Scopo:    Crea nello schema di tooling il sinonimo privato che permette ai
--           generatori di citare lib_err col nome pulito, senza qualificare con il
--           nome dell'owner (che cambia da progetto a progetto). Stessa via di
--           schemi.md e di #APP#_TST: i sinonimi privati dei consumer si creano al
--           provisioning da un'utenza di installazione, così lo schema di tooling
--           resta senza CREATE SYNONYM. Il grant sottostante è in
--           #APP#_gen_object_grants.grt.sql.
--           Nota: sotto opzione B la scrittura dei file usa sys.utl_file diretto,
--           quindi NON serve un sinonimo verso lib_file. Le viste DBA_* non hanno
--           bisogno di sinonimi (Oracle ne pubblica già i pubblici); l'accesso è
--           dato dalle grant di dizionario dirette in SYS/Grants/#APP#_gen.grt.sql.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260801  AA   Creazione (provisioning gen_doc)
--   20260801  AA   Opzione B: rimosso il sinonimo verso lib_file
-- =============================================================================

prompt #APP#_gen: Creating private synonym to #APP#

create synonym #APP#_gen.lib_err for #APP#.lib_err;

prompt File: #APP#_gen_synonyms.syn.sql <end>
