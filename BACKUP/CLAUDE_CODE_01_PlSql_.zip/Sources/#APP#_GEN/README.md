# Schema `#APP#_GEN` — Tooling di generazione

Questo albero ospita il **tooling di generazione** del framework: i package `gen_*` che, leggendo il dizionario dati, producono artefatti derivati — a partire da **`gen_doc`**, che genera la documentazione HTML degli oggetti di uno schema. È lo schema gemello di `#APP#_TST` sul piano del ciclo di vita: esiste **solo negli ambienti di sviluppo e test**, non deve mai comparire in produzione e i suoi script restano fuori dai pacchetti di release. Legge ed **emette artefatti**; non scrive sugli oggetti di `#APP#` e non riceve alcun privilegio di DDL sull'owner.

Il codice è **codice del framework a tutti gli effetti**: segue le convenzioni (identificatori inglesi, commenti italiani UTF-8, stile di codifica, un file per oggetto) come qualsiasi altro sorgente. Il prefisso `gen_` è quello del tooling, in fila con gli altri prefissi di pillar.

## Organizzazione

- `Packages/` — i package di generazione: **`gen_doc`** (spec + body) per la documentazione dal dizionario. Seguiranno `gen_shell`, `gen_testbook`, `gen_qc`.
- `Templates/` — la **forma di riferimento congelata** dell'output di `gen_doc`: il foglio di stile condiviso `gen_doc.css`, la pagina Tabella e l'indice di schema d'esempio, con il proprio `README.md` (alberatura di pubblicazione, convenzione di naming, appunto di riorganizzazione flat → albero). Non è codice PL/SQL ma il bersaglio che il body di `gen_doc` riproduce.
- `Provisioning/` — grant di oggetto dall'owner e sinonimi privati (vedi sotto).
- `Install/install.ins.sql` — l'orchestratore che installa i package nell'ordine di dipendenza.

## Come `gen_doc` legge e scrive

- **Legge** i metadati dalle viste **`DBA_*`**, con grant *dirette e mirate* (soluzione A) in `Sources/SYS/Grants/#APP#_gen.grt.sql` — non `select_catalog_role`/`select any dictionary`, perché un ruolo non è visibile dentro il PL/SQL a diritti del definer.
- **Scrive** i file via **`sys.utl_file` diretto** (opzione B), *non* via `lib_file`: così le sue directory di output restano grantate al solo `#APP#_GEN` dev/test, mai all'owner di produzione. **Segnala** gli errori con **`#APP#.lib_err`** (`EXECUTE` **diretto** a `#APP#_gen`, non via ruolo, per la ragione della compilazione definer's rights). L'`EXECUTE` su `sys.utl_file` e i READ/WRITE sulle directory sono in `SYS/Grants/#APP#_gen.grt.sql`.
- Il disegno separa il **rendering** dalla **scrittura**: `table_page` è una funzione pura che restituisce il CLOB della pagina; `generate_table`/`generate_schema_tables` lo scrivono su file. La generazione è *flat* in un'unica `DIRECTORY`, la pubblicazione è ad *albero* — vedi `Templates/README.md`.

## Provisioning e la deroga al meccanismo guscio

Poiché i generatori vivono **fuori** da `#APP#`, per usarne le librerie lo schema riceve `EXECUTE` sui package di **logica dal nome pulito** (`lib_file`, `lib_err`) — non sul guscio `_shell`. È la stessa deroga controllata di `#APP#_TST`, deliberata: il guscio protegge il codice dai consumatori **in produzione**, dove `#APP#_GEN` non esiste. Il ragionamento completo è in `Architettura_DB/schemi.md`.

Ordine di provisioning (una tantum per ambiente), da eseguire prima dell'install:

1. `Sources/SYS/Users/#APP#_gen.usr.sql` — come DBA: crea l'utente.
2. `Sources/SYS/Directories/#APP#_output_docgen.dir.sql` e `#APP#_output_codegen.dir.sql` — come DBA: creano le directory di output (SOLO dev/test; il path è per-ambiente).
3. `Sources/SYS/Grants/#APP#_gen.grt.sql` — come DBA: `CREATE SESSION`, privilegi di creazione dei propri oggetti, `EXECUTE` su `sys.utl_file`, READ/WRITE sulle directory di output, e grant *dirette* sulle viste `DBA_*` (soluzione A).
4. `Provisioning/#APP#_gen_object_grants.grt.sql` — come owner `#APP#`: `EXECUTE` diretto su `lib_err`.
5. `Provisioning/#APP#_gen_synonyms.syn.sql` — come utenza con `CREATE ANY SYNONYM`: sinonimo privato `lib_err` verso `#APP#`.

Poi, come `#APP#_GEN`: `@@Install/install.ins.sql`.

## La DIRECTORY di output

`gen_doc` scrive in un oggetto `DIRECTORY` di Oracle passato come parametro. Le directory di generazione sono materializzate in `Sources/SYS/Directories/` (`#APP#_output_docgen`, `#APP#_output_codegen`), create come DBA **solo in dev/test** e con READ/WRITE concesso a `#APP#_GEN` (opzione B: scrittura via `utl_file` diretto). Il **path sul filesystem** resta un segnaposto per-ambiente, da sostituire al provisioning. La strategia completa delle directory — inclusi i canali di integrazione coi sistemi esterni — è in `Sources/SYS/Directories/README.md`.
