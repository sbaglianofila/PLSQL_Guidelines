# Precondizioni di esecuzione — il gate dei main process

Questo documento descrive il meccanismo con cui un'elaborazione decide, all'ingresso, se ha senso che parta. Riguarda `lib_gate`, le tabelle `cfg_gate_*` e il modo in cui il verdetto si innesta nel ciclo di vita dei run gestito da `lib_batch`. Va letto insieme a `pacchetti_base.md`, che colloca questi package nel quadro generale, e a `Architettura_DB/colonne_amministrative.md` per la parte di audit delle tabelle.

## Il problema

Ogni elaborazione seria comincia con una manciata di controlli che non c'entrano nulla con quello che l'elaborazione fa. Sono girato sul database giusto? Il processo è abilitato o qualcuno l'ha spento la settimana scorsa? Il carico anagrafiche di stanotte è andato a buon fine, o sto per elaborare su una base incompleta? C'è effettivamente qualcosa da elaborare? Sono dentro la finestra in cui mi è concesso girare?

Scritti a mano, questi controlli hanno tre difetti che si presentano puntualmente. Vengono copiati da un processo all'altro con piccole varianti, così che sistemarne uno non sistema gli altri. Finiscono cablati nel codice, per cui sospendere temporaneamente un processo richiede un rilascio invece di un `update`. E soprattutto comprimono in un booleano due situazioni che non sono affatto la stessa cosa: "non c'è niente da fare" e "il mondo non è come dovrebbe essere". Chi presidia i batch di notte paga questo terzo difetto tutte le volte, perché o si soffocano gli errori veri dentro uscite silenziose, oppure si alza un allarme ogni volta che un processo trova la coda vuota.

Il gate risolve esattamente questi tre difetti, e nient'altro. Non orchestra, non pianifica, non decide al posto di nessuno.

## Le tre idee su cui si regge

### Separare valutare, decidere e agire

`lib_gate` valuta le regole e restituisce un verdetto. Non scrive sul registro dei run, non manda notifiche, non fa `return` al posto del chiamante, e non solleva eccezioni per le condizioni che sta valutando. È il chiamante che, ricevuto il verdetto, decide che farsene.

La separazione sembra un formalismo e invece è ciò che rende il meccanismo riusabile. La stessa identica regola — mettiamo, la finestra oraria 22:00–05:00 — deve poter essere bloccante per un processo che non ha alcun motivo di girare di giorno, e puramente informativa per un altro che di norma gira di notte ma che ogni tanto si rilancia a mano. Se il gate decidesse da sé, per ottenere due comportamenti servirebbero due gate.

### Il verdetto è ternario, mai booleano

Le decisioni possibili sono tre: `RUN`, `SKIP`, `ABORT`. La distinzione fra le ultime due è la ragione di esistere dell'intero meccanismo.

`SKIP` è la condizione fisiologica: non c'è niente da elaborare, siamo fuori finestra, oggi è festivo. Il processo deve terminare in modo pulito e silenzioso, e va bene così — non è successo niente di male. `ABORT` è l'anomalia: il predecessore è fallito, sto girando sul database sbagliato, manca un parametro di configurazione. Qui il processo deve fermarsi rumorosamente, perché qualcuno deve guardare.

Comprimere le due cose in un `boolean` porta sempre in uno dei due fossi. Se si tratta tutto come uscita pulita, gli errori veri passano inosservati fino a quando qualcuno non nota, tre giorni dopo, che una tabella è vuota. Se si tratta tutto come errore, il turno di reperibilità viene svegliato ogni notte in cui la coda è vuota, e nel giro di due settimane l'allarme viene ignorato per abitudine — che è il modo peggiore di perdere un allarme.

### Il dispatch è statico

Il tipo di regola è un codice di un dominio chiuso, e nel body di `lib_gate` un `case` mappa ogni codice a una funzione privata compilata. Non si mettono nomi di funzione in tabella da eseguire con `execute immediate`.

La tentazione c'è, perché quella flessibilità sembra gratis, e non lo è. Con il dispatch dinamico si perdono le dipendenze nel dizionario dati, quindi rinominare qualcosa smette di rompere la compilazione e comincia a rompere la produzione; il debug diventa archeologia; e l'analisi d'impatto prima di una modifica non è più possibile con gli strumenti standard. Il livello giusto di dinamicità è quello che il framework adotta anche altrove: **quali** regole valgono per **quale** processo è configurazione, **come** si valuta una regola è codice.

Da qui discende una regola operativa non negoziabile, e vale la pena enunciarla in modo esplicito perché è la prima a saltare quando il meccanismo viene esteso in fretta: **nessuna funzione di check può avere effetti collaterali**. Niente `commit`, niente `rollback`, niente DML, niente transazioni autonome, niente chiamate a servizi esterni. Un check è un'interrogazione pura, richiamabile un numero arbitrario di volte con lo stesso esito. Se questa invarianza salta, il gate diventa esso stesso una sorgente di stato e non è più possibile ragionarci sopra — la suite di test la verifica esplicitamente, chiamando `evaluate` due volte di seguito e confrontando i verdetti.

## Quattro domande diverse, quattro meccanismi diversi

Prima di entrare nel dettaglio conviene fissare i confini, perché il gate ha tre vicini che gli somigliano abbastanza da invogliare ad accorparli, e sarebbe un errore.

| Domanda | Chi risponde | Natura del "no" |
|---|---|---|
| **Chi** sta chiedendo, ne ha diritto? | `lib_authz` | Sempre un errore. È sicurezza: fail-closed, `k_NOT_ALLOWED` |
| Ne sta già girando **un'altra istanza**? | `lib_lock`, via `lib_batch.start_run` | Non è una valutazione: è l'acquisizione di una risorsa |
| **Ha senso partire** adesso, qui, così? | `lib_gate` | Ternario: può essere fisiologico (`SKIP`) o anomalo (`ABORT`) |
| Questa **entità** può cambiare stato? | `lib_workflow.check_guard` | Criterio sul dato, non sull'esecuzione |

I permessi e le precondizioni sono le due che più spesso si vorrebbero unire, ed è proprio l'unione da evitare. `lib_authz` risponde a una domanda sul **soggetto** e la sua risposta è binaria per costruzione: un diniego di permesso è sempre un errore, non esiste un diniego fisiologico. `lib_gate` risponde a una domanda sul **contesto di esecuzione** e la sua risposta è ternaria. Sono due assi indipendenti: un utente autorizzatissimo può benissimo lanciare un processo in un momento in cui non ha senso che parta, e un processo perfettamente tempestivo può essere lanciato da chi non ne ha diritto.

In concreto questo significa due regole che non si aggirano. Nel gate **non esiste** un tipo di regola `AUTHZ`, e in `adm_profile_functionalities` **non esistono** finestre orarie. Se un batch deve girare con un'identità applicativa, la imposta `lib_session.set_actor`, e l'eventuale controllo dei permessi lo fa `lib_authz.assert_access` come chiamata separata e visibile nel codice. Due asserzioni distinte in due righe distinte costano una riga in più e si mantengono da sole.

Sul terzo vicino c'è una nota terminologica da tenere presente. Il pillar workflow usa già la parola `guard` (`wfl_transition_guards`, `guard_code`, `guard_handler`), che in italiano chiamiamo *criteri*: sono guardie sull'**entità**, valutano se un ordine può passare da uno stato all'altro. Le precondizioni di questo documento sono guardie sull'**esecuzione**. Per questo il package si chiama `lib_gate` e non `lib_guard`: la collisione di nome su due concetti diversi sarebbe costata più di quanto costi ricordarsi due parole.

## La sequenza: il gate sta dentro il run, non prima

Questo è il punto che più facilmente si sbaglia, e la scelta è deliberata. La sequenza corretta è:

1. `lib_batch.start_run` — apre il run, e prende il lock di istanza singola se richiesto
2. `lib_authz.assert_access` — chi sta lanciando, quando c'è un chiamante da verificare
3. `lib_batch.check_gate` — se ha senso partire
4. il corpo dell'elaborazione, con i `checkpoint`
5. `lib_batch.end_run` sul successo, `fail_run` nell'handler

La tentazione naturale è valutare le precondizioni **prima** di aprire il run: sembra più pulito, e soprattutto evita di sporcare il registro con righe di processi che non hanno fatto nulla. È esattamente il ragionamento da non seguire.

Se il gate sta prima dello `start_run`, un processo che non parte perché fuori finestra, o che viene bloccato perché il predecessore è fallito, non lascia **nessuna** riga in `log_process_runs`. E l'assenza di righe è ambigua nel modo peggiore possibile: non distingue "il processo ha valutato la situazione e ha deciso di non partire" da "il processo non è mai stato lanciato, e il problema è nello scheduler". Sono due diagnosi opposte, con due interventi opposti, e alle tre di notte è precisamente la distinzione che serve. Un registro delle esecuzioni che tace proprio quando le cose non vanno come previsto non sta rispondendo alla domanda per cui esiste.

Tenendo il gate dentro il run, invece, il verdetto ternario si mappa uno a uno sugli esiti già previsti dal registro, senza bisogno di inventare niente:

| Verdetto | Esito su `log_process_runs` | Chi lo scrive |
|---|---|---|
| `RUN` | resta `RUNNING`, poi `SUCCESS` a fine corsa | `end_run` |
| `SKIP` | `SKIPPED`, con il motivo in `error_message` | `skip_run`, chiamata da `check_gate` |
| `ABORT` | `FAILED`, con l'errore in `error_message` | `fail_run`, dall'handler del chiamante |

Il lock di istanza singola resta invece **prima** di tutto, dentro `start_run`, e per una ragione diversa da tutte le altre: acquisire un lock non è valutare una precondizione. Se un'altra istanza sta già girando, la seconda non deve nemmeno esistere come run — non è un'esecuzione saltata, è un'esecuzione che non è cominciata. Per questo `start_run` prende il lock prima dell'insert, e un avvio bloccato non lascia riga.

Sull'`ABORT` c'è una scelta che vale la pena motivare: `check_gate` si limita a sollevare, e non chiude il run. Potrebbe chiuderlo come `FAILED` e poi sollevare, ma duplicherebbe il lavoro dell'handler del chiamante — che deve esserci comunque, per tutti gli altri errori che possono capitare nel corpo. Una sola strada verso `FAILED` è più facile da tenere corretta di due.

## Il modello dati

La configurazione vive in tre tabelle, tutte con prefisso `cfg_` perché contengono dati che modificano il comportamento dell'applicazione — la definizione stessa del prefisso in `02_naming_conventions.md`.

`cfg_gate_rule_types` è il dominio chiuso dei tipi di regola. Fa due lavori insieme: è la foreign key che impedisce di configurare una regola che non esiste, ed è la documentazione dei parametri attesi da ciascun tipo, che altrimenti vivrebbe solo nella testa di chi ha scritto il dispatch. Le sue righe corrispondono una a una ai rami del `case` di `evaluate`, arrivano dal seed del framework e **non si popolano a progetto**.

`cfg_gate_rules` è l'associazione processo → regole, ed è la tabella che si tocca davvero. La colonna `severity` sta qui e non sul tipo, e questa collocazione è il motivo per cui la tabella ha la struttura che ha: come si diceva sopra, la stessa regola deve poter essere bloccante per un processo e informativa per un altro. La colonna `is_active` permette di sospendere una precondizione senza perderne la configurazione, che è quasi sempre quello che si vuole davvero quando si dice "togli quel controllo". Il campo `note` esiste perché fra un anno nessuno ricorderà perché quella regola c'è, e la risposta deve stare accanto alla regola.

`cfg_gate_objects` è la lista bianca degli oggetti interrogabili dalla regola `DATA_READY`. Non è una comodità, è un controllo di sicurezza: `DATA_READY` è l'unico check che costruisce SQL dinamico, e senza lista bianca chiunque ottenga la scrittura su `cfg_gate_rules` otterrebbe di fatto l'esecuzione di SQL arbitrario nello schema owner. Il nome dell'oggetto passa comunque anche per `dbms_assert.sql_object_name` prima di entrare nella statement: la lista bianca stabilisce *quali* oggetti sono ammessi, `dbms_assert` verifica che il testo sia davvero un identificatore e per giunta esistente. Sono due controlli indipendenti e vanno tenuti entrambi.

Non c'è una quarta tabella per le esecuzioni, e questa è la principale differenza rispetto a un gate scritto come libreria a sé: la sorgente del check `DEPENDENCY` è `log_process_runs`, il registro che `lib_batch` popola comunque. La dipendenza fra processi si legge quindi dai fatti già tracciati, non da un flag che qualcuno deve ricordarsi di alzare.

## I tipi di regola

Il set iniziale copre i casi che ricorrono in pratica. Vale la pena notare che quasi tutti delegano a un package base invece di reimplementarne la logica, ed è la ragione per cui questo meccanismo ha senso dentro il framework e non come libreria isolata.

| Codice | Verifica | `param_1` | `param_2` | Delega a |
|---|---|---|---|---|
| `ENABLED` | il processo è abilitato a configurazione | nome del flag in `cfg_parameters` | — | `lib_config.get_flag` |
| `ENVIRONMENT` | l'ambiente corrente è fra quelli ammessi | elenco separato da virgole | — | `lib_config.environment` |
| `TIME_WINDOW` | l'ora ricade nella finestra | inizio `HH24:MI` | fine `HH24:MI` | — |
| `DAY_OF_WEEK` | il giorno è fra quelli ammessi | elenco `1..7`, 1 = lunedì | — | — |
| `WORKING_DAY` | è un giorno lavorativo | codice calendario (null = `DEFAULT`) | — | `lib_calendar.is_working_day` |
| `DEPENDENCY` | il predecessore è andato a buon fine | nome del processo | validità in ore | `log_process_runs` |
| `DATA_READY` | c'è almeno una riga da elaborare | nome oggetto (in lista bianca) | — | — |

Tre di questi meritano una nota, perché nascondono una scelta.

`ENVIRONMENT` legge l'ambiente da `lib_config.environment`, cioè dal parametro `ENVIRONMENT`, e non da `sys_context('userenv','db_name')` come farebbe l'implementazione ingenua. Il nome fisico del database cambia con le migrazioni, i cloni e i rinnovi infrastrutturali, e ogni volta bisognerebbe ricordarsi di aggiornare le regole; il parametro no, ed è già la guardia che usano `lib_mail` e il tooling per non spedire mail vere dal collaudo. Un solo concetto di ambiente in tutto il framework.

`DAY_OF_WEEK` numera i giorni secondo ISO, con lunedì uguale a 1, e ricava il numero dalla distanza dall'inizio della settimana ISO invece di usare `to_char(d,'D')`. Non è pignoleria: `'D'` dipende da `NLS_TERRITORY`, quindi la stessa regola darebbe risultati diversi a seconda di chi lancia il processo — un bug che si manifesta solo quando il batch viene rilanciato a mano da una postazione configurata diversamente, cioè nel momento peggiore.

`DEPENDENCY` ha due semantiche, scelte dalla presenza di `param_2`. Senza, vale la giornata: il predecessore deve essere finito bene nella stessa data della data di riferimento. Con, vale una finestra mobile: finito bene nelle ultime N ore. La seconda è quella da usare per le catene che scavalcano la mezzanotte, dove "stessa data" è ambiguo — un processo che parte alle 23:50 e finisce alle 00:05 cade formalmente nel giorno dopo, e la finestra mobile evita il problema invece di doverlo ragionare ogni volta.

## Come si usa

Nel caso normale il verdetto si applica con una riga, perché `lib_batch.check_gate` fa da ponte fra la valutazione e l'azione:

```sql
l_run_id := lib_batch.start_run(i_process_name => k_PROCESS, i_single_instance => true);

if ( not lib_batch.check_gate(i_run_id => l_run_id, i_process_name => k_PROCESS) )
then
    return;
end if;
```

Il `false` significa che il processo è stato saltato: `check_gate` ha già chiuso il run come `SKIPPED` con il motivo e ha già scritto la riga di log informativa, quindi al chiamante resta soltanto da uscire. Un verdetto `ABORT` non torna mai come valore: solleva `lib_err.e_precondition_failed`, che l'handler del processo tratta come qualunque altro errore.

Chi ha bisogno di distinguere `SKIP` e `ABORT` con una politica propria — mandare una mail solo in un caso, per dire — chiama `lib_gate.evaluate` direttamente e legge `decision`, `failed_rules` e `message`. Chi invece non ha niente da decidere perché qualunque precondizione non soddisfatta è un errore usa `lib_gate.assert_can_run`, che solleva anche sullo `SKIP`.

Una raccomandazione che vale la pena rispettare: il gate va chiamato **prima di qualunque DML e prima di aprire cursori**, subito dopo `start_run`. E se il processo lavora su una data di business diversa da oggi, quella data va passata con `i_ref_date`, non recuperata da dentro un check — un check che si va a cercare il proprio contesto smette di essere una funzione pura e ricomincia a essere imprevedibile.

La configurazione corrispondente ha questa forma, ed è utile leggere l'ordine delle severità:

```sql
insert into cfg_gate_rules (process_name, rule_seq, rule_code, severity, param_1, param_2, note)
values ('CARICO_FATTURE', 10, 'ENVIRONMENT', 'ABORT', 'TEST,PROD', null,
        'Non deve mai girare in sviluppo: scrive sul gestionale reale');

insert into cfg_gate_rules (process_name, rule_seq, rule_code, severity, param_1, param_2, note)
values ('CARICO_FATTURE', 20, 'ENABLED', 'ABORT', 'CARICO_FATTURE_ENABLED', null,
        'Interruttore per sospendere il carico senza toccare lo scheduler');

insert into cfg_gate_rules (process_name, rule_seq, rule_code, severity, param_1, param_2, note)
values ('CARICO_FATTURE', 30, 'DEPENDENCY', 'ABORT', 'IMPORT_ANAGRAFICHE', '18',
        'Senza anagrafiche aggiornate le fatture restano orfane');

insert into cfg_gate_rules (process_name, rule_seq, rule_code, severity, param_1, param_2, note)
values ('CARICO_FATTURE', 40, 'TIME_WINDOW', 'SKIP', '22:00', '05:00',
        'Fuori dalla finestra notturna si rimanda, non e'' un errore');

insert into cfg_gate_rules (process_name, rule_seq, rule_code, severity, param_1, param_2, note)
values ('CARICO_FATTURE', 50, 'DATA_READY', 'SKIP', 'WRK_FATTURE_STAGING', null,
        'Staging vuota: non c''e'' niente da fare, e va bene cosi''');
commit;
```

Le condizioni **ambientali e di configurazione** sono `ABORT`, quelle di **opportunità** sono `SKIP`. È il partizionamento che funziona nella grande maggioranza dei casi reali, e conviene partire da lì e derogare consapevolmente, non il contrario. Le sequenze vanno a passi di dieci per poter inserire una regola in mezzo senza rinumerare.

Quando un processo non parte e nessuno ricorda perché, la prima cosa da guardare è `lib_gate.describe('CARICO_FATTURE')`, che elenca la configurazione così com'è — regole disattivate incluse e marcate, perché molto spesso è proprio una regola spenta la risposta.

## Il contratto transazionale di `lib_batch`

L'aver spostato il gate dentro il run ha reso evidente un problema che c'era già: `lib_batch` scriveva su `log_process_runs` con DML ordinaria, nella transazione del chiamante. La conseguenza è che se il processo solleva e il chiamante di livello superiore fa `rollback`, sparisce non solo la riga `FAILED` ma anche la `RUNNING` iniziale, e l'esecuzione torna invisibile — di nuovo, proprio nel caso in cui la traccia serve.

Per questo tutte le scritture su `log_process_runs` sono ora in **transazione autonoma**, isolate in tre moduli privati di `lib_batch` che fanno soltanto DML e `commit`. È una deroga dichiarata e circoscritta alla regola "il commit è del chiamante", imposta dalla natura di ciò che si scrive: un registro di esecuzioni che l'elaborazione registrata può cancellare non è un registro. È la stessa disciplina che `lib_logging` applica da sempre, e per la stessa ragione.

Il motivo per cui le DML sono isolate in moduli privati e non marcate direttamente sui moduli pubblici non è pignoleria: una transazione autonoma deve chiudersi prima di restituire il controllo, quindi tutto ciò che non è quella specifica DML — il lock, il logging, la strumentazione di sessione — deve stare fuori. Il lock in particolare resta deliberatamente all'esterno; `dbms_lock` lavora a livello di sessione con `release_on_commit` a false, quindi il commit autonomo non lo toccherebbe comunque, ma mescolare acquisizione di risorse e scrittura del registro renderebbe illeggibile chi rilascia cosa.

C'è una conseguenza pratica che va tenuta a mente ed è già riflessa nelle suite: **le righe di run non si ripuliscono con un `rollback`**. Un test che ne crea deve cancellarle esplicitamente, in una transazione autonoma propria.

## Estendere il meccanismo

Aggiungere un tipo di regola richiede quattro passi, tutti obbligatori: inserire la riga in `cfg_gate_rule_types` (nel seed del framework, con la descrizione dei parametri), scrivere la funzione `chk_*` privata nel body di `lib_gate`, aggiungere il ramo al `case` di `evaluate`, e scrivere il caso di test.

Non esiste modo di aggiungere una regola senza toccare il codice, ed è esattamente l'obiettivo. Il ramo `else` del `case` solleva invece di ignorare la regola sconosciuta proprio per garantire che una riga inserita a catalogo senza il codice corrispondente si manifesti subito e rumorosamente: una regola fantasma — configurata, visibile nell'elenco, e che non blocca niente — è peggio dell'assenza di regole, perché produce falsa sicurezza. La foreign key verso `cfg_gate_rule_types` copre già gran parte del caso, ma la difesa in profondità qui costa tre righe.

## Cosa questo meccanismo deliberatamente non fa

Alcune cose sono state escluse per scelta e non vanno reintrodotte in fase di integrazione, perché ognuna di esse smonta uno dei principi.

Non esegue nomi di procedura letti da tabella. Il solo SQL dinamico ammesso è il conteggio di `DATA_READY`, protetto da lista bianca e `dbms_assert`.

Nessun check scrive. Se un check "ha bisogno" di registrare qualcosa, il requisito è mal posto: quella scrittura appartiene al chiamante.

Il gate non manda notifiche e non decide se uno `SKIP` merita una riga di log o il silenzio. Restituisce un verdetto; logging e alerting sono del chiamante, che è l'unico a saperlo.

Non si usa una colonna di stato su tabella come lock. La mutua esclusione è di `lib_lock`, che si appoggia a `dbms_lock` proprio perché un flag `RUNNING` su tabella sopravvive al crash della sessione e blocca il processo finché qualcuno non lo resetta a mano — tipicamente alle tre di notte.

E non si accorpano `SKIP` e `ABORT` in un booleano, nemmeno "per ora", nemmeno "tanto poi lo sistemiamo". È la distinzione da cui dipende l'intera utilità del meccanismo.
