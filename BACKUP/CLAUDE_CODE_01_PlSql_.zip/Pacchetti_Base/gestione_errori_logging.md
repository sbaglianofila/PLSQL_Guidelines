# Gestione errori e logging — guida pratica

Questa guida spiega come funziona la gestione centralizzata di **log ed errori** del framework: quali tabelle esistono e cosa contengono, come i due package `lib_logging` e `lib_err` le usano, e come scrivere codice che le sfrutti nel modo giusto. È pensata per essere letta una volta per intero e poi tenuta come riferimento: ogni concetto è accompagnato da dati d'esempio e da blocchi di codice che puoi copiare ed eseguire su un'istanza di sviluppo per vederli all'opera.

L'impianto risponde a tre esigenze concrete. La prima è **tracciare** ciò che succede in esecuzione — non solo gli errori, ma anche l'inizio e la fine dei processi e gli eventi informativi — in una forma interrogabile dall'Application Maintenance. La seconda è **codificare i messaggi** in un catalogo, con segnaposto sostituibili, così che il testo mostrato o loggato sia pulito e correggibile a runtime senza ricompilare. La terza è **rendere leggibili gli errori Oracle**, traducendo quelli tecnici (`ORA-00001: unique constraint violated`) in messaggi comprensibili (`Dato già presente`), pur conservando sempre il dettaglio tecnico per la diagnosi.

Una nota sulla lingua, prima di iniziare: il framework scrive i **propri** messaggi in inglese, com'è per tutto il codice di base. Un progetto che adotta questa base può invece usare l'italiano per i **propri** messaggi di dominio, purché lo faccia in modo uniforme. Negli esempi di questa guida i messaggi di dominio sono in italiano, proprio per mostrare quel caso d'uso.

---

## 1. Il quadro d'insieme

Prima delle tabelle conviene fissare quattro idee, perché tutto il resto ne discende.

**Due assi indipendenti su ogni riga di log.** Ogni evento registrato ha un *livello* (`log_level`: `DEBUG`, `INFO`, `WARN`, `ERROR`) che dice **quanto è importante**, e un *tipo* (`message_type`: `START`, `END`, `LOG`, `ERROR`) che dice **che genere di evento è**. Sono cose diverse: l'inizio di una procedura è un evento di tipo `START` ma di livello `INFO`; un warning funzionale è di tipo `LOG` ma di livello `WARN`. Tenerli separati permette interrogazioni precise ("dammi il ciclo di vita dei processi" filtra su `message_type`; "dammi tutto ciò che è almeno WARN" filtra su `log_level`).

**Due identificativi per correlare, passati esplicitamente.** Il `correlation_id` è il *trace id*: un identificativo che accomuna tutti gli eventi di **una singola esecuzione/flusso**, anche quando attraversa più procedure. L'`execution_id` è il *span id*: identifica **una singola invocazione** di una procedura, così che il suo `START` e il suo `END` si appaino anche se la stessa procedura gira più volte nello stesso flusso. Entrambi sono opzionali e vengono passati esplicitamente dal chiamante (non derivati dallo stato di sessione), perché così restano corretti anche con un connection pool.

**Il codice `-20xxx` è un meccanismo, non un'identità.** Oracle mette a disposizione solo mille codici (`-20000..-20999`) per `raise_application_error`. Sprecarne uno per ogni messaggio applicativo è insostenibile. Perciò se ne tengono **pochi, dedicati**, uno per ogni condizione che un chiamante deve poter intercettare per nome e su cui reagire (blocco ottimistico, risorsa occupata, permesso negato…); tutti gli **altri** messaggi di dominio — che sono tanti — si sollevano sotto un unico codice generico `BUSINESS_ERROR`, e la loro identità è il **`message_code`**, non il numero.

**Il logging non rompe mai il chiamante.** Tutte le scritture di log avvengono in **transazione autonoma** (con `commit` proprio) e catturano internamente qualsiasi errore: se il logging fallisce, fa `rollback` in silenzio e la procedura chiamante prosegue. Il log inoltre **sopravvive al rollback** della transazione applicativa, perché è appunto una transazione separata — proprio ciò che serve per avere traccia di un errore anche dopo che la transazione che l'ha causato è stata annullata.

---

## 2. Le tabelle

Sono cinque: due per gli eventi di log, due per i cataloghi dei messaggi, e una (già esistente) per la configurazione.

### 2.1 `log_events` — il flusso unico degli eventi

È la tabella principale: **ogni** evento di log — di qualunque livello e tipo — finisce qui, una riga per evento. Il dettaglio diagnostico pesante degli errori (backtrace, call stack) sta invece nella tabella separata `log_error_details`, così che questo flusso resti snello.

| Colonna | Tipo | Significato |
|---|---|---|
| `event_id` | number, identity | Chiave surrogata. |
| `logged_at` | timestamp | Istante della registrazione (tempo della transazione autonoma). |
| `log_level` | varchar2(5) | Gravità: `DEBUG` / `INFO` / `WARN` / `ERROR`. |
| `message_type` | varchar2(10) | Natura: `START` / `END` / `LOG` / `ERROR`. Default `LOG`. |
| `process_name` | varchar2(128) | Modulo `dbms_application_info` in esecuzione (lo imposta `lib_batch`); serve a filtrare un run. |
| `scope` | varchar2(128) | Ambito logico, tipicamente `PACKAGE.SUBPROGRAM`: chi ha loggato. |
| `message` | varchar2(4000) | Testo dell'evento, già con i segnaposto sostituiti. |
| `error_code` | number | `sqlcode` catturato per gli eventi `ERROR` (negativo per gli errori applicativi); null altrimenti. |
| `correlation_id` | varchar2(64) | Il *trace id* del flusso (opzionale). |
| `execution_id` | varchar2(64) | Lo *span id* della singola invocazione (opzionale). |
| `actor` | varchar2(128) | Attore effettivo (proxy-aware) risolto da `lib_session.current_actor`. |

Gli indici coprono gli accessi tipici delle query di controllo: per data, per processo, per `correlation_id`, per `execution_id`, e per `(log_level, logged_at)`.

### 2.2 `log_error_details` — il dettaglio degli errori

Una riga **solo per gli eventi `ERROR`**, in join uno-a-uno con `log_events` su `event_id`. Tiene ciò che serve a localizzare l'origine e a non perdere mai il testo tecnico:

| Colonna | Significato |
|---|---|
| `event_id` | Evento `ERROR` proprietario (PK e FK verso `log_events`). |
| `sqlerrm_text` | Il `sqlerrm` **grezzo**, conservato sempre: così l'ORA originale resta anche quando `log_events.message` mostra una traduzione. |
| `error_backtrace` | `dbms_utility.format_error_backtrace`: la riga dove l'eccezione è stata sollevata. |
| `call_stack` | `dbms_utility.format_call_stack` al momento del log. |

La separazione tra flusso (`log_events`) e dettaglio (`log_error_details`) è deliberata: la maggior parte delle interrogazioni guarda solo il flusso, e paga il costo del testo diagnostico pesante solo quando si va davvero a investigare un singolo errore.

### 2.3 `cfg_error_messages` — il catalogo dei codici d'errore

Contiene i messaggi legati a un **codice numerico**, di due specie distinte dalla colonna `error_kind`:

- righe **`APP`**: i pochi codici applicativi dedicati (`-20000..-20999`), con la loro eccezione con nome in `lib_err`;
- righe **`ORACLE`**: le **traduzioni** degli errori Oracle nativi, con chiave il `sqlcode` (per esempio `-1` per `ORA-00001`).

| Colonna | Significato |
|---|---|
| `error_code` | Codice numerico: per `APP` il `-20xxx`, per `ORACLE` il `sqlcode` nativo. |
| `error_kind` | `APP` oppure `ORACLE`. Default `APP`. |
| `error_name` | Nome leggibile (per `APP` rispecchia la costante `k_` di `lib_err`; per `ORACLE` un mnemonico). Univoco. |
| `message_template` | Il template, con segnaposto `%1..%10`. |

Un vincolo condizionato tiene le righe `APP` nella banda `-20xxx`, mentre le `ORACLE` possono avere qualunque codice. Codici applicativi e Oracle non si sovrappongono come numeri, quindi convivono in un'unica tabella senza ambiguità.

### 2.4 `cfg_messages` — il catalogo dei messaggi di dominio

È il catalogo dei **tuoi** messaggi, identificati dal tuo **`message_code`** (una stringa nel tuo namespace, come `ORD_IMPORT_COMPLETATO`). Vi finiscono i messaggi informativi, i warning e gli errori di dominio: la severità non è nella tabella, la decide l'API che chiami (`log_info`, `log_warn`, `raise_msg`…).

| Colonna | Significato |
|---|---|
| `message_code` | Codice del messaggio (chiave naturale), nel tuo namespace. |
| `message_template` | Il template, con segnaposto `%1..%10`. |

Il framework **non** semina questa tabella: i codici sono di dominio, li definisce il progetto. La convenzione è tenerli come costanti in un package per dominio (`ord_msg_codes`, `mag_msg_codes`, …), mai come stringhe sparse nel codice.

### 2.5 `cfg_parameters` — la configurazione del logging

Due parametri, letti da `lib_config`, governano il logging:

- `LOG_MIN_LEVEL` (default `INFO`): il livello minimo scritto. Sotto questa soglia gli eventi `DEBUG`/`INFO`/`WARN` vengono scartati. Gli **errori si scrivono sempre**, indipendentemente da questa soglia.
- `LOG_RETENTION_DAYS` (default `90`): l'età in giorni oltre la quale `lib_logging.purge` cancella le righe.

Entrambi stanno nel gruppo `LOGGING` della colonna `param_group`, che raggruppa logicamente i parametri per area: `select * from cfg_parameters where param_group = 'LOGGING'` li elenca tutti senza doversi affidare al prefisso del nome.

Essendo modificabili a runtime (`lib_config.set_value`), puoi alzare la verbosità a `DEBUG` su un ambiente senza ricompilare nulla; ricordati poi di chiamare `lib_logging.refresh` per invalidare la cache del livello.

---

## 3. Dati d'esempio

Prima di provare gli esempi, popola i due cataloghi. Questi `insert` sono sicuri da rieseguire solo se le righe non esistono già (in produzione useresti un `MERGE`, come fa il seed del framework; qui li lasciamo semplici per leggibilità).

**Qualche messaggio di dominio in `cfg_messages`** (nota il raddoppio dell'apice per gli apostrofi italiani):

```sql
insert into cfg_messages (message_code, message_template) values
   ('ORD_IMPORT_COMPLETATO', 'Import ordini completato. Righe elaborate: %1');
insert into cfg_messages (message_code, message_template) values
   ('ORD_ARTICOLO_SALTATO',  'Articolo %1 saltato: %2');
insert into cfg_messages (message_code, message_template) values
   ('ORD_ARTICOLO_NON_VALIDO', 'L''articolo %1 non è valido per il magazzino %2');
insert into cfg_messages (message_code, message_template) values
   ('ORD_UTENTE_NON_ABILITATO', 'Non sei abilitato all''operazione %1');
commit;
```

**Un paio di traduzioni Oracle in `cfg_error_messages`** (righe `ORACLE`, con chiave il `sqlcode`):

```sql
insert into cfg_error_messages (error_code, error_kind, error_name, message_template) values
   (-1,    'ORACLE', 'DUP_VAL_ON_INDEX', 'Dato già presente');
insert into cfg_error_messages (error_code, error_kind, error_name, message_template) values
   (-2291, 'ORACLE', 'PARENT_KEY_MISSING', 'Riferimento inesistente');
commit;
```

Da questo momento ogni `ORA-00001` che viene **loggato** comparirà come `Dato già presente`, con l'ORA originale conservato in `log_error_details.sqlerrm_text`.

I codici applicativi dedicati (`APP`) sono già seminati dal framework; non devi aggiungerli tu.

---

## 4. I package: cosa offrono

### 4.1 `lib_logging` — il motore di logging

Registra gli eventi in `log_events` (e il dettaglio errori in `log_error_details`) in transazione autonoma. Le sue procedure vengono in due forme: a **testo libero** (passi la stringa già pronta) e a **catalogo** (passi un `message_code` e i parametri, e il testo lo compone lui da `cfg_messages`).

Registrazione degli eventi, per livello:

- `log_info` / `log_warn` / `log_debug` — versione a **testo libero**: `log_info(i_text => '...', i_scope => '...')`.
- `log_info` / `log_warn` / `log_debug` — versione a **catalogo**: `log_info(i_message_code => '...', i_p1 => ..., i_scope => '...')`. Le due forme si distinguono dal nome del primo parametro (`i_text` vs `i_message_code`): usa **sempre la notazione con nome**.
- `log_error(i_text => '...', i_scope => '...')` — da chiamare **dentro un exception handler**: registra `error_code` (`sqlcode`), il messaggio (con eventuale traduzione Oracle), e nel dettaglio `sqlerrm`, backtrace e call stack. È sempre scritto, mai filtrato.

Tracciamento del ciclo di vita:

- `start_proc(i_scope => '...') return ...` — scrive un evento `START`, **restituisce** un `execution_id` fresco e **apre un frame** di strumentazione (salva il module/action correnti, imposta l'`ACTION` al `scope`, reclama il `MODULE` solo se nullo). La strumentazione di `v$session` arriva così "gratis", senza gestire a mano lo stack di `lib_session`.
- `end_proc(i_scope => '...', i_execution_id => l_exec)` — sul percorso di **successo**: scrive l'evento `END` e **chiude il frame** ripristinando il module/action del chiamante.
- `end_proc_error(i_scope => '...', i_execution_id => l_exec)` — sul percorso di **errore**, da chiamare nel `when others` obbligatorio: scrive un `END` marcato come chiusura in errore e **chiude il frame** (ripristina lo stato). **Non logga** l'errore: se vuoi loggarlo lì chiami `lib_err.reraise`/`log_error`, altrimenti solo `raise`. È questo handler obbligatorio a garantire che lo stack resti sempre bilanciato (si veda lo scheletro standard, cap. 08 delle guidelines).

Utilità:

- `new_correlation_id` / `new_execution_id` — generatori di identificativi (token esadecimali) da tenere lato chiamante.
- `message_of(i_message_code => '...', i_p1 => ...) return varchar2` — **compone** il testo di un messaggio dal catalogo `cfg_messages` **senza loggarlo**: utile per mostrarlo a video.
- `refresh` — svuota la cache del livello minimo (dopo aver cambiato `LOG_MIN_LEVEL`).
- `purge(i_retention_days => ...)` — cancella le righe più vecchie della retention (pensata per un job schedulato).

Tutti i parametri `i_correlation_id`, `i_execution_id`, `i_scope` sono opzionali su ogni procedura di log. Quando `i_correlation_id` è nullo, il writer ripiega sul correlation id di sessione (`lib_session.current_correlation`, cioè il `CLIENT_IDENTIFIER` impostato da `set_correlation`): così una voce di log resta agganciata al flusso corrente anche se il chiamante non passa esplicitamente il trace id. Il valore passato per argomento resta la fonte prevalente; il fallback vale solo *entro la stessa sessione* — un correlation id non attraversa da solo un confine asincrono (per esempio l'accodamento in `wrk_mail_queue` e il successivo drenaggio da parte di un job), che richiederebbe di persistere il trace id sul dato.

Sul versante `scope`: il valore segue il formato `package.subprogram` (per esempio `lib_mail.send`), così la colonna `scope` di `log_events` distingue *quale* sottoprogramma ha emesso la voce, non solo il package. I package di base ottengono il sottoprogramma componendo la costante di package con il nome del modulo (`k_SCOPE || '.send'`), tenendo un'unica fonte del nome del package; le procedure pienamente strumentate usano invece la costante locale `c_scope` mostrata nello scheletro standard (cap. 08 delle guidelines, `11_patterns.md`). Il meccanismo è libero: ciò che la convenzione fissa è il *formato del valore*.

### 4.2 `lib_err` — il catalogo e il motore degli errori

Solleva gli errori (unico posto del progetto che chiama `raise_application_error`), li logga prima di sollevarli, e li rilancia preservando lo stack. Segue il principio "pochi codici dedicati + un generico".

- `raise(i_error => lib_err.k_..., i_p1 => ...)` — solleva uno dei **codici dedicati** col suo messaggio fisso, preso da `cfg_error_messages`.
- `raise_msg(i_message_code => '...', i_p1 => ..., i_error => lib_err.k_BUSINESS_ERROR)` — solleva un **messaggio di dominio**, identificato dal suo `message_code`: compone il testo da `cfg_messages` e lo segnala sotto `BUSINESS_ERROR` per default, oppure sotto un codice dedicato quando quel caso specifico deve restare intercettabile per nome.
- `reraise(i_scope => '...')` — da un exception handler: logga l'eccezione corrente e la rilancia. I nostri errori applicativi (`-20xxx`) sono preservati verbatim; qualunque altro errore Oracle è avvolto come `UNEXPECTED` mantenendo l'originale sullo stack.
- `message_of(i_error => lib_err.k_..., i_p1 => ...) return varchar2` — il messaggio composto di un **codice dedicato**, per mostrarlo senza sollevare.

I **codici dedicati** che userai più spesso, ciascuno con la sua eccezione con nome:

| Costante | Codice | Eccezione | Quando |
|---|---|---|---|
| `k_INVALID_PARAMETER` | -20000 | `e_invalid_parameter` | argomento non valido (di solito un bug al call site) |
| `k_STALE_DATA` | -20001 | `e_stale_data` | conflitto di blocco ottimistico (il chiamante ritenta) |
| `k_LOCK_REQUEST_FAILED` | -20002 | `e_lock_request_failed` | lock applicativo non ottenuto |
| `k_ALREADY_RUNNING` | -20003 | `e_already_running` | processo già in esecuzione |
| `k_NOT_ALLOWED` | -20014 | `e_not_allowed` | permesso mancante (autorizzazione) |
| `k_UNEXPECTED` | -20099 | — | wrapper per errori Oracle imprevisti (lo usa `reraise`) |
| `k_BUSINESS_ERROR` | -20999 | `e_business_error` | codice portante generico per i messaggi di dominio |

Esistono anche alcuni codici dedicati di infrastruttura usati dai package base (file, mail, configurazione): non ti riguardano nell'uso quotidiano.

---

## 5. Esempi pratici

Gli esempi assumono di essere connessi come lo schema applicativo. Puoi eseguirli così come sono, dopo aver inserito i dati d'esempio del capitolo 3.

### 5.1 Una procedura tracciata dall'inizio alla fine

Il pattern quotidiano (lo **scheletro standard** obbligatorio, cap. 08 delle guidelines): apri con `start_proc`, tieni il `correlation_id` e l'`execution_id`, logga gli eventi significativi a catalogo, chiudi con `end_proc` sul successo, e nel `when others` obbligatorio chiama `end_proc_error` (chiude e ripristina) e poi `raise`. Qui scegliamo di **loggare** l'errore aggiungendo `lib_err.reraise` prima del `raise` implicito.

```sql
create or replace procedure prc_importa_ordini is
   c_scope   constant varchar2(128) := 'PRC_IMPORTA_ORDINI';
   l_corr    varchar2(64) := lib_logging.new_correlation_id;
   l_exec    varchar2(64);
   l_righe   pls_integer := 0;
begin
   l_exec := lib_logging.start_proc(i_scope => c_scope, i_correlation_id => l_corr);

   -- ... logica applicativa che valorizza l_righe ...
   l_righe := 125;

   lib_logging.log_info( i_message_code   => 'ORD_IMPORT_COMPLETATO'
                       , i_p1             => l_righe
                       , i_correlation_id => l_corr
                       , i_execution_id   => l_exec
                       , i_scope          => c_scope
                       );

   lib_logging.end_proc(i_scope => c_scope, i_execution_id => l_exec, i_correlation_id => l_corr);
exception
   when others then
      lib_logging.end_proc_error(i_scope => c_scope, i_execution_id => l_exec, i_correlation_id => l_corr);
      lib_err.reraise(i_scope => c_scope, i_execution_id => l_exec, i_correlation_id => l_corr);  -- opzionale: logga
      -- se non volessi loggare qui, basterebbe: raise;
end;
/
```

Eseguendola con successo, in `log_events` trovi tre righe con lo stesso `correlation_id` ed `execution_id`: un `START`, un `LOG`/`INFO` con testo `Import ordini completato. Righe elaborate: 125`, e un `END`. In caso di errore trovi invece `START`, l'`END (error)` (da `end_proc_error`) e un evento `ERROR` (da `reraise`).

### 5.2 Sollevare un errore di dominio

Il caso più comune: una regola di business violata. Usi `raise_msg` con un `message_code`; di default viene sollevato sotto `BUSINESS_ERROR`.

```sql
begin
   if 1 = 1 then  -- condizione di esempio
      lib_err.raise_msg( i_message_code => 'ORD_ARTICOLO_NON_VALIDO'
                       , i_p1           => 'ABC123'
                       , i_p2           => 'M01'
                       );
   end if;
exception
   when lib_err.e_business_error then
      dbms_output.put_line('Catturato business error: ' || sqlerrm);
end;
/
```

Il chiamante vede `ORA-20999: L'articolo ABC123 non è valido per il magazzino M01`, e l'errore è già finito nel log. Se invece un caso specifico deve restare **intercettabile per nome** — per esempio un difetto di autorizzazione — lo sollevi sotto un codice dedicato:

```sql
begin
   lib_err.raise_msg( i_message_code => 'ORD_UTENTE_NON_ABILITATO'
                    , i_p1           => 'ANNULLA_ORDINE'
                    , i_error        => lib_err.k_NOT_ALLOWED
                    );
exception
   when lib_err.e_not_allowed then
      dbms_output.put_line('Accesso negato, gestito a parte.');
end;
/
```

### 5.3 Sollevare un errore di infrastruttura dedicato

Quando la condizione è una di quelle poche con codice dedicato e messaggio fisso, usi `raise` con la costante:

```sql
begin
   lib_err.raise(i_error => lib_err.k_ALREADY_RUNNING, i_p1 => 'IMPORT_NOTTURNO');
exception
   when lib_err.e_already_running then
      dbms_output.put_line('Il processo è già in corso, salto.');
end;
/
```

### 5.4 Tradurre un errore Oracle

Questo è il caso che ti interessava. Hai già registrato in `cfg_error_messages` la traduzione di `ORA-00001` (`sqlcode = -1`) come `Dato già presente`. Ora provochi l'errore, lo catturi e lo logghi: la **traduzione avviene da sola** al momento del log, mentre l'ORA originale resta nel dettaglio.

```sql
declare
   c_scope constant varchar2(128) := 'DEMO_ORACLE';
begin
   raise dup_val_on_index;   -- simula ORA-00001 (sqlcode -1)
exception
   when others then
      lib_logging.log_error(i_text => 'Inserimento cliente', i_scope => c_scope);
end;
/
```

Poi guardi cosa è stato registrato:

```sql
select e.message              as messaggio_pulito
     , e.error_code
     , d.sqlerrm_text         as ora_originale
  from log_events e
  join log_error_details d on d.event_id = e.event_id
 where e.scope = 'DEMO_ORACLE'
 order by e.logged_at desc;
```

Il `messaggio_pulito` sarà `Inserimento cliente - Dato già presente`, mentre `ora_originale` conserva `ORA-00001: unique constraint ... violated`. Se **non** avessi catalogato quel codice, il messaggio pulito ripiegherebbe automaticamente sull'`sqlerrm`.

### 5.5 Ritornare un messaggio pulito a un chiamante (senza loggarlo)

Quando ti serve solo il testo — per mostrarlo a video, per un `dbms_output`, per un servizio — usi `message_of`, che compone senza scrivere nulla nel log:

```sql
declare
   l_testo varchar2(4000);
begin
   l_testo := lib_logging.message_of( i_message_code => 'ORD_ARTICOLO_SALTATO'
                                     , i_p1           => 'ABC123'
                                     , i_p2           => 'prezzo mancante'
                                     );
   dbms_output.put_line(l_testo);   -- Articolo ABC123 saltato: prezzo mancante
end;
/
```

Per i codici dedicati esiste il gemello `lib_err.message_of(i_error => lib_err.k_..., ...)`.

### 5.6 Interrogare i log

Alcune query di controllo che userai spesso.

**Gli ultimi errori con il loro dettaglio tecnico:**

```sql
select e.logged_at, e.scope, e.message, e.error_code, d.sqlerrm_text, d.error_backtrace
  from log_events e
  join log_error_details d on d.event_id = e.event_id
 where e.log_level = 'ERROR'
 order by e.logged_at desc
 fetch first 50 rows only;
```

**Tutti gli eventi di una singola esecuzione**, ricostruita dal `correlation_id`:

```sql
select logged_at, message_type, log_level, scope, message
  from log_events
 where correlation_id = :p_correlation_id
 order by logged_at;
```

**La durata di ogni invocazione tracciata**, appaiando `START` ed `END` per `execution_id` (scova le esecuzioni lente o mai chiuse):

```sql
select scope
     , execution_id
     , min(case when message_type = 'START' then logged_at end) as inizio
     , max(case when message_type = 'END'   then logged_at end) as fine
     , max(case when message_type = 'END'   then logged_at end)
     - min(case when message_type = 'START' then logged_at end) as durata
  from log_events
 where message_type in ('START', 'END')
 group by scope, execution_id
 order by inizio desc;
```

---

## 6. Convenzioni e buone pratiche

**Tieni i `message_code` come costanti, per dominio.** Non spargere le stringhe nel codice: raccoglile in un package `*_msg_codes` (uno per dominio) e referenzia quelle. Rende i codici verificabili dal compilatore e i rinomini sicuri.

```sql
create or replace package ord_msg_codes is
   c_inf_import_completato   constant varchar2(100) := 'ORD_IMPORT_COMPLETATO';
   c_wrn_articolo_saltato    constant varchar2(100) := 'ORD_ARTICOLO_SALTATO';
   c_err_articolo_non_valido constant varchar2(100) := 'ORD_ARTICOLO_NON_VALIDO';
   c_err_utente_non_abilitato constant varchar2(100) := 'ORD_UTENTE_NON_ABILITATO';
end ord_msg_codes;
/
```

**Assegna un codice dedicato solo se serve intercettarlo.** La domanda da porsi è sempre: *un chiamante scriverebbe mai `when quella_eccezione then ...` per reagire in modo diverso?* Se sì, merita un codice dedicato; altrimenti è un messaggio di dominio, e va sotto `BUSINESS_ERROR` via `raise_msg`. Promuovere un messaggio a codice dedicato in un secondo momento è additivo e a basso costo, quindi parti sempre stretto.

**Traccia le unità di lavoro, non i micro-helper.** Lo scheletro `start_proc`/`end_proc`/`end_proc_error` (e con esso l'handler obbligatorio) è per le procedure che rappresentano un'operazione sensata — quelle che possono girare da sole o essere innestate in altre. Una piccola funzione privata chiamata molte volte (una `get_id` in un loop) **non** si traccia: aprirle uno span le riempirebbe di `START`/`END`. Quei micro-helper gestiscono solo le eccezioni prevedibili, lasciano propagare l'imprevisto all'unità che li racchiude, e al più usano un `lib_session.set_action` per mostrare il passo in `v$session`.

**Logga con misura.** Registra sempre `START`, `END` ed `ERROR` delle unità di lavoro. Usa `INFO` per gli eventi significativi, `DEBUG` solo quando serve. Evita il log riga-per-riga dentro i cicli massivi, salvo debug temporaneo: ogni scrittura è un `commit` autonomo, e loggare troppo degrada le prestazioni.

**Non nascondere `raise;` in wrapper.** Il pattern canonico in un handler è chiamare `lib_err.reraise` (che logga e rilancia preservando lo stack) oppure `lib_err.raise` / `raise_msg` seguiti dal `raise;` implicito che questi già fanno. Il rilancio esplicito resta il modo più pulito per propagare l'eccezione corrente.

**Attenzione ai dati sensibili.** I messaggi e i log finiscono in tabelle interrogabili: non metterci password, token o dati personali non necessari.

---

## 7. Note operative

**Alzare la verbosità a runtime.** Per accendere il `DEBUG` su un ambiente senza ricompilare:

```sql
begin
   lib_config.set_value(i_name => 'LOG_MIN_LEVEL', i_value => 'DEBUG');
   commit;
   lib_logging.refresh;   -- invalida la cache del livello
end;
/
```

Ricordati di riportarlo a `INFO` quando hai finito.

**Retention.** La pulizia è pensata come job schedulato che chiama `lib_logging.purge`. Senza argomento usa `LOG_RETENTION_DAYS` dalla configurazione; puoi anche forzarla: `lib_logging.purge(i_retention_days => 30);`.

**Errori nel logger.** Per costruzione il logger non solleva mai: se una scrittura fallisce, fa `rollback` e tace. Questo significa che, in casi patologici (per esempio una tabella di log mancante), potresti perdere una riga di log senza che l'applicazione se ne accorga — è un compromesso voluto, perché il logging non deve mai diventare la causa di un errore applicativo.

---

## 8. In una riga

Metti i **tuoi** messaggi (di ogni genere) in `cfg_messages`, per `message_code`, e usali con `log_info`/`log_warn`/`log_debug` per loggarli, `raise_msg` per sollevarli, `message_of` per ottenerne il testo. Cataloga in `cfg_error_messages` (righe `ORACLE`) le **traduzioni** degli errori Oracle che vuoi rendere leggibili: la traduzione avviene da sola quando l'errore viene loggato, e il testo tecnico resta sempre in `log_error_details`. I codici `-20xxx` restano pochi e dedicati, per le sole condizioni che un chiamante deve intercettare per nome.
