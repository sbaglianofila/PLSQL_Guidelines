prompt ------------------------------------------------------------

prompt File: <table_name>.tab.sql <start>

prompt

-- =============================================================================
-- File:     <table_name>.tab.sql
-- Oggetto:  <table_name> (tabella)
-- Schema:   #APP#
-- Scopo:    <scopo>
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data       Aut   Modifica
--   <YYYYMMDD>  <AA>  Creazione
-- =============================================================================


prompt -- Creating table

-- Nella create restano solo colonne, tipi e i NOT NULL nominati esplicitamente.
-- I default (non amministrativi), i constraint PK/UK/CK e gli indici sono in
-- sezioni dedicate più sotto; le foreign key stanno in file separati.
create table <table_name>
   ( <column_name>  <datatype>          constraint <table_name>_nn_<column_name>  not null
   , <column_name>  <datatype>          constraint <table_name>_nn_<column_name>  not null
   -- , <column_name>  <datatype>
   -- Colonne amministrative: blocco fisso, popolato dal trigger <table_name>_audit_trg
   -- (vedi Architettura_DB/colonne_amministrative.md). Restano unite qui perché sono
   -- impiantistica standard identica su ogni tabella, non scelte di disegno della tabella.
   , row_version   number             default 1  constraint <table_name>_nn_row_version  not null
   , created_by    varchar2(64 char)  invisible  constraint <table_name>_nn_created_by   not null
   , created_at    timestamp(6)       invisible  constraint <table_name>_nn_created_at   not null
   , created_app   varchar2(64 char)  invisible  constraint <table_name>_nn_created_app  not null
   , modified_by   varchar2(64 char)  invisible
   , modified_at   timestamp(6)       invisible
   , modified_app  varchar2(64 char)  invisible
   );


prompt -- Adding defaults

-- Default delle sole colonne di dominio (il default di row_version sta nel blocco
-- amministrativo della create). Rimuovere la sezione se nessuna colonna ha un default.
alter table <table_name>
   modify ( <column_name>  default <default_value>
          );


prompt -- Creating constraints

-- Primary key. La clausola "using index" crea l'indice di supporto con lo stesso
-- nome del constraint (<table_name>_pk); aggiungere "tablespace <idx_tbs>" se serve.
alter table <table_name>
   add constraint <table_name>_pk  primary key ( <column_name> )
   using index;

-- Unique key (indice omonimo al constraint tramite "using index").
alter table <table_name>
   add constraint <table_name>_uk_<column_name>  unique ( <column_name> )
   using index;

-- Check (di colonna: <table_name>_ck_<colonna>; di tabella: <table_name>_ck[n]).
alter table <table_name>
   add constraint <table_name>_ck_<column_name>  check ( <column_name> in ( '<val1>', '<val2>' ) );

-- Le foreign key NON vanno qui: si creano in file separati (FKs/<table_name>.fky.sql,
-- dal template template_foreign_key.fky.sql), eseguiti in una sezione dedicata dell'install.


prompt -- Adding comments

comment on table  <table_name>                is '<scopo della tabella>';
comment on column <table_name>.<column_name>  is '<scopo della colonna>';
-- Colonne amministrative (standard su ogni tabella; vedi colonne_amministrative.md)
comment on column <table_name>.row_version    is 'Versione della riga per il locking ottimistico, incrementata dal trigger a ogni modifica.';
comment on column <table_name>.created_by     is 'Utente applicativo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column <table_name>.created_at     is 'Istante dell''inserimento (invisibile, impostata dal trigger).';
comment on column <table_name>.created_app    is 'Programma/modulo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column <table_name>.modified_by    is 'Utente applicativo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column <table_name>.modified_at    is 'Istante dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column <table_name>.modified_app   is 'Programma/modulo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';


prompt -- Creating indexes

-- Indici non legati a constraint: nome <table_name>_idx_<colonne> con la dicitura "idx".
-- create index <table_name>_idx_<column_name> on <table_name> ( <column_name> );


-- Promemoria: creare il trigger di audit <table_name>_audit_trg dal template
-- template_trigger_audit.trg.sql per popolare le colonne amministrative.

prompt File: <table_name>.tab.sql <end>

prompt
