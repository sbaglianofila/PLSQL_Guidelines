prompt ------------------------------------------------------------

prompt File: pkg_<name>.pks.sql <start>

prompt

-- =============================================================================
-- File:     pkg_<name>.pks.sql
-- Oggetto:  pkg_<name> (package specification)
-- Schema:   #APP#
-- Scopo:    Package di logica per <name>: contiene la logica reale. Mantiene il
--           nome pulito e non viene MAI concesso in grant. Quando va esposto a un
--           consumer, si aggiunge la shell pkg_<name>_shell e si concede EXECUTE
--           su QUELLA, mai su questo package. Vedi schemi.md.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data       Aut   Modifica
--   <YYYYMMDD>  <AA>  Creazione
-- =============================================================================

prompt -- Creating package specification

create or replace
package pkg_<name>
is
--------------------------------------------------------------------------------
-- <descrizione del subprogram>
function <function_name>(i_<param_name> in <datatype>)
    return <datatype>;
--------------------------------------------------------------------------------
end pkg_<name>;
/

show errors package pkg_<name>

prompt File: pkg_<name>.pks.sql <end>

prompt
