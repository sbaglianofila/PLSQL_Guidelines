prompt ------------------------------------------------------------

prompt File: pkg_<name>_shell.pks.sql <start>

prompt

-- =============================================================================
-- File:     pkg_<name>_shell.pks.sql
-- Oggetto:  pkg_<name>_shell (package specification)
-- Schema:   #APP#
-- Scopo:    Shell pubblica per <name>. Non contiene logica: ogni subprogram
--           delega a pkg_<name>. Concedere EXECUTE su QUESTA shell ai ruoli
--           consumer; non concedere mai pkg_<name>. Vedi schemi.md.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data       Aut   Modifica
--   <YYYYMMDD>  <AA>  Creazione
-- =============================================================================

prompt -- Creating package specification

create or replace
package pkg_<name>_shell is

-- <descrizione del subprogram>
function <function_name>(i_<param_name> in <datatype>) return <datatype>;

end pkg_<name>_shell;
/

show errors package pkg_<name>_shell

prompt File: pkg_<name>_shell.pks.sql <end>

prompt
