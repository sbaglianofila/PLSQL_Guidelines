prompt ------------------------------------------------------------

prompt File: pkg_<name>_shell.pkb.sql <start>

prompt

-- =============================================================================
-- File:     pkg_<name>_shell.pkb.sql
-- Oggetto:  pkg_<name>_shell (package body)
-- Schema:   #APP#
-- Scopo:    Body della shell: pura delega a pkg_<name>, nessuna logica. Gira con
--           definer rights (il default) così da poter raggiungere il package di
--           logica.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data       Aut   Modifica
--   <YYYYMMDD>  <AA>  Creazione
-- =============================================================================

prompt -- Creating package body

create or replace
package body pkg_<name>_shell is

function <function_name>(i_<param_name> in <datatype>) return <datatype> is
begin
   return pkg_<name>.<function_name>(i_<param_name>);
end <function_name>;

end pkg_<name>_shell;
/

show errors package body pkg_<name>_shell

prompt File: pkg_<name>_shell.pkb.sql <end>

prompt
