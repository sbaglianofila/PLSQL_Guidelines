prompt ------------------------------------------------------------

prompt File: <process_name>.prc.sql <start>

prompt

-- =============================================================================
-- File:     <process_name>.prc.sql
-- Object:   <process_name> (main process)
-- Schema:   #APP#
-- Purpose:  <purpose>
-- -----------------------------------------------------------------------------
-- Questo template è per i MAIN PROCESS: le elaborazioni che qualcuno lancia -
-- lo scheduler, una maschera, un operatore - e che devono lasciare traccia di
-- essersi svolte. NON è per le procedure di servizio richiamate dall'interno di
-- un'elaborazione: quelle non aprono un run e non valutano precondizioni, le
-- ereditano dal processo che le chiama (per quelle si usa template_procedure).
--
-- La sequenza sotto non è un suggerimento, è l'ordine corretto, e ogni passo sta
-- dove sta per una ragione:
--
--   1. start_run     apre il run e - se richiesto - prende il lock di istanza
--                    singola PRIMA di scrivere, così un avvio bloccato da
--                    un'istanza già in corso non lascia una riga spuria.
--   2. lib_authz     CHI sta lanciando. Solo per i processi con un chiamante da
--                    verificare (tipicamente da maschera); un batch schedulato che
--                    gira con l'identità dello schema non ne ha bisogno e la riga
--                    si toglie. Un diniego qui è SEMPRE un errore.
--   3. check_gate    SE HA SENSO partire adesso, qui, in questo stato del mondo.
--                    Dentro il run e non prima: così anche il processo che decide
--                    di non partire lascia la sua riga, e "ha deciso di non
--                    partire" resta distinguibile da "non è mai stato lanciato".
--   4. il corpo, con checkpoint sui passi lunghi.
--   5. end_run sul successo, fail_run nell'handler.
--
-- I passi 2 e 3 sono due domande diverse e restano due chiamate diverse: i
-- permessi rispondono a "chi", le precondizioni a "quando e se". Accorparle
-- sembra un risparmio e diventa un pasticcio il giorno in cui una delle due
-- cambia. Vedi Pacchetti_Base/precondizioni_esecuzione.md.
-- -----------------------------------------------------------------------------
-- Changelog (authoritative history: version control)
--   Date      Aut  Change
--   <YYYYMMDD> <AA>  Creation
-- =============================================================================

prompt -- Creating main process

create or replace
procedure <process_name>
   ( i_<param_name>  in  <datatype> default null
   )
is
   k_PROCESS  constant lib_types.name_sbt  := '<PROCESS_NAME>';
   k_SCOPE    constant lib_types.scope_sbt := '<process_name>';

   l_run_id   number;
   l_rows     pls_integer := 0;
begin

   -- 1. Apertura del run. i_single_instance => true quando due esecuzioni
   --    contemporanee dello stesso processo si darebbero fastidio.
   l_run_id := lib_batch.start_run( i_process_name    => k_PROCESS
                                  , i_single_instance => true
                                  );

   -- 2. Permessi. Da togliere sui processi senza un chiamante da verificare.
   lib_authz.assert_access( i_functionality_code => '<FUNCTIONALITY_CODE>'
                          , i_mode               => lib_authz.k_mode_execute
                          );

   -- 3. Precondizioni di esecuzione. false = saltato: il run è già stato chiuso
   --    come SKIPPED con il motivo, non resta che uscire in silenzio.
   if ( not lib_batch.check_gate(i_run_id => l_run_id, i_process_name => k_PROCESS) )
   then
       return;
   end if;

   -- 4. Corpo dell'elaborazione.
   lib_batch.checkpoint(i_run_id => l_run_id, i_step => '<STEP_NAME>');

   -- <logica del processo>

   -- 5. Chiusura con l'esito e i contatori.
   lib_batch.end_run( i_run_id         => l_run_id
                    , i_rows_processed => l_rows
                    );

exception
   when others
   then
       -- fail_run chiude il run come FAILED e rilascia il lock; lib_err.reraise
       -- logga e ripropaga. L'ordine conta: prima si registra l'esito, poi si
       -- rilancia, altrimenti un errore nel logging lascerebbe il run appeso in
       -- RUNNING per sempre.
       -- La guardia sul null serve per l'unico errore che precede l'apertura del
       -- run: start_run che non ottiene il lock perché un'altra istanza sta già
       -- girando. Lì non c'è nessun run da chiudere.
       if ( l_run_id is not null )
       then
           lib_batch.fail_run(i_run_id => l_run_id);
       end if;

       lib_err.reraise(i_scope => k_SCOPE);
end <process_name>;
/

show errors procedure <process_name>

prompt File: <process_name>.prc.sql <end>

prompt
