prompt File: pkg_orders_shell.pks.sql <start>
-- =============================================================================
-- File:     pkg_orders_shell.pks.sql
-- Object:   PKG_ORDERS_SHELL (package specification)
-- Schema:   #APP# (owner)
-- Purpose:  Public shell API for orders. Contains no logic: every subprogram
--           delegates to PKG_ORDERS. Grant EXECUTE on THIS shell to consumer
--           roles; never grant PKG_ORDERS. See the encapsulation layer in
--           schemi.md.
-- -----------------------------------------------------------------------------
-- Changelog (authoritative history: version control)
--   Date      Aut  Change
--   20260701  AA   Creation
-- =============================================================================

prompt PKG_ORDERS_SHELL: Creating package specification
create or replace package pkg_orders_shell is

-- Returns the OPEN orders of a customer.
-- i_customer_id : customer whose open orders are requested.
function open_orders_by_customer(i_customer_id in number) return sys_refcursor;

-- Performs a workflow action on an order (see pkg_orders.change_status).
-- i_order_id        : the order to move.
-- i_transition_code : the action to perform (e.g. 'APPROVE').
-- i_role_code       : business role performing the action, or null to skip the check.
-- i_reason          : reason for the change, when the action requires one.
procedure change_status( i_order_id        in number
                       , i_transition_code in varchar2
                       , i_role_code       in varchar2 default null
                       , i_reason          in varchar2 default null );

end pkg_orders_shell;
/
show errors package pkg_orders_shell

prompt File: pkg_orders_shell.pks.sql <end>
