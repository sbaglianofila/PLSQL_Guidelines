prompt File: pkg_orders.pks.sql <start>
-- =============================================================================
-- File:     pkg_orders.pks.sql
-- Object:   PKG_ORDERS (package specification)
-- Schema:   #APP# (owner)
-- Purpose:  Logic package for orders. Holds the real logic and keeps the clean
--           name. NEVER granted: consumers reach it only through the
--           PKG_ORDERS_SHELL shell. See the encapsulation layer in schemi.md.
-- -----------------------------------------------------------------------------
-- Changelog (authoritative history: version control)
--   Date      Aut  Change
--   20260701  AA   Creation
-- =============================================================================

prompt PKG_ORDERS: Creating package specification
create or replace package pkg_orders is

-- Returns the OPEN orders of a customer.
-- i_customer_id : customer whose open orders are requested.
function open_orders_by_customer(i_customer_id in number) return sys_refcursor;

-- Moves an order by performing a workflow action: validates it against the ORDER
-- workflow and records the transition in wfl_orders_status_log, all in one
-- transaction. This is the contract of the workflow pillar (stati_workflow.md):
-- lib_workflow validates, the Table API writes the business status and the
-- per-entity history together, so no state change escapes the log. Raises
-- lib_err.e_not_allowed when the action is not permitted from the current status,
-- not allowed for the role, or a required reason is missing.
-- i_order_id        : the order to move.
-- i_transition_code : the action to perform (e.g. 'APPROVE').
-- i_role_code       : business role performing the action, or null to skip the check.
-- i_reason          : reason for the change, when the action requires one.
procedure change_status( i_order_id        in number
                       , i_transition_code in varchar2
                       , i_role_code       in varchar2 default null
                       , i_reason          in varchar2 default null );

-- Guard dispatcher for the ORDER workflow. Called by name (dynamically) from
-- lib_workflow when a transition has guards, once per guard, with a FIXED uniform
-- signature; it loads the order by PK and evaluates the guard identified by
-- i_guard_code, returning true/false. It is NOT part of the public API and is not
-- exposed on the shell: lib_workflow (owner-side) reaches it within the schema.
-- Wire it up by setting wfl_workflows.guard_handler = 'pkg_orders.check_guard' for
-- the ORDER workflow, and add wfl_transition_guards rows with the guard codes below.
-- i_workflow_code / i_transition_code / i_from_status / i_to_status : transition context.
-- i_entity_pk  : the order_id, as a string (uniform dispatch signature).
-- i_guard_code : which rule to evaluate (e.g. 'AMOUNT_UNDER_AUTO_LIMIT').
function check_guard( i_workflow_code   in varchar2
                    , i_transition_code in varchar2
                    , i_from_status     in varchar2
                    , i_to_status       in varchar2
                    , i_entity_pk       in varchar2
                    , i_guard_code      in varchar2 )
    return boolean;

end pkg_orders;
/
show errors package pkg_orders

prompt File: pkg_orders.pks.sql <end>
