prompt File: orders.tab.sql <start>
-- =============================================================================
-- File:     orders.tab.sql
-- Oggetto:  orders (tabella)
-- Schema:   #APP#
-- Scopo:    Testate degli ordini. Una riga per ordine cliente.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260701  AA   Creazione
-- =============================================================================

prompt orders: Creating table

create table orders
   ( order_id      number
   , customer_id   number             constraint orders_nn_customer_id  not null
   , order_date    date               constraint orders_nn_order_date   not null
   , status        varchar2(32 char)  constraint orders_nn_status       not null
   -- Colonna virtuale costante: il workflow di questa entità. Rende scrivibile la
   -- foreign key composita verso wfl_statuses (vedi stati_workflow.md).
   , status_wfl    varchar2(32 char)  generated always as ('ORDER') virtual
   , total_amount  number(14,2)
   -- Colonne amministrative: blocco fisso, popolato dal trigger orders_audit_trg
   -- (vedi Architettura_DB/colonne_amministrative.md).
   , row_version   number             default 1  constraint orders_nn_row_version  not null
   , created_by    varchar2(64 char)  invisible  constraint orders_nn_created_by   not null
   , created_at    timestamp(6)       invisible  constraint orders_nn_created_at   not null
   , created_app   varchar2(64 char)  invisible  constraint orders_nn_created_app  not null
   , modified_by   varchar2(64 char)  invisible
   , modified_at   timestamp(6)       invisible
   , modified_app  varchar2(64 char)  invisible
   );

prompt orders: Adding constraints

alter table orders
   add constraint orders_pk primary key ( order_id )
   using index;

-- Nota: lo stato NON ha più un check con la lista dei valori cablata. La validità
-- di status è ora vincolata dichiarativamente dalla foreign key composita verso
-- wfl_statuses (in orders.fky.sql), e le transizioni ammesse dal pillar workflow
-- (wfl_transitions, applicate da pkg_orders.change_status). Vedi stati_workflow.md.

prompt orders: Adding comments

comment on table  orders              is 'Testate degli ordini. Una riga per ordine cliente.';
comment on column orders.order_id     is 'Chiave primaria surrogata.';
comment on column orders.customer_id  is 'Cliente proprietario. La FK è creata nella cartella FKs.';
comment on column orders.order_date   is 'Data di business dell''ordine.';
comment on column orders.status       is 'Stato del ciclo di vita; vincolato a wfl_statuses del workflow ORDER dalla foreign key composita orders_fk_status.';
comment on column orders.status_wfl   is 'Colonna virtuale costante (''ORDER''): il workflow, usato dalla foreign key composita verso wfl_statuses.';
comment on column orders.total_amount is 'Totale lordo dell''ordine.';
-- Colonne amministrative (standard su ogni tabella; vedi colonne_amministrative.md)
comment on column orders.row_version  is 'Versione della riga per il locking ottimistico, incrementata dal trigger a ogni modifica.';
comment on column orders.created_by   is 'Utente applicativo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column orders.created_at   is 'Istante dell''inserimento (invisibile, impostata dal trigger).';
comment on column orders.created_app  is 'Programma/modulo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column orders.modified_by  is 'Utente applicativo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column orders.modified_at  is 'Istante dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column orders.modified_app is 'Programma/modulo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';

prompt orders: Creating indexes

create index orders_idx_customer_id on orders ( customer_id );

-- Promemoria: il trigger di audit è in orders_audit_trg.trg.sql.

prompt File: orders.tab.sql <end>
