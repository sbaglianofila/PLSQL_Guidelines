prompt File: wfl_orders_status_log.fky.sql <start>
-- =============================================================================
-- File:     wfl_orders_status_log.fky.sql
-- Oggetto:  Foreign key di wfl_orders_status_log
-- Schema:   #APP#
-- Scopo:    Vincoli referenziali della storia dei cambi di stato. La prima è la
--           foreign key TIPIZZATA verso la riga di business (order_id -> orders):
--           è la ragione per cui l'audit è una tabella dedicata per entità e non
--           un contenitore generico. Le altre due sono composite verso wfl_statuses
--           e usano la colonna virtuale costante status_wfl (= 'ORDER') per
--           vincolare from_status e to_status ai soli stati DEL workflow ORDER.
--           from_status è nullo alla nascita dell'ordine: una foreign key composita
--           con una colonna nulla è soddisfatta (MATCH SIMPLE), quindi la riga di
--           nascita passa senza forzare uno stato di partenza fittizio.
--           In file separato perché van creati dopo le tabelle (vedi sorgenti.md).
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260725  AA   Creazione
-- =============================================================================

prompt wfl_orders_status_log: Creating foreign keys

alter table wfl_orders_status_log
   add constraint wfl_orders_status_log_fk_order
   foreign key ( order_id )
   references orders ( order_id );

alter table wfl_orders_status_log
   add constraint wfl_orders_status_log_fk_to
   foreign key ( status_wfl, to_status )
   references wfl_statuses ( workflow_code, status_code );

alter table wfl_orders_status_log
   add constraint wfl_orders_status_log_fk_from
   foreign key ( status_wfl, from_status )
   references wfl_statuses ( workflow_code, status_code );

prompt File: wfl_orders_status_log.fky.sql <end>
