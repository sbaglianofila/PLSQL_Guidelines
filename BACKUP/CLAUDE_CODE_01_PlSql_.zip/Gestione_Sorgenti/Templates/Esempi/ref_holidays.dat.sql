prompt File: ref_holidays.dat.sql <start>
-- =============================================================================
-- File:     ref_holidays.dat.sql
-- Oggetto:  Dati di seed per ref_holidays (esempio: calendario civile italiano)
-- Schema:   #APP#
-- Scopo:    Popolare ref_holidays per un intervallo di anni. È un ESEMPIO, non un
--           seed del framework: il framework non distribuisce festività perché
--           dipendono dal paese, dalla piazza e dall'anno. Un progetto copia
--           questo file in Sources/#APP#/Data/, corregge l'elenco e l'intervallo
--           di anni, e lo cabla nel proprio orchestratore.
--           Le festività a data fissa sono scritte una volta e moltiplicate per gli
--           anni; le feste mobili sono CALCOLATE da lib_calendar.get_easter_date,
--           che è la ragione per cui questo file può coprire quindici anni in una
--           volta invece di essere riaperto ogni dicembre. È esattamente la
--           manutenzione annuale che il calcolo della Pasqua elimina.
-- Nota:     Usa MERGE, quindi lo script è idempotente e rieseguibile: non
--           sovrascrive le righe esistenti, inserisce solo quelle mancanti, così
--           le correzioni fatte a mano su un ambiente sono preservate. Estendere
--           l'intervallo di anni e rilanciare è un'operazione sicura.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260730  AA   Creazione
-- =============================================================================

whenever sqlerror exit failure rollback

prompt ref_holidays: Seeding rows
merge into ref_holidays t
using ( -- L'intervallo di anni da generare: i due numeri di questa CTE sono le sole
        -- cose da ritoccare per estenderlo. La WITH sta dentro la USING perché una
        -- MERGE non ammette una clausola WITH che la preceda.
        with years as ( select 2026 + level - 1 as year_no
                          from dual
                       connect by level <= 15         -- dal 2026 al 2040
                      )
        -- Festività a data fissa del calendario civile italiano. Il santo patrono
        -- è per comune e va aggiunto dal progetto: non esiste un valore nazionale.
        select 'DEFAULT'                                     as calendar_code
             , to_date(f.day_month || y.year_no, 'DDMMYYYY') as holiday_date
             , f.description                                 as description
          from years y
         cross join ( select '0101' as day_month, 'Capodanno' as description from dual
                      union all select '0601', 'Epifania'                    from dual
                      union all select '2504', 'Festa della Liberazione'      from dual
                      union all select '0105', 'Festa del Lavoro'            from dual
                      union all select '0206', 'Festa della Repubblica'       from dual
                      union all select '1508', 'Assunzione (Ferragosto)'      from dual
                      union all select '0111', 'Ognissanti'                   from dual
                      union all select '0812', 'Immacolata Concezione'        from dual
                      union all select '2512', 'Natale'                       from dual
                      union all select '2612', 'Santo Stefano'                from dual
                    ) f
        union all
        -- Feste mobili, derivate dalla domenica di Pasqua sommando lo scarto in
        -- giorni. Delle sette feste mobili che lib_calendar sa calcolare (le
        -- costanti k_* della sua specifica) qui compaiono solo le due civilmente
        -- festive in Italia: Carnevale, Ceneri, Ascensione, Pentecoste e Corpus
        -- Domini sono ricorrenze liturgiche, non giorni non lavorativi.
        -- Lo scarto è un letterale e non lib_calendar.k_EASTER_MONDAY perché le
        -- costanti di package non sono visibili da SQL; il commento fa da ponte.
        select 'DEFAULT'
             , lib_calendar.get_easter_date(y.year_no) + m.offset_days
             , m.description
          from years y
         cross join ( select 0 as offset_days, 'Pasqua' as description from dual
                      -- + k_EASTER_MONDAY
                      union all select 1, 'Lunedì dell''Angelo (Pasquetta)' from dual
                    ) m
      ) s
   on (    t.calendar_code = s.calendar_code
       and t.holiday_date  = s.holiday_date
      )
 when not matched then
    insert (  t.calendar_code
            , t.holiday_date
            , t.description
           )
    values (  s.calendar_code
            , s.holiday_date
            , s.description
           );

prompt ref_holidays: Committing seed data
commit;

-- Query di controllo per l'AM: quante festività per anno (dodici attese per il
-- calendario italiano senza patrono) e quali cadono di sabato o domenica, che sono
-- quelle "perse" e spiegano un conteggio di giorni lavorativi più alto dell'atteso.
--
--   select to_char(rfh.holiday_date, 'YYYY')          as year_no
--        , count(*)                                   as holidays
--        , count(case when rfh.holiday_date - trunc(rfh.holiday_date, 'IW') >= 5
--                     then 1
--                end)                                 as on_weekend
--     from ref_holidays rfh
--    where rfh.calendar_code = 'DEFAULT'
--    group by to_char(rfh.holiday_date, 'YYYY')
--    order by 1;

prompt File: ref_holidays.dat.sql <end>
