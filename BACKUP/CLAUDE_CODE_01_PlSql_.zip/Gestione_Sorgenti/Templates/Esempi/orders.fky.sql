prompt File: orders.fky.sql <start>
-- =============================================================================
-- File:     orders.fky.sql
-- Object:   ORDERS foreign keys
-- Schema:   #APP# (owner)
-- Purpose:  Foreign key constraints for ORDERS. Applied after all referenced
--           tables exist, which is why FKs live in their own folder.
-- -----------------------------------------------------------------------------
-- Changelog (authoritative history: version control)
--   Date      Aut  Change
--   20260701  AA   Creation
-- =============================================================================

prompt ORDERS: Creating foreign key ORDERS_FK_CUSTOMER
alter table orders add constraint orders_fk_customer
   foreign key (customer_id) references customers (customer_id);

-- Foreign key composita con colonna virtuale costante: vincola status ai soli
-- stati del workflow ORDER (vedi stati_workflow.md). Sostituisce il vecchio check
-- con la lista dei valori cablata. Richiede che wfl_statuses esista.
prompt ORDERS: Creating foreign key ORDERS_FK_STATUS
alter table orders add constraint orders_fk_status
   foreign key (status_wfl, status) references wfl_statuses (workflow_code, status_code);

prompt File: orders.fky.sql <end>
