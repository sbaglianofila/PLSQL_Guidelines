prompt File: wfl_orders_status_log.tab.sql <start>
-- =============================================================================
-- File:     wfl_orders_status_log.tab.sql
-- Oggetto:  wfl_orders_status_log (tabella)
-- Schema:   #APP#
-- Scopo:    Esempio della tabella di STORIA per-entità del pillar workflow: una
--           riga per ogni transizione di stato avvenuta su un ordine. È il
--           terzo livello descritto in stati_workflow.md, realizzato - come vuole
--           la regola di promozione - con una tabella dedicata per entità e una
--           foreign key TIPIZZATA verso la riga di business (order_id -> orders),
--           non con un contenitore generico entity_table/entity_id. Le colonne di
--           dominio changed_at/changed_by sono esplicite (auto-descrittive)
--           accanto alle sette colonne amministrative standard: il significato
--           funzionale del cambiamento si legge nelle prime. È scritta dalla Table
--           API (pkg_orders.change_status), non da lib_workflow. Le foreign key
--           sono in FKs/wfl_orders_status_log.fky.sql.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260725  AA   Creazione
-- =============================================================================

prompt wfl_orders_status_log: Creating table

create table wfl_orders_status_log
   ( log_id           number(24)          generated always as identity  constraint wfl_orders_status_log_nn_id   not null
   , order_id         number              constraint wfl_orders_status_log_nn_order  not null
   , from_status      varchar2(32 char)
   , to_status        varchar2(32 char)   constraint wfl_orders_status_log_nn_to     not null
   -- Colonna virtuale costante: il workflow di questa entità. Serve alle due
   -- foreign key composite verso wfl_statuses (from e to), sullo stesso schema
   -- usato dalle tabelle di business (vedi stati_workflow.md e lookups.md).
   , status_wfl       varchar2(32 char)   generated always as ('ORDER') virtual
   , transition_code  varchar2(32 char)
   , changed_at       timestamp(6)        constraint wfl_orders_status_log_nn_chg_at  not null
   , changed_by       varchar2(64 char)   constraint wfl_orders_status_log_nn_chg_by  not null
   , reason           varchar2(4000 char)
   -- Colonne amministrative: blocco fisso, popolato dal trigger
   -- (vedi Architettura_DB/colonne_amministrative.md).
   , row_version       number               default 1  constraint wfl_orders_status_log_nn_row_version  not null
   , created_by        varchar2(64 char)    invisible  constraint wfl_orders_status_log_nn_created_by   not null
   , created_at        timestamp(6)         invisible  constraint wfl_orders_status_log_nn_created_at   not null
   , created_app       varchar2(64 char)    invisible  constraint wfl_orders_status_log_nn_created_app  not null
   , modified_by       varchar2(64 char)    invisible
   , modified_at       timestamp(6)         invisible
   , modified_app      varchar2(64 char)    invisible
   );

prompt wfl_orders_status_log: Adding constraints

alter table wfl_orders_status_log
   add constraint wfl_orders_status_log_pk primary key ( log_id )
   using index;

prompt wfl_orders_status_log: Creating indexes

-- L'accesso tipico è "la storia di quest'ordine, in ordine di tempo".
create index wfl_orders_status_log_idx_order on wfl_orders_status_log ( order_id, changed_at );

prompt wfl_orders_status_log: Adding comments

comment on table  wfl_orders_status_log                 is 'Storia dei cambi di stato degli ordini: una riga per transizione avvenuta. Append-only, scritta da pkg_orders.change_status. Esempio del terzo livello del pillar workflow (stati_workflow.md).';
comment on column wfl_orders_status_log.log_id          is 'Chiave surrogata interna (identity generata).';
comment on column wfl_orders_status_log.order_id        is 'Ordine che ha cambiato stato (foreign key tipizzata verso orders).';
comment on column wfl_orders_status_log.from_status     is 'Stato di partenza; nullo alla nascita dell''ordine nello stato iniziale.';
comment on column wfl_orders_status_log.to_status       is 'Stato di arrivo.';
comment on column wfl_orders_status_log.status_wfl      is 'Colonna virtuale costante (''ORDER''): il workflow, usato dalle foreign key composite verso wfl_statuses.';
comment on column wfl_orders_status_log.transition_code is 'Codice dell''azione che ha prodotto la transizione (es. APPROVE); nullo per la riga di nascita.';
comment on column wfl_orders_status_log.changed_at      is 'Istante del cambiamento (colonna di dominio esplicita).';
comment on column wfl_orders_status_log.changed_by      is 'Utente che ha effettuato il cambiamento (colonna di dominio esplicita).';
comment on column wfl_orders_status_log.reason          is 'Motivo del cambiamento; obbligatorio se la transizione lo richiede (wfl_transitions.requires_reason).';
-- Colonne amministrative (standard su ogni tabella; vedi colonne_amministrative.md)
comment on column wfl_orders_status_log.row_version     is 'Versione della riga per il locking ottimistico, incrementata dal trigger a ogni modifica.';
comment on column wfl_orders_status_log.created_by      is 'Utente applicativo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column wfl_orders_status_log.created_at      is 'Istante dell''inserimento (invisibile, impostata dal trigger).';
comment on column wfl_orders_status_log.created_app     is 'Programma/modulo che ha inserito la riga (invisibile, impostata dal trigger).';
comment on column wfl_orders_status_log.modified_by     is 'Utente applicativo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column wfl_orders_status_log.modified_at     is 'Istante dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';
comment on column wfl_orders_status_log.modified_app    is 'Programma/modulo dell''ultimo aggiornamento (invisibile, nulla fino al primo update).';

-- Promemoria: il trigger di audit è in wfl_orders_status_log_audit_trg.trg.sql.

prompt File: wfl_orders_status_log.tab.sql <end>
