prompt File: pkg_orders.pkb.sql <start>
-- =============================================================================
-- File:     pkg_orders.pkb.sql
-- Object:   PKG_ORDERS (package body)
-- Schema:   #APP# (owner)
-- Purpose:  Real logic (joins, filters) for the orders API. Not granted;
--           reached from consumers only through PKG_ORDERS_SHELL.
-- -----------------------------------------------------------------------------
-- Changelog (authoritative history: version control)
--   Date      Aut  Change
--   20260701  AA   Creation
-- =============================================================================

prompt PKG_ORDERS: Creating package body
create or replace package body pkg_orders is

k_STATUS_OPEN constant orders.status%type      := 'OPEN';
k_WORKFLOW    constant varchar2(32 char)        := 'ORDER';

function open_orders_by_customer(i_customer_id in number) return sys_refcursor is
   l_result sys_refcursor;
begin
   open l_result for
      select o.order_id
           , o.order_date
           , o.total_amount
        --
        from orders o
        --
       where o.customer_id = i_customer_id
         and o.status      = k_STATUS_OPEN;
   return l_result;
end open_orders_by_customer;

procedure change_status( i_order_id        in number
                       , i_transition_code in varchar2
                       , i_role_code       in varchar2 default null
                       , i_reason          in varchar2 default null ) is
   l_from  orders.status%type;
   l_to    orders.status%type;
begin
   -- Lock the business row and read its current status.
   select status into l_from from orders where order_id = i_order_id for update;

   -- Validate the action against the state machine. Raises lib_err.e_not_allowed
   -- if the action is not permitted from l_from, not allowed for the role, or a
   -- required reason is missing. lib_workflow does the checking; it does not write.
   lib_workflow.assert_action( i_workflow_code   => k_WORKFLOW
                             , i_from_status     => l_from
                             , i_transition_code => i_transition_code
                             , i_role_code       => i_role_code
                             , i_reason          => i_reason
                             , i_entity_pk       => to_char(i_order_id) );

   l_to := lib_workflow.target_status(k_WORKFLOW, l_from, i_transition_code);

   -- Apply the new status on the business row...
   update orders
      set status = l_to
    where order_id = i_order_id;

   -- ...and record the history in the SAME transaction: the two writes are atomic,
   -- so no state change escapes the per-entity log.
   insert into wfl_orders_status_log ( order_id, from_status, to_status
                                     , transition_code, changed_at, changed_by, reason )
   values ( i_order_id, l_from, l_to
          , i_transition_code, systimestamp, lib_session.current_actor, i_reason );
end change_status;

function check_guard( i_workflow_code   in varchar2
                    , i_transition_code in varchar2
                    , i_from_status     in varchar2
                    , i_to_status       in varchar2
                    , i_entity_pk       in varchar2
                    , i_guard_code      in varchar2 ) return boolean is
   l_order  orders%rowtype;
begin
   -- A guard loads the entity row by PK and reads what it needs. i_entity_pk is a
   -- string so lib_workflow's dispatch signature stays uniform across entities.
   select * into l_order from orders where order_id = to_number(i_entity_pk);

   -- Pure predicates: they only read and return true/false. The reason a guard
   -- denies lives in wfl_transition_guards.deny_message_code, not here.
   case i_guard_code
      when 'AMOUNT_PRESENT' then
         return l_order.total_amount is not null;
      when 'AMOUNT_UNDER_AUTO_LIMIT' then
         return nvl(l_order.total_amount, 0) < 1000;
      else
         -- Unknown guard code: a configuration bug, surfaced loudly rather than
         -- silently allowing or denying the transition.
         lib_err.raise(lib_err.k_INVALID_PARAMETER, 'i_guard_code', i_guard_code);
         return false;   -- not reached; keeps the function single-exit-safe
   end case;
end check_guard;

end pkg_orders;
/
show errors package body pkg_orders

prompt File: pkg_orders.pkb.sql <end>
