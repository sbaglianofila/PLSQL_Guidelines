prompt File: wfl_orders_status_log_audit_trg.trg.sql <start>
-- =============================================================================
-- File:     wfl_orders_status_log_audit_trg.trg.sql
-- Oggetto:  wfl_orders_status_log_audit_trg (trigger)
-- Schema:   #APP#
-- Scopo:    Mantiene le colonne amministrative standard di wfl_orders_status_log.
--           Anche una tabella di audit di dominio porta le sette colonne standard
--           (created_* coincidono di fatto con changed_*, ma lo standard vale per
--           ogni tabella; vedi colonne_amministrative.md). Vedi anche
--           stati_workflow.md per il rapporto tra colonne esplicite e amministrative.
-- Nota:     Le colonne di creazione sono immutabili negli update; row_version è
--           autorità del server e ignora qualsiasi valore fornito dal client.
--           Attore e programma sono risolti da lib_session (current_actor /
--           current_module), unico punto per fallback e cap: il trigger dipende
--           quindi da lib_session, installato dopo i package base.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260725  AA   Creazione
-- =============================================================================

prompt wfl_orders_status_log_audit_trg: Creating trigger

create or replace trigger wfl_orders_status_log_audit_trg
   before insert or update on wfl_orders_status_log
   for each row
begin

    -- Attore e programma sono risolti da lib_session (current_actor /
    -- current_module): fallback e cap di lunghezza vivono lì, in un unico punto,
    -- così i trigger non li duplicano. CLIENT_IDENTIFIER non è l'attore (porta il
    -- correlation id). Il trigger dipende quindi da lib_session, installato dopo
    -- i package base.
    if (inserting)
    then

        :new.created_by   := lib_session.current_actor;
        :new.created_at   := systimestamp;
        :new.created_app  := lib_session.current_module;
        :new.modified_by  := null;
        :new.modified_at  := null;
        :new.modified_app := null;

        :new.row_version  := 1;

    elsif (updating)
    then

        :new.created_by   := :old.created_by;
        :new.created_at   := :old.created_at;
        :new.created_app  := :old.created_app;
        --
        :new.modified_by  := lib_session.current_actor;
        :new.modified_at  := systimestamp;
        :new.modified_app := lib_session.current_module;

        :new.row_version  := nvl(:old.row_version, 0) + 1;

    end if;

end wfl_orders_status_log_audit_trg;
/
show errors trigger wfl_orders_status_log_audit_trg

prompt File: wfl_orders_status_log_audit_trg.trg.sql <end>
