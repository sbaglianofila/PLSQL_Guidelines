# Template dei sorgenti

Questa cartella raccoglie gli scheletri generici di partenza per i file sorgente di un progetto costruito sulla base. Ogni template nasce già conforme alle convenzioni di denominazione, di stile e di gestione dei sorgenti definite nelle guidelines e in `sorgenti.md`: si copia il template, si sostituiscono i segnaposto e si riempie il contenuto, partendo così da una struttura corretta nella forma.

I file `template_*` sono generici. Esempi concreti d'uso — con un oggetto reale al posto dei segnaposto — sono raccolti nella cartella `Esempi/`.

## Legenda dei segnaposto

I template usano segnaposto testuali da sostituire alla creazione del file reale. Il nome del file stesso va rinominato di conseguenza (ad esempio `template_table.tab.sql` diventa `orders.tab.sql`), e il marcatore `File:` all'interno va aggiornato al nome reale.

| Segnaposto | Significato |
|---|---|
| `#APP#` | Schema owner; sostituito col nome del prodotto all'istanziazione del progetto |
| `<table_name>`, `<view_name>`, `<object_name>`, ... | Nome dell'oggetto, in minuscolo |
| `<column_name>`, `<attribute_name>`, `<param_name>` | Nome di colonna, attributo o parametro |
| `<datatype>` | Tipo Oracle (es. `number`, `varchar2(30 char)`, `date`) |
| `<purpose>` | Descrizione in una riga dello scopo dell'oggetto |
| `<AA>` | Iniziali dell'autore, nel changelog di intestazione |
| `<YYYYMMDD_NN>` | Token di datazione delle migrazioni (data + progressivo), nel nome file |

## Convenzioni comuni a tutti i template

Ogni file è pensato per essere eseguito con **SQL\*Plus** o **SQLcl** e produce un log leggibile, così che in caso di errore sia immediato capire cosa si è rotto e dove.

Ogni file si apre con `prompt File: <nomefile> <start>` e si chiude con `prompt File: <nomefile> <end>`. Questi marcatori delimitano il contributo di ciascun file nel log complessivo, rendendo evidente dove inizia e finisce l'esecuzione di ogni sorgente anche quando molti file vengono concatenati da un orchestratore.

Subito dopo il marcatore di apertura c'è un'**intestazione** che identifica il file e l'oggetto, ne dichiara lo scopo e contiene un **changelog manuale** in forma tabellare — data, iniziali dell'autore, descrizione concisa della modifica. Il changelog nel file è un ausilio alla consegna e alla lettura veloce; la storia autorevole e completa resta il version control.

All'interno del file, ogni fase significativa è annunciata da un `prompt` in **inglese** che descrive cosa si sta facendo (`Creating table`, `Adding comments`, `Creating indexes`, `Creating package body`…). A differenza dei commenti `--`, i `prompt` compaiono sempre nel log indipendentemente dalle impostazioni di echo, ed è per questo che sono lo strumento con cui si traccia l'avanzamento.

Al termine di ogni oggetto **compilabile** — package spec e body, procedure, funzioni, trigger, type spec e body, viste — si inserisce `show errors <tipo> <nome>`. È essenziale: un oggetto PL/SQL può essere creato *con errori di compilazione* senza che SQL\*Plus lo segnali come errore SQL, quindi `whenever sqlerror` da solo non basta a intercettarlo; `show errors` riversa gli errori di compilazione nel log, dove diventano diagnosticabili. Tabelle, sequence, indici e foreign key non prevedono `show errors`, perché o l'istruzione riesce, o fallisce come errore SQL.

## Esecuzione e gestione degli errori

Le impostazioni di sessione e la gestione degli errori (`whenever sqlerror exit failure rollback`, `set`, `spool`) sono definite negli **orchestratori** (`template_install.ins.sql`), non nei singoli file oggetto. Un file oggetto è pensato per essere invocato da un orchestratore, oppure eseguito manualmente mentre si è connessi allo schema corretto; per questo non altera impostazioni globali di sessione, che sarebbero un effetto collaterale indesiderato in concatenazione. Le migrazioni DML (`.scr`) e i seed (`.dat`) fanno eccezione: gestiscono in proprio `whenever sqlerror` e il `commit`, perché possono essere eseguiti anche isolatamente.

## Template generici disponibili

| File | Oggetto |
|---|---|
| `template_install.ins.sql` | Orchestratore di install (vale anche da riferimento dell'ordine di dipendenza) |
| `template_sequence.seq.sql` | Sequence |
| `template_type.typ.sql` / `template_type_body.tyb.sql` | Object type: spec e body |
| `template_table.tab.sql` | Tabella (baseline): creazione, colonne amministrative, commenti, indici |
| `template_alter.alt.sql` | Migrazione: alter table (file datato) |
| `template_index.idx.sql` | Indice standalone |
| `template_foreign_key.fky.sql` | Foreign key |
| `template_mv_log.mvl.sql` | Materialized view log |
| `template_view.vue.sql` / `template_view_shell.vue.sql` | Vista di logica (nome pulito `<name>_v`, mai grantata) e vista guscio (`<name>_shell_v`, delega, grantata) |
| `template_materialized_view.mvw.sql` | Materialized view |
| `template_package.pks.sql` / `template_package_body.pkb.sql` | Package di logica `pkg_<name>` (nome pulito, logica, mai grantato) |
| `template_package_shell.pks.sql` / `.pkb.sql` | Package guscio `pkg_<name>_shell` (delega, grantato) |
| `template_procedure.prc.sql` | Procedura standalone |
| `template_main_process.prc.sql` | Main process: l'elaborazione che qualcuno lancia e che deve lasciare traccia. Materializza la sequenza `start_run` → permessi → precondizioni → corpo → `end_run`/`fail_run`; vedi `Pacchetti_Base/precondizioni_esecuzione.md` |
| `template_function.fnc.sql` | Funzione standalone |
| `template_trigger.trg.sql` | Trigger generico |
| `template_trigger_audit.trg.sql` | Trigger di audit `<table>_audit_trg`: popola le colonne amministrative (audit + `row_version`); vedi `Architettura_DB/colonne_amministrative.md` |
| `template_grant.grt.sql` | Grant a ruoli |
| `template_synonym.syn.sql` | Sinonimo privato |
| `template_data.dat.sql` | Dati seed/configurazione (idempotenti via merge) |
| `template_script.scr.sql` | Migrazione DML una tantum |
| `template_test_suite.pks.sql` / `.pkb.sql` | Suite utPLSQL |

### Template di provisioning privilegiato (cartella `SYS`)

Questi template producono gli script da eseguire con un'utenza privilegiata (o da consegnare ai DBA del cliente). Non contengono mai password reali: le utenze si creano con un segnaposto, e il segreto viene impostato nell'ambiente di destinazione.

| File | Oggetto |
|---|---|
| `template_install_sys.ins.sql` | Orchestratore del provisioning (tablespace → utenze → ruoli → grant) |
| `template_tablespace.tbs.sql` | Tablespace dedicato |
| `template_user.usr.sql` | Creazione utenza, con le varianti per owner/AM, consumatori e tooling |
| `template_role.rol.sql` | Ruolo di profilo |
| `template_system_grant.grt.sql` | Privilegi di sistema, appartenenza ai ruoli e proxy, per profilo |

## Il template di tabella nel dettaglio

Il template di tabella (`template_table.tab.sql`) è il più articolato, e merita una spiegazione per intero perché introduce un principio che ne governa la struttura: la **separazione per sezioni**. Un file di tabella non è un unico `create table` che stipa al proprio interno colonne, default, vincoli e indici, ma una sequenza di sezioni distinte, ciascuna dedicata a una sola categoria di oggetti. Questa struttura vale come riferimento anche quando si scrive una tabella che il template non copre in ogni dettaglio.

### La create table: colonne, tipi e NOT NULL nominati

Nel blocco `create table` entrano soltanto le colonne con il loro tipo e i vincoli di **obbligatorietà**. Tutto il resto — i default delle colonne di dominio, le chiavi, i vincoli di valore, gli indici — è rimandato alle sezioni successive. La ragione è di leggibilità: una `create` ridotta all'osso comunica a colpo d'occhio la *forma* della tabella — quali colonne esistono, di che tipo, quali sono obbligatorie — senza che l'occhio debba scavalcare clausole di natura diversa.

I vincoli di NOT NULL restano inline, perché appartengono alla forma della colonna, ma vanno **sempre nominati esplicitamente**, secondo lo schema `<tabella>_nn_<colonna>` di `02_naming_conventions.md`:

```sql
create table orders
   ( order_id     number             constraint orders_nn_order_id    not null
   , order_date   date               constraint orders_nn_order_date  not null
   , status       varchar2(20 char)  constraint orders_nn_status      not null
   -- ...
   );
```

Un vincolo nominato non è un formalismo: quando viene violato, Oracle riporta il *nome* del constraint nell'errore, dicendo subito quale regola e quale tabella hanno fatto fallire l'operazione. Un NOT NULL anonimo, invece, riceve da Oracle un nome generato di sistema (`SYS_C0012345`) diverso da un ambiente all'altro: rende i messaggi d'errore opachi, i diff tra ambienti rumorosi, e impossibile riferirsi al vincolo per nome per modificarlo o rimuoverlo. Nominare esplicitamente ogni NOT NULL costa una manciata di caratteri e restituisce diagnosi chiare e riproducibili.

### Il blocco delle colonne amministrative

Le sette colonne amministrative (`row_version`, `created_*`, `modified_*`) restano **unite dentro la `create`**, come blocco fisso in coda alle colonne di dominio, e non vengono distribuite tra le sezioni successive. Fa parte di questo blocco anche il `default 1` di `row_version`, l'unico default che vive nella `create` invece che nella sezione dedicata. La ragione è che queste colonne non sono una scelta di disegno della singola tabella ma impiantistica standard, identica ovunque e generabile automaticamente: tenerle come un'unità coesa e riconoscibile vale più della regola generale di separazione, che serve invece a isolare le *scelte* di authoring. La loro definizione completa — tipi, visibilità, trigger che le popola — è in `Architettura_DB/colonne_amministrative.md`.

### I default in sezione separata

I valori di default delle colonne di **dominio** si dichiarano in una sezione propria, dopo la `create`, con `alter table ... modify`. Raccoglierli in un unico punto li rende verificabili insieme in code review — i default sono spesso il luogo di sottili errori di regole di business — e mantiene la `create` pulita. Se nessuna colonna di dominio ha un default, la sezione si rimuove.

### I constraint in sezione separata, sempre nominati

Chiavi primarie, chiavi univoche e vincoli di valore (`check`) si aggiungono in una sezione dedicata, ciascuno con un `alter table ... add constraint` e un nome esplicito secondo `02_naming_conventions.md` (`<tabella>_pk`, `<tabella>_uk[n]_<colonna>`, `<tabella>_ck[n]_<colonna>` o `<tabella>_ck[n]` per i check di tabella). Le motivazioni sono le stesse dei NOT NULL nominati — errori parlanti, nomi stabili tra ambienti — con in più due vantaggi di ciclo di vita: un constraint separato e nominato può essere **disabilitato, rimosso o ricreato indipendentemente** senza toccare la DDL della tabella, cosa preziosa nelle migrazioni; e la separazione permette di aggiungere i vincoli *dopo* un caricamento dati massivo, quando imporli riga per riga durante l'insert sarebbe costoso.

Per le chiavi primarie e univoche si usa **sempre la clausola `using index`**:

```sql
alter table orders
   add constraint orders_pk  primary key ( order_id )
   using index;
```

`using index` fa sì che l'indice di supporto che Oracle crea per la chiave erediti il **nome del constraint** (`orders_pk`), rendendo il nome dell'indice deterministico e coerente con la regola "gli indici che servono un constraint prendono lo stesso nome del constraint" di `02_naming_conventions.md`; e consente, dove serve, di indirizzarne lo storage aggiungendo `tablespace <nome>`. Senza la clausola l'indice verrebbe comunque creato, ma nome e collocazione resterebbero impliciti e fuori controllo.

### Le foreign key in file separati

Le foreign key **non** stanno nel file della tabella: si definiscono in file dedicati sotto `FKs/<tabella>.fky.sql` (dal template `template_foreign_key.fky.sql`), eseguiti in una fase di install successiva alla creazione di tutte le tabelle. Il motivo è la gestione delle dipendenze: una FK lega due tabelle, e se il vincolo vivesse nella `create` l'ordine di creazione delle tabelle diventerebbe vincolato e soggetto a stalli (A referenzia B, B referenzia A). Creando prima tutte le tabelle — in qualsiasi ordine — e aggiungendo le FK solo dopo, il problema sparisce. Le FK sono inoltre i vincoli che più spesso si disabilitano e ricreano durante le migrazioni di dati, e tenerle in file propri rende l'operazione localizzata.

### Gli indici in sezione separata

Gli indici non legati a un constraint si creano in una sezione propria, con nome `<tabella>_idx_<colonne>` (dicitura `idx`, secondo `02_naming_conventions.md`). Separarli riflette la loro natura: sono decisioni di performance che evolvono per conto proprio, indipendentemente dalla forma della tabella — se ne aggiungono e se ne tolgono nel tempo in base ai piani di esecuzione — e isolarli li rende facili da trovare, rivedere e modificare senza intaccare il resto della DDL.

### L'ordine delle sezioni

Un file di tabella si legge quindi sempre nella stessa sequenza: intestazione, `create table` (colonne di dominio e blocco amministrativo), default di dominio, constraint (PK, UK, CK), commenti a dizionario, indici, e infine il promemoria del trigger di audit. Ogni sezione è annunciata da una riga `prompt <tabella>: <azione>`, mentre gli elementi strutturali comuni a ogni file — marcatori, header con changelog, `show errors` — sono quelli descritti sopra in «Convenzioni comuni a tutti i template».
