prompt ------------------------------------------------------------

prompt File: pkg_<name>.pkb.sql <start>

prompt

-- =============================================================================
-- File:     pkg_<name>.pkb.sql
-- Oggetto:  pkg_<name> (package body)
-- Schema:   #APP#
-- Scopo:    Logica reale (join, filtri, algoritmi) per <name>. Non concesso in
--           grant; raggiunto dall'interno dell'owner per nome, e dai consumer
--           solo attraverso la shell pkg_<name>_shell.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data       Aut   Modifica
--   <YYYYMMDD>  <AA>  Creazione
-- =============================================================================

prompt -- Creating package body

create or replace
package body pkg_<name>
is
-- Costanti --------------------------------------------------------------------

-- Tipi ------------------------------------------------------------------------

-- Globali ---------------------------------------------------------------------

-- Dichiarazioni forward (opzionali) -------------------------------------------

-- Moduli privati --------------------------------------------------------------

-- Moduli pubblici -------------------------------------------------------------

--------------------------------------------------------------------------------
function <function_name>(i_<param_name> in <datatype>)
    return <datatype>
-- <descrizione del subprogram>
is
   l_result <datatype>;
begin
   -- <logica implementativa>
   return (l_result);
end <function_name>;
--------------------------------------------------------------------------------
end pkg_<name>;
/

show errors package body pkg_<name>

prompt File: pkg_<name>.pkb.sql <end>

prompt
