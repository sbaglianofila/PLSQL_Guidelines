# Utenti, profili e autorizzazioni

> **Bozza in via di consolidamento.** L'impianto — un RBAC a strati — e le scelte di fondo sono ormai fissati (vedi "Decisioni prese"). Restano da produrre gli oggetti di database; il documento diventerà stabile con la loro realizzazione.

## Di cosa parla questo documento, e di cosa no

Questo pillar definisce l'**autorizzazione funzionale a livello applicativo**: chi può vedere e usare quali maschere e quali funzioni dell'applicazione, e in che modo — in lettura, in scrittura o in esecuzione. È il modello che risponde alla domanda "questo utente può aprire l'anagrafica clienti? può modificarla? può lanciare l'elaborazione di chiusura?".

Va tenuto rigorosamente distinto dai **ruoli di database** descritti in `schemi.md`. Quelli — `#APP#_app_role`, `#APP#_ro_role`, `#APP#_am_role` — sono ruoli Oracle che governano i privilegi di *schema*: chi può eseguire quali package, leggere quali viste, fare DML su quali tabelle. Sono pochi, statici, definiti in fase di provisioning, e riguardano le *utenze di database* (il front end si connette come `#APP#_APP`, e basta). I ruoli e i profili di questo documento sono invece **dati applicativi**, righe in tabelle `adm_*`, gestiti a runtime dagli amministratori funzionali, e riguardano gli *utenti finali* dell'applicazione — persone, non account Oracle. La parola "ruolo" ha quindi due significati nel framework, e questa è la sede in cui vale il secondo.

Il legame tra i due mondi passa per l'identità di sessione. L'utente finale si autentica verso l'applicazione (con quale meccanismo — SSO, LDAP, tabella credenziali — è una scelta di progetto che questo documento non fissa), e la sua identità viene propagata al database come `CLIENT_IDENTIFIER`, lo stesso valore che il trigger di audit scrive in `created_by`/`modified_by` (vedi `colonne_amministrative.md`) e che l'audit dei cambi di stato registra in `changed_by` (vedi `stati_workflow.md`). Questo pillar è, in un certo senso, l'anagrafe di *chi sono* quelle identità e di *cosa* possono fare.

## Il modello a strati

L'impianto è una catena a quattro entità con tre relazioni molti‑a‑molti in mezzo. In prosa: un **utente** riceve uno o più **profili**; un profilo è un insieme di **ruoli** aziendali; le **funzionalità** — le capacità legate alle maschere — sono grantate ai profili con un modo di accesso. Un utente ottiene così, per transitività, le funzionalità di tutti i profili che gli sono assegnati.

Il ruolo aziendale è l'unità organizzativa atomica ("Contabile", "Responsabile Magazzino"); il profilo è un pacchetto di ruoli che rappresenta una figura lavorativa ("Impiegato amministrativo"); la funzionalità è la singola capacità operativa su una maschera. Questa separazione tra ruolo (mattone organizzativo) e profilo (figura assegnabile) è ciò che rende il tuo "insiemi di ruoli fanno un profilo": il profilo esiste per non dover riassegnare gli stessi ruoli a ogni utente simile.

## Le entità

### Gli utenti: `adm_users`

L'anagrafe degli utenti finali dell'applicazione. Non contiene necessariamente le credenziali — se l'autenticazione è esterna (SSO/LDAP) qui vive solo l'identità e lo stato — ma è il punto in cui l'identità applicativa diventa un dato referenziabile.

| Colonna | Tipo | Scopo |
|---|---|---|
| `user_id` | `number(12)` (`id_medium`) | Chiave primaria surrogata |
| `username` | `varchar2(64 char)`, unique | Identificativo di login, pubblicato nel contesto `APP_CTX` (`APP_USER`) via `lib_session.set_actor` |
| `full_name` | `varchar2(128 char)` | Nome per esteso |
| `email` | `email` | Contatto |
| `is_active` | `flag` | Utenza abilitata o disattivata |

### I ruoli aziendali: `adm_roles`

I ruoli organizzativi atomici. Tabella piccola e stabile, quindi chiave primaria naturale sul codice, coerentemente con la scelta fatta per le lookup.

| Colonna | Tipo | Scopo |
|---|---|---|
| `role_code` | `varchar2(32 char)` | Chiave primaria: codice del ruolo (`'ACCOUNTANT'`) |
| `name` | `varchar2(128 char)` | Nome leggibile |
| `description` | `varchar2(512 char)` | A cosa corrisponde il ruolo |
| `is_system` | `flag` | Ruolo predefinito del framework, non modificabile dagli amministratori |

### I profili: `adm_profiles`

I pacchetti di ruoli, ossia le figure assegnabili agli utenti. Stessa logica di chiave naturale.

| Colonna | Tipo | Scopo |
|---|---|---|
| `profile_code` | `varchar2(32 char)` | Chiave primaria: codice del profilo (`'ADMIN_CLERK'`) |
| `name` | `varchar2(128 char)` | Nome leggibile della figura |
| `description` | `varchar2(512 char)` | Descrizione della figura lavorativa |
| `is_system` | `flag` | Profilo predefinito, non modificabile |

### I moduli: `adm_modules`

Il livello in cima alla gerarchia del menu, che è a tre gradini: **modulo → maschera → funzionalità**. Un modulo raggruppa più maschere ("Contabilità", "Magazzino", "Anagrafiche"). Gli si è data una tabella dedicata per la stessa ragione per cui le maschere non sono un attributo testuale sulle funzionalità: il modulo porta attributi propri — un nome leggibile, una descrizione, un ordinamento a menu — e, soprattutto, una lista governata evita i moduli‑fantasma da refuso che il testo libero non impedirebbe. Le maschere lo referenziano con una foreign key.

| Colonna | Tipo | Scopo |
|---|---|---|
| `module_code` | `varchar2(32 char)` | Chiave primaria: codice del modulo (`'ACCOUNTING'`) |
| `name` | `varchar2(128 char)` | Nome leggibile del modulo |
| `description` | `varchar2(512 char)` | A cosa corrisponde il modulo |
| `sort_order` | `number` | Ordinamento dei moduli nel menu |
| `is_active` | `flag` | Modulo attivo o dismesso |

### Le maschere: `adm_masks`

Le schermate dell'applicazione, ciascuna delle quali raggruppa una o più funzionalità e appartiene a un modulo. Si è scelto di dare alle maschere una tabella dedicata, e non un semplice attributo testuale sulle funzionalità, perché la maschera porta attributi propri — un titolo, il modulo di appartenenza, un ordinamento a menu — che ne fanno un'entità a sé e non una semplice etichetta. Il `module_code` non è testo libero: è una foreign key verso `adm_modules`, così il riferimento è integro e la gerarchia del menu ha un livello superiore governato.

| Colonna | Tipo | Scopo |
|---|---|---|
| `mask_code` | `varchar2(32 char)` | Chiave primaria: codice della maschera |
| `name` | `varchar2(128 char)` | Titolo della maschera |
| `description` | `varchar2(512 char)` | A cosa serve la schermata |
| `module_code` | `varchar2(32 char)` | Foreign key verso `adm_modules`: il modulo di appartenenza |
| `sort_order` | `number` | Ordinamento delle maschere nel menu (entro il modulo) |
| `is_active` | `flag` | Maschera attiva o dismessa |

### Le funzionalità: `adm_functionalities`

Le capacità operative dell'applicazione, ciascuna legata a una maschera. Una funzionalità è la cosa che si granta: "Anagrafica Clienti", "Distinta base", "Chiusura di periodo". Una maschera espone tipicamente più funzionalità distinte — una per azione o area — e la relazione con la maschera è quindi molti‑a‑uno, materializzata da una foreign key.

| Colonna | Tipo | Scopo |
|---|---|---|
| `functionality_code` | `varchar2(32 char)` | Chiave primaria: codice della funzionalità |
| `mask_code` | `varchar2(32 char)` | Foreign key verso `adm_masks`: la schermata di appartenenza |
| `name` | `varchar2(128 char)` | Nome leggibile |
| `description` | `varchar2(512 char)` | Cosa consente di fare |

## Le relazioni

Le tre relazioni molti‑a‑molti che cuciono insieme le entità sono altrettante tabelle di associazione. Due di esse portano una **finestra di validità temporale**; una no, e la differenza non è casuale.

**`adm_profile_roles`** — la composizione di un profilo in ruoli, chiave `(profile_code, role_code)`. È la materializzazione di "insiemi di ruoli fanno un profilo". Questa relazione **non** porta finestra temporale: la composizione di un profilo è una scelta di disegno, strutturale e stabile, non qualcosa che si apre o si chiude nel tempo. "Questo ruolo compone il profilo solo a marzo" non è un'esigenza reale, e — poiché i ruoli non gate direttamente le funzionalità, essendo il tessuto organizzativo (§"Il modello a strati") — una finestra qui non concederebbe né revocherebbe alcun permesso effettivo. Resta perciò atemporale.

**`adm_user_profiles`** — l'assegnazione dei profili a un utente, chiave `(user_id, profile_code)`. È il punto in cui un utente diventa "qualcuno che può fare qualcosa". Poiché un utente può avere più profili, e ogni profilo porta più ruoli, ne discende che un utente ha effettivamente più ruoli aziendali — l'unione dei ruoli dei suoi profili — che è il senso del tuo "l'utente può avere diversi ruoli". Questa relazione porta una **finestra di validità** (`valid_from`/`valid_to`), perché l'assegnazione di un profilo a una persona è spesso a termine: una sostituzione, una reggenza, un incarico temporaneo. Poter dire "questo utente ha il profilo Responsabile dal 1° marzo al 30 giugno" senza doverlo ricordare e revocare a mano è esattamente ciò che la finestra offre.

| Colonna | Tipo | Scopo |
|---|---|---|
| `user_id` | `number(12)` (`id_medium`) | Utente a cui si assegna il profilo |
| `profile_code` | `varchar2(32 char)` | Profilo assegnato |
| `valid_from` | `date` | Inizio validità dell'assegnazione (incluso); `null` = da sempre |
| `valid_to` | `date` | Fine validità (inclusa); `null` = senza scadenza |

**`adm_profile_functionalities`** — i grant delle funzionalità ai profili, con il modo di accesso e la finestra di validità. Chiave `(profile_code, functionality_code)`, più i flag di modo e le date. È qui che vive il caso che apre questa scelta: "apri la maschera ORDINI al profilo ADMIN_CLERK a partire dal 1° marzo". Concedere o revocare per data, senza inventare profili né toccare il codice, è precisamente ciò che serve.

| Colonna | Tipo | Scopo |
|---|---|---|
| `profile_code` | `varchar2(32 char)` | Profilo a cui si concede la funzionalità |
| `functionality_code` | `varchar2(32 char)` | Funzionalità concessa |
| `can_read` | `flag` | Accesso in lettura |
| `can_write` | `flag` | Accesso in scrittura |
| `can_execute` | `flag` | Accesso in esecuzione |
| `valid_from` | `date` | Inizio validità del grant (incluso); `null` = da sempre |
| `valid_to` | `date` | Fine validità (inclusa); `null` = senza scadenza |

### La semantica della finestra temporale

Le finestre sono a **grana giornaliera** — sono date, non istanti. `valid_from` è il primo giorno in cui il grant è attivo, incluso; `valid_to` è l'ultimo giorno in cui lo è, incluso; entrambe sono nullable, dove `null` su `valid_from` significa "da sempre" e `null` su `valid_to` "senza scadenza". Il confronto si fa contro `trunc(sysdate)`: un grant è valido oggi se `valid_from` è nullo o `<= trunc(sysdate)`, e `valid_to` è nullo o `>= trunc(sysdate)`. La scelta della grana — il giorno e non il secondo — non è un dettaglio: è ciò che rende sostenibile lo strato veloce descritto più avanti, perché il permesso effettivo cambia solo alle mezzanotti e non a ogni istante.

## Le eccezioni nominali: `adm_user_functionalities`

C'è un caso che il modello a profili, da solo, gestisce male: la singola persona che deve poter fare *una* cosa in più rispetto a ciò che i suoi profili le concedono. Il contabile che, in via eccezionale, deve vedere la maschera ORDINI. Risolverlo creando un profilo dedicato — o duplicando un profilo esistente aggiungendovi quella funzionalità — porta alla proliferazione di profili‑fotocopia che l'intero impianto vuole evitare. La risposta è un **grant diretto all'utente**, alla grana della funzionalità, che si affianca ai grant per profilo come eccezione additiva.

La scelta della grana è deliberata. L'eccezione va sulla *funzionalità*, non sul profilo: assegnare un profilo in più a un utente lo si fa già con `adm_user_profiles`, mentre ciò che qui manca è concedere la singola capacità senza costruirle attorno un profilo. La tabella è perciò il parallelo esatto di `adm_profile_functionalities`, con lo stesso terzetto di modi, ma agganciata all'utente.

| Colonna | Tipo | Scopo |
|---|---|---|
| `user_id` | `number(12)` (`id_medium`) | Utente a cui si concede l'eccezione |
| `functionality_code` | `varchar2(32 char)` | Funzionalità concessa in eccezione |
| `can_read` | `flag` | Accesso in lettura |
| `can_write` | `flag` | Accesso in scrittura |
| `can_execute` | `flag` | Accesso in esecuzione |
| `valid_from` | `date` | Inizio validità (incluso); `null` = da subito |
| `valid_to` | `date` | Fine validità (inclusa); `null` = senza scadenza |
| `reason` | `varchar2(512 char)` | Motivazione dell'eccezione |

Due vincoli ne governano l'uso, e vanno tenuti fermi. Il primo: l'eccezione è **solo additiva**. Concede, non nega mai. Il permesso effettivo resta l'unione (l'OR) di tutto ciò che l'utente ottiene dai profili e dalle sue eccezioni; non esiste un'eccezione "in sottrazione" che tolga un permesso altrimenti concesso. La ragione è di sanità del modello: introdurre il *deny* per utente farebbe nascere il problema della precedenza — vince la negazione o la concessione? — che è la parte fragile e litigiosa di ogni sistema di autorizzazione. Se un progetto avesse davvero bisogno di negare, sarà una decisione esplicita e separata, non un'inerzia che ci si porta dietro adesso.

Il secondo: il campo `reason` non è decorativo. Un'eccezione nominale è esattamente ciò che un audit di sicurezza va a guardare per primo, e la domanda "perché questo utente vede ORDINI mentre il suo profilo non glielo consente?" deve avere una risposta scritta accanto al dato, non affidata alla memoria di chi l'ha concessa.

## I modi di accesso

I tre modi — lettura, scrittura, esecuzione — sono modellati come tre flag distinti sul grant, e non come un unico livello, perché non sono strettamente gerarchici: una figura può avere lettura e scrittura su una maschera anagrafica ma non l'esecuzione di un'azione che quella maschera espone, oppure la sola esecuzione di un'elaborazione senza vederne i dati. Tre booleani indipendenti esprimono qualunque combinazione senza forzare una scala. Quando un utente ha più profili che concedono la stessa funzionalità con modi diversi, il modo effettivo è l'**unione** (l'OR) dei flag: basta che un profilo conceda la scrittura perché l'utente scriva.

## La risoluzione dei permessi effettivi

Il permesso effettivo di un utente su una funzionalità è l'**unione di due contributi**, entrambi filtrati per validità temporale al momento della domanda:

- il contributo **dai profili** — dall'utente ai suoi profili validi oggi (`adm_user_profiles`), dai profili ai loro grant validi oggi (`adm_profile_functionalities`), aggregando in OR i modi concessi;
- il contributo **dalle eccezioni nominali** — i grant diretti validi in questo momento (`adm_user_functionalities`).

Il modo effettivo su una funzionalità è l'OR di tutti i flag che le due strade concedono: basta che un profilo *o* un'eccezione conceda la scrittura perché l'utente scriva.

Questa risoluzione non va sparsa nel codice applicativo: vive in un package di base — `lib_authz` — che espone le domande ricorrenti, `has_access(i_user, i_functionality, i_mode)` che risponde sì/no, e `functionalities_of(i_user)` che restituisce l'elenco delle funzionalità con i modi effettivi, tipicamente per costruire il menu dell'utente all'accesso. Come gli altri package di lettura di dati stabili (`lib_config`, `lib_lookup`), `lib_authz` tiene in cache per sessione i permessi risolti; la cache va però tarata sulla presenza di finestre temporali — per un utente con grant o eccezioni in scadenza, o non si cache quel ramo o gli si dà una TTL breve, così che una scadenza nell'arco della sessione non passi inosservata. Questo package va aggiunto al catalogo dei pacchetti base.

## Lo strato veloce: la vista materializzata dei permessi da profilo

La domanda calda — "questo utente può fare questa cosa?" — è una lettura ripetuta a ogni azione dell'interfaccia, e ripercorrere ogni volta la catena a quattro tabelle con le sue aggregazioni è lavoro sprecato su dati che cambiano di rado. Conviene precalcolare il **permesso effettivo già aggregato** in una vista materializzata e interrogarla con un solo accesso a indice.

Il punto di disegno decisivo è *cosa* materializzare. Non il prodotto cartesiano utente×ruolo×profilo×maschera×funzionalità — largo, ridondante (lo stesso permesso concesso da due profili genererebbe due righe) e inutilmente grande. Si materializza invece il risultato **aggregato**, una riga per coppia utente/funzionalità con i modi già messi in OR:

```
mv_user_effective_perms
  user_id
  functionality_code
  can_read / can_write / can_execute   -- OR dei modi da tutti i profili validi oggi
  mask_code / module_code              -- per costruire il menu senza tornare sulle base
  primary key (user_id, functionality_code)
```

Questa struttura è piccola — è utenti × funzionalità *distinte raggiungibili*, non il cartesiano — e risponde a `has_access` con una singola lettura su chiave univoca. Il join e l'aggregazione in OR si pagano **una volta**, dentro la query della vista, e non a ogni interrogazione.

Un chiarimento importante sul perimetro: la vista materializza **solo il contributo dai profili**. Le eccezioni nominali (`adm_user_functionalities`) restano **fuori**, lette al volo. Sono minuscole per definizione — eccezioni per pochi utenti — quindi la loro lettura live è un accesso a indice trascurabile, e tenerle fuori lascia la libertà, se un domani servisse, di dar loro una grana più fine del giorno senza dover ripensare la cadenza di refresh della vista. `has_access` diventa così l'OR di due letture: la vista materializzata (permessi da profilo, validi oggi) *or* la lettura live dell'eccezione (valida in questo istante).

### Perché una materializzata, e non una vista normale

Vale la pena chiederselo, perché su questi volumi — verosimilmente al più poche centinaia di migliaia di righe — una **vista normale** con la stessa aggregazione, più la cache di sessione di `lib_authz`, potrebbe già rispondere abbastanza in fretta. La materializzata si giustifica se si misura che la vista al volo è troppo lenta sotto carico, o se si vogliono indici fisici sul risultato aggregato. È una scelta da prendere con un numero in mano, non a priori. Il documento fissa la *forma* — aggregata, non cartesiana, solo profili — perché quella è corretta in entrambi i casi; se poi lo strato sia una MV o una vista è una decisione di realizzazione da confermare in fase di implementazione.

### La politica di refresh

Se lo strato è una vista materializzata, il come e il quando rinfrescarla è la scelta che tiene insieme correttezza e costo. Servono due meccanismi complementari:

- **Su evento** — dopo ogni modifica amministrativa alla mappa dei permessi (assegnazioni, grant, composizioni), il package che l'ha eseguita, a commit avvenuto, richiede il refresh completo della vista attraverso il punto unico `lib_authz.refresh_mv` (lo stesso che chiama il job schedulato). Le modifiche sono rare, quindi i refresh sono rari.
- **Schedulato una volta al giorno, a inizio giornata (00:00)** — per far scattare i confini di data delle finestre temporali, che cambiano il permesso effettivo *senza* alcuna DML: un grant che parte il 1° marzo diventa attivo quando la vista viene rinfrescata quel giorno.

Questi due insieme catturano ogni cambiamento con **zero finestra di incoerenza**, e il merito è della grana giornaliera delle finestre. Se le validità fossero al secondo, un refresh notturno lascerebbe buchi imprevedibili nell'arco della giornata; ma poiché il permesso effettivo cambia solo alle mezzanotti, un refresh allineato alla mezzanotte è esatto per costruzione, non un compromesso. La vista materializza sempre lo stato "valido oggi" (filtro `trunc(sysdate)` nella sua query), e va rinfrescata in modo **atomico** (`atomic_refresh => true`), così da non esporre mai un istante in cui è vuota o parziale — che, su una tabella di permessi, significherebbe negare l'accesso a tutti. Si evita invece il fast‑refresh incrementale: l'aggregazione in OR (un `max` sui flag 0/1) ha vincoli fastidiosi in cancellazione e su questi volumi non serve, mentre il refresh completo su evento è più semplice e altrettanto economico.

Un'ultima nota di responsabilità: la vista materializzata **non è mai la sorgente di verità**. È una proiezione calcolata, ricostruibile in ogni momento dalle tabelle `adm_*`. La verità su "chi ha concesso cosa e quando" vive nelle sette colonne amministrative delle tabelle base (§"Le colonne amministrative"), non qui.

### Il contratto del refresh su evento

Il refresh su evento ha un esecutore preciso: **la Table API di scrittura sulle `adm_*`** — il package attraverso cui passano tutti gli `insert`/`update`/`delete` sui grant, i profili e le assegnazioni. Non è un dettaglio di comodo ma il posto *obbligato*, e per tre ragioni che vanno tenute ferme quando quell'API verrà scritta, perché sono esattamente ciò che si dimentica.

La prima: il refresh vive **dopo il commit, non dentro la transazione**. `dbms_mview.refresh` esegue `commit` al proprio interno, quindi invocarlo mentre la transazione che modifica le `adm_*` è ancora aperta committerebbe a metà il lavoro in corso; e un trigger di riga, che non può committare né rinfrescare una MV, è escluso a maggior ragione. Ne discende che l'aggancio è **codice del chiamante a valle del commit**, non un automatismo dichiarativo sul database: è per questo che appartiene all'API e non a un trigger sulle tabelle.

La seconda: il refresh si fa **una volta per unità di lavoro, non per riga**. Se un amministratore concede cinquanta funzionalità in un'unica operazione, si vuole *un* refresh alla fine, non cinquanta: la chiamata a `refresh_mv` sta a valle del commit del blocco di modifiche, mai dentro il ciclo che le applica. Se un domani il refresh completo risultasse pesante sotto raffiche, il pattern pulito è **coalescere** — l'API sottomette un job "esegui una volta subito" invece del refresh sincrono, così la scrittura ritorna immediatamente e le raffiche si fondono in un solo refresh — ma dato che le `adm_*` cambiano di rado si parte dal refresh sincrono dopo commit, più semplice, e si passa al debounce solo se le misure lo chiedono.

La terza: il refresh della MV **non tocca le cache di sessione** di `lib_authz`. `refresh_mv` aggiorna il dato materializzato; le altre sessioni continuano a servire la loro copia in memoria fino allo scadere del TTL. La sessione dell'amministratore che ha appena modificato, se vuole vedere il cambiamento immediatamente, chiama anche `lib_authz.refresh` (la cache, da non confondere con `refresh_mv`).

Da questi vincoli discende la scelta del **confine transazionale**, che è una deroga *dichiarata e circoscritta* alla regola generale del framework "il commit è del chiamante". Quella regola esiste per far comporre alla logica applicativa più scritture in un'unica unità di lavoro atomica, ed è il comportamento del flusso transazionale dell'applicazione. Le operazioni RBAC non stanno in quel flusso: sono atti amministrativi discreti, fuori banda, fatti da un amministratore, che non devono comporre con la DML di business — e il vincolo "refresh dopo il commit" impone comunque che la Table API possieda e chiuda la propria transazione. Quindi la write API delle `adm_*` **committa da sé**: ogni operazione fa la sua DML, committa, e poi (dove serve) chiama `refresh_mv`. Questa deroga vale *solo* per le operazioni amministrative delle `adm_*`; ovunque altro la regola del commit al chiamante resta invariata. Perché la deroga non diventi un footgun va marcata a voce alta nell'header del package (*"queste procedure committano; non invocarle dentro una transazione applicativa aperta"*), e il caricamento **iniziale** del catalogo non passa da questa API ma dagli script di seed `.dat.sql` (dati di baseline), così un setup di massa non genera un commit e un refresh per riga.

La catena completa è quindi: l'API modifica le `adm_*` → `commit` → `lib_authz.refresh_mv` (rinfresca la MV) → opzionalmente `lib_authz.refresh` (invalida la propria cache). L'esecutore di questa catena è il package **`lib_authz_admin`**, la Table API di scrittura sulle `adm_*`, gemello di scrittura di `lib_authz`. Non tutte le sue operazioni chiamano `refresh_mv`: solo quelle che toccano ciò che la MV materializza (assegnazioni utente-profilo e grant funzionalità-profilo); le eccezioni nominali e lo stato dell'utente, che `lib_authz` legge al volo, e la composizione profilo-ruolo, che non gate le funzionalità e non entra nella MV, committano soltanto.

## Le colonne amministrative

Tutte le tabelle `adm_*`, comprese quelle di associazione, portano le sette colonne amministrative standard con il loro trigger di audit (`colonne_amministrative.md`). Qui non è un automatismo formale ma un requisito sostanziale: sapere chi ha assegnato un profilo a un utente, chi ha concesso una funzionalità a un profilo e quando, è informazione di sicurezza di prima importanza, e un cambiamento non tracciato alla mappa dei permessi è esattamente ciò che un audit di sicurezza deve poter ricostruire.

## Decisioni prese

I quattro nodi lasciati aperti nella prima stesura sono stati sciolti.

L'**assegnazione e i grant** restano come impostati: l'utente riceve *profili* (`adm_user_profiles`) e le funzionalità sono grantate ai *profili* (`adm_profile_functionalities`); i ruoli sono il tessuto organizzativo che compone il profilo, non un'unità che gate direttamente le funzionalità. È il modello più semplice e corrisponde all'enunciato originario.

Le **maschere** hanno una tabella dedicata `adm_masks`, e le funzionalità la referenziano con una foreign key: una maschera raggruppa più funzionalità e porta attributi propri (titolo, modulo, ordinamento a menu) che giustificano l'entità separata.

Anche i **moduli** hanno una tabella dedicata `adm_modules`, referenziata da `adm_masks.module_code` con una foreign key, per la stessa regola di promozione applicata alle maschere: il modulo è il livello superiore del menu (modulo → maschera → funzionalità), porta attributi propri (nome, descrizione, ordinamento) e una lista governata evita i moduli‑fantasma da refuso che il testo libero consentirebbe. Scelta simmetrica a quella sulle maschere, non un'aggiunta speculativa; la vista materializzata e `lib_authz` non ne sono toccati, perché continuano a portare `module_code` come codice e le etichette si risolvono in fase di costruzione del menu.

La **scrittura sulle `adm_*`** passa da una Table API dedicata, il package `lib_authz_admin` (gemello di scrittura di `lib_authz`), e non da DML sparsa: è il punto in cui si incapsulano validazione, audit e — dove serve — l'innesco del refresh su evento. La API **committa da sé** (ogni operazione: DML → commit → eventuale `refresh_mv`), deroga dichiarata e circoscritta alla regola generale "commit al chiamante", giustificata dalla natura amministrativa e fuori-banda di queste operazioni e imposta dal vincolo "refresh dopo il commit" (vedi §"Il contratto del refresh su evento"). Il caricamento iniziale del catalogo resta invece competenza degli script di seed, non della API.

L'**autenticazione** è assunta **esterna**: il framework riceve a valle solo l'identità (`username`, pubblicato nel contesto `APP_CTX` via `lib_session.set_actor`) e non gestisce credenziali né password. Se un progetto dovesse gestirle internamente, sarà un'estensione da definire esplicitamente (memorizzazione con hash, policy, `dbms_crypto`), non un'assunzione di questo impianto.

I **modi di accesso** sono tre flag indipendenti (`can_read`/`can_write`/`can_execute`) sul grant, adatti a tre modi fissi; non si adotta una lookup dei modi, che avrebbe senso solo con modi numerosi o variabili.

Le **finestre temporali** sono state introdotte sulle due relazioni di assegnazione/grant — `adm_user_profiles` e `adm_profile_functionalities` — con grana a data (`valid_from`/`valid_to`), per poter aprire e chiudere accessi per data senza creare profili ad hoc. La composizione `adm_profile_roles` resta atemporale, essendo strutturale. La grana giornaliera è una scelta portante e non incidentale: rende il permesso effettivo variabile solo alle mezzanotti, e questo è ciò che rende sostenibile lo strato materializzato con refresh su evento più uno schedulato giornaliero.

Le **eccezioni nominali** (`adm_user_functionalities`) integrano il modello a profili con grant diretti all'utente: additivi (mai in negazione), a grana di funzionalità, opzionalmente a tempo, con motivazione obbligatoria (`reason`) per l'audit. Esistono per evitare la proliferazione di profili‑fotocopia creati solo per concedere pochi permessi individuali.

Lo **strato veloce** è una proiezione aggregata dei permessi da profilo (`mv_user_effective_perms`): una riga per utente/funzionalità con i modi in OR, non il prodotto cartesiano, e con i soli permessi da profilo — le eccezioni restano lette al volo. Se realizzato come vista materializzata, il refresh è su evento più uno schedulato giornaliero a mezzanotte, atomico, senza fast‑refresh incrementale. Se lo strato debba essere una MV o una vista normale è una decisione di implementazione da confermare con misure alla mano.

## Possibile estensione futura

Una **gerarchia di funzionalità** — una funzionalità padre che ne raccoglie di figlie, per concedere in blocco un'intera area — non è prevista in questa versione, ma è un'aggiunta naturale se un progetto ne mostrasse il bisogno: si realizzerebbe con un'auto‑referenza su `adm_functionalities`, senza toccare il resto dell'impianto.
