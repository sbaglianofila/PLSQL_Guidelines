# Stati e workflow

Lo stato di un ordine, di una pratica, di un documento sembra a prima vista una lista di valori come un'altra — `OPEN`, `PROCESSED`, `CANCELLED` — e verrebbe la tentazione di metterlo tra le lookup generiche descritte in `lookups.md`. È una tentazione da respingere, perché uno stato non è un valore piatto: è un nodo di una **macchina a stati**. Di uno stato non interessa solo il codice e l'etichetta, ma da quali altri stati ci si può arrivare e verso quali si può proseguire — le *transizioni ammesse* — e, altrettanto importante, la storia di come ogni singola entità ha attraversato quegli stati nel tempo: chi ha portato l'ordine da `OPEN` a `PROCESSED`, quando e perché.

Nessuna di queste tre cose — le transizioni, le regole che le governano, l'audit dei cambiamenti per entità — entra nelle tabelle di lookup, che sanno soltanto elencare valori. È l'esempio più netto della "regola di promozione" enunciata in `lookups.md`: gli stati graduano a un pillar dedicato, con un prefisso proprio, `wfl_` (workflow). Questo documento ne definisce l'impianto e ne spiega le regole.

Vale la pena distinguere subito questo pillar dal lavoro sulle colonne amministrative (`colonne_amministrative.md`), perché i due si completano ma operano a livelli diversi. Le sette colonne amministrative dicono, per ogni riga, chi l'ha modificata l'ultima volta e quando — un'informazione a grana di riga, indifferenziata rispetto a *cosa* è cambiato. L'audit dei cambi di stato dice qualcosa di più specifico e più ricco: che la dimensione *stato* è passata da un valore a un altro, per opera di chi, quando e per quale motivo. La prima è impiantistica generale; la seconda è tracciamento di dominio sulla transizione di stato.

## Che cosa si costruisce ora, e che cosa no

Il pillar si articola su livelli che è bene tenere distinti, perché non hanno lo stesso peso né la stessa priorità. C'è la **definizione** del workflow — quali processi esistono, quali stati, quali archi ammessi, chi è autorizzato — che è configurazione dichiarativa a basso volume. C'è la **storia** — una riga per ogni transizione realmente avvenuta su una specifica entità — che è dato transazionale. E c'è la parte **operativa** — la to-do list di chi deve agire, con scadenze e notifiche — che porta valore all'utente finale ma è un impegno più grosso.

Di questi, il framework realizza ora i primi due: le tabelle di definizione, il motore di validazione `lib_workflow`, e le regole di integrità che legano gli stati alle tabelle di business. La storia è un **pattern per-entità** documentato qui e materializzato dalla Table API di ciascuna entità. La parte operativa — i *task* — e gli *hook/notifiche* al passaggio di stato sono riconosciuti come evoluzioni desiderabili ma **rimandati**: se ne parla in fondo, tra gli sviluppi futuri, e non si costruiscono finché un bisogno concreto non li chiami. È una scelta deliberata, coerente col principio del framework di non anticipare strutture che complicherebbero senza ripagare.

## Perché la definizione è una tabella unica e la storia è per entità

Qui va sciolto subito un dubbio legittimo, perché il pillar mescola due scelte opposte e l'asimmetria, se non spiegata, sembra una svista: le tabelle di **definizione** (stati e transizioni) sono **uniche** per tutti i workflow, mentre l'**audit** della storia è una tabella **dedicata per ciascuna entità**. Perché non trattarle allo stesso modo?

La ragione è la regola di promozione di `lookups.md`, applicata con precisione. Quella regola non dice "quando una cosa cresce, dàlle una tabella propria"; dice qualcosa di più mirato: si promuove a tabella dedicata quando il contenitore generico **perde una foreign key tipizzata verso la riga di business**. È esattamente il caso dell'audit — `wfl_orders_status_log.order_id` che punta a `orders` è integrità dichiarativa vera, che un contenitore generico con colonne `entity_table`/`entity_id` butterebbe via. Ma una transizione non punta a nessuna riga di business: punta a due stati, che vivono già in `wfl_statuses`. La foreign key tipizzata c'è ed è pulita sia nella versione unica sia in una ipotetica versione per entità — **non si perde niente** a tenerla unica. Il criterio che promuove l'audit semplicemente non si attiva sulle transizioni.

Detto in positivo: la **definizione** è configurazione a basso volume, senza riferimenti al business, consumata da un motore generico → tabella unica. La **storia** è dato transazionale ad alto volume, con riferimento diretto a una riga di business, consumato per entità → tabella dedicata. Sono due nature diverse e meritano due trattamenti diversi.

La scelta della tabella unica per le transizioni ha, oltre a questo, tre vantaggi concreti che pesano. Il primo, e il più importante, è che `lib_workflow` resta un **package statico scritto una volta**: la validazione è una `select` su una tabella nota, non un nome di tabella che dipende da un parametro. Con transizioni declinate per entità quella `select` non si potrebbe scrivere senza SQL dinamico dentro il motore di validazione — proprio il codice in cui non lo si vuole, perché un errore di configurazione diventerebbe un `ORA-00942` a runtime invece di un problema visibile in compilazione. Il secondo è che aggiungere un workflow diventa un **inserimento di dati**, non un cambiamento di struttura con DDL, grant e sinonimi al seguito. Il terzo è che le query trasversali — generare la documentazione di un processo, disegnarne il diagramma, o le query di controllo dell'AM del tipo "esistono stati da cui non esce alcuna transizione?" — sono una `select`, non una `union` su un insieme di tabelle che cresce a ogni entità.

Il prezzo della tabella unica è di due tipi, e nessuno dei due obbliga a spezzarla. Il primo è di rilascio: due sviluppatori che aggiungono transizioni a workflow diversi nello stesso sprint toccano lo stesso oggetto. Si risolve separando i **file di seed**, non le tabelle — un file per workflow (`wfl_transitions_order.dat.sql`, `wfl_transitions_contract.dat.sql`), ciascuno che gestisce le sole righe del proprio `workflow_code` — così si ottiene l'isolamento in version control mantenendo il motore unico. Il secondo è che il set di colonne è comune a tutti i workflow: un attributo condizionale che servisse a un solo processo si aggiungerebbe a tutti. Ma è proprio il caso che gli sviluppi futuri (il motore di regole) hanno deciso di non anticipare, quindi non morde oggi. Se un domani l'isolamento tra workflow dovesse contare di più — per permessi fini o pura leggibilità — la via di mezzo prima di spezzare la tabella è una **vista per workflow** (`wfl_order_transitions_v`) con `check option`, che dà il nome dedicato senza toccare il motore.

## L'impianto della definizione

La definizione è una catena di quattro tabelle: il workflow, i suoi stati, le transizioni ammesse tra gli stati, e i ruoli autorizzati a ciascuna transizione.

### Il workflow: `wfl_workflows`

È la testata del pillar, la novità rispetto alla prima stesura. Prima il `workflow_code` era un codice libero che compariva ovunque senza una tabella che lo definisse; ora è un'entità, ed è ciò che rende possibile la foreign key composita dalle tabelle di business (la si vede più avanti). La chiave è naturale, il codice mnemonico del processo, per la stessa ragione delle lookup: è una tabella minuscola e stabile, dove la costante che comparirà nelle colonne virtuali di business dev'essere leggibile e non un surrogato opaco.

| Colonna | Dominio | Scopo |
|---|---|---|
| `workflow_code` | `code` | Chiave naturale del workflow (`'ORDER'`) |
| `name` | `name` | Etichetta leggibile del processo |
| `description` | `description` | Cosa governa |
| `entity_table` | `short_name` | Tabella di business governata, a scopo documentativo (non è una foreign key: la tabella di business può non esistere ancora) |
| `guard_handler` | `name` | `package.funzione` dispatcher che valuta i criteri del workflow; nullo se il workflow non ne ha (vedi "I criteri") |
| `is_valid` | `flag` | Workflow attivo o dismesso |

Oltre a queste, come ogni tabella, porta le sette colonne amministrative con il relativo trigger.

### Gli stati: `wfl_statuses`

Ogni workflow ha il proprio insieme di stati. A differenza di un valore di lookup, uno stato porta attributi che descrivono il suo ruolo nella macchina: se è lo stato *iniziale* in cui un'entità nasce, se è uno degli stati *finali* oltre i quali non si prosegue, oltre all'etichetta e all'ordinamento.

| Colonna | Dominio | Scopo |
|---|---|---|
| `workflow_code` | `code` | Il workflow di appartenenza (FK verso `wfl_workflows`) |
| `status_code` | `code` | Il codice dello stato (`'OPEN'`), unico entro il workflow |
| `label` | `name` | Testo mostrato a video |
| `sort_order` | `number` | Ordine di presentazione |
| `is_initial` | `flag` | Stato in cui l'entità nasce (al più uno per workflow) |
| `is_final` | `flag` | Stato terminale (zero o più per workflow) |
| `is_valid` | `flag` | Stato ancora in uso o dismesso |

La chiave è `(workflow_code, status_code)`. Il vincolo "al più uno stato iniziale per workflow" non è lasciato alla disciplina di chi inserisce i dati ma è imposto da un **indice unico funzionale**, la cui chiave è valorizzata solo per la riga con `is_initial = 'Y'` e nulla per le altre — Oracle non indicizza le chiavi tutte-nulle, quindi il vincolo morde solo dove serve senza impedire i molti stati non iniziali.

### Le transizioni: `wfl_transitions`

È qui che vive la macchina a stati vera e propria: l'elenco degli archi ammessi tra uno stato e l'altro, una riga per transizione permessa. Rispetto alla prima stesura questa tabella porta una scelta importante: la transizione ha un **codice proprio**, `transition_code`, e non è identificata dalla sola coppia `(from, to)`.

La ragione è che in interfaccia l'utente non sceglie uno stato di arrivo, sceglie un'**azione** — "Approva", "Respingi", "Rimanda al richiedente". Se la transizione non avesse un'identità propria, l'azione andrebbe ricostruita ogni volta dalla coppia di stati, e non sarebbe nemmeno univoca: due azioni diverse possono portare allo stesso stato di arrivo ("respinto per importo" e "respinto per documenti" finiscono entrambe in `REJECTED`). Il codice dà anche l'aggancio naturale per l'etichetta del bottone e per il messaggio a catalogo.

| Colonna | Dominio | Scopo |
|---|---|---|
| `workflow_code` | `code` | Il workflow di appartenenza (FK verso `wfl_workflows`) |
| `transition_code` | `code` | Il codice dell'azione (`'APPROVE'`); con `workflow_code` forma la chiave |
| `from_status` | `code` | Stato di partenza |
| `to_status` | `code` | Stato di arrivo |
| `label` | `name` | Etichetta dell'azione a video |
| `requires_reason` | `flag` | La causale è obbligatoria per questa azione |
| `is_valid` | `flag` | Transizione attiva o disattivata |

La chiave è `(workflow_code, transition_code)`; un vincolo di unicità aggiuntivo su `(workflow_code, from_status, transition_code)` garantisce che da uno stato non partano due azioni con lo stesso codice. Le foreign key di `from_status` e `to_status` sono **composite**, su `(workflow_code, status_code)` verso `wfl_statuses`: così non solo lo stato deve esistere, ma deve appartenere *allo stesso workflow* della transizione, non a un altro. Un check impedisce inoltre la transizione degenere di uno stato verso sé stesso. La regola "da `OPEN` si può solo andare a `PROCESSED` o `CANCELLED`" diventa così un dato, non codice: aggiungere o togliere un arco non richiede di ricompilare nulla.

### I ruoli autorizzati: `wfl_transition_roles`

La prima stesura teneva un singolo `allowed_role` sulla transizione. È troppo stretto: "Approva" la possono fare Responsabile *o* Direttore, e un attributo singolo costringerebbe a duplicare la riga della transizione — che è la stessa transizione — solo per moltiplicare i ruoli. Il controllo di ruolo diventa quindi una tabella ponte molti-a-molti.

| Colonna | Dominio | Scopo |
|---|---|---|
| `workflow_code` | `code` | Parte della FK verso `wfl_transitions` |
| `transition_code` | `code` | Parte della FK verso `wfl_transitions` |
| `role_code` | `code` | Ruolo aziendale autorizzato all'azione |

La chiave è la terna intera. La convenzione è deliberata e va ricordata: **l'assenza di righe per una transizione significa "nessun controllo di ruolo"**, cioè l'azione è ammessa a chiunque e decide la sola macchina a stati; appena compare una riga, la transizione si chiude ai soli ruoli elencati.

Il `role_code` è il codice del **ruolo aziendale applicativo** del pillar RBAC (`adm_roles` in `utenti_profili.md`), non un ruolo di database di `schemi.md`: la distinzione tra i due significati di "ruolo" è discussa lì. La foreign key verso `adm_roles` che chiuderebbe l'integrità è **predisposta ma differita**, commentata nel file delle foreign key, perché il pillar RBAC non è ancora realizzato come oggetti; va abilitata quando lo sarà. Fino ad allora la validità del codice ruolo è a carico della sola Table API.

### I criteri: `wfl_transition_guards`

> Nota terminologica: nel codice questi oggetti portano il nome inglese standard delle macchine a stati UML — `guard` (`wfl_transition_guards`, `guard_code`, `guard_handler`, `check_guard`). Nella documentazione italiana li chiamiamo **criteri** perché "guardia" è un calco che suona forzato; è la solita divisione del framework tra identificatori inglesi e prosa italiana.

Il ruolo dice *chi* può compiere un'azione; resta da esprimere *se i dati lo permettono*. "Approva" può richiedere che l'importo sia sotto una soglia, che la documentazione sia completa, che il cliente non sia in blocco. Questa è la condizione che la sola macchina a stati e il solo ruolo non catturano, e per la quale la prima stesura rimandava a un generico "motore di regole".

La scelta qui è deliberatamente **sobria**, per non costruire quel motore. Una condizione non si esprime *come dato* — niente operatori, soglie, alberi di `AND`/`OR` in tabella, che trasformerebbero il pillar in un interprete di regole da mantenere. Si esprime come **codice PL/SQL compilato dietro un nome**: un *criterio* è un puntatore a una funzione booleana. La logica vive dove le appartiene — in un package applicativo, testabile e sotto version control — e la tabella registra soltanto *quali* criteri valgono per *quale* transizione. È il pattern strategy: il confine da non superare è mettere la condizione nel dato; finché la condizione è codice, si resta nel punto giusto.

I criteri vivono in una tabella figlia di `wfl_transitions`, gemella di `wfl_transition_roles`:

| Colonna | Dominio | Scopo |
|---|---|---|
| `workflow_code` | `code` | Parte della FK verso `wfl_transitions` |
| `transition_code` | `code` | Parte della FK verso `wfl_transitions` |
| `guard_code` | `code` | Nome logico del criterio (`'AMOUNT_UNDER_LIMIT'`); parte della chiave |
| `deny_message_code` | `code` | Messaggio `cfg_messages` sollevato quando il criterio nega |
| `sort_order` | `number` | Ordine di valutazione |

La chiave è `(workflow_code, transition_code, guard_code)`. La semantica è per **`AND`**: più criteri sulla stessa transizione devono passare *tutti*, valutati in ordine, e al primo che nega si solleva il suo `deny_message_code`. Come per i ruoli, **l'assenza di righe significa nessun criterio**: la transizione dipende solo dalla macchina a stati e dal ruolo. Due responsabilità nette e componibili: `wfl_transition_roles` esprime il *chi*, `wfl_transition_guards` esprime il *se i dati lo consentono*.

Il fatto che il criterio sia un **predicato puro** — ritorna vero/falso senza effetti collaterali — è voluto: lo rende banale da testare in isolamento, e tiene separato il *controllo* (codice) dalla sua *spiegazione* (`deny_message_code`, dato correggibile a runtime). La causale del rifiuto non è cablata nella funzione.

**Un solo dispatcher per workflow.** La tabella non memorizza un identificatore `package.funzione` per ogni criterio, ma solo il `guard_code` logico; il puntatore al codice sta una volta sola su `wfl_workflows.guard_handler` (per esempio `pkg_orders.check_guard`). Quel dispatcher riceve il `guard_code` e smista internamente con un `case`. Questo riduce la superficie dinamica a **un unico punto di chiamata per workflow**, tiene i `guard_code` come token puliti invece che nomi di codice sparsi nel dato, e raccoglie tutti i criteri di un'entità in un solo package dove si leggono insieme.

La firma del dispatcher è **fissa e uniforme**, così `lib_workflow` chiama ogni workflow allo stesso modo:

```plsql
function check_guard( i_workflow_code   in varchar2
                    , i_transition_code in varchar2
                    , i_from_status     in varchar2
                    , i_to_status       in varchar2
                    , i_entity_pk       in varchar2   -- la PK della riga coinvolta
                    , i_guard_code      in varchar2 )
    return boolean;
```

La **PK dell'entità** è in ingresso perché un criterio data-driven deve caricare la riga per decidere (l'importo di *quell'*ordine, non un importo astratto). È passata come `varchar2` — stringa — proprio per tenere la firma unica: una PK surrogata `number` si converte, e una PK non numerica o composita non rompe il contratto. Il dispatcher carica la riga per PK e legge ciò che gli serve.

**Come `lib_workflow` chiama il dispatcher, e l'unico pericolo.** Il motore è generico e non può dipendere da `pkg_orders`: lo chiamerebbe per nome, con una chiamata PL/SQL dinamica (`execute immediate` di un blocco anonimo). Questo *late binding* non è una scorciatoia ma la scelta corretta di stratificazione — è ciò che tiene il codice base indipendente dal codice applicativo, con la dipendenza nel verso giusto (l'app conosce il contratto, non viceversa). Il pericolo reale è uno solo: `guard_handler` è un nome concatenato dentro codice dinamico, quindi va **validato** prima dell'uso con `dbms_assert.qualified_sql_name`, che neutralizza ogni tentativo di injection (è configurazione di amministratori, non input utente, ma la difesa resta d'obbligo). Nota tecnica: un `boolean` non è bindabile in SQL dinamico, perciò il blocco converte l'esito (`... := case when check_guard(...) then 1 else 0 end`). Se una transizione ha criteri ma il suo workflow non ha un `guard_handler`, è un errore di configurazione e viene segnalato esplicitamente (`WFL_GUARD_HANDLER_MISSING`).

## L'integrità dal lato delle tabelle di business

Restava, dalla prima stesura, un nodo aperto: come vincolare la colonna di stato di una tabella di business ai soli stati del suo workflow. Con `wfl_workflows` come padre e la chiave naturale su `wfl_statuses`, la strada è la stessa **foreign key composita con colonna virtuale costante** già usata per le lookup, e ora la si può adottare pienamente.

Il problema è identico a quello delle lookup: la tabella di business porta solo il `status_code` (`'OPEN'`), non la coppia `(workflow_code, status_code)` che identifica lo stato in `wfl_statuses`. La soluzione è aggiungere alla tabella di business una colonna virtuale che vale la costante del workflow, e definire la foreign key sulla coppia. La colonna virtuale non occupa spazio, è calcolata e sempre uguale, e rende la foreign key auto-documentante:

```sql
  status         varchar2(32 char)
, status_wfl     varchar2(32 char) generated always as ('ORDER') virtual
, constraint orders_fk_status
     foreign key (status_wfl, status)
     references wfl_statuses (workflow_code, status_code)
```

Si legge "questa colonna di stato appartiene al workflow `ORDER`", ed è qui che la chiave naturale di `wfl_workflows` e `wfl_statuses` ripaga: la costante è il codice leggibile del processo, non un numero opaco. Come per le lookup, questo è uno strumento **opt-in**, riferimento per riferimento: lo si usa dove l'integrità dichiarativa della colonna di stato conta davvero; dove non è critico, la validazione dello stato resta alla Table API in scrittura. E come per le lookup, va confermato in fase di compilazione sull'istanza target che la foreign key su colonna virtuale sia accettata nella configurazione — è una costruzione supportata da Oracle, ma il codice del framework non è ancora stato compilato su un database.

## La storia dei cambiamenti

La storia registra ciò che è realmente accaduto: una riga per ogni transizione avvenuta su una specifica entità. È un log append-only che risponde alla domanda "come è arrivato quest'ordine allo stato in cui è?". Come spiegato sopra, è realizzato con una **tabella dedicata per entità** — `wfl_<entità>_status_log`, per esempio `wfl_orders_status_log` — con foreign key tipizzata verso la riga di business, e non con un contenitore generico. Il costo di una tabella in più per entità con workflow è basso e ripaga in chiarezza e integrità; le entità senza workflow semplicemente non ne hanno.

| Colonna | Dominio | Scopo |
|---|---|---|
| *(FK all'entità)* | `id_medium` | La riga di business che ha cambiato stato (FK tipizzata, es. `order_id` → `orders`) |
| `from_status` | `code` | Stato di partenza (nullo alla creazione) |
| `to_status` | `code` | Stato di arrivo |
| `transition_code` | `code` | L'azione compiuta, così il log registra *cosa* è stato fatto e non solo il salto |
| `changed_at` | `datetime_val` | Istante del cambiamento |
| `changed_by` | `short_name` | Utente che ha effettuato il cambiamento |
| `reason` | `note` | Motivo del cambiamento (obbligatorio se l'azione lo richiede) |

Sul rapporto con le colonne amministrative vale la pena chiarire un potenziale doppione: la tabella di audit porta comunque le sette colonne amministrative standard, e le sue `created_by`/`created_at` conterrebbero di fatto la stessa informazione di `changed_by`/`changed_at`, dato che ogni riga di log nasce nel momento del cambiamento e non viene più modificata. Si adottano comunque le **colonne esplicite** `changed_by`/`changed_at`, perché `reason`, `from_status`, `to_status` e `transition_code` sono già dati di dominio e avere accanto l'attore e l'istante espliciti rende la tabella auto-descrittiva, senza dover ricordare che qui, eccezionalmente, l'audit di riga coincide col dato di business.

Poiché il nome della tabella di log dipende dall'entità, questa storia **non** è scritta da `lib_workflow` (che è statico e non conosce le tabelle di business), ma dalla Table API dell'entità, generata dal template di pillar. È una conseguenza diretta della scelta dell'audit per-entità, e va accettata come tale: centralizzare la validazione e distribuire la scrittura della storia è il compromesso che tiene il motore pulito senza rinunciare all'integrità tipizzata del log. Il contratto operativo è descritto nella sezione seguente.

Una tentazione da nominare per respingerla: introdurre una `wfl_instances` generica, un'istanza di processo per ogni riga di business. Reintrodurrebbe la coppia `entity_table`/`entity_id` che il framework ha già rifiutato per le lookup, e creerebbe un terzo posto in cui cercare la verità. Lo stato vive nella colonna sulla tabella di business, la storia nel log dedicato: due posti, non tre.

## La validazione: `lib_workflow`

Le tabelle di definizione descrivono la macchina a stati; `lib_workflow` è il package di base che la fa rispettare e la interroga, scritto una volta per tutti i workflow. Concentrare qui il controllo evita che ogni entità reimplementi la logica delle transizioni. In lettura è il gemello di `lib_lookup` sul versante del workflow: tiene in cache per workflow gli stati, le transizioni valide e i ruoli, che cambiano di rado.

La convenzione d'uso segue quella di `lib_lookup`: le **interrogazioni non sollevano** — tornano `false`, `null` o collezione vuota di fronte a un dato mancante, così l'interfaccia resta robusta — mentre l'unico punto che solleva è `assert_action`, il punto di applicazione. Le operazioni principali:

- `status_exists`, `initial_status`, `is_final` — le domande di base sugli stati di un workflow.
- `can_transition(workflow, from, to, role)` — vero se esiste una transizione valida tra due stati, e se il ruolo (quando indicato) è autorizzato.
- `target_status(workflow, from, transition)` — lo stato di arrivo di un'azione a partire da uno stato, il modo naturale di lavorare dall'interfaccia dove l'utente sceglie un'azione.
- `available_actions(workflow, from, role)` — l'elenco delle azioni disponibili da uno stato, per disegnare i bottoni, già filtrate sul ruolo.
- `assert_action(workflow, from, transition, role, reason, entity_pk)` — il **punto di applicazione**: valida in sequenza che l'azione sia una transizione ammessa da quello stato, che il ruolo sia autorizzato, che la causale ci sia se obbligatoria e — infine — che tutti i **criteri** della transizione passino, sollevando alla prima condizione mancante. La `entity_pk` (opzionale) è ciò che i criteri ricevono per caricare la riga; la si passa quando la transizione ha criteri che ne hanno bisogno. Non muta nulla.

Il contratto con la Table API dell'entità è quindi netto e va rispettato perché nessun cambiamento di stato sfugga alla validazione e all'audit: la Table API chiama `assert_action` (passando la PK della riga) per validare, poi — nella **stessa transazione** — scrive il nuovo stato sulla riga di business e inserisce una riga nel proprio `wfl_<entità>_status_log`. Si cambia stato solo così. Gli errori di `assert_action` sono sollevati via `lib_err.raise_msg` sotto il codice dedicato `k_NOT_ALLOWED`, così restano intercettabili per nome: i tre a catalogo del framework (`WFL_TRANSITION_NOT_ALLOWED`, `WFL_ROLE_NOT_ALLOWED`, `WFL_REASON_REQUIRED`, più `WFL_GUARD_HANDLER_MISSING` per la configurazione errata) hanno il testo come dato in `cfg_messages`; il messaggio con cui un **criterio** nega è invece il suo `deny_message_code`, un codice `cfg_messages` di progetto, così ogni criterio spiega da sé perché ha bloccato.

Un **esempio completo e lavorato** di tutto questo — l'entità `orders` con la colonna di stato vincolata a `wfl_statuses` dalla foreign key composita, la tabella di storia `wfl_orders_status_log` con il suo trigger e le sue foreign key, e la `pkg_orders.change_status` che applica il contratto (valida con `assert_action`, poi scrive lo stato di business e la riga di log nella stessa transazione) — vive in `Gestione_Sorgenti/Templates/Esempi/`. È il riferimento concreto da cui partire per dotare di workflow una nuova entità.

## Sviluppi futuri

La **parte operativa** — i *task*, la to-do list di chi deve agire — resta l'estensione desiderabile ma deliberatamente rimandata, da costruire solo quando un bisogno concreto la giustifichi. Un ordine in attesa di approvazione non è solo un ordine con una colonna valorizzata, è un'incombenza che pende sulla scrivania di un ruolo, con una scadenza, da notificare e da escalare se non evasa. Questa parte porta valore reale all'utente, ma è un impegno maggiore e, a differenza della definizione e della storia, il suo contenitore naturale è generico — la domanda "cosa devo fare io oggi" attraversa ordini, contratti e pratiche insieme, e una tabella di task per entità la renderebbe una `union` su N tabelle. Se e quando si costruirà, il pattern è: assegnazione **al ruolo**, presa in carico **dall'utente** (perché un'incombenza non muoia quando la persona è in ferie), con i task aperti e chiusi da `lib_workflow` come effetto delle transizioni. Finché non serve, non si costruisce.

Restano rimandati anche gli **hook al passaggio di stato** — un'azione richiamata *dopo* una transizione, tipicamente la notifica via email. Da non confondere con i criteri: il criterio decide *prima* se la transizione è ammessa e non ha effetti; l'hook agisce *dopo* che è avvenuta. Con `lib_mail` e `wrk_mail_queue` già in casa, il caso "transizione → email al ruolo interessato" è a portata di mano come singolo hook cablato nella Table API, senza costruire un dispatcher di hook generico prima che serva.

Va infine ribadito il confine che il framework ha scelto di **non** superare: un **motore di regole data-driven**, in cui le condizioni dei criteri sono espresse *come dato* (operatori, soglie, alberi logici in tabella) invece che come codice. I criteri nominati descritti sopra coprono il bisogno reale tenendo la logica in PL/SQL compilato e testabile; un interprete di regole sarebbe un motore generico che il framework non ha chiesto e che complica senza ripagare. Non è un "non ancora": è una scelta di disegno.

## Improvement disponibili con Oracle 23ai

L'impianto è pensato per la baseline 19c e non richiede nulla oltre a essa. Su Oracle 23ai il tipo `boolean` nativo per le colonne di tabella sostituirebbe i flag `varchar2(1)` con `'Y'/'N'` (`is_initial`, `is_final`, `is_valid`, `requires_reason`). Coerentemente col principio del framework, resta un improvement da valutare se e quando serve, non una struttura da anticipare.
