create or replace
function get_easter_date ( i_year in number )
    return date
-------------------------------------------------------------------------
-- Algoritmo di Meeus/Jones/Butcher
-- Calcola la data della Pasqua cattolica (calendario gregoriano).
-- Valido per gli anni dal 1583 in poi.
-------------------------------------------------------------------------
is

    l_golden_number         number; -- Posizione dell'anno nel ciclo metonico (19 anni)
    l_century               number; -- Secolo
    l_year_of_century       number; -- Anno all'interno del secolo
    l_leap_century          number; -- Numero di anni bisestili del secolo
    l_century_remainder     number; -- Resto della divisione del secolo per 4
    l_correction1           number; -- Prima correzione del calendario gregoriano
    l_correction2           number; -- Seconda correzione del calendario gregoriano
    l_epact                 number; -- Epatta (et� della Luna al 1� gennaio)
    l_leap_years            number; -- Anni bisestili trascorsi nel secolo
    l_year_remainder        number; -- Resto della divisione dell'anno per 4
    l_weekday_offset        number; -- Correzione per il giorno della settimana
    l_month_correction      number; -- Correzione finale dell'algoritmo

    l_month                 number; -- Mese della Pasqua (3=Marzo, 4=Aprile)
    l_day                   number; -- Giorno della Pasqua

begin

    if (i_year < 1583)
    then

        raise_application_error(-20000, 'La funzione � valida solo per gli anni dal 1583.');

    end if;

    -------------------------------------------------------------------------
    -- Calcolo dei parametri intermedi dell'algoritmo
    -------------------------------------------------------------------------
    l_golden_number     := mod(i_year, 19);

    l_century           := trunc(i_year / 100);
    l_year_of_century   := mod(i_year, 100);

    l_leap_century      := trunc(l_century / 4);
    l_century_remainder := mod(l_century, 4);

    l_correction1       := trunc((l_century + 8) / 25);
    l_correction2       := trunc((l_century - l_correction1 + 1) / 3);

    -- Calcolo dell'epatta (fase lunare)
    l_epact := mod(  19 * l_golden_number
                        + l_century
                        - l_leap_century
                        - l_correction2
                        + 15
                   , 30);

    l_leap_years     := trunc(l_year_of_century / 4);
    l_year_remainder := mod(l_year_of_century, 4);

    -- Correzione legata al giorno della settimana
    l_weekday_offset := mod(  32 + 2 * l_century_remainder
                                 + 2 * l_leap_years
                                 - l_epact
                                 - l_year_remainder
                            , 7);

    -- Correzione finale
    l_month_correction := trunc(  ( l_golden_number + 11 * l_epact
                                        + 22 * l_weekday_offset
                                  ) / 451
                               );

    -------------------------------------------------------------------------
    -- Determinazione di mese e giorno della Pasqua
    -------------------------------------------------------------------------

    l_month := trunc( (l_epact + l_weekday_offset - 7 * l_month_correction + 114) / 31);

    l_day := mod(  l_epact + l_weekday_offset
                        - 7 * l_month_correction
                        + 114
                 , 31
                ) + 1;

    return to_date(    lpad(l_day,2,'0') || '/'
                    || lpad(l_month,2,'0') || '/'
                    || i_year
                   , 'DD/MM/YYYY'
                  );

    --return datefromparts(i_year, l_month, l_day); -- Solo 23ai

/*

-- Pasquetta
easter_date(anno) + 1

-- Carnevale (Marted� Grasso)
easter_date(anno) - 47

-- Mercoled� delle Ceneri
easter_date(anno) - 46

-- Domenica delle Palme
easter_date(anno) - 7

-- Ascensione (tradizione liturgica)
easter_date(anno) + 39

-- Pentecoste
easter_date(anno) + 49

-- Corpus Domini (tradizione)
easter_date(anno) + 60

*/

end get_easter_date;
/
