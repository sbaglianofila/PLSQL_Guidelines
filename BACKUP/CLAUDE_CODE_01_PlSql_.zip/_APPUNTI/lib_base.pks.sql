-- =============================================================================
-- Filename     : lib_base.pks.sql
-- Author       : fs
-- Date         : 2025
-- Description  : Basic PL/SQL Library. Generic Constants and Subtypes.
-- =============================================================================

prompt -- File : lib_base.pks.sql

prompt -------------------------------------------------------------------------

prompt -- Package Creation ...

create or replace
package lib_base
authid definer
------------------------------------------------------------------------------------------------------------------------
-- Version &&_Major_Release . &&_Minor_Release . &&_Patch_Number
------------------------------------------------------------------------------------------------------------------------
/***
-- Package centralizing generic constants and subtype definitions that are useful
-- throughout the entire application, independently of any specific business domain.
--
-- This package is intentionally kept free of business-level types and constants.
-- Application-domain subtypes belong in lib_app; context-specific constants belong
-- in the packages that own the relevant logic. Keeping lib_base generic ensures
-- that it remains a stable, low-churn dependency.
--
-- All varchar2 subtypes use CHAR semantics to behave correctly under multibyte
-- character sets (AL32UTF8). Raw byte-length declarations are never used here.
***/
is

-- =============================================================================
-- Subtypes — Technical strings
-- Subtypes for strings that reference Oracle artefacts or internal structures.
-- These sizes reflect Oracle Database 19c limits; the object_name_sbt covers the
-- extended 128-byte identifier length introduced in Oracle 12.2.
-- =============================================================================

subtype big_string_sbt              is varchar2(32767 char); -- Maximum PL/SQL varchar2 length
subtype max_sql_string_sbt          is varchar2(4000  char); -- Maximum SQL varchar2 length
subtype object_name_sbt             is varchar2(128   char); -- Oracle object / identifier name (12.2+)
subtype program_unit_sbt            is varchar2(256   char); -- Fully qualified: schema.package.subprogram
subtype ora_name_sbt                is varchar2(30    char); -- Oracle identifier, pre-12.2 limit (compatibility)
subtype statement_sbt               is varchar2(32767 char); -- Dynamic SQL statement buffer

-- =============================================================================
-- Subtypes — Flags and switches
-- Numeric and character surrogates for boolean values. Use when a boolean cannot
-- be stored in a table column (Oracle < 23c) or when interoperability with SQL
-- contexts requires a scalar type. For pure PL/SQL logic, prefer the native
-- boolean type directly.
--
-- Pair with lib_base constants: k_TRUE/k_FALSE, k_YES/k_NO, k_TRUE_CHR/k_FALSE_CHR,
-- k_YES_CHR/k_NO_CHR.
-- =============================================================================

subtype switch_sbt                  is number(1,0);          -- Generic on/off switch: 1 = on, 0 = off
subtype flag_num_sbt                is number(1,0);          -- Numeric boolean surrogate: 1 = true, 0 = false
subtype flag_char_sbt               is varchar2(1 char);     -- Character boolean surrogate: 'Y' / 'N'

-- =============================================================================
-- Subtypes — Miscellaneous technical
-- =============================================================================

subtype dummy_sbt                   is varchar2(4000 char);  -- Generic scratch / dummy variable
subtype guid_sbt                    is varchar2(36   char);  -- GUID in canonical form: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx

-- =============================================================================
-- Constants — PL/SQL engine limits
-- Hard limits imposed by the Oracle PL/SQL runtime. Centralising them avoids
-- magic numbers in code that computes buffer sizes or validates input lengths.
-- =============================================================================

k_VC2_MAXLEN                constant pls_integer                := 32767;       -- Maximum varchar2 length in PL/SQL context
k_VC2_SQL_MAXLEN            constant pls_integer                := 4000;        -- Maximum varchar2 length in SQL context
k_MIN_PLS_INT               constant pls_integer                := -2147483647; -- Minimum pls_integer value
k_MAX_PLS_INT               constant pls_integer                := 2147483647;  -- Maximum pls_integer value
k_MIN_SIMPLE_INT            constant simple_integer             := -2147483647; -- Minimum simple_integer value
k_MAX_SIMPLE_INT            constant simple_integer             := 2147483647;  -- Maximum simple_integer value

-- =============================================================================
-- Constants — Boolean surrogates (numeric)
-- Used with flag_num_sbt and switch_sbt. The pairing is consistent:
-- 1 always means true/yes/on, 0 always means false/no/off.
-- =============================================================================

k_TRUE                      constant switch_sbt                 := 1;
k_FALSE                     constant switch_sbt                 := 0;

k_YES                       constant switch_sbt                 := 1;
k_NO                        constant switch_sbt                 := 0;

-- =============================================================================
-- Constants — Boolean surrogates (character)
-- Character equivalents of the numeric boolean surrogates above.
-- k_TRUE_CHR / k_FALSE_CHR are the full-word forms used in messages and logs.
-- k_YES_CHR  / k_NO_CHR    are the single-character forms used in flag columns.
-- =============================================================================

k_TRUE_CHR                  constant varchar2(5 char)           := 'TRUE';
k_FALSE_CHR                 constant varchar2(5 char)           := 'FALSE';

k_YES_CHR                   constant varchar2(1 char)           := 'Y';
k_NO_CHR                    constant varchar2(1 char)           := 'N';

-- =============================================================================
-- Constants — Common date / time sentinels
-- Sentinel dates used as conventional boundaries in range-based queries and
-- open-ended validity intervals. Using named constants avoids scattering the
-- same literal date across the codebase.
-- =============================================================================

k_DATE_MIN                  constant date                       := date '0001-01-01'; -- Conventional "beginning of time"
k_DATE_MAX                  constant date                       := date '9999-12-31'; -- Conventional "end of time" / open-ended validity

-- =============================================================================
-- Constants — Numeric sentinels
-- =============================================================================

k_ZERO                      constant number                     := 0;
k_ONE                       constant number                     := 1;

------------------------------------------------------------------------------------------------------------------------
end lib_base;
/

prompt -- ... Errors

show error package lib_base

-- EOF lib_base.pks.sql
prompt
