create or replace package body tst_assert as

  procedure save_result(
    p_case_id  in number,
    p_name     in varchar2,
    p_expected in clob,
    p_actual   in clob,
    p_status   in varchar2,
    p_message  in varchar2
  ) is
    pragma autonomous_transaction;
  begin
    insert into tst_assert_result (
      case_id,
      assert_name,
      expected_value,
      actual_value,
      status,
      message
    ) values (
      p_case_id,
      upper(trim(p_name)),
      p_expected,
      p_actual,
      upper(trim(p_status)),
      p_message
    );

    commit;
  exception
    when others then
      rollback;
      raise;
  end save_result;

  function same_varchar2(
    p_expected in varchar2,
    p_actual   in varchar2
  ) return boolean is
  begin
    if p_expected is null and p_actual is null then
      return true;
    elsif p_expected is null or p_actual is null then
      return false;
    else
      return p_expected = p_actual;
    end if;
  end same_varchar2;

  procedure pass(
    p_case_id in number,
    p_name    in varchar2,
    p_message in varchar2 default null
  ) is
  begin
    save_result(
      p_case_id  => p_case_id,
      p_name     => p_name,
      p_expected => null,
      p_actual   => null,
      p_status   => 'PASS',
      p_message  => p_message
    );
  end pass;

  procedure fail(
    p_case_id in number,
    p_name    in varchar2,
    p_message in varchar2 default null,
    p_expected in clob default null,
    p_actual   in clob default null
  ) is
  begin
    save_result(
      p_case_id  => p_case_id,
      p_name     => p_name,
      p_expected => p_expected,
      p_actual   => p_actual,
      p_status   => 'FAIL',
      p_message  => p_message
    );
  end fail;

  procedure assert_true(
    p_case_id in number,
    p_name    in varchar2,
    p_condition in boolean,
    p_message in varchar2 default null
  ) is
  begin
    if p_condition is null then
      save_result(p_case_id, p_name, to_clob('TRUE'), to_clob('NULL'), 'FAIL', nvl(p_message, 'Condition is NULL.'));
    elsif p_condition then
      save_result(p_case_id, p_name, to_clob('TRUE'), to_clob('TRUE'), 'PASS', p_message);
    else
      save_result(p_case_id, p_name, to_clob('TRUE'), to_clob('FALSE'), 'FAIL', nvl(p_message, 'Condition is FALSE.'));
    end if;
  end assert_true;

  procedure eq_varchar2(
    p_case_id  in number,
    p_name     in varchar2,
    p_expected in varchar2,
    p_actual   in varchar2,
    p_message  in varchar2 default null
  ) is
  begin
    if same_varchar2(p_expected, p_actual) then
      save_result(p_case_id, p_name, tst_util.to_text(p_expected), tst_util.to_text(p_actual), 'PASS', p_message);
    else
      save_result(p_case_id, p_name, tst_util.to_text(p_expected), tst_util.to_text(p_actual), 'FAIL', nvl(p_message, 'VARCHAR2 values are different.'));
    end if;
  end eq_varchar2;

  procedure eq_number(
    p_case_id   in number,
    p_name      in varchar2,
    p_expected  in number,
    p_actual    in number,
    p_tolerance in number default 0,
    p_message   in varchar2 default null
  ) is
    l_ok boolean;
  begin
    if p_expected is null and p_actual is null then
      l_ok := true;
    elsif p_expected is null or p_actual is null then
      l_ok := false;
    else
      l_ok := abs(p_expected - p_actual) <= nvl(p_tolerance, 0);
    end if;

    if l_ok then
      save_result(p_case_id, p_name, tst_util.to_text(p_expected), tst_util.to_text(p_actual), 'PASS', p_message);
    else
      save_result(p_case_id, p_name, tst_util.to_text(p_expected), tst_util.to_text(p_actual), 'FAIL', nvl(p_message, 'NUMBER values are different.'));
    end if;
  end eq_number;

  procedure eq_date(
    p_case_id  in number,
    p_name     in varchar2,
    p_expected in date,
    p_actual   in date,
    p_message  in varchar2 default null
  ) is
    l_ok boolean;
  begin
    if p_expected is null and p_actual is null then
      l_ok := true;
    elsif p_expected is null or p_actual is null then
      l_ok := false;
    else
      l_ok := p_expected = p_actual;
    end if;

    if l_ok then
      save_result(p_case_id, p_name, tst_util.to_text(p_expected), tst_util.to_text(p_actual), 'PASS', p_message);
    else
      save_result(p_case_id, p_name, tst_util.to_text(p_expected), tst_util.to_text(p_actual), 'FAIL', nvl(p_message, 'DATE values are different.'));
    end if;
  end eq_date;

  procedure eq_timestamp(
    p_case_id  in number,
    p_name     in varchar2,
    p_expected in timestamp,
    p_actual   in timestamp,
    p_message  in varchar2 default null
  ) is
    l_ok boolean;
  begin
    if p_expected is null and p_actual is null then
      l_ok := true;
    elsif p_expected is null or p_actual is null then
      l_ok := false;
    else
      l_ok := p_expected = p_actual;
    end if;

    if l_ok then
      save_result(p_case_id, p_name, tst_util.to_text(p_expected), tst_util.to_text(p_actual), 'PASS', p_message);
    else
      save_result(p_case_id, p_name, tst_util.to_text(p_expected), tst_util.to_text(p_actual), 'FAIL', nvl(p_message, 'TIMESTAMP values are different.'));
    end if;
  end eq_timestamp;

  procedure is_null(
    p_case_id in number,
    p_name    in varchar2,
    p_actual  in varchar2,
    p_message in varchar2 default null
  ) is
  begin
    if p_actual is null then
      save_result(p_case_id, p_name, to_clob('NULL'), to_clob('NULL'), 'PASS', p_message);
    else
      save_result(p_case_id, p_name, to_clob('NULL'), tst_util.to_text(p_actual), 'FAIL', nvl(p_message, 'Value is not NULL.'));
    end if;
  end is_null;

  procedure is_not_null(
    p_case_id in number,
    p_name    in varchar2,
    p_actual  in varchar2,
    p_message in varchar2 default null
  ) is
  begin
    if p_actual is not null then
      save_result(p_case_id, p_name, to_clob('NOT NULL'), tst_util.to_text(p_actual), 'PASS', p_message);
    else
      save_result(p_case_id, p_name, to_clob('NOT NULL'), to_clob('NULL'), 'FAIL', nvl(p_message, 'Value is NULL.'));
    end if;
  end is_not_null;

end tst_assert;
/
show errors package body tst_assert
