create or replace package tst_util as

  subtype t_name is varchar2(128);

  function normalize_name(
    p_name in varchar2
  ) return varchar2;

  function boolean_to_varchar2(
    p_value in boolean
  ) return varchar2;

  function flag_to_boolean(
    p_value in varchar2
  ) return boolean;

  function elapsed_ms(
    p_started_at in timestamp,
    p_ended_at   in timestamp default systimestamp
  ) return number;

  function clob_preview(
    p_value  in clob,
    p_length in pls_integer default 4000
  ) return varchar2;

  function to_text(
    p_value in varchar2
  ) return clob;

  function to_text(
    p_value in number
  ) return clob;

  function to_text(
    p_value in date
  ) return clob;

  function to_text(
    p_value in timestamp
  ) return clob;

  function to_text(
    p_value in clob
  ) return clob;

end tst_util;
/
show errors package tst_util
