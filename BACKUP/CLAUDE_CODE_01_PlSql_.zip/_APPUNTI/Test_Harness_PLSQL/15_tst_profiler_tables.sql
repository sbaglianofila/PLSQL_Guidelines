set define off

prompt Creating PL/SQL Test Harness profiler tables...

create table tst_profiler_case (
  profiler_case_id    number generated always as identity,
  run_id              number not null,
  case_id             number not null,
  profiler_runid      number,
  started_at          timestamp(6) default systimestamp not null,
  stopped_at          timestamp(6),
  status              varchar2(30) default 'RUNNING' not null,
  start_result_code   number,
  stop_result_code    number,
  flush_result_code   number,
  error_code          number,
  error_message       varchar2(4000),
  run_comment         varchar2(4000),
  created_by          varchar2(128) default sys_context('USERENV','SESSION_USER') not null,
  created_at          timestamp(6) default systimestamp not null,
  constraint tst_profiler_case_pk primary key (profiler_case_id),
  constraint tst_profiler_case_run_fk foreign key (run_id) references tst_run(run_id),
  constraint tst_profiler_case_case_fk foreign key (case_id) references tst_case(case_id),
  constraint tst_profiler_case_uk unique (case_id),
  constraint tst_profiler_case_ck_status check (status in ('RUNNING','STOPPED','ERROR','NOT_AVAILABLE'))
);

create index tst_profiler_case_i01 on tst_profiler_case(run_id, status);
create index tst_profiler_case_i02 on tst_profiler_case(profiler_runid);

prompt Profiler tables created.
