create or replace package tst_assert as

  procedure pass(
    p_case_id in number,
    p_name    in varchar2,
    p_message in varchar2 default null
  );

  procedure fail(
    p_case_id in number,
    p_name    in varchar2,
    p_message in varchar2 default null,
    p_expected in clob default null,
    p_actual   in clob default null
  );

  procedure assert_true(
    p_case_id in number,
    p_name    in varchar2,
    p_condition in boolean,
    p_message in varchar2 default null
  );

  procedure eq_varchar2(
    p_case_id  in number,
    p_name     in varchar2,
    p_expected in varchar2,
    p_actual   in varchar2,
    p_message  in varchar2 default null
  );

  procedure eq_number(
    p_case_id   in number,
    p_name      in varchar2,
    p_expected  in number,
    p_actual    in number,
    p_tolerance in number default 0,
    p_message   in varchar2 default null
  );

  procedure eq_date(
    p_case_id  in number,
    p_name     in varchar2,
    p_expected in date,
    p_actual   in date,
    p_message  in varchar2 default null
  );

  procedure eq_timestamp(
    p_case_id  in number,
    p_name     in varchar2,
    p_expected in timestamp,
    p_actual   in timestamp,
    p_message  in varchar2 default null
  );

  procedure is_null(
    p_case_id in number,
    p_name    in varchar2,
    p_actual  in varchar2,
    p_message in varchar2 default null
  );

  procedure is_not_null(
    p_case_id in number,
    p_name    in varchar2,
    p_actual  in varchar2,
    p_message in varchar2 default null
  );

end tst_assert;
/
show errors package tst_assert
