set define off
set serveroutput on

prompt ============================================================
prompt Installing PL/SQL Test Harness runtime v0.1
prompt ============================================================

@@01_tst_tables.sql
@@02_tst_util.pks
@@03_tst_util.pkb
@@04_tst_log.pks
@@05_tst_log.pkb
@@06_tst_assert.pks
@@07_tst_assert.pkb
@@08_tst_runner.pks
@@09_tst_runner.pkb

prompt ============================================================
prompt Runtime installation completed.
prompt Optional demo:
prompt   @90_demo_target.sql
prompt   @91_demo_test_wrapper.sql
prompt ============================================================
