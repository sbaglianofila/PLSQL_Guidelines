create or replace package body tst_generator as

  c_lf constant varchar2(1) := chr(10);

  procedure append_clob(
    p_clob in out nocopy clob,
    p_text in varchar2
  ) is
  begin
    if p_clob is null then
      dbms_lob.createtemporary(p_clob, true);
    end if;

    dbms_lob.append(p_clob, to_clob(p_text));
  end append_clob;

  procedure append_line(
    p_clob in out nocopy clob,
    p_text in varchar2 default null
  ) is
  begin
    append_clob(p_clob, nvl(p_text, '') || c_lf);
  end append_line;

  function yn(
    p_value in varchar2,
    p_default in varchar2 default 'N'
  ) return varchar2 is
    l_value varchar2(10) := upper(trim(nvl(p_value, p_default)));
  begin
    if l_value in ('Y','YES','S','SI','TRUE','1') then
      return 'Y';
    else
      return 'N';
    end if;
  end yn;

  function ql(
    p_value in varchar2
  ) return varchar2 is
  begin
    return '''' || replace(p_value, '''', '''''') || '''';
  end ql;

  function normalize_optional_name(
    p_name in varchar2
  ) return varchar2 is
  begin
    if p_name is null then
      return null;
    end if;

    return tst_util.normalize_name(p_name);
  end normalize_optional_name;

  function default_test_package_name(
    p_package_name in varchar2
  ) return varchar2 is
    l_package_name varchar2(128) := tst_util.normalize_name(p_package_name);
  begin
    if length(l_package_name) > 123 then
      return substr(l_package_name, 1, 123) || '_TEST';
    else
      return l_package_name || '_TEST';
    end if;
  end default_test_package_name;

  function generated_test_proc_name(
    p_program_name in varchar2,
    p_overload     in varchar2
  ) return varchar2 is
    l_name varchar2(128);
  begin
    l_name := 'TEST_' || upper(p_program_name);

    if p_overload is not null then
      l_name := l_name || '_' || lpad(p_overload, 3, '0');
    end if;

    return substr(l_name, 1, 128);
  end generated_test_proc_name;

  function alias_name(
    p_argument_name in varchar2
  ) return varchar2 is
  begin
    return lower(substr(tst_util.normalize_name(p_argument_name), 1, 120));
  end alias_name;

  function local_var_name(
    p_argument_name in varchar2
  ) return varchar2 is
  begin
    return lower(substr('L_' || tst_util.normalize_name(p_argument_name), 1, 128));
  end local_var_name;

  function plsql_decl_type(
    p_category in varchar2
  ) return varchar2 is
  begin
    case p_category
      when 'VARCHAR2' then return 'varchar2(4000)';
      when 'NUMBER'   then return 'number';
      when 'DATE'     then return 'date';
      when 'TIMESTAMP'then return 'timestamp';
      when 'CLOB'     then return 'clob';
      when 'BOOLEAN'  then return 'boolean';
      else return null;
    end case;
  end plsql_decl_type;

  function cursor_null_expr(
    p_category in varchar2
  ) return varchar2 is
  begin
    case p_category
      when 'VARCHAR2' then return 'cast(null as varchar2(4000))';
      when 'NUMBER'   then return 'cast(null as number)';
      when 'DATE'     then return 'cast(null as date)';
      when 'TIMESTAMP'then return 'cast(null as timestamp)';
      when 'CLOB'     then return 'to_clob(null)';
      when 'BOOLEAN'  then return 'cast(null as varchar2(30))';
      else return 'cast(null as varchar2(4000))';
    end case;
  end cursor_null_expr;

  function can_auto_assert_return(
    p_category in varchar2
  ) return boolean is
  begin
    return p_category in ('VARCHAR2','NUMBER','DATE','TIMESTAMP','BOOLEAN');
  end can_auto_assert_return;

  function target_ref(
    p_owner        in varchar2,
    p_package_name in varchar2,
    p_program_name in varchar2
  ) return varchar2 is
  begin
    return lower(p_owner) || '.' || lower(p_package_name) || '.' || lower(p_program_name);
  end target_ref;

  function type_label(
    p_data_type in varchar2,
    p_pls_type  in varchar2,
    p_category  in varchar2
  ) return varchar2 is
  begin
    if p_category = 'BOOLEAN' then
      return 'BOOLEAN';
    else
      return nvl(upper(p_data_type), upper(p_pls_type));
    end if;
  end type_label;

  procedure append_log_param(
    p_ddl       in out nocopy clob,
    p_case_id   in varchar2,
    p_name      in varchar2,
    p_mode      in varchar2,
    p_type      in varchar2,
    p_category  in varchar2,
    p_expr      in varchar2
  ) is
  begin
    if p_category = 'CLOB' then
      append_line(p_ddl, '        tst_log.log_param_clob(' || p_case_id || ', ' || ql(p_name) || ', ' || ql(p_mode) || ', ' || ql(p_type) || ', ' || p_expr || ');');
    else
      append_line(p_ddl, '        tst_log.log_param(' || p_case_id || ', ' || ql(p_name) || ', ' || ql(p_mode) || ', ' || ql(p_type) || ', ' || p_expr || ');');
    end if;
  end append_log_param;

  procedure append_log_output(
    p_ddl       in out nocopy clob,
    p_case_id   in varchar2,
    p_name      in varchar2,
    p_type      in varchar2,
    p_category  in varchar2,
    p_expr      in varchar2
  ) is
  begin
    if p_category = 'CLOB' then
      append_line(p_ddl, '        tst_log.log_output_clob(' || p_case_id || ', ' || ql(p_name) || ', ' || ql(p_type) || ', ' || p_expr || ');');
    else
      append_line(p_ddl, '        tst_log.log_output(' || p_case_id || ', ' || ql(p_name) || ', ' || ql(p_type) || ', ' || p_expr || ');');
    end if;
  end append_log_output;

  procedure append_log_return(
    p_ddl       in out nocopy clob,
    p_case_id   in varchar2,
    p_type      in varchar2,
    p_category  in varchar2,
    p_expr      in varchar2
  ) is
  begin
    if p_category = 'CLOB' then
      append_line(p_ddl, '        tst_log.log_return_value_clob(' || p_case_id || ', ' || ql(p_type) || ', ' || p_expr || ');');
    else
      append_line(p_ddl, '        tst_log.log_return_value(' || p_case_id || ', ' || ql(p_type) || ', ' || p_expr || ');');
    end if;
  end append_log_return;

  procedure append_unsupported_stub(
    p_ddl              in out nocopy clob,
    p_owner            in varchar2,
    p_package_name     in varchar2,
    p_test_package_name in varchar2,
    p_program_name     in varchar2,
    p_overload         in varchar2,
    p_test_proc_name   in varchar2,
    p_reason           in varchar2,
    p_signature_hash   in varchar2,
    p_transaction_mode in varchar2,
    p_profile_mode     in varchar2
  ) is
  begin
    append_line(p_ddl, '  procedure ' || lower(p_test_proc_name) || ' is');
    append_line(p_ddl, '    l_run_id number;');
    append_line(p_ddl, '    l_case_id number;');
    append_line(p_ddl, '  begin');
    append_line(p_ddl, '    l_run_id := tst_runner.start_run(');
    append_line(p_ddl, '      p_owner                  => ' || ql(p_owner) || ',');
    append_line(p_ddl, '      p_package_name           => ' || ql(p_package_name) || ',');
    append_line(p_ddl, '      p_program_name           => ' || ql(p_program_name) || ',');
    append_line(p_ddl, '      p_generated_package_name => ' || ql(p_test_package_name) || ',');
    append_line(p_ddl, '      p_profile_mode           => ' || ql(p_profile_mode) || ',');
    append_line(p_ddl, '      p_transaction_mode       => ' || ql(p_transaction_mode) || ',');
    append_line(p_ddl, '      p_note                   => ' || ql('Generated by TST_GENERATOR. Manual completion required. Signature hash: ' || p_signature_hash) || '');
    append_line(p_ddl, '    );');
    append_line(p_ddl);
    append_line(p_ddl, '    l_case_id := tst_runner.start_case(');
    append_line(p_ddl, '      p_run_id           => l_run_id,');
    append_line(p_ddl, '      p_case_code        => ''MANUAL_REQUIRED'',');
    append_line(p_ddl, '      p_case_description => ' || ql(substr(p_reason, 1, 4000)));
    append_line(p_ddl, '    );');
    append_line(p_ddl);
    append_line(p_ddl, '    tst_runner.skip_case(l_case_id, ' || ql(substr(p_reason, 1, 4000)) || ');');
    append_line(p_ddl, '    tst_runner.end_run_success(l_run_id);');
    append_line(p_ddl, '  exception');
    append_line(p_ddl, '    when others then');
    append_line(p_ddl, '      if l_run_id is not null then');
    append_line(p_ddl, '        tst_runner.end_run_error(l_run_id, sqlcode, sqlerrm);');
    append_line(p_ddl, '        end if;');
    append_line(p_ddl, '      raise;');
    append_line(p_ddl, '  end ' || lower(p_test_proc_name) || ';');
    append_line(p_ddl);
  end append_unsupported_stub;

  procedure append_supported_wrapper(
    p_ddl               in out nocopy clob,
    p_owner             in varchar2,
    p_package_name      in varchar2,
    p_test_package_name in varchar2,
    p_program_name      in varchar2,
    p_overload          in varchar2,
    p_test_proc_name    in varchar2,
    p_is_function       in varchar2,
    p_return_category   in varchar2,
    p_return_type_label in varchar2,
    p_signature_hash    in varchar2,
    p_transaction_mode  in varchar2,
    p_profile_mode      in varchar2
  ) is
    l_first_col boolean := true;
    l_first_arg boolean := true;
    l_arg_expr  varchar2(4000);
    l_alias     varchar2(128);
    l_var       varchar2(128);
    l_category  varchar2(30);
    l_type      varchar2(128);

    procedure add_cursor_col(
      p_expr  in varchar2,
      p_alias in varchar2
    ) is
    begin
      if l_first_col then
        append_line(p_ddl, '      select ' || p_expr || ' as ' || lower(p_alias));
        l_first_col := false;
      else
        append_line(p_ddl, '             ' || p_expr || ' as ' || lower(p_alias));
      end if;
    end add_cursor_col;
  begin
    append_line(p_ddl, '  procedure ' || lower(p_test_proc_name) || ' is');
    append_line(p_ddl);
    append_line(p_ddl, '    cursor c_test is');

    add_cursor_col('cast(null as varchar2(100))', 'case_code');
    add_cursor_col('cast(null as varchar2(4000))', 'case_description');

    for a in (
      select argument_name,
             in_out,
             data_type,
             pls_type,
             position,
             sequence
        from all_arguments
       where owner = p_owner
         and package_name = p_package_name
         and object_name = p_program_name
         and nvl(overload, chr(0)) = nvl(p_overload, chr(0))
         and data_level = 0
         and position > 0
       order by position, sequence
    ) loop
      l_alias := alias_name(a.argument_name);
      l_category := tst_signature.simple_type_category(a.data_type, a.pls_type);

      if a.in_out in ('IN','IN/OUT') then
        add_cursor_col(cursor_null_expr(l_category), l_alias);
      end if;
    end loop;

    add_cursor_col('cast(''N'' as varchar2(1))', 'expect_error');
    add_cursor_col('cast(null as number)', 'expect_sqlcode');

    if p_is_function = 'Y' and can_auto_assert_return(p_return_category) then
      add_cursor_col(cursor_null_expr(p_return_category), 'expected_return_value');
    end if;

    append_line(p_ddl, '      from dual');
    append_line(p_ddl, '     where 1 = 0;');
    append_line(p_ddl);
    append_line(p_ddl, '    l_run_id number;');
    append_line(p_ddl, '    l_case_id number;');
    append_line(p_ddl, '    l_profiler_runid number;');
    append_line(p_ddl, '    l_transaction_mode constant varchar2(30) := ' || ql(p_transaction_mode) || ';');
    append_line(p_ddl, '    l_profile_mode constant varchar2(30) := ' || ql(p_profile_mode) || ';');

    if p_is_function = 'Y' then
      append_line(p_ddl, '    l_return_value ' || plsql_decl_type(p_return_category) || ';');
    end if;

    for a in (
      select argument_name,
             in_out,
             data_type,
             pls_type,
             position,
             sequence
        from all_arguments
       where owner = p_owner
         and package_name = p_package_name
         and object_name = p_program_name
         and nvl(overload, chr(0)) = nvl(p_overload, chr(0))
         and data_level = 0
         and position > 0
       order by position, sequence
    ) loop
      l_category := tst_signature.simple_type_category(a.data_type, a.pls_type);

      if a.in_out in ('OUT','IN/OUT') or l_category = 'BOOLEAN' then
        append_line(p_ddl, '    ' || local_var_name(a.argument_name) || ' ' || plsql_decl_type(l_category) || ';');
      end if;
    end loop;

    append_line(p_ddl);
    append_line(p_ddl, '  begin');
    append_line(p_ddl, '    l_run_id := tst_runner.start_run(');
    append_line(p_ddl, '      p_owner                  => ' || ql(p_owner) || ',');
    append_line(p_ddl, '      p_package_name           => ' || ql(p_package_name) || ',');
    append_line(p_ddl, '      p_program_name           => ' || ql(p_program_name) || ',');
    append_line(p_ddl, '      p_generated_package_name => ' || ql(p_test_package_name) || ',');
    append_line(p_ddl, '      p_profile_mode           => l_profile_mode,');
    append_line(p_ddl, '      p_transaction_mode       => l_transaction_mode,');
    append_line(p_ddl, '      p_note                   => ' || ql('Generated by TST_GENERATOR. Signature hash: ' || p_signature_hash) || '');
    append_line(p_ddl, '    );');
    append_line(p_ddl);
    append_line(p_ddl, '    for r in c_test loop');
    append_line(p_ddl, '      savepoint tst_case_sp;');
    append_line(p_ddl);
    append_line(p_ddl, '      l_case_id := tst_runner.start_case(');
    append_line(p_ddl, '        p_run_id           => l_run_id,');
    append_line(p_ddl, '        p_case_code        => r.case_code,');
    append_line(p_ddl, '        p_case_description => r.case_description,');
    append_line(p_ddl, '        p_expect_error     => r.expect_error,');
    append_line(p_ddl, '        p_expect_sqlcode   => r.expect_sqlcode');
    append_line(p_ddl, '      );');
    append_line(p_ddl);
    append_line(p_ddl, '      begin');
    append_line(p_ddl, '        if l_profile_mode = ''PROFILER'' then');
    append_line(p_ddl, '          l_profiler_runid := tst_profiler.start_case(');
    append_line(p_ddl, '          p_run_id      => l_run_id,');
    append_line(p_ddl, '          p_case_id     => l_case_id,');
    append_line(p_ddl, '          p_run_comment => ''TST_HARNESS '' || ' || ql(p_package_name || '.' || p_program_name) || ' || '' CASE='' || nvl(r.case_code, to_char(l_case_id))');
    append_line(p_ddl, '        );');
    append_line(p_ddl, '        end if;');
    append_line(p_ddl);

    for a in (
      select argument_name,
             in_out,
             data_type,
             pls_type,
             position,
             sequence
        from all_arguments
       where owner = p_owner
         and package_name = p_package_name
         and object_name = p_program_name
         and nvl(overload, chr(0)) = nvl(p_overload, chr(0))
         and data_level = 0
         and position > 0
       order by position, sequence
    ) loop
      l_alias := alias_name(a.argument_name);
      l_var := local_var_name(a.argument_name);
      l_category := tst_signature.simple_type_category(a.data_type, a.pls_type);

      if l_category = 'BOOLEAN' and a.in_out in ('IN','IN/OUT') then
        append_line(p_ddl, '        ' || l_var || ' := tst_util.flag_to_boolean(r.' || l_alias || ');');
      elsif a.in_out = 'IN/OUT' then
        append_line(p_ddl, '        ' || l_var || ' := r.' || l_alias || ';');
      end if;
    end loop;

    for a in (
      select argument_name,
             in_out,
             data_type,
             pls_type,
             position,
             sequence
        from all_arguments
       where owner = p_owner
         and package_name = p_package_name
         and object_name = p_program_name
         and nvl(overload, chr(0)) = nvl(p_overload, chr(0))
         and data_level = 0
         and position > 0
       order by position, sequence
    ) loop
      l_alias := alias_name(a.argument_name);
      l_category := tst_signature.simple_type_category(a.data_type, a.pls_type);
      l_type := type_label(a.data_type, a.pls_type, l_category);

      if a.in_out in ('IN','IN/OUT') then
        append_log_param(
          p_ddl      => p_ddl,
          p_case_id  => 'l_case_id',
          p_name     => a.argument_name,
          p_mode     => replace(a.in_out, '/', ' '),
          p_type     => l_type,
          p_category => case when l_category = 'BOOLEAN' then 'VARCHAR2' else l_category end,
          p_expr     => 'r.' || l_alias
        );
      end if;
    end loop;

    append_line(p_ddl);

    if p_is_function = 'Y' then
      append_line(p_ddl, '        l_return_value := ' || target_ref(p_owner, p_package_name, p_program_name) || '(');
    else
      append_line(p_ddl, '        ' || target_ref(p_owner, p_package_name, p_program_name) || '(');
    end if;

    l_first_arg := true;

    for a in (
      select argument_name,
             in_out,
             data_type,
             pls_type,
             position,
             sequence
        from all_arguments
       where owner = p_owner
         and package_name = p_package_name
         and object_name = p_program_name
         and nvl(overload, chr(0)) = nvl(p_overload, chr(0))
         and data_level = 0
         and position > 0
       order by position, sequence
    ) loop
      l_alias := alias_name(a.argument_name);
      l_var := local_var_name(a.argument_name);
      l_category := tst_signature.simple_type_category(a.data_type, a.pls_type);

      if a.in_out = 'IN' and l_category <> 'BOOLEAN' then
        l_arg_expr := 'r.' || l_alias;
      else
        l_arg_expr := l_var;
      end if;

      if l_first_arg then
        append_line(p_ddl, '          ' || lower(a.argument_name) || ' => ' || l_arg_expr);
        l_first_arg := false;
      else
        append_line(p_ddl, '        , ' || lower(a.argument_name) || ' => ' || l_arg_expr);
      end if;
    end loop;

    if l_first_arg then
      append_line(p_ddl, '        );');
    else
      append_line(p_ddl, '        );');
    end if;
    append_line(p_ddl);

    for a in (
      select argument_name,
             in_out,
             data_type,
             pls_type,
             position,
             sequence
        from all_arguments
       where owner = p_owner
         and package_name = p_package_name
         and object_name = p_program_name
         and nvl(overload, chr(0)) = nvl(p_overload, chr(0))
         and data_level = 0
         and position > 0
       order by position, sequence
    ) loop
      l_var := local_var_name(a.argument_name);
      l_category := tst_signature.simple_type_category(a.data_type, a.pls_type);
      l_type := type_label(a.data_type, a.pls_type, l_category);

      if a.in_out in ('OUT','IN/OUT') then
        append_log_output(
          p_ddl      => p_ddl,
          p_case_id  => 'l_case_id',
          p_name     => a.argument_name,
          p_type     => l_type,
          p_category => case when l_category = 'BOOLEAN' then 'VARCHAR2' else l_category end,
          p_expr     => case when l_category = 'BOOLEAN' then 'tst_util.boolean_to_varchar2(' || l_var || ')' else l_var end
        );
      end if;
    end loop;

    if p_is_function = 'Y' then
      append_log_return(
        p_ddl      => p_ddl,
        p_case_id  => 'l_case_id',
        p_type     => p_return_type_label,
        p_category => case when p_return_category = 'BOOLEAN' then 'VARCHAR2' else p_return_category end,
        p_expr     => case when p_return_category = 'BOOLEAN' then 'tst_util.boolean_to_varchar2(l_return_value)' else 'l_return_value' end
      );

      if can_auto_assert_return(p_return_category) then
        append_line(p_ddl);
        case p_return_category
          when 'VARCHAR2' then
            append_line(p_ddl, '        tst_assert.eq_varchar2(');
            append_line(p_ddl, '          p_case_id  => l_case_id,');
            append_line(p_ddl, '          p_name     => ''RETURN_VALUE'',');
            append_line(p_ddl, '          p_expected => r.expected_return_value,');
            append_line(p_ddl, '          p_actual   => l_return_value');
            append_line(p_ddl, '        );');
          when 'NUMBER' then
            append_line(p_ddl, '        tst_assert.eq_number(');
            append_line(p_ddl, '          p_case_id  => l_case_id,');
            append_line(p_ddl, '          p_name     => ''RETURN_VALUE'',');
            append_line(p_ddl, '          p_expected => r.expected_return_value,');
            append_line(p_ddl, '          p_actual   => l_return_value');
            append_line(p_ddl, '        );');
          when 'DATE' then
            append_line(p_ddl, '        tst_assert.eq_date(');
            append_line(p_ddl, '          p_case_id  => l_case_id,');
            append_line(p_ddl, '          p_name     => ''RETURN_VALUE'',');
            append_line(p_ddl, '          p_expected => r.expected_return_value,');
            append_line(p_ddl, '          p_actual   => l_return_value');
            append_line(p_ddl, '        );');
          when 'TIMESTAMP' then
            append_line(p_ddl, '        tst_assert.eq_timestamp(');
            append_line(p_ddl, '          p_case_id  => l_case_id,');
            append_line(p_ddl, '          p_name     => ''RETURN_VALUE'',');
            append_line(p_ddl, '          p_expected => r.expected_return_value,');
            append_line(p_ddl, '          p_actual   => l_return_value');
            append_line(p_ddl, '        );');
          when 'BOOLEAN' then
            append_line(p_ddl, '        tst_assert.eq_varchar2(');
            append_line(p_ddl, '          p_case_id  => l_case_id,');
            append_line(p_ddl, '          p_name     => ''RETURN_VALUE'',');
            append_line(p_ddl, '          p_expected => upper(r.expected_return_value),');
            append_line(p_ddl, '          p_actual   => tst_util.boolean_to_varchar2(l_return_value)');
            append_line(p_ddl, '        );');
        end case;
      else
        append_line(p_ddl, '        -- Return value logged only. Add a custom assert here if needed.');
      end if;
    end if;

    append_line(p_ddl);
    append_line(p_ddl, '        if l_profile_mode = ''PROFILER'' then');
    append_line(p_ddl, '          tst_profiler.stop_case(l_case_id);');
    append_line(p_ddl, '        end if;');
    append_line(p_ddl);
    append_line(p_ddl, '        tst_runner.end_case_success(l_case_id);');
    append_line(p_ddl);
    append_line(p_ddl, '        if l_transaction_mode = ''ROLLBACK'' then');
    append_line(p_ddl, '          rollback to tst_case_sp;');
    append_line(p_ddl, '        elsif l_transaction_mode = ''COMMIT'' then');
    append_line(p_ddl, '          commit;');
    append_line(p_ddl, '        end if;');
    append_line(p_ddl, '      exception');
    append_line(p_ddl, '        when others then');
    append_line(p_ddl, '          if l_profile_mode = ''PROFILER'' then');
    append_line(p_ddl, '            tst_profiler.safe_stop_case(l_case_id);');
    append_line(p_ddl, '          end if;');
    append_line(p_ddl);
    append_line(p_ddl, '          tst_runner.end_case_error(');
    append_line(p_ddl, '            p_case_id     => l_case_id,');
    append_line(p_ddl, '            p_sqlcode     => sqlcode,');
    append_line(p_ddl, '            p_sqlerrm     => sqlerrm,');
    append_line(p_ddl, '            p_error_stack => dbms_utility.format_error_stack,');
    append_line(p_ddl, '            p_backtrace   => dbms_utility.format_error_backtrace');
    append_line(p_ddl, '          );');
    append_line(p_ddl);
    append_line(p_ddl, '          if l_transaction_mode = ''ROLLBACK'' then');
    append_line(p_ddl, '            rollback to tst_case_sp;');
    append_line(p_ddl, '          elsif l_transaction_mode = ''COMMIT'' then');
    append_line(p_ddl, '            commit;');
    append_line(p_ddl, '          end if;');
    append_line(p_ddl, '      end;');
    append_line(p_ddl, '    end loop;');
    append_line(p_ddl);
    append_line(p_ddl, '    tst_runner.end_run_success(l_run_id);');
    append_line(p_ddl, '  exception');
    append_line(p_ddl, '    when others then');
    append_line(p_ddl, '      if l_run_id is not null then');
    append_line(p_ddl, '        tst_runner.end_run_error(');
    append_line(p_ddl, '          p_run_id  => l_run_id,');
    append_line(p_ddl, '          p_sqlcode => sqlcode,');
    append_line(p_ddl, '          p_sqlerrm => sqlerrm');
    append_line(p_ddl, '        );');
    append_line(p_ddl, '        end if;');
    append_line(p_ddl, '      raise;');
    append_line(p_ddl, '  end ' || lower(p_test_proc_name) || ';');
    append_line(p_ddl);
  end append_supported_wrapper;

  function unsupported_reason(
    p_owner        in varchar2,
    p_package_name in varchar2,
    p_program_name in varchar2,
    p_overload     in varchar2
  ) return varchar2 is
    l_reason varchar2(4000);
    l_nested number;
    l_category varchar2(30);
  begin
    select count(*)
      into l_nested
      from all_arguments
     where owner = p_owner
       and package_name = p_package_name
       and object_name = p_program_name
       and nvl(overload, chr(0)) = nvl(p_overload, chr(0))
       and data_level > 0;

    if l_nested > 0 then
      l_reason := l_reason || 'Contains complex/nested argument metadata (DATA_LEVEL > 0). ';
    end if;

    for a in (
      select nvl(argument_name, '<RETURN>') as argument_name,
             data_type,
             pls_type,
             position
        from all_arguments
       where owner = p_owner
         and package_name = p_package_name
         and object_name = p_program_name
         and nvl(overload, chr(0)) = nvl(p_overload, chr(0))
         and data_level = 0
       order by sequence
    ) loop
      l_category := tst_signature.simple_type_category(a.data_type, a.pls_type);

      if l_category = 'UNSUPPORTED' then
        l_reason := l_reason || 'Unsupported type for ' || a.argument_name || ': DATA_TYPE=' || nvl(a.data_type, '<NULL>') || ', PLS_TYPE=' || nvl(a.pls_type, '<NULL>') || '. ';
      end if;
    end loop;

    return l_reason;
  end unsupported_reason;

  function generate_package_test_ddl(
    p_owner               in varchar2,
    p_package_name        in varchar2,
    p_test_package_name   in varchar2 default null,
    p_include_unsupported in varchar2 default 'Y',
    p_transaction_mode    in varchar2 default 'ROLLBACK',
    p_profile_mode        in varchar2 default 'NONE'
  ) return clob is
    l_owner              varchar2(128) := tst_util.normalize_name(p_owner);
    l_package_name       varchar2(128) := tst_util.normalize_name(p_package_name);
    l_test_package_name  varchar2(128) := normalize_optional_name(p_test_package_name);
    l_include_unsupported varchar2(1) := yn(p_include_unsupported, 'Y');
    l_transaction_mode   varchar2(30) := upper(trim(nvl(p_transaction_mode, 'ROLLBACK')));
    l_profile_mode       varchar2(30) := upper(trim(nvl(p_profile_mode, 'NONE')));
    l_ddl                clob;
    l_count              number;
    l_signature_hash     varchar2(64);
    l_test_proc_name     varchar2(128);
    l_reason             varchar2(4000);
    l_is_function        varchar2(1);
    l_return_category    varchar2(30);
    l_return_type_label  varchar2(128);
  begin
    if l_test_package_name is null then
      l_test_package_name := default_test_package_name(l_package_name);
    end if;

    if l_transaction_mode not in ('ROLLBACK','COMMIT','MANUAL') then
      raise_application_error(-20940, 'Unsupported transaction mode: ' || p_transaction_mode);
    end if;

    if l_profile_mode not in ('NONE','PROFILER') then
      raise_application_error(-20943, 'Unsupported generator profile mode: ' || p_profile_mode || '. Supported modes in v0.3: NONE, PROFILER.');
    end if;

    select count(*)
      into l_count
      from all_objects
     where owner = l_owner
       and object_name = l_package_name
       and object_type = 'PACKAGE';

    if l_count = 0 then
      raise_application_error(-20941, 'Package not found or not visible: ' || l_owner || '.' || l_package_name);
    end if;

    l_signature_hash := tst_signature.get_signature_hash(l_owner, l_package_name);

    append_line(l_ddl, 'set define off');
    append_line(l_ddl, 'prompt Generated test package for ' || l_owner || '.' || l_package_name);
    append_line(l_ddl, 'prompt Signature hash: ' || l_signature_hash);
    append_line(l_ddl, 'prompt Profile mode: ' || l_profile_mode);
    append_line(l_ddl);
    append_line(l_ddl, 'create or replace package ' || lower(l_test_package_name) || ' as');
    append_line(l_ddl);
    append_line(l_ddl, '  -- Generated by TST_GENERATOR.');
    append_line(l_ddl, '  -- Review and customize each cursor c_test before using it for real regression tests.');
    append_line(l_ddl, '  -- Source signature hash: ' || l_signature_hash);
    append_line(l_ddl);

    for p in (
      select procedure_name,
             overload,
             subprogram_id
        from all_procedures
       where owner = l_owner
         and object_name = l_package_name
         and object_type = 'PACKAGE'
         and procedure_name is not null
       order by procedure_name, lpad(nvl(overload, '0'), 10, '0'), subprogram_id
    ) loop
      l_reason := unsupported_reason(l_owner, l_package_name, p.procedure_name, p.overload);

      if l_reason is null or l_include_unsupported = 'Y' then
        l_test_proc_name := generated_test_proc_name(p.procedure_name, p.overload);
        append_line(l_ddl, '  procedure ' || lower(l_test_proc_name) || ';');
      end if;
    end loop;

    append_line(l_ddl);
    append_line(l_ddl, 'end ' || lower(l_test_package_name) || ';');
    append_line(l_ddl, '/');
    append_line(l_ddl, 'show errors package ' || lower(l_test_package_name));
    append_line(l_ddl);
    append_line(l_ddl, 'create or replace package body ' || lower(l_test_package_name) || ' as');
    append_line(l_ddl);

    for p in (
      select procedure_name,
             overload,
             subprogram_id
        from all_procedures
       where owner = l_owner
         and object_name = l_package_name
         and object_type = 'PACKAGE'
         and procedure_name is not null
       order by procedure_name, lpad(nvl(overload, '0'), 10, '0'), subprogram_id
    ) loop
      l_reason := unsupported_reason(l_owner, l_package_name, p.procedure_name, p.overload);

      if l_reason is not null and l_include_unsupported = 'N' then
        null;
      else
        l_test_proc_name := generated_test_proc_name(p.procedure_name, p.overload);

        l_is_function := 'N';
        l_return_category := null;
        l_return_type_label := null;

        for r in (
          select data_type,
                 pls_type
            from all_arguments
           where owner = l_owner
             and package_name = l_package_name
             and object_name = p.procedure_name
             and nvl(overload, chr(0)) = nvl(p.overload, chr(0))
             and data_level = 0
             and position = 0
           order by sequence
        ) loop
          l_is_function := 'Y';
          l_return_category := tst_signature.simple_type_category(r.data_type, r.pls_type);
          l_return_type_label := type_label(r.data_type, r.pls_type, l_return_category);
        end loop;

        append_line(l_ddl, '  -- Target: ' || l_owner || '.' || l_package_name || '.' || p.procedure_name || case when p.overload is not null then ' overload ' || p.overload else '' end);

        if l_reason is not null then
          append_line(l_ddl, '  -- MANUAL COMPLETION REQUIRED: ' || substr(l_reason, 1, 3500));
          append_unsupported_stub(
            p_ddl               => l_ddl,
            p_owner             => l_owner,
            p_package_name      => l_package_name,
            p_test_package_name => l_test_package_name,
            p_program_name      => p.procedure_name,
            p_overload          => p.overload,
            p_test_proc_name    => l_test_proc_name,
            p_reason            => l_reason,
            p_signature_hash    => l_signature_hash,
            p_transaction_mode  => l_transaction_mode,
            p_profile_mode      => l_profile_mode
          );
        else
          append_supported_wrapper(
            p_ddl               => l_ddl,
            p_owner             => l_owner,
            p_package_name      => l_package_name,
            p_test_package_name => l_test_package_name,
            p_program_name      => p.procedure_name,
            p_overload          => p.overload,
            p_test_proc_name    => l_test_proc_name,
            p_is_function       => l_is_function,
            p_return_category   => l_return_category,
            p_return_type_label => l_return_type_label,
            p_signature_hash    => l_signature_hash,
            p_transaction_mode  => l_transaction_mode,
            p_profile_mode      => l_profile_mode
          );
        end if;
      end if;
    end loop;

    append_line(l_ddl, 'end ' || lower(l_test_package_name) || ';');
    append_line(l_ddl, '/');
    append_line(l_ddl, 'show errors package body ' || lower(l_test_package_name));
    append_line(l_ddl);

    return l_ddl;
  end generate_package_test_ddl;

  function generate_package_test(
    p_owner               in varchar2,
    p_package_name        in varchar2,
    p_test_package_name   in varchar2 default null,
    p_output_mode         in varchar2 default 'TABLE',
    p_include_unsupported in varchar2 default 'Y',
    p_transaction_mode    in varchar2 default 'ROLLBACK',
    p_profile_mode        in varchar2 default 'NONE',
    p_note                in clob default null
  ) return number is
    l_owner             varchar2(128) := tst_util.normalize_name(p_owner);
    l_package_name      varchar2(128) := tst_util.normalize_name(p_package_name);
    l_test_package_name varchar2(128) := normalize_optional_name(p_test_package_name);
    l_output_mode       varchar2(30) := upper(trim(nvl(p_output_mode, 'TABLE')));
    l_ddl               clob;
    l_hash              varchar2(64);
    l_generated_id      number;
  begin
    if l_test_package_name is null then
      l_test_package_name := default_test_package_name(l_package_name);
    end if;

    l_ddl := generate_package_test_ddl(
               p_owner               => l_owner,
               p_package_name        => l_package_name,
               p_test_package_name   => l_test_package_name,
               p_include_unsupported => p_include_unsupported,
               p_transaction_mode    => p_transaction_mode,
               p_profile_mode        => p_profile_mode
             );

    l_hash := tst_signature.get_signature_hash(l_owner, l_package_name);

    if l_output_mode = 'TABLE' then
      insert into tst_generated_object (
        source_owner,
        source_package_name,
        generated_package_name,
        source_signature_hash,
        generation_status,
        generated_ddl,
        note
      ) values (
        l_owner,
        l_package_name,
        l_test_package_name,
        l_hash,
        'GENERATED',
        l_ddl,
        p_note
      ) returning generated_id into l_generated_id;

      return l_generated_id;
    elsif l_output_mode = 'DBMS_OUTPUT' then
      declare
        l_len integer;
        l_pos integer := 1;
        l_chunk varchar2(32767);
      begin
        l_len := dbms_lob.getlength(l_ddl);

        while l_pos <= l_len loop
          l_chunk := dbms_lob.substr(l_ddl, 32000, l_pos);
          dbms_output.put_line(l_chunk);
          l_pos := l_pos + 32000;
        end loop;
      end;

      return null;
    else
      raise_application_error(-20942, 'Unsupported output mode: ' || p_output_mode || '. Supported modes: TABLE, DBMS_OUTPUT.');
    end if;
  exception
    when others then
      if l_output_mode = 'TABLE' then
        begin
          insert into tst_generated_object (
            source_owner,
            source_package_name,
            generated_package_name,
            source_signature_hash,
            generation_status,
            generated_ddl,
            note
          ) values (
            nvl(l_owner, '<UNKNOWN>'),
            nvl(l_package_name, '<UNKNOWN>'),
            nvl(l_test_package_name, '<UNKNOWN>'),
            null,
            'ERROR',
            l_ddl,
            to_clob('Generation error: ' || sqlcode || ' - ' || sqlerrm)
          );
        exception
          when others then
            null;
        end;
      end if;
      raise;
  end generate_package_test;

  procedure print_generated_ddl(
    p_generated_id in number
  ) is
    l_ddl clob;
    l_len integer;
    l_pos integer := 1;
    l_chunk varchar2(32767);
  begin
    select generated_ddl
      into l_ddl
      from tst_generated_object
     where generated_id = p_generated_id;

    if l_ddl is null then
      dbms_output.put_line('-- No DDL found for generated_id=' || p_generated_id);
      return;
    end if;

    l_len := dbms_lob.getlength(l_ddl);

    while l_pos <= l_len loop
      l_chunk := dbms_lob.substr(l_ddl, 32000, l_pos);
      dbms_output.put_line(l_chunk);
      l_pos := l_pos + 32000;
    end loop;
  end print_generated_ddl;

end tst_generator;
/
show errors package body tst_generator
