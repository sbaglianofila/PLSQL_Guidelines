create or replace package tst_runner as

  function start_run(
    p_owner                  in varchar2,
    p_package_name           in varchar2 default null,
    p_program_name           in varchar2 default null,
    p_generated_package_name in varchar2 default null,
    p_profile_mode           in varchar2 default 'NONE',
    p_coverage_mode          in varchar2 default 'NONE',
    p_transaction_mode       in varchar2 default 'ROLLBACK',
    p_note                   in clob default null
  ) return number;

  function start_case(
    p_run_id           in number,
    p_case_code        in varchar2 default null,
    p_case_description in varchar2 default null,
    p_expect_error     in varchar2 default 'N',
    p_expect_sqlcode   in number default null
  ) return number;

  procedure end_case_success(
    p_case_id in number
  );

  procedure end_case_error(
    p_case_id     in number,
    p_sqlcode     in number,
    p_sqlerrm     in varchar2,
    p_error_stack in clob default null,
    p_backtrace   in clob default null
  );

  procedure skip_case(
    p_case_id in number,
    p_reason  in varchar2 default null
  );

  procedure end_run_success(
    p_run_id in number
  );

  procedure end_run_error(
    p_run_id  in number,
    p_sqlcode in number,
    p_sqlerrm in varchar2
  );

end tst_runner;
/
show errors package tst_runner
