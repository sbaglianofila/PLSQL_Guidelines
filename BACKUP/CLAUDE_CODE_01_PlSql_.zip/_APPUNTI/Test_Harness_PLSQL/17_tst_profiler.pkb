create or replace package body tst_profiler as

  c_ok constant number := 0;

  function table_exists(
    p_table_name in varchar2
  ) return boolean is
    l_count number;
  begin
    select count(*)
      into l_count
      from user_tables
     where table_name = upper(p_table_name);

    return l_count > 0;
  end table_exists;

  function profiler_available return varchar2 is
  begin
    -- If this package body compiles, EXECUTE on DBMS_PROFILER is available.
    -- At runtime we mainly verify that the profiler repository tables exist
    -- in the schema that is executing the tests.
    if not table_exists('PLSQL_PROFILER_RUNS') then
      return 'N';
    end if;

    if not table_exists('PLSQL_PROFILER_UNITS') then
      return 'N';
    end if;

    if not table_exists('PLSQL_PROFILER_DATA') then
      return 'N';
    end if;

    return 'Y';
  exception
    when others then
      return 'N';
  end profiler_available;

  procedure assert_ready is
  begin
    if profiler_available <> 'Y' then
      raise_application_error(
        -20960,
        'DBMS_PROFILER is not ready for this schema. Check EXECUTE privilege on SYS.DBMS_PROFILER and install profiler tables with profload.sql in the schema that runs the tests.'
      );
    end if;
  end assert_ready;

  function start_case(
    p_run_id      in number,
    p_case_id     in number,
    p_run_comment in varchar2 default null
  ) return number is
    pragma autonomous_transaction;
    l_profiler_runid binary_integer;
    l_result         binary_integer;
    l_comment        varchar2(4000);
  begin
    assert_ready;

    l_comment := substr(
                   nvl(
                     p_run_comment,
                     'TST_HARNESS RUN_ID=' || p_run_id || ' CASE_ID=' || p_case_id
                   ),
                   1,
                   4000
                 );

    l_result := dbms_profiler.start_profiler(
                  run_comment => l_comment,
                  run_number  => l_profiler_runid
                );

    insert into tst_profiler_case (
      run_id,
      case_id,
      profiler_runid,
      status,
      start_result_code,
      run_comment
    ) values (
      p_run_id,
      p_case_id,
      l_profiler_runid,
      case when l_result = c_ok then 'RUNNING' else 'ERROR' end,
      l_result,
      l_comment
    );

    if l_result <> c_ok then
      update tst_profiler_case
         set error_code = l_result,
             error_message = 'DBMS_PROFILER.START_PROFILER returned code ' || l_result
       where case_id = p_case_id;

      commit;
      raise_application_error(-20961, 'DBMS_PROFILER.START_PROFILER returned code ' || l_result);
    end if;

    tst_log.message(
      p_run_id  => p_run_id,
      p_case_id => p_case_id,
      p_level   => 'DEBUG',
      p_message => 'DBMS_PROFILER started. PROFILER_RUNID=' || l_profiler_runid
    );

    commit;
    return l_profiler_runid;
  exception
    when dup_val_on_index then
      rollback;
      raise_application_error(-20962, 'A profiler record already exists for CASE_ID=' || p_case_id);
    when others then
      begin
        l_result := dbms_profiler.stop_profiler;
        l_result := dbms_profiler.flush_data;
      exception
        when others then
          null;
      end;
      rollback;
      raise;
  end start_case;

  procedure stop_case(
    p_case_id in number
  ) is
    pragma autonomous_transaction;
    l_run_id          number;
    l_profiler_runid  number;
    l_stop_result     binary_integer;
    l_flush_result    binary_integer;
  begin
    select run_id, profiler_runid
      into l_run_id, l_profiler_runid
      from tst_profiler_case
     where case_id = p_case_id
       and status = 'RUNNING'
       for update;

    l_stop_result := dbms_profiler.stop_profiler;
    l_flush_result := dbms_profiler.flush_data;

    update tst_profiler_case
       set stopped_at = systimestamp,
           status = case when nvl(l_stop_result, -1) = c_ok and nvl(l_flush_result, -1) = c_ok then 'STOPPED' else 'ERROR' end,
           stop_result_code = l_stop_result,
           flush_result_code = l_flush_result,
           error_code = case when nvl(l_stop_result, -1) <> c_ok then l_stop_result
                             when nvl(l_flush_result, -1) <> c_ok then l_flush_result
                             else null end,
           error_message = case when nvl(l_stop_result, -1) <> c_ok then 'DBMS_PROFILER.STOP_PROFILER returned code ' || l_stop_result
                                when nvl(l_flush_result, -1) <> c_ok then 'DBMS_PROFILER.FLUSH_DATA returned code ' || l_flush_result
                                else null end
     where case_id = p_case_id;

    tst_log.message(
      p_run_id  => l_run_id,
      p_case_id => p_case_id,
      p_level   => case when nvl(l_stop_result, -1) = c_ok and nvl(l_flush_result, -1) = c_ok then 'DEBUG' else 'WARN' end,
      p_message => 'DBMS_PROFILER stopped. PROFILER_RUNID=' || l_profiler_runid ||
                   ', STOP_CODE=' || l_stop_result || ', FLUSH_CODE=' || l_flush_result
    );

    if nvl(l_stop_result, -1) <> c_ok or nvl(l_flush_result, -1) <> c_ok then
      commit;
      raise_application_error(-20963, 'DBMS_PROFILER stop/flush returned a non-zero status. See TST_PROFILER_CASE.');
    end if;

    commit;
  exception
    when no_data_found then
      rollback;
      raise_application_error(-20964, 'No running profiler record found for CASE_ID=' || p_case_id);
    when others then
      rollback;
      raise;
  end stop_case;

  procedure safe_stop_case(
    p_case_id in number
  ) is
    pragma autonomous_transaction;
    l_run_id number;
    l_dummy  binary_integer;
  begin
    begin
      l_dummy := dbms_profiler.stop_profiler;
      l_dummy := dbms_profiler.flush_data;
    exception
      when others then
        null;
    end;

    begin
      select run_id
        into l_run_id
        from tst_case
       where case_id = p_case_id;
    exception
      when no_data_found then
        l_run_id := null;
    end;

    update tst_profiler_case
       set stopped_at = nvl(stopped_at, systimestamp),
           status = case when status = 'RUNNING' then 'ERROR' else status end,
           error_code = nvl(error_code, -1),
           error_message = nvl(error_message, 'Profiler stopped through SAFE_STOP_CASE after target exception or cleanup path.')
     where case_id = p_case_id
       and status = 'RUNNING';

    tst_log.message(
      p_run_id  => l_run_id,
      p_case_id => p_case_id,
      p_level   => 'DEBUG',
      p_message => 'DBMS_PROFILER safe stop executed.'
    );

    commit;
  exception
    when others then
      rollback;
      null;
  end safe_stop_case;

end tst_profiler;
/
show errors package body tst_profiler
