set define off
set serveroutput on size unlimited

prompt ============================================================
prompt Installing PL/SQL Test Harness full v0.3
prompt Runtime v0.1 + Generator v0.3 + DBMS_PROFILER add-on
prompt ============================================================

@@00_install_runtime.sql
@@00_install_profiler.sql

prompt ============================================================
prompt Full installation completed.
prompt Optional demo:
prompt   @90_demo_target.sql
prompt   @19_demo_generate_wrapper_with_profiler.sql
prompt ============================================================
