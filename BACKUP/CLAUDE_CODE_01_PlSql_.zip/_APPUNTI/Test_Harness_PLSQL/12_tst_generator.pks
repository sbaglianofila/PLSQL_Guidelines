create or replace package tst_generator as

  function default_test_package_name(
    p_package_name in varchar2
  ) return varchar2;

  function generate_package_test_ddl(
    p_owner               in varchar2,
    p_package_name        in varchar2,
    p_test_package_name   in varchar2 default null,
    p_include_unsupported in varchar2 default 'Y',
    p_transaction_mode    in varchar2 default 'ROLLBACK',
    p_profile_mode        in varchar2 default 'NONE'
  ) return clob;

  function generate_package_test(
    p_owner               in varchar2,
    p_package_name        in varchar2,
    p_test_package_name   in varchar2 default null,
    p_output_mode         in varchar2 default 'TABLE',
    p_include_unsupported in varchar2 default 'Y',
    p_transaction_mode    in varchar2 default 'ROLLBACK',
    p_profile_mode        in varchar2 default 'NONE',
    p_note                in clob default null
  ) return number;

  procedure print_generated_ddl(
    p_generated_id in number
  );

end tst_generator;
/
show errors package tst_generator
