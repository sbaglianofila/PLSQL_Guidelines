set define off

prompt Creating generator helper views...

create or replace view tst_v_generated_latest as
select g.generated_id,
       g.source_owner,
       g.source_package_name,
       g.generated_package_name,
       g.generated_at,
       g.source_signature_hash,
       case
         when tst_signature.has_signature_changed(
                g.source_owner,
                g.source_package_name,
                g.source_signature_hash
              ) = 'Y'
         then 'Y'
         else 'N'
       end as signature_changed,
       g.generation_status,
       dbms_lob.getlength(g.generated_ddl) as generated_ddl_length,
       g.created_by
from tst_generated_object g
where g.generated_id = (
  select max(g2.generated_id)
    from tst_generated_object g2
   where g2.source_owner = g.source_owner
     and g2.source_package_name = g.source_package_name
     and g2.generated_package_name = g.generated_package_name
);

prompt Generator helper views created.
