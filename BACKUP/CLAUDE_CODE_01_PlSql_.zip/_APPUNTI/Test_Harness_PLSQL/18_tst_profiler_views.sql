set define off

prompt Creating PL/SQL Test Harness profiler views...

create or replace view tst_v_profiler_case as
select pc.profiler_case_id,
       pc.run_id,
       pc.case_id,
       c.case_code,
       c.case_description,
       r.source_owner,
       r.source_package_name,
       r.source_program_name,
       pc.profiler_runid,
       pc.started_at,
       pc.stopped_at,
       pc.status,
       pc.start_result_code,
       pc.stop_result_code,
       pc.flush_result_code,
       pr.run_date as profiler_run_date,
       pr.run_comment as profiler_run_comment,
       pr.run_total_time as profiler_total_time,
       pc.error_code,
       pc.error_message
  from tst_profiler_case pc
  join tst_case c on c.case_id = pc.case_id
  join tst_run r on r.run_id = pc.run_id
  left join plsql_profiler_runs pr on pr.runid = pc.profiler_runid;

create or replace view tst_v_profiler_unit_summary as
select pc.run_id,
       pc.case_id,
       c.case_code,
       pc.profiler_runid,
       u.unit_owner,
       u.unit_name,
       u.unit_type,
       u.unit_number,
       u.total_time,
       sum(nvl(d.total_occur, 0)) as total_line_occurrences,
       sum(nvl(d.total_time, 0)) as total_line_time
  from tst_profiler_case pc
  join tst_case c on c.case_id = pc.case_id
  join plsql_profiler_units u on u.runid = pc.profiler_runid
  left join plsql_profiler_data d
    on d.runid = u.runid
   and d.unit_number = u.unit_number
 group by pc.run_id,
          pc.case_id,
          c.case_code,
          pc.profiler_runid,
          u.unit_owner,
          u.unit_name,
          u.unit_type,
          u.unit_number,
          u.total_time;

create or replace view tst_v_profiler_hot_lines as
select pc.run_id,
       pc.case_id,
       c.case_code,
       pc.profiler_runid,
       u.unit_owner,
       u.unit_name,
       u.unit_type,
       d.line# as line_no,
       d.total_occur,
       d.total_time,
       d.min_time,
       d.max_time
  from tst_profiler_case pc
  join tst_case c on c.case_id = pc.case_id
  join plsql_profiler_units u on u.runid = pc.profiler_runid
  join plsql_profiler_data d
    on d.runid = u.runid
   and d.unit_number = u.unit_number
 where nvl(d.total_occur, 0) > 0;

prompt Profiler views created.
