set define off

prompt Creating demo target objects...

create table demo_ordini (
  id_ordine  number primary key,
  stato      varchar2(30) not null,
  updated_by varchar2(100),
  updated_at date
);

insert into demo_ordini(id_ordine, stato) values (1001, 'INSERITO');
insert into demo_ordini(id_ordine, stato) values (1002, 'CHIUSO');
commit;

create or replace package demo_pkg_ordini as

  procedure cambia_stato_ordine(
    p_id_ordine in number,
    p_stato_new in varchar2,
    p_user      in varchar2
  );

  function normalizza_codice(
    p_codice in varchar2
  ) return varchar2;

end demo_pkg_ordini;
/
show errors package demo_pkg_ordini

create or replace package body demo_pkg_ordini as

  procedure cambia_stato_ordine(
    p_id_ordine in number,
    p_stato_new in varchar2,
    p_user      in varchar2
  ) is
    l_stato_old demo_ordini.stato%type;
  begin
    select stato
      into l_stato_old
      from demo_ordini
     where id_ordine = p_id_ordine;

    if l_stato_old = 'CHIUSO' then
      raise_application_error(-20001, 'Ordine chiuso: cambio stato non ammesso.');
    end if;

    update demo_ordini
       set stato = upper(trim(p_stato_new)),
           updated_by = p_user,
           updated_at = sysdate
     where id_ordine = p_id_ordine;
  end cambia_stato_ordine;

  function normalizza_codice(
    p_codice in varchar2
  ) return varchar2 is
  begin
    return upper(trim(p_codice));
  end normalizza_codice;

end demo_pkg_ordini;
/
show errors package body demo_pkg_ordini

prompt Demo target created.
