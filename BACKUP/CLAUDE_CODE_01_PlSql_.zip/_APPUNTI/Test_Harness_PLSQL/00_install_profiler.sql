set define off
set serveroutput on size unlimited

prompt Installing PL/SQL Test Harness profiler add-on v0.3...

@15_tst_profiler_tables.sql
@16_tst_profiler.pks
@17_tst_profiler.pkb
@18_tst_profiler_views.sql
@12_tst_generator.pks
@13_tst_generator.pkb

prompt Profiler add-on v0.3 installed.
