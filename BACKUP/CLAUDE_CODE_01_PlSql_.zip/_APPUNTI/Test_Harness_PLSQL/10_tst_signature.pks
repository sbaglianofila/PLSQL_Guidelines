create or replace package tst_signature as

  function get_signature_text(
    p_owner        in varchar2,
    p_package_name in varchar2,
    p_program_name in varchar2 default null
  ) return clob;

  function get_signature_hash(
    p_owner        in varchar2,
    p_package_name in varchar2,
    p_program_name in varchar2 default null
  ) return varchar2;

  function has_signature_changed(
    p_owner         in varchar2,
    p_package_name  in varchar2,
    p_expected_hash in varchar2,
    p_program_name  in varchar2 default null
  ) return varchar2;

  function simple_type_category(
    p_data_type in varchar2,
    p_pls_type  in varchar2 default null
  ) return varchar2;

  function is_simple_supported(
    p_data_type in varchar2,
    p_pls_type  in varchar2 default null
  ) return varchar2;

end tst_signature;
/
show errors package tst_signature
