create or replace package tst_profiler as

  function profiler_available return varchar2;

  procedure assert_ready;

  function start_case(
    p_run_id      in number,
    p_case_id     in number,
    p_run_comment in varchar2 default null
  ) return number;

  procedure stop_case(
    p_case_id in number
  );

  procedure safe_stop_case(
    p_case_id in number
  );

end tst_profiler;
/
show errors package tst_profiler
