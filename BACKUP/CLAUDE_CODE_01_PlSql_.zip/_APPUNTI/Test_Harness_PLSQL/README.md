# PL/SQL Test Harness - Runtime v0.1

Questa e' una prima versione concreta del runtime per il tool di generazione automatica di wrapper di test PL/SQL.

L'obiettivo della v0.1 non e' ancora generare automaticamente i package `_TEST`, ma preparare il runtime stabile su cui il generatore dovra' appoggiarsi.

## Contenuto

| File | Descrizione |
|---|---|
| `00_install_runtime.sql` | Script SQL*Plus che installa tutto il runtime in ordine. |
| `01_tst_tables.sql` | Tabelle, vincoli, indici e viste base. |
| `02_tst_util.pks` / `03_tst_util.pkb` | Utility comuni. |
| `04_tst_log.pks` / `05_tst_log.pkb` | Logging di parametri, output, return value e messaggi tecnici. |
| `06_tst_assert.pks` / `07_tst_assert.pkb` | Assert minimali. |
| `08_tst_runner.pks` / `09_tst_runner.pkb` | Gestione run e casi. |
| `90_demo_target.sql` | Oggetto demo da testare. |
| `91_demo_test_wrapper.sql` | Esempio di package `_TEST` scritto a mano, come modello per il futuro generatore. |

## Installazione

Da SQL*Plus o SQLcl, posizionarsi nella cartella degli script ed eseguire:

```sql
@00_install_runtime.sql
```

Attenzione: `01_tst_tables.sql` crea gli oggetti. Se gli oggetti esistono gia', lo script andra' in errore. Per ora e' volutamente semplice: in una versione successiva si potra' aggiungere uno script di migrazione o reinstallazione controllata.

## Esecuzione demo

Dopo l'installazione del runtime:

```sql
@90_demo_target.sql
@91_demo_test_wrapper.sql

begin
  demo_pkg_ordini_test.test_cambia_stato_ordine;
  demo_pkg_ordini_test.test_normalizza_codice;
end;
/
```

Poi consultare gli esiti:

```sql
select *
from tst_v_run_summary
order by run_id desc;

select *
from tst_v_case_detail
order by case_id desc;

select *
from tst_v_assert_failure
order by assert_id desc;
```

## Pattern usato

Il wrapper di test deve essere sottile. Deve contenere il cursore dei casi, chiamare il codice target e delegare il resto ai package comuni:

- `TST_RUNNER` apre e chiude run/case.
- `TST_LOG` salva input, output, return value e log tecnico.
- `TST_ASSERT` salva il risultato degli assert.
- `TST_UTIL` contiene utility comuni.

Il logging usa autonomous transaction, quindi rimane persistente anche se il caso di test fa rollback.

## Convenzioni di stato

### TST_RUN.STATUS

- `RUNNING`
- `SUCCESS`
- `FAILED`
- `ERROR`

### TST_CASE.STATUS

- `RUNNING`
- `PASS`
- `FAIL`
- `ERROR`
- `SKIPPED`

`PASS` significa che il caso non ha errori non attesi e non ha assert falliti.  
`FAIL` significa che il caso e' stato eseguito, ma almeno un assert o una condizione attesa non e' rispettata.  
`ERROR` significa errore non atteso durante l'esecuzione.

## Nota importante sulle transazioni

Il wrapper demo usa `SAVEPOINT` e `ROLLBACK TO SAVEPOINT` per isolare i casi.

Questo funziona se il codice target non fa `COMMIT`. Se il codice target fa `COMMIT`, il savepoint viene perso e il framework non puo' garantire il rollback automatico del caso.

Regola consigliata: il codice business testabile non dovrebbe fare commit interni. Il commit dovrebbe stare nel livello orchestratore.

## Prossimo step

Il prossimo blocco naturale e':

- `TST_SIGNATURE`, per calcolare hash della firma da `ALL_ARGUMENTS`;
- `TST_GENERATOR`, per generare automaticamente il package `<TARGET>_TEST` usando le API di questa v0.1.
