create or replace package body tst_util as

  function normalize_name(
    p_name in varchar2
  ) return varchar2 is
    l_name varchar2(128);
  begin
    l_name := upper(trim(p_name));

    if l_name is null then
      raise_application_error(-20900, 'Name cannot be null.');
    end if;

    if not regexp_like(l_name, '^[A-Z][A-Z0-9_$#]*$') then
      raise_application_error(-20901, 'Invalid SQL simple name: ' || p_name);
    end if;

    return l_name;
  end normalize_name;

  function boolean_to_varchar2(
    p_value in boolean
  ) return varchar2 is
  begin
    if p_value is null then
      return 'NULL';
    elsif p_value then
      return 'TRUE';
    else
      return 'FALSE';
    end if;
  end boolean_to_varchar2;

  function flag_to_boolean(
    p_value in varchar2
  ) return boolean is
    l_value varchar2(30);
  begin
    l_value := upper(trim(p_value));

    if l_value in ('Y','YES','S','SI','TRUE','T','1') then
      return true;
    elsif l_value in ('N','NO','FALSE','F','0') then
      return false;
    elsif l_value is null then
      return null;
    else
      raise_application_error(-20902, 'Invalid boolean flag: ' || p_value);
    end if;
  end flag_to_boolean;

  function elapsed_ms(
    p_started_at in timestamp,
    p_ended_at   in timestamp default systimestamp
  ) return number is
    l_interval interval day to second;
  begin
    if p_started_at is null or p_ended_at is null then
      return null;
    end if;

    l_interval := p_ended_at - p_started_at;

    return   extract(day    from l_interval) * 86400000
           + extract(hour   from l_interval) * 3600000
           + extract(minute from l_interval) * 60000
           + extract(second from l_interval) * 1000;
  end elapsed_ms;

  function clob_preview(
    p_value  in clob,
    p_length in pls_integer default 4000
  ) return varchar2 is
  begin
    if p_value is null then
      return null;
    end if;

    return dbms_lob.substr(p_value, least(nvl(p_length, 4000), 4000), 1);
  end clob_preview;

  function to_text(
    p_value in varchar2
  ) return clob is
  begin
    return to_clob(p_value);
  end to_text;

  function to_text(
    p_value in number
  ) return clob is
  begin
    if p_value is null then
      return null;
    end if;

    return to_clob(to_char(p_value));
  end to_text;

  function to_text(
    p_value in date
  ) return clob is
  begin
    if p_value is null then
      return null;
    end if;

    return to_clob(to_char(p_value, 'YYYY-MM-DD HH24:MI:SS'));
  end to_text;

  function to_text(
    p_value in timestamp
  ) return clob is
  begin
    if p_value is null then
      return null;
    end if;

    return to_clob(to_char(p_value, 'YYYY-MM-DD HH24:MI:SS.FF6'));
  end to_text;

  function to_text(
    p_value in clob
  ) return clob is
  begin
    return p_value;
  end to_text;

end tst_util;
/
show errors package body tst_util
