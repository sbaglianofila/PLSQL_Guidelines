set define off
set serveroutput on size unlimited

prompt ============================================================
prompt Demo: generate wrapper for DEMO_PKG_ORDINI
prompt Prerequisite: run 90_demo_target.sql from runtime v0.1 first.
prompt ============================================================

declare
  l_generated_id number;
begin
  l_generated_id := tst_generator.generate_package_test(
    p_owner               => user,
    p_package_name        => 'DEMO_PKG_ORDINI',
    p_test_package_name   => 'DEMO_PKG_ORDINI_GEN_TEST',
    p_output_mode         => 'TABLE',
    p_include_unsupported => 'Y',
    p_transaction_mode    => 'ROLLBACK',
    p_note                => 'Demo generation for DEMO_PKG_ORDINI.'
  );

  dbms_output.put_line('Generated DDL saved in TST_GENERATED_OBJECT. GENERATED_ID=' || l_generated_id);
  dbms_output.put_line('To print it: exec tst_generator.print_generated_ddl(' || l_generated_id || ');');
end;
/

commit;

column source_owner format a20
column source_package_name format a30
column generated_package_name format a30
column source_signature_hash format a64

select generated_id,
       source_owner,
       source_package_name,
       generated_package_name,
       generation_status,
       source_signature_hash,
       generated_at
  from tst_generated_object
 order by generated_id desc
 fetch first 5 rows only;

prompt ============================================================
prompt To inspect the generated DDL:
prompt   set serveroutput on size unlimited
prompt   exec tst_generator.print_generated_ddl(<GENERATED_ID>);
prompt ============================================================
