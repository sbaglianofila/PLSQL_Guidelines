# Test Harness PL/SQL generato automaticamente

## Idea, architettura e linee guida per un framework leggero di test/esecuzione

Questa guida descrive un'idea di framework PL/SQL personalizzato per generare automaticamente wrapper di test a partire dalle firme di package, procedure e function Oracle.

L'obiettivo non e' creare un'alternativa completa a strumenti come utPLSQL, ma costruire un sistema pragmatico, utile nei progetti gestionali Oracle, capace di:

- generare package di test a partire dalle firme del codice applicativo;
- eseguire automaticamente procedure e function con input parametrico;
- loggare input, output, errori e tempi di esecuzione;
- salvare il valore di ritorno delle function;
- integrare, dove utile, strumenti Oracle come `DBMS_PROFILER`, `DBMS_HPROF`, `DBMS_PLSQL_CODE_COVERAGE`, `DBMS_APPLICATION_INFO`;
- fornire una base concreta per test di regressione, controlli tecnici e analisi prestazionali.

Il concetto centrale e' quello di creare un **test harness generato**, cioe' una struttura di supporto che permette di lanciare in modo standardizzato il codice PL/SQL da verificare.

---

# 1. Inquadramento dell'idea

L'idea e' molto valida, ma va inquadrata correttamente.

Non si tratta propriamente di creare un framework di unit test completo, almeno non nella prima versione. Si tratta piuttosto di creare un **execution harness** o **test harness** per PL/SQL.

La differenza e' importante.

```text
utPLSQL
= framework di unit test con assert, suite, runner, reporter, integrazione CI/CD

framework custom
= generatore di wrapper eseguibili, con input parametrico, logging, profiling, coverage e output su tabelle
```

Quindi non e' necessariamente una soluzione peggiore. E' una soluzione diversa, piu' pragmatica e spesso piu' vicina al modo in cui si lavora realmente su codice PL/SQL gestionale.

In molti progetti Oracle, infatti, il problema iniziale non e' tanto avere un framework di test perfetto, quanto avere un modo standard, ripetibile e tracciato per lanciare package, procedure e function, raccogliere risultati e poter fare analisi successive.

---

# 2. Perche' puo' essere utile

Questa soluzione puo' essere molto utile soprattutto per quattro motivi.

## 2.1 Standardizza il modo di lanciare il codice

Senza un framework di supporto, i test manuali tendono a essere fatti con script sparsi:

```sql
begin
  pkg_ordini.elabora_ordine(
      p_id_ordine => 1001
  );
end;
/
```

Oppure con blocchi anonimi salvati localmente, modificati al volo e difficili da versionare.

Con un package di test generato, invece, si avrebbe sempre una struttura standard:

```sql
begin
  pkg_ordini_test.test_elabora_ordine;
end;
/
```

Il wrapper di test si occupa di:

- aprire una run;
- leggere i casi di test;
- chiamare il codice target;
- loggare input e output;
- intercettare errori;
- misurare tempi;
- salvare il risultato;
- chiudere la run.

Questo rende il test piu' leggibile, replicabile e archiviabile.

## 2.2 Crea automaticamente lo scaffolding

La parte piu' interessante e' la generazione automatica dello scaffolding.

Il generatore puo' leggere le firme da viste come:

```text
USER_ARGUMENTS
ALL_ARGUMENTS
DBA_ARGUMENTS
USER_PROCEDURES
ALL_PROCEDURES
DBA_PROCEDURES
```

A partire da queste informazioni puo' generare un package con suffisso `_TEST`.

Esempio:

```text
PKG_ORDINI
  procedure valida_ordine(...)
  function calcola_totale(...) return number
```

Diventa:

```text
PKG_ORDINI_TEST
  procedure test_valida_ordine
  procedure test_calcola_totale
```

Il codice generato non deve essere perfetto o definitivo. Deve essere una base pronta da rifinire.

Questa e' una cosa molto utile, perche' riduce l'attrito iniziale. Lo sviluppatore non deve partire da zero ogni volta.

## 2.3 Supporta regressioni tecniche e test semi-automatici

Non sempre serve un vero unit test con assert sofisticati.

A volte serve semplicemente dire:

```text
lancia questa procedura su questi 200 casi;
logga input, output, errore, elapsed time e run id;
poi mi controllo gli esiti.
```

Questo approccio e' particolarmente utile per:

- batch;
- caricamenti;
- normalizzazioni;
- controlli dati;
- procedure di bonifica;
- report;
- procedure usate in AM;
- regressioni tecniche dopo modifiche.

## 2.4 Obbliga a censire meglio gli scenari di test

L'idea del cursore come input dei casi di test e' molto buona.

Il wrapper generato puo' contenere un cursore vuoto, da popolare successivamente con select specifiche.

Esempio:

```sql
cursor c_test is
  select 26 as site,
         date '2026-07-01' as data_rif,
         'ORD123' as codice_ordine
  from dual;
```

Oppure, per piu' casi:

```sql
cursor c_test is
  select 'CASE_001' as case_code,
         26         as site,
         date '2026-07-01' as data_rif,
         'ORD123'  as codice_ordine
  from dual
  union all
  select 'CASE_002',
         27,
         date '2026-07-02',
         'ORD456'
  from dual;
```

In questo modo i casi sono:

- leggibili;
- versionabili;
- modificabili;
- ripetibili;
- facilmente commentabili.

---

# 3. Non chiamarlo subito framework di unit test

Qui e' importante essere un po' rigorosi.

Se il framework si limita a:

```text
eseguo il codice;
loggo output;
loggo errore;
loggo performance.
```

allora non e' ancora un vero framework di unit test.

E' un **execution harness**.

Questo non e' un problema, ma va dichiarato chiaramente.

Per avvicinarsi a un vero framework di test, serve almeno un concetto di:

```text
expected result
actual result
assertion
esito PASS / FAIL
```

Anche molto semplice.

Non serve rifare utPLSQL. Pero' e' importante che ogni caso di test possa concludersi con un esito leggibile.

Esempi di assert minimi:

```text
PASS = la chiamata non va in errore
PASS = la function ritorna il valore atteso
PASS = dopo la chiamata esiste una riga attesa
PASS = il rowcount atteso e' 10
PASS = lo stato ordine e' passato da INSERITO a VALIDATO
FAIL = errore non previsto
FAIL = valore di ritorno diverso
FAIL = output atteso non trovato
```

Senza questa parte si rischia di avere un sistema che esegue tanto codice, ma che richiede sempre un controllo manuale successivo.

Il controllo manuale puo' andare bene all'inizio, ma se l'obiettivo e' creare regressioni ripetibili, prima o poi serve almeno una logica base di assert.

---

# 4. Architettura proposta

La soluzione si puo' dividere in tre livelli principali.

```text
1. Generatore
   Legge package, procedure e function e genera il package _TEST.

2. Runtime di test
   Package centrale che gestisce run, case, step, profiling, coverage, logging e assert.

3. Tabelle di risultato
   Salvano run, casi eseguiti, input, output, errori, tempi, coverage e profiler.
```

Il punto fondamentale e' non mettere tutta la logica dentro ogni package `_TEST` generato.

Il package generato deve essere abbastanza sottile. Deve contenere il codice specifico per chiamare il target, ma deve demandare la logica comune a package centralizzati.

Esempio di architettura:

```text
TST_GENERATOR
  Genera package di test.

TST_RUNNER
  Gestisce apertura/chiusura run e case.

TST_LOG
  Scrive log tecnici e diagnostici.

TST_ASSERT
  Gestisce assert e PASS/FAIL.

TST_PROFILER
  Incapsula DBMS_PROFILER / DBMS_HPROF.

TST_COVERAGE
  Incapsula DBMS_PLSQL_CODE_COVERAGE.

TST_UTIL
  Utility comuni.
```

Il package generato, invece, sara' del tipo:

```text
PKG_ORDINI_TEST
  test_valida_ordine
  test_calcola_totale
  test_cambia_stato_ordine
```

---

# 5. Flusso ideale di una procedura generata

Supponiamo di avere questa procedura target:

```sql
procedure cambia_stato_ordine(
    p_id_ordine  in number,
    p_stato_new  in varchar2,
    p_user       in varchar2
);
```

Il generatore potrebbe produrre una procedura di test simile a questa:

```sql
procedure test_cambia_stato_ordine is

  cursor c_test is
    select cast(null as varchar2(100))  as case_code,
           cast(null as varchar2(4000)) as case_description,
           cast(null as number)         as p_id_ordine,
           cast(null as varchar2(30))   as p_stato_new,
           cast(null as varchar2(100))  as p_user,
           cast('N' as varchar2(1))     as expect_error,
           cast(null as number)         as expect_sqlcode,
           cast(null as varchar2(30))   as expected_status
    from dual
    where 1 = 0;

  l_run_id   number;
  l_case_id  number;

begin
  l_run_id := tst_runner.start_run(
                p_owner        => 'APP',
                p_package_name => 'PKG_ORDINI',
                p_program_name => 'CAMBIA_STATO_ORDINE'
              );

  for r in c_test loop
    l_case_id := tst_runner.start_case(
                   p_run_id           => l_run_id,
                   p_case_code        => r.case_code,
                   p_case_description => r.case_description
                 );

    begin
      tst_log.log_param(l_case_id, 'P_ID_ORDINE', 'IN', 'NUMBER', r.p_id_ordine);
      tst_log.log_param(l_case_id, 'P_STATO_NEW', 'IN', 'VARCHAR2', r.p_stato_new);
      tst_log.log_param(l_case_id, 'P_USER',      'IN', 'VARCHAR2', r.p_user);

      tst_profiler.start_case(l_case_id);
      tst_coverage.start_case(l_case_id);

      pkg_ordini.cambia_stato_ordine(
        p_id_ordine => r.p_id_ordine,
        p_stato_new => r.p_stato_new,
        p_user      => r.p_user
      );

      tst_coverage.stop_case(l_case_id);
      tst_profiler.stop_case(l_case_id);

      -- Sezione assert personalizzabile.
      -- Qui lo sviluppatore puo' aggiungere controlli sul database.
      -- Esempio:
      -- select stato
      -- into l_actual_status
      -- from ordini
      -- where id_ordine = r.p_id_ordine;
      --
      -- tst_assert.eq_varchar2(
      --   p_case_id  => l_case_id,
      --   p_name     => 'STATO_ORDINE',
      --   p_expected => r.expected_status,
      --   p_actual   => l_actual_status
      -- );

      tst_runner.end_case_success(l_case_id);

    exception
      when others then
        tst_coverage.safe_stop(l_case_id);
        tst_profiler.safe_stop(l_case_id);

        tst_runner.end_case_error(
          p_case_id    => l_case_id,
          p_sqlcode    => sqlcode,
          p_sqlerrm    => sqlerrm,
          p_error_stack => dbms_utility.format_error_stack,
          p_backtrace   => dbms_utility.format_error_backtrace
        );
    end;
  end loop;

  tst_runner.end_run_success(l_run_id);

exception
  when others then
    tst_runner.end_run_error(
      p_run_id  => l_run_id,
      p_sqlcode => sqlcode,
      p_sqlerrm => sqlerrm
    );
    raise;
end test_cambia_stato_ordine;
```

Questo esempio non vuole essere il codice definitivo, ma mostra il pattern.

Il wrapper:

- apre una run;
- cicla sui casi;
- logga i parametri;
- avvia profiling e coverage;
- chiama il target;
- ferma profiling e coverage;
- permette assert personalizzati;
- salva esito positivo o errore.

---

# 6. Gestione delle function

Per le function il framework diventa ancora piu' interessante, perche' puo' salvare automaticamente il valore di ritorno.

Esempio di function target:

```sql
function normalizza_codice(
    p_codice in varchar2
) return varchar2;
```

Il wrapper generato puo' fare:

```sql
l_ret := pkg_articoli.normalizza_codice(
           p_codice => r.p_codice
         );

tst_log.log_return_value(
  p_case_id    => l_case_id,
  p_value_type => 'VARCHAR2',
  p_value      => l_ret
);
```

Questo e' molto utile, perche' consente di confrontare il valore restituito con un expected value.

Il cursore potrebbe quindi avere anche una colonna:

```sql
expected_return_value
```

E il wrapper potrebbe generare automaticamente un assert commentato o gia' attivo:

```sql
tst_assert.eq_varchar2(
  p_case_id  => l_case_id,
  p_name     => 'RETURN_VALUE',
  p_expected => r.expected_return_value,
  p_actual   => l_ret
);
```

## 6.1 Come salvare il valore di ritorno

Conviene prevedere una tabella output flessibile.

Esempio logico:

```text
TST_CASE_OUTPUT
- output_id
- case_id
- output_name
- output_type
- value_varchar2
- value_number
- value_date
- value_timestamp
- value_clob
```

Per tipi semplici funziona molto bene.

Per `BOOLEAN`, attenzione: non e' un tipo SQL e non puo' essere salvato direttamente in tabella. Va convertito in una rappresentazione testuale:

```text
TRUE
FALSE
NULL
```

Per `CLOB`, si puo' usare una colonna CLOB.

Per tipi complessi come record, collection, object type e ref cursor, meglio non cercare subito di automatizzare tutto. Il generatore puo' classificare questi casi come non gestiti automaticamente e produrre scaffolding commentato da completare a mano.

---

# 7. Parametri IN, OUT e IN OUT

Il modello basato su cursore funziona molto bene per i parametri `IN`.

Per i parametri `OUT` e `IN OUT` serve qualche accorgimento.

## 7.1 Parametri IN

I parametri `IN` vengono letti dal cursore.

Esempio:

```sql
procedure valida_ordine(
    p_id_ordine in number,
    p_user      in varchar2
);
```

Il cursore generato puo' contenere:

```sql
cursor c_test is
  select cast(null as number)        as p_id_ordine,
         cast(null as varchar2(100)) as p_user
  from dual
  where 1 = 0;
```

La chiamata sara':

```sql
pkg_ordini.valida_ordine(
  p_id_ordine => r.p_id_ordine,
  p_user      => r.p_user
);
```

## 7.2 Parametri OUT

Per i parametri `OUT`, il wrapper deve dichiarare una variabile locale.

Esempio:

```sql
procedure calcola_esito(
    p_id_ordine in  number,
    p_esito     out varchar2
);
```

Il wrapper generato dovra' fare:

```sql
l_esito varchar2(4000);

pkg_ordini.calcola_esito(
  p_id_ordine => r.p_id_ordine,
  p_esito     => l_esito
);

tst_log.log_output(
  p_case_id     => l_case_id,
  p_output_name => 'P_ESITO',
  p_output_type => 'VARCHAR2',
  p_value       => l_esito
);
```

## 7.3 Parametri IN OUT

Per i parametri `IN OUT`, il cursore deve fornire il valore iniziale, poi il wrapper deve loggare il valore finale.

Esempio:

```sql
procedure calcola(
    p_id       in     number,
    p_importo  in out number,
    p_esito    out    varchar2
);
```

Il cursore puo' contenere:

```sql
cursor c_test is
  select cast(null as number) as p_id,
         cast(null as number) as p_importo_iniziale
  from dual
  where 1 = 0;
```

Il wrapper fara':

```sql
l_importo number := r.p_importo_iniziale;
l_esito   varchar2(4000);

pkg_test.calcola(
  p_id      => r.p_id,
  p_importo => l_importo,
  p_esito   => l_esito
);

tst_log.log_output(l_case_id, 'P_IMPORTO', 'NUMBER',   l_importo);
tst_log.log_output(l_case_id, 'P_ESITO',   'VARCHAR2', l_esito);
```

In sintesi:

```text
IN      -> letto dal cursore
OUT     -> variabile locale + log dopo chiamata
IN OUT  -> valore iniziale dal cursore + log valore finale
RETURN  -> log valore di ritorno
```

---

# 8. Gestione del cursore di input

L'idea del cursore come scaffolding e' molto buona.

Il generatore potrebbe produrre un cursore vuoto, con colonne gia' coerenti con la firma della procedura.

Esempio:

```sql
cursor c_test is
  /*
    Popolare questo cursore con i casi di test.

    Colonne richieste:
    - CASE_CODE
    - CASE_DESCRIPTION
    - P_ID_ORDINE
    - P_STATO_NEW
    - P_USER
    - EXPECT_ERROR
    - EXPECT_SQLCODE
    - EXPECTED_STATUS
  */
  select cast(null as varchar2(100))  as case_code,
         cast(null as varchar2(4000)) as case_description,
         cast(null as number)         as p_id_ordine,
         cast(null as varchar2(30))   as p_stato_new,
         cast(null as varchar2(100))  as p_user,
         cast('N' as varchar2(1))     as expect_error,
         cast(null as number)         as expect_sqlcode,
         cast(null as varchar2(30))   as expected_status
  from dual
  where 1 = 0;
```

Lo sviluppatore poi lo modifica:

```sql
cursor c_test is
  select 'ORD_VALID_001' as case_code,
         'Cambio stato ordine valido' as case_description,
         1001 as p_id_ordine,
         'VALIDATO' as p_stato_new,
         'FABIO' as p_user,
         'N' as expect_error,
         null as expect_sqlcode,
         'VALIDATO' as expected_status
  from dual
  union all
  select 'ORD_ERR_001',
         'Cambio stato non ammesso',
         1002,
         'CHIUSO',
         'FABIO',
         'Y',
         -20001,
         null
  from dual;
```

Questo modello ha diversi vantaggi:

- i test restano nel codice;
- i casi sono versionabili su Git;
- e' semplice capire quali input vengono usati;
- si possono usare select reali per recuperare casi dal database;
- si possono commentare facilmente scenari specifici.

## 8.1 Modalita' statica e table-driven

All'inizio conviene usare il cursore statico nel package `_TEST`.

In futuro si potrebbe aggiungere anche una modalita' table-driven.

```text
Modalita' STATIC
- il cursore e' scritto nel package _TEST;
- i casi sono versionati nel codice;
- e' piu' semplice e leggibile.

Modalita' TABLE-DRIVEN
- i casi di test sono salvati in tabelle dedicate;
- e' piu' flessibile per regressioni massive;
- e' piu' adatta a esecuzioni configurabili.
```

Esempio di tabelle per modalita' table-driven:

```text
TST_DATASET
- dataset_id
- dataset_code
- target_owner
- target_package
- target_procedure
- description
- active_flag

TST_DATASET_CASE
- case_id
- dataset_id
- case_code
- case_description
- active_flag

TST_DATASET_PARAM
- param_id
- case_id
- param_name
- value_type
- value_varchar2
- value_number
- value_date
- value_timestamp
- value_clob
```

Pero' questa evoluzione non dovrebbe essere la prima cosa da fare. Meglio partire semplice.

---

# 9. Tabelle di log consigliate

Una parte fondamentale del framework e' il modello dati di logging.

## 9.1 TST_RUN

Tabella di testata della run.

```text
TST_RUN
- run_id
- run_ts
- source_owner
- source_object_name
- source_package_name
- generated_package_name
- started_at
- ended_at
- status
- total_cases
- success_cases
- failed_cases
- profile_mode
- coverage_mode
- note
```

Esempio di significato:

```text
run_id                 Identificativo della run.
source_owner           Owner del package/procedura testata.
source_package_name    Nome package target.
generated_package_name Nome package _TEST generato.
status                 RUNNING / SUCCESS / FAILED / WARNING.
profile_mode           NONE / PROFILER / HPROF.
coverage_mode          NONE / BASIC / FULL.
```

## 9.2 TST_CASE

Tabella dei singoli casi eseguiti.

```text
TST_CASE
- case_id
- run_id
- case_code
- case_description
- started_at
- ended_at
- status
- elapsed_ms
- sqlcode
- sqlerrm
- error_stack
- error_backtrace
```

Questa tabella consente di sapere quali casi sono passati, quali sono falliti e con quale errore.

## 9.3 TST_CASE_PARAM

Tabella dei parametri in ingresso o iniziali.

```text
TST_CASE_PARAM
- param_id
- case_id
- param_name
- param_mode
- param_type
- value_varchar2
- value_number
- value_date
- value_timestamp
- value_clob
```

Esempio:

```text
P_ID_ORDINE  IN      NUMBER    1001
P_USER       IN      VARCHAR2  FABIO
P_IMPORTO    IN OUT  NUMBER    150.50
```

## 9.4 TST_CASE_OUTPUT

Tabella degli output, dei parametri OUT/IN OUT finali e dei return value.

```text
TST_CASE_OUTPUT
- output_id
- case_id
- output_name
- output_type
- value_varchar2
- value_number
- value_date
- value_timestamp
- value_clob
```

Esempio:

```text
RETURN_VALUE  VARCHAR2  OK
P_ESITO       VARCHAR2  VALIDATO
P_IMPORTO     NUMBER    180.75
```

## 9.5 TST_ASSERT

Tabella degli assert.

```text
TST_ASSERT
- assert_id
- case_id
- assert_name
- expected_value
- actual_value
- status
- message
```

Esempio:

```text
assert_name     STATO_ORDINE
expected_value  VALIDATO
actual_value    VALIDATO
status          PASS
```

Oppure:

```text
assert_name     RETURN_VALUE
expected_value  100
actual_value    95
status          FAIL
message         Valore di ritorno diverso dall'atteso
```

## 9.6 TST_GENERATED_OBJECT

Tabella degli oggetti generati.

```text
TST_GENERATED_OBJECT
- generated_id
- source_owner
- source_package
- generated_package
- generated_at
- source_signature_hash
- generation_status
- generated_ddl
- note
```

Questa tabella e' molto importante per capire se il package `_TEST` e' allineato alla firma corrente del package originale.

---

# 10. Signature hash

Una best practice molto utile e' calcolare un hash della firma del package sorgente al momento della generazione.

La firma dovrebbe considerare almeno:

```text
package_name
procedure/function name
overload
argument_name
position
data_type
in_out
type_owner
type_name
defaulted
return type
```

L'hash viene salvato in `TST_GENERATED_OBJECT`.

Quando si lancia il test, il framework puo' ricalcolare l'hash della firma attuale e confrontarlo con quello salvato.

Se la firma e' cambiata, si puo' decidere di:

```text
- mostrare un warning;
- bloccare l'esecuzione;
- richiedere rigenerazione del package _TEST;
- loggare lo stato SIGNATURE_MISMATCH.
```

Questo evita un problema molto frequente:

```text
Ho cambiato la firma della procedura reale,
ma il package _TEST e' rimasto vecchio.
```

In alcuni casi il package non compilera' piu', quindi il problema sara' evidente. In altri casi, invece, il rischio e' piu' subdolo, soprattutto con overload, default parameter o modifiche parziali.

---

# 11. Coverage e profiling

L'integrazione con strumenti Oracle di coverage e profiling e' interessante, ma va resa opzionale.

Non conviene accendere tutto sempre.

## 11.1 Modalita' consigliate

Si possono prevedere piu' modalita' di esecuzione.

```text
LIGHT
- elapsed time
- sqlcode/sqlerrm
- input/output
- esito

PROFILE
- tutto LIGHT
- DBMS_PROFILER oppure DBMS_HPROF

COVERAGE
- tutto LIGHT
- DBMS_PLSQL_CODE_COVERAGE

FULL
- LIGHT + coverage + profiler
```

La modalita' di default dovrebbe essere `LIGHT`.

Profiling e coverage hanno overhead e prerequisiti. Vanno usati quando servono, non necessariamente a ogni lancio.

## 11.2 DBMS_PROFILER

`DBMS_PROFILER` consente di raccogliere dati di esecuzione line-by-line sul codice PL/SQL.

Puo' essere utile per capire:

- quali righe sono state eseguite;
- quante volte;
- quanto tempo e' stato speso;
- quali sezioni sono piu' pesanti.

Ha pero' bisogno delle tabelle di supporto previste dal profiler.

In un framework custom puo' essere incapsulato da un package come `TST_PROFILER`.

Esempio logico:

```sql
tst_profiler.start_case(l_case_id);

-- chiamata al codice target

tst_profiler.stop_case(l_case_id);
```

## 11.3 DBMS_HPROF

`DBMS_HPROF` e' il profiler gerarchico PL/SQL.

E' piu' potente quando vuoi capire la catena delle chiamate:

```text
procedura A
  chiama B
    chiama C
  chiama D
```

E' molto utile per analisi prestazionali piu' serie, ma e' anche piu' macchinoso.

Tipicamente richiede:

- directory Oracle;
- generazione di file raw;
- analisi del file prodotto;
- tabelle di output;
- gestione dei permessi.

Per questo motivo non lo renderei obbligatorio nella prima versione.

Meglio partire con misurazioni semplici tramite `SYSTIMESTAMP` e introdurre HPROF come modalita' avanzata.

## 11.4 DBMS_PLSQL_CODE_COVERAGE

`DBMS_PLSQL_CODE_COVERAGE` puo' essere usato per raccogliere dati di coverage del codice PL/SQL.

E' utile per capire quali parti del codice sono state effettivamente attraversate dai test.

Anche qui, pero', attenzione: la coverage non dice se il risultato e' corretto. Dice solo che un blocco di codice e' stato eseguito.

Quindi va usata insieme agli assert, non al posto degli assert.

---

# 12. DBMS_APPLICATION_INFO

`DBMS_APPLICATION_INFO` andrebbe usato sempre nel framework.

Consente di valorizzare modulo e azione della sessione.

Esempio:

```sql
dbms_application_info.set_module(
  module_name => 'TST_HARNESS',
  action_name => 'PKG_ORDINI.CAMBIA_STATO_ORDINE'
);
```

Durante l'esecuzione di un singolo caso:

```sql
dbms_application_info.set_action(
  action_name => 'CASE: ORD_VALID_001'
);
```

Questo e' utile per:

- monitorare sessioni attive;
- leggere `V$SESSION`;
- analizzare performance;
- correlare test e attivita' database;
- rendere piu' leggibili eventuali trace.

---

# 13. Transazioni, commit e rollback

Questo e' uno dei punti piu' delicati.

Se il codice testato fa DML, bisogna decidere cosa deve succedere alla fine del caso.

Si puo' prevedere una configurazione:

```text
transaction_mode = ROLLBACK
transaction_mode = COMMIT
transaction_mode = MANUAL
```

Default consigliato: `ROLLBACK`.

Il wrapper puo' usare un savepoint:

```sql
savepoint tst_case_sp;

-- esecuzione del caso

if l_transaction_mode = 'ROLLBACK' then
  rollback to tst_case_sp;
elsif l_transaction_mode = 'COMMIT' then
  commit;
end if;
```

Pero' c'e' una trappola importante.

Se il codice target fa `COMMIT`, il savepoint viene perso. In quel caso il framework non puo' piu' garantire il rollback automatico del caso.

Per questo conviene classificare il codice target:

```text
target_has_commit = Y/N/UNKNOWN
```

Oppure, ancora meglio, adottare una regola architetturale:

```text
Il codice business non deve fare commit.
Il commit lo decide il livello orchestratore.
```

Questa regola rende il codice molto piu' testabile.

## 13.1 Logging con autonomous transaction

Il logging del framework dovrebbe probabilmente usare autonomous transaction.

Altrimenti, se il test fa rollback, si perderebbe anche il log della run.

Esempio:

```sql
procedure log_case(...) is
  pragma autonomous_transaction;
begin
  insert into tst_case_log (...)
  values (...);

  commit;
end;
```

Questa soluzione e' corretta, ma va usata con moderazione.

L'autonomous transaction dovrebbe stare nel framework di log, non essere sparsa ovunque nel codice generato.

---

# 14. Generatore dinamico, wrapper statici

Un punto importante: non conviene creare subito un runner completamente dinamico che chiama qualunque procedura tramite `EXECUTE IMMEDIATE` leggendo parametri da tabelle.

Sulla carta sembra elegante, ma in PL/SQL diventa rapidamente complicato.

I problemi principali sono:

- tipi `OUT` e `IN OUT`;
- overload;
- record;
- collection;
- object type;
- boolean;
- ref cursor;
- default parameter;
- sicurezza;
- leggibilita';
- debug.

La soluzione migliore e':

```text
Generatore dinamico, wrapper statici.
```

Cioe':

- il generatore legge il dizionario dati;
- produce codice PL/SQL statico;
- il codice generato viene compilato;
- se la firma non torna, il package non compila;
- il wrapper e' leggibile, modificabile e versionabile.

Esempio di codice statico generato:

```sql
pkg_ordini.cambia_stato_ordine(
  p_id_ordine => r.p_id_ordine,
  p_stato_new => r.p_stato_new,
  p_user      => r.p_user
);
```

Questo e' molto meglio di una chiamata totalmente dinamica, perche':

- compila;
- fallisce subito se cambia la firma;
- e' piu' sicuro;
- e' piu' facile da debuggare;
- e' piu' facile da versionare;
- gestisce meglio i tipi.

---

# 15. Cosa generare automaticamente e cosa no

Il generatore dovrebbe essere ambizioso, ma non troppo.

## 15.1 Casi adatti alla generazione automatica

La prima versione dovrebbe gestire bene:

```text
procedure e function in package specification
parametri IN semplici
parametri OUT semplici
parametri IN OUT semplici
return type semplice
logging standard
gestione errore
elapsed time
placeholder assert
placeholder cursore
commenti tecnici
```

Tipi semplici:

```text
NUMBER
VARCHAR2
CHAR
DATE
TIMESTAMP
CLOB
```

## 15.2 Casi da trattare con cautela

Da gestire, ma con attenzione:

```text
overload
default parameter
boolean
date/timestamp
number con precisione/scala
varchar2 con lunghezza
```

## 15.3 Casi da non automatizzare subito

Meglio non cercare di automatizzare nella prima versione:

```text
record PL/SQL
collection
object type complessi
ref cursor
JSON object type
BLOB grossi
procedure con parametri di tipo package record
funzioni pipelined
procedure con commit interno
procedure che fanno DDL
```

Non sono impossibili, ma rischiano di far esplodere la complessita'.

Il generatore puo' comunque produrre una procedura commentata, indicando che e' richiesta personalizzazione manuale.

---

# 16. Overload

Gli overload sono una trappola importante.

Esempio:

```sql
procedure elabora(p_id number);
procedure elabora(p_codice varchar2);
```

Il generatore non puo' produrre due procedure con lo stesso nome.

Possibili nomi generati:

```text
test_elabora_001
test_elabora_002
```

Oppure:

```text
test_elabora_by_number
test_elabora_by_varchar2
```

La prima soluzione e' piu' semplice da generare automaticamente.

La seconda e' piu' leggibile, ma richiede logica piu' sofisticata.

Scelta consigliata per la prima versione:

```text
TEST_<procedure_name>_<overload>
```

E nel commento generato si specifica la firma.

Esempio:

```sql
procedure test_elabora_001 is
  -- Target signature:
  -- PKG_ORDINI.ELABORA(P_ID IN NUMBER)
begin
  ...
end;
```

---

# 17. Default parameter

I parametri con default vanno gestiti con attenzione.

Esempio:

```sql
procedure cerca(
  p_codice in varchar2,
  p_data   in date default sysdate
);
```

Ci sono due possibilita':

```text
A. Il wrapper passa sempre tutti i parametri.
B. Il wrapper genera anche casi in cui alcuni default non vengono passati.
```

Per la prima versione conviene scegliere A.

Quindi il wrapper chiamera':

```sql
pkg_test.cerca(
  p_codice => r.p_codice,
  p_data   => r.p_data
);
```

Testare il comportamento dei default e' utile, ma puo' essere introdotto in una fase successiva.

---

# 18. Boolean

Il tipo `BOOLEAN` in PL/SQL e' comodo, ma non e' direttamente utilizzabile in SQL.

Questo significa che non puoi avere una colonna tabellare di tipo `BOOLEAN` e non puoi selezionare direttamente un valore booleano da un cursore SQL.

Per il framework, conviene rappresentare i boolean come stringhe:

```text
Y / N
TRUE / FALSE
1 / 0
```

E poi convertirli nel wrapper.

Esempio:

```sql
l_flag := case r.p_flag
            when 'Y' then true
            when 'N' then false
            else null
          end;
```

Per loggare un valore booleano:

```sql
tst_log.log_output(
  p_case_id     => l_case_id,
  p_output_name => 'RETURN_VALUE',
  p_output_type => 'BOOLEAN',
  p_value       => case
                     when l_ret then 'TRUE'
                     when not l_ret then 'FALSE'
                     else 'NULL'
                   end
);
```

Attenzione: in PL/SQL non si puo' sempre usare `case when l_ret then` se il boolean puo' essere null senza ragionarci bene. Conviene avere una utility dedicata:

```sql
tst_util.boolean_to_varchar2(l_ret)
```

---

# 19. Assert minimali

Per evitare che il framework diventi solo un lanciatore di procedure, e' importante aggiungere un package di assert minimale.

Esempi:

```sql
tst_assert.eq_number(...);
tst_assert.eq_varchar2(...);
tst_assert.eq_date(...);
tst_assert.is_null(...);
tst_assert.is_not_null(...);
tst_assert.expect_error(...);
tst_assert.query_returns_count(...);
tst_assert.query_returns_value(...);
```

## 19.1 Esempio di assert su return value

```sql
tst_assert.eq_varchar2(
  p_case_id  => l_case_id,
  p_name     => 'RETURN_VALUE',
  p_expected => r.expected_return_value,
  p_actual   => l_ret
);
```

## 19.2 Esempio di assert su stato database

Nel PL/SQL gestionale, spesso il risultato non e' il valore di ritorno, ma lo stato del database dopo la chiamata.

Esempio:

```sql
select stato
into l_actual_status
from ordini
where id_ordine = r.p_id_ordine;

tst_assert.eq_varchar2(
  p_case_id  => l_case_id,
  p_name     => 'STATO_ORDINE',
  p_expected => r.expected_status,
  p_actual   => l_actual_status
);
```

Questa parte e' fondamentale.

La vera utilita' del framework non e' solo dire che la procedura e' stata eseguita, ma verificare che abbia prodotto l'effetto atteso.

---

# 20. Query di verifica post-esecuzione

Una buona pratica e' prevedere nel cursore colonne di expected result.

Esempi:

```text
expected_status
expected_count
expected_error
expected_sqlcode
expected_return_value
```

Dopo la chiamata, il wrapper puo' eseguire query di verifica.

Esempio:

```sql
select count(*)
into l_actual_count
from ordini_log
where id_ordine = r.p_id_ordine;

tst_assert.eq_number(
  p_case_id  => l_case_id,
  p_name     => 'NUMERO_LOG_ORDINE',
  p_expected => r.expected_log_count,
  p_actual   => l_actual_count
);
```

In questo modo il test diventa molto piu' significativo.

---

# 21. Gestione degli errori attesi

Non tutti gli errori sono fallimenti.

Alcuni casi di test devono verificare proprio che una procedura vada in errore.

Esempio:

```text
Cambio stato non ammesso -> atteso ORA-20001
```

Il cursore puo' contenere:

```text
expect_error
expect_sqlcode
```

Esempio:

```sql
select 'ORD_ERR_001' as case_code,
       'Cambio stato non ammesso' as case_description,
       1002 as p_id_ordine,
       'CHIUSO' as p_stato_new,
       'Y' as expect_error,
       -20001 as expect_sqlcode
from dual;
```

Nel blocco exception il framework puo' distinguere:

```text
Errore atteso con SQLCODE corretto       -> PASS
Errore atteso con SQLCODE diverso        -> FAIL
Errore non atteso                        -> FAIL
Nessun errore ma errore atteso           -> FAIL
Nessun errore e nessun errore atteso     -> PASS tecnico
```

Questo e' molto utile per testare validazioni business.

---

# 22. Sicurezza nella generazione

Se il generatore produce codice dinamicamente, bisogna proteggere i nomi oggetto.

Da evitare:

```sql
l_sql := 'create package ' || p_package_name || '_test as ...';
```

senza nessun controllo.

Meglio usare controlli sui nomi e, dove possibile, `DBMS_ASSERT`.

Esempi di aspetti da validare:

```text
owner
package name
procedure name
suffix generato
schema di destinazione
```

Inoltre, conviene limitare la generazione a oggetti realmente presenti nel dizionario dati e accessibili all'utente.

---

# 23. Versionamento

I package `_TEST` generati dovrebbero essere versionati.

Questo perche', dopo la generazione, lo sviluppatore andra' a modificarli:

- popolando il cursore;
- aggiungendo assert;
- aggiungendo query di verifica;
- gestendo casi particolari;
- commentando scenari.

Quindi il flusso ideale potrebbe essere:

```text
1. Genero PKG_ORDINI_TEST.
2. Lo salvo nel repository Git.
3. Lo personalizzo.
4. Lo mantengo come parte del codice di progetto.
5. Se cambia la firma del package sorgente, rigenero o aggiorno consapevolmente.
```

Attenzione: se il generatore sovrascrive sempre il package `_TEST`, rischia di cancellare personalizzazioni manuali.

Meglio prevedere modalita' diverse:

```text
GENERATE_NEW
- genera solo se non esiste.

REGENERATE_FORCE
- sovrascrive tutto.

REGENERATE_TO_FILE
- genera un nuovo file di confronto.

MERGE_HINT
- genera solo sezioni suggerite, da applicare manualmente.
```

Per partire, la cosa piu' semplice e sicura e':

```text
Generare il file .sql e far decidere allo sviluppatore se applicarlo.
```

---

# 24. Output ideale delle run

Dopo un lancio, dovrebbe essere possibile interrogare le run.

Esempio:

```sql
select run_id,
       source_package_name,
       source_object_name,
       status,
       total_cases,
       success_cases,
       failed_cases,
       elapsed_ms
from tst_run
order by run_id desc;
```

Poi i singoli casi:

```sql
select case_code,
       case_description,
       status,
       elapsed_ms,
       sqlcode,
       sqlerrm
from tst_case
where run_id = :run_id
order by case_id;
```

Output e return value:

```sql
select output_name,
       output_type,
       value_varchar2,
       value_number,
       value_date,
       value_timestamp
from tst_case_output
where case_id = :case_id;
```

Assert:

```sql
select assert_name,
       expected_value,
       actual_value,
       status,
       message
from tst_assert
where case_id = :case_id
order by assert_id;
```

Questo rende il framework molto utile anche in contesto AM, perche' puoi lanciare una batteria di casi e poi analizzare le differenze.

---

# 25. Pattern complessivo

Il pattern puo' essere chiamato:

```text
Generated PL/SQL Test Harness Pattern
```

Componenti principali:

```text
Test Wrapper
- package _TEST generato a partire dal target.

Fixture Cursor
- cursore dei casi di test, inizialmente vuoto, poi popolato dallo sviluppatore.

Test Runner
- motore comune per apertura/chiusura run e case.

Test Logger
- log input, output, errori, tempi.

Profiler Adapter
- wrapper verso DBMS_PROFILER / DBMS_HPROF.

Coverage Adapter
- wrapper verso DBMS_PLSQL_CODE_COVERAGE.

Assertion Helper
- package minimale di assert.

Signature Fingerprint
- hash della firma del codice target.
```

---

# 26. Roadmap consigliata

Conviene procedere per step, senza cercare di fare subito tutto.

## Step 1 - Harness base

Generare package `_TEST` con:

```text
una procedura test per ogni subprogram pubblico
cursore vuoto da popolare
loop sui casi
chiamata al target
log input
log output / return value
log errori
elapsed time
PASS/FAIL tecnico
```

Questo gia' darebbe valore concreto.

## Step 2 - Assert minimale

Aggiungere:

```text
expected_error
expected_sqlcode
expected_return_value
assert base
```

In questa fase il framework inizia ad avvicinarsi a un vero sistema di test.

## Step 3 - Signature hash

Aggiungere il controllo di coerenza tra firma sorgente e package `_TEST` generato.

Se la firma cambia, il framework deve evidenziare il problema.

## Step 4 - Coverage

Integrare `DBMS_PLSQL_CODE_COVERAGE`.

Non come default obbligatorio, ma come modalita' opzionale.

## Step 5 - Profiling

Integrare prima misurazioni semplici tramite `SYSTIMESTAMP`, poi eventualmente `DBMS_PROFILER` e `DBMS_HPROF`.

HPROF e' potente, ma piu' laborioso. Non lo metterei come prerequisito della prima versione.

## Step 6 - Dataset tabellari

Solo dopo aver consolidato il cursore statico, aggiungere la possibilita' di leggere casi da tabelle.

Questa evoluzione puo' essere utile per:

- regressioni massive;
- casi AM;
- test alimentati da query reali;
- dataset condivisi tra piu' wrapper.

---

# 27. Criticita' principali

## 27.1 Rischio di creare solo un lanciatore automatico

La critica principale e' questa: il framework rischia di diventare solo un sistema per lanciare procedure e salvare log.

Questo sarebbe comunque utile, ma non sarebbe davvero un sistema di test.

Per evitarlo, bisogna introdurre fin dall'inizio:

```text
1. Esito PASS/FAIL per ogni caso.
2. Input/output tracciati.
3. Sezione assert in ogni wrapper.
```

Anche se gli assert inizialmente sono pochi, la struttura deve esserci.

## 27.2 Complessita' sui tipi PL/SQL

Tipi complessi, record, collection, ref cursor e boolean possono complicare molto il generatore.

Meglio partire dai tipi semplici e classificare gli altri come `MANUAL_COMPLETION_REQUIRED`.

## 27.3 Commit nel codice target

Se il codice target fa commit, il framework non puo' sempre garantire rollback e isolamento.

Questo va dichiarato chiaramente.

## 27.4 Manutenzione dei package generati

I package generati verranno modificati a mano.

Quindi bisogna evitare rigenerazioni distruttive.

## 27.5 Coverage interpretata male

La coverage dice cosa viene eseguito, non se il comportamento e' corretto.

Non deve sostituire gli assert.

---

# 28. Giudizio finale

L'idea e' decisamente valida.

Non la imposterei come alternativa a utPLSQL, ma come framework interno piu' pragmatico e aderente al modo in cui spesso si lavora su PL/SQL gestionale.

L'obiettivo dovrebbe essere:

```text
generare velocemente wrapper testabili;
lanciare procedure e function con dataset controllati;
salvare input, output, errori e performance;
avere un primo livello di PASS/FAIL;
integrare coverage e profiling quando serve.
```

Il punto chiave e':

```text
Non cercare di interpretare dinamicamente qualunque PL/SQL.
Genera codice statico, leggibile e modificabile.
```

Questa scelta rende il framework molto piu' semplice, sicuro e manutenibile.

La versione iniziale dovrebbe essere volutamente limitata, ma solida:

```text
package target semplice
parametri semplici
cursore scaffold
log standard
return value
errori attesi
assert base
signature hash
```

Da li' si puo' evolvere gradualmente.

In un contesto Oracle PL/SQL, soprattutto gestionale, un framework del genere potrebbe diventare molto utile per:

- test tecnici;
- regressioni;
- AM;
- bonifiche;
- validazioni massive;
- analisi performance;
- documentazione implicita degli scenari;
- onboarding di nuovi sviluppatori.

La cosa importante e' non esagerare all'inizio. Meglio un framework piccolo, chiaro e usato davvero, piuttosto che un sistema troppo ambizioso che nessuno mantiene.
