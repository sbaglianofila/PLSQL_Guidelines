create or replace package body tst_log as

  procedure insert_param(
    p_case_id         in number,
    p_param_name      in varchar2,
    p_param_mode      in varchar2,
    p_param_type      in varchar2,
    p_value_varchar2  in varchar2 default null,
    p_value_number    in number default null,
    p_value_date      in date default null,
    p_value_timestamp in timestamp default null,
    p_value_clob      in clob default null
  ) is
    pragma autonomous_transaction;
  begin
    insert into tst_case_param (
      case_id,
      param_name,
      param_mode,
      param_type,
      value_varchar2,
      value_number,
      value_date,
      value_timestamp,
      value_clob
    ) values (
      p_case_id,
      upper(trim(p_param_name)),
      upper(trim(p_param_mode)),
      upper(trim(p_param_type)),
      p_value_varchar2,
      p_value_number,
      p_value_date,
      p_value_timestamp,
      p_value_clob
    );

    commit;
  exception
    when others then
      rollback;
      raise;
  end insert_param;

  procedure insert_output(
    p_case_id         in number,
    p_output_name     in varchar2,
    p_output_type     in varchar2,
    p_value_varchar2  in varchar2 default null,
    p_value_number    in number default null,
    p_value_date      in date default null,
    p_value_timestamp in timestamp default null,
    p_value_clob      in clob default null
  ) is
    pragma autonomous_transaction;
  begin
    insert into tst_case_output (
      case_id,
      output_name,
      output_type,
      value_varchar2,
      value_number,
      value_date,
      value_timestamp,
      value_clob
    ) values (
      p_case_id,
      upper(trim(p_output_name)),
      upper(trim(p_output_type)),
      p_value_varchar2,
      p_value_number,
      p_value_date,
      p_value_timestamp,
      p_value_clob
    );

    commit;
  exception
    when others then
      rollback;
      raise;
  end insert_output;

  procedure message(
    p_run_id  in number default null,
    p_case_id in number default null,
    p_level   in varchar2 default 'INFO',
    p_message in clob,
    p_sqlcode in number default null,
    p_sqlerrm in varchar2 default null
  ) is
    pragma autonomous_transaction;
    l_level varchar2(20);
  begin
    l_level := upper(nvl(trim(p_level), 'INFO'));

    if l_level not in ('DEBUG','INFO','WARN','ERROR') then
      l_level := 'INFO';
    end if;

    insert into tst_log_msg (
      run_id,
      case_id,
      log_level,
      message,
      sqlcode_value,
      sqlerrm_value
    ) values (
      p_run_id,
      p_case_id,
      l_level,
      p_message,
      p_sqlcode,
      p_sqlerrm
    );

    commit;
  exception
    when others then
      rollback;
      raise;
  end message;

  procedure log_param(
    p_case_id    in number,
    p_param_name in varchar2,
    p_param_mode in varchar2,
    p_param_type in varchar2,
    p_value      in varchar2
  ) is
  begin
    insert_param(
      p_case_id        => p_case_id,
      p_param_name     => p_param_name,
      p_param_mode     => p_param_mode,
      p_param_type     => p_param_type,
      p_value_varchar2 => p_value
    );
  end log_param;

  procedure log_param(
    p_case_id    in number,
    p_param_name in varchar2,
    p_param_mode in varchar2,
    p_param_type in varchar2,
    p_value      in number
  ) is
  begin
    insert_param(
      p_case_id      => p_case_id,
      p_param_name   => p_param_name,
      p_param_mode   => p_param_mode,
      p_param_type   => p_param_type,
      p_value_number => p_value
    );
  end log_param;

  procedure log_param(
    p_case_id    in number,
    p_param_name in varchar2,
    p_param_mode in varchar2,
    p_param_type in varchar2,
    p_value      in date
  ) is
  begin
    insert_param(
      p_case_id    => p_case_id,
      p_param_name => p_param_name,
      p_param_mode => p_param_mode,
      p_param_type => p_param_type,
      p_value_date => p_value
    );
  end log_param;

  procedure log_param(
    p_case_id    in number,
    p_param_name in varchar2,
    p_param_mode in varchar2,
    p_param_type in varchar2,
    p_value      in timestamp
  ) is
  begin
    insert_param(
      p_case_id         => p_case_id,
      p_param_name      => p_param_name,
      p_param_mode      => p_param_mode,
      p_param_type      => p_param_type,
      p_value_timestamp => p_value
    );
  end log_param;

  procedure log_param_clob(
    p_case_id    in number,
    p_param_name in varchar2,
    p_param_mode in varchar2,
    p_param_type in varchar2,
    p_value      in clob
  ) is
  begin
    insert_param(
      p_case_id        => p_case_id,
      p_param_name     => p_param_name,
      p_param_mode     => p_param_mode,
      p_param_type     => p_param_type,
      p_value_varchar2 => tst_util.clob_preview(p_value),
      p_value_clob     => p_value
    );
  end log_param_clob;

  procedure log_output(
    p_case_id     in number,
    p_output_name in varchar2,
    p_output_type in varchar2,
    p_value       in varchar2
  ) is
  begin
    insert_output(
      p_case_id        => p_case_id,
      p_output_name    => p_output_name,
      p_output_type    => p_output_type,
      p_value_varchar2 => p_value
    );
  end log_output;

  procedure log_output(
    p_case_id     in number,
    p_output_name in varchar2,
    p_output_type in varchar2,
    p_value       in number
  ) is
  begin
    insert_output(
      p_case_id      => p_case_id,
      p_output_name  => p_output_name,
      p_output_type  => p_output_type,
      p_value_number => p_value
    );
  end log_output;

  procedure log_output(
    p_case_id     in number,
    p_output_name in varchar2,
    p_output_type in varchar2,
    p_value       in date
  ) is
  begin
    insert_output(
      p_case_id    => p_case_id,
      p_output_name=> p_output_name,
      p_output_type=> p_output_type,
      p_value_date => p_value
    );
  end log_output;

  procedure log_output(
    p_case_id     in number,
    p_output_name in varchar2,
    p_output_type in varchar2,
    p_value       in timestamp
  ) is
  begin
    insert_output(
      p_case_id         => p_case_id,
      p_output_name     => p_output_name,
      p_output_type     => p_output_type,
      p_value_timestamp => p_value
    );
  end log_output;

  procedure log_output_clob(
    p_case_id     in number,
    p_output_name in varchar2,
    p_output_type in varchar2,
    p_value       in clob
  ) is
  begin
    insert_output(
      p_case_id        => p_case_id,
      p_output_name    => p_output_name,
      p_output_type    => p_output_type,
      p_value_varchar2 => tst_util.clob_preview(p_value),
      p_value_clob     => p_value
    );
  end log_output_clob;

  procedure log_return_value(
    p_case_id    in number,
    p_value_type in varchar2,
    p_value      in varchar2
  ) is
  begin
    log_output(p_case_id, 'RETURN_VALUE', p_value_type, p_value);
  end log_return_value;

  procedure log_return_value(
    p_case_id    in number,
    p_value_type in varchar2,
    p_value      in number
  ) is
  begin
    log_output(p_case_id, 'RETURN_VALUE', p_value_type, p_value);
  end log_return_value;

  procedure log_return_value(
    p_case_id    in number,
    p_value_type in varchar2,
    p_value      in date
  ) is
  begin
    log_output(p_case_id, 'RETURN_VALUE', p_value_type, p_value);
  end log_return_value;

  procedure log_return_value(
    p_case_id    in number,
    p_value_type in varchar2,
    p_value      in timestamp
  ) is
  begin
    log_output(p_case_id, 'RETURN_VALUE', p_value_type, p_value);
  end log_return_value;

  procedure log_return_value_clob(
    p_case_id    in number,
    p_value_type in varchar2,
    p_value      in clob
  ) is
  begin
    log_output_clob(p_case_id, 'RETURN_VALUE', p_value_type, p_value);
  end log_return_value_clob;

end tst_log;
/
show errors package body tst_log
