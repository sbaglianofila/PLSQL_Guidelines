create or replace package tst_log as

  procedure message(
    p_run_id  in number default null,
    p_case_id in number default null,
    p_level   in varchar2 default 'INFO',
    p_message in clob,
    p_sqlcode in number default null,
    p_sqlerrm in varchar2 default null
  );

  procedure log_param(
    p_case_id    in number,
    p_param_name in varchar2,
    p_param_mode in varchar2,
    p_param_type in varchar2,
    p_value      in varchar2
  );

  procedure log_param(
    p_case_id    in number,
    p_param_name in varchar2,
    p_param_mode in varchar2,
    p_param_type in varchar2,
    p_value      in number
  );

  procedure log_param(
    p_case_id    in number,
    p_param_name in varchar2,
    p_param_mode in varchar2,
    p_param_type in varchar2,
    p_value      in date
  );

  procedure log_param(
    p_case_id    in number,
    p_param_name in varchar2,
    p_param_mode in varchar2,
    p_param_type in varchar2,
    p_value      in timestamp
  );

  procedure log_param_clob(
    p_case_id    in number,
    p_param_name in varchar2,
    p_param_mode in varchar2,
    p_param_type in varchar2,
    p_value      in clob
  );

  procedure log_output(
    p_case_id     in number,
    p_output_name in varchar2,
    p_output_type in varchar2,
    p_value       in varchar2
  );

  procedure log_output(
    p_case_id     in number,
    p_output_name in varchar2,
    p_output_type in varchar2,
    p_value       in number
  );

  procedure log_output(
    p_case_id     in number,
    p_output_name in varchar2,
    p_output_type in varchar2,
    p_value       in date
  );

  procedure log_output(
    p_case_id     in number,
    p_output_name in varchar2,
    p_output_type in varchar2,
    p_value       in timestamp
  );

  procedure log_output_clob(
    p_case_id     in number,
    p_output_name in varchar2,
    p_output_type in varchar2,
    p_value       in clob
  );

  procedure log_return_value(
    p_case_id    in number,
    p_value_type in varchar2,
    p_value      in varchar2
  );

  procedure log_return_value(
    p_case_id    in number,
    p_value_type in varchar2,
    p_value      in number
  );

  procedure log_return_value(
    p_case_id    in number,
    p_value_type in varchar2,
    p_value      in date
  );

  procedure log_return_value(
    p_case_id    in number,
    p_value_type in varchar2,
    p_value      in timestamp
  );

  procedure log_return_value_clob(
    p_case_id    in number,
    p_value_type in varchar2,
    p_value      in clob
  );

end tst_log;
/
show errors package tst_log
