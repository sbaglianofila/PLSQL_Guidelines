set serveroutput on size unlimited
set define off

prompt Generating demo wrapper with DBMS_PROFILER enabled...

declare
  l_generated_id number;
begin
  l_generated_id := tst_generator.generate_package_test(
    p_owner               => user,
    p_package_name        => 'DEMO_PKG_ORDINI',
    p_test_package_name   => 'DEMO_PKG_ORDINI_PROF_TEST',
    p_output_mode         => 'TABLE',
    p_include_unsupported => 'Y',
    p_transaction_mode    => 'ROLLBACK',
    p_profile_mode        => 'PROFILER',
    p_note                => 'Demo wrapper generated with DBMS_PROFILER enabled by TST Harness v0.3.'
  );

  dbms_output.put_line('Generated id = ' || l_generated_id);
  dbms_output.put_line('Print with: exec tst_generator.print_generated_ddl(' || l_generated_id || ');');
end;
/

commit;
