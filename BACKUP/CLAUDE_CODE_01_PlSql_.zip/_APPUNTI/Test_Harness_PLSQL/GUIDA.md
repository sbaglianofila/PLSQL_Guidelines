# Guida completa all'utilizzo del PL/SQL Test Harness

## Versione documento

Documento riferito al progetto **PL/SQL Test Harness v0.2**, composto da:

- runtime v0.1;
- generatore v0.2;
- demo target;
- demo wrapper `_TEST`;
- script di installazione.

Questa guida è pensata per chi apre il progetto senza aver seguito la fase di ideazione. L'obiettivo è spiegare cosa fa il tool, cosa non fa, come installarlo, come usarlo, come leggere gli esiti e come estenderlo in modo ordinato.

---

# 1. Scopo del tool

Il **PL/SQL Test Harness** è un tool leggero per facilitare la creazione, l'esecuzione e la tracciatura di test tecnici su package Oracle PL/SQL.

Non nasce come alternativa completa a framework come `utPLSQL`. Il suo scopo è più pragmatico:

- generare wrapper PL/SQL di test a partire dalle firme dei package applicativi;
- creare automaticamente una base di codice modificabile a mano;
- standardizzare il modo in cui procedure e function vengono lanciate;
- loggare input, output, return value, errori ed esiti;
- gestire un primo livello di assert;
- mantenere uno storico interrogabile delle esecuzioni;
- aiutare nelle regressioni tecniche, nelle attività AM, nei test manuali ripetibili e nelle verifiche post-modifica.

La filosofia è:

```text
Generatore dinamico, wrapper statici.
```

Questo significa che il tool legge il dizionario dati Oracle, genera codice PL/SQL statico, ma non prova a eseguire dinamicamente qualunque procedura passando parametri da tabelle generiche. Questa scelta rende il risultato più leggibile, versionabile, debuggabile e sicuro.

---

# 2. Cosa risolve

In molti progetti PL/SQL i test tecnici vengono eseguiti con blocchi anonimi sparsi, script locali o query modificate al volo.

Esempio classico:

```sql
begin
  pkg_ordini.cambia_stato_ordine(
    p_id_ordine => 1001,
    p_stato_new => 'VALIDATO',
    p_user      => 'FABIO'
  );
end;
/
```

Questo approccio funziona, ma presenta diversi problemi:

- gli script non sono sempre versionati;
- non esiste uno storico delle esecuzioni;
- non viene sempre tracciato l'input usato;
- gli errori vengono persi o copiati a mano;
- è difficile ripetere la stessa batteria di casi;
- non c'è un formato comune per leggere gli esiti;
- i test dipendono molto da chi li lancia.

Con il Test Harness l'obiettivo diventa:

```sql
begin
  pkg_ordini_test.test_cambia_stato_ordine;
end;
/
```

Il wrapper `_TEST` si occupa di:

- aprire una run;
- aprire un case;
- leggere gli input da un cursore;
- loggare i parametri;
- chiamare il codice reale;
- loggare output e return value;
- eseguire assert;
- gestire errori attesi e non attesi;
- chiudere il case;
- chiudere la run;
- rendere tutto consultabile su tabelle.

---

# 3. Cosa non è

È importante non fraintendere il perimetro del tool.

Il Test Harness non è, almeno in questa versione:

- un framework completo di unit test;
- un sostituto diretto di `utPLSQL`;
- un sistema di CI/CD;
- un generatore perfetto per qualunque tipo PL/SQL;
- un runner dinamico universale;
- uno strumento che garantisce rollback se il codice target fa `COMMIT` interno;
- un sistema che interpreta automaticamente il risultato business corretto.

La parte di verifica resta in mano allo sviluppatore, tramite gli assert da aggiungere o personalizzare nel wrapper generato.

Questo non è un limite grave. Anzi, è una scelta voluta. Nei contesti gestionali Oracle è spesso più utile avere uno strumento semplice, leggibile e adottabile, piuttosto che un framework molto sofisticato che nessuno mantiene.

---

# 4. Componenti principali

Il progetto è composto da due blocchi.

## 4.1 Runtime v0.1

Il runtime contiene le tabelle e i package comuni usati dai wrapper di test.

File principali:

```text
00_install_runtime.sql
01_tst_tables.sql
02_tst_util.pks
03_tst_util.pkb
04_tst_log.pks
05_tst_log.pkb
06_tst_assert.pks
07_tst_assert.pkb
08_tst_runner.pks
09_tst_runner.pkb
90_demo_target.sql
91_demo_test_wrapper.sql
README.md
```

Il runtime fornisce:

- modello dati per run, case, parametri, output, assert e log;
- package di logging;
- package di assert;
- package di gestione run/case;
- utility comuni;
- demo manuale.

## 4.2 Generatore v0.2

Il generatore legge il dizionario dati Oracle e produce il DDL del package `_TEST`.

File principali:

```text
00_install_generator.sql
10_tst_signature.pks
11_tst_signature.pkb
12_tst_generator.pks
13_tst_generator.pkb
14_tst_generator_views.sql
20_demo_generate_wrapper.sql
README_GENERATOR.md
```

Il generatore fornisce:

- calcolo della firma pubblica di un package;
- hash della firma;
- generazione del package di test;
- salvataggio del DDL generato in tabella;
- stampa del DDL tramite `DBMS_OUTPUT`;
- vista per individuare package target con firma cambiata.

## 4.3 Installazione completa

Nel pacchetto completo è presente anche:

```text
00_install_all.sql
```

Questo script installa runtime e generatore in sequenza.

---

# 5. Architettura logica

L'architettura è divisa in tre livelli.

```text
+------------------------------+
| Package applicativo target   |
| Esempio: PKG_ORDINI          |
+------------------------------+
              |
              | letto da ALL_PROCEDURES / ALL_ARGUMENTS
              v
+------------------------------+
| TST_GENERATOR                |
| Genera PKG_ORDINI_TEST       |
+------------------------------+
              |
              | produce codice statico
              v
+------------------------------+
| Package _TEST                |
| Esempio: PKG_ORDINI_TEST     |
+------------------------------+
              |
              | usa API comuni
              v
+------------------------------+
| Runtime TST_*                |
| Runner, log, assert, tabelle |
+------------------------------+
```

Il package `_TEST` non deve contenere tutto il framework. Deve essere sottile e leggibile.

Il runtime centralizza:

- apertura e chiusura run;
- apertura e chiusura case;
- gestione degli errori;
- logging parametri;
- logging output;
- logging return value;
- assert;
- messaggi tecnici.

---

# 6. Installazione

## 6.1 Prerequisiti

La versione è pensata per Oracle Database 19c o superiore.

Sono richiesti almeno:

- possibilità di creare tabelle;
- possibilità di creare package;
- possibilità di creare viste;
- accesso alle viste dizionario `ALL_PROCEDURES` e `ALL_ARGUMENTS`;
- `DBMS_CRYPTO` disponibile per il calcolo dell'hash della firma;
- `DBMS_OUTPUT` per stampare il DDL generato.

In base allo schema di installazione potrebbero servire privilegi espliciti, ad esempio:

```sql
grant execute on sys.dbms_crypto to <schema_tool>;
```

La concessione dei privilegi dipende dalle policy del database. Non va data alla leggera in produzione.

## 6.2 Installare tutto

Da SQL*Plus o SQLcl, posizionarsi nella cartella del progetto ed eseguire:

```sql
@00_install_all.sql
```

Lo script installa prima il runtime e poi il generatore.

## 6.3 Installare solo il runtime

```sql
@00_install_runtime.sql
```

Usare questa modalità se si vuole installare solo il motore comune, senza generatore.

## 6.4 Installare solo il generatore

```sql
@00_install_generator.sql
```

Questa modalità presuppone che il runtime sia già stato installato.

## 6.5 Nota sugli oggetti già esistenti

Gli script della v0.2 sono volutamente semplici. Se gli oggetti esistono già, la creazione può andare in errore.

Per un uso reale conviene aggiungere in futuro:

- script di drop controllato;
- script di upgrade;
- versionamento schema;
- controllo oggetti già presenti;
- script di reinstallazione per ambienti dev.

Nella prima versione, però, la semplicità aiuta a capire meglio cosa viene creato.

---

# 7. Modello dati

## 7.1 TST_RUN

`TST_RUN` è la testata della run.

Ogni esecuzione di una procedura `test_*` apre una run.

Campi principali:

| Campo | Significato |
|---|---|
| `RUN_ID` | Identificativo della run. |
| `SOURCE_OWNER` | Owner del package target. |
| `SOURCE_PACKAGE_NAME` | Nome del package applicativo testato. |
| `SOURCE_PROGRAM_NAME` | Nome della procedure/function testata. |
| `GENERATED_PACKAGE_NAME` | Nome del package `_TEST`. |
| `STARTED_AT` | Timestamp di inizio run. |
| `ENDED_AT` | Timestamp di fine run. |
| `ELAPSED_MS` | Durata in millisecondi. |
| `STATUS` | Stato della run. |
| `TOTAL_CASES` | Numero totale dei casi. |
| `SUCCESS_CASES` | Numero casi passati. |
| `FAILED_CASES` | Numero casi falliti. |
| `PROFILE_MODE` | Modalità profiler, attualmente predisposta. |
| `COVERAGE_MODE` | Modalità coverage, attualmente predisposta. |
| `TRANSACTION_MODE` | Modalità transazionale dichiarata. |
| `NOTE` | Note libere. |

Stati possibili:

```text
RUNNING
SUCCESS
FAILED
ERROR
```

## 7.2 TST_CASE

`TST_CASE` contiene i singoli casi di test.

Una run può contenere molti case.

Campi principali:

| Campo | Significato |
|---|---|
| `CASE_ID` | Identificativo del case. |
| `RUN_ID` | Run di appartenenza. |
| `CASE_CODE` | Codice funzionale/tecnico del caso. |
| `CASE_DESCRIPTION` | Descrizione leggibile. |
| `STATUS` | Stato del caso. |
| `EXPECT_ERROR` | Indica se ci si aspetta un errore. |
| `EXPECT_SQLCODE` | SQLCODE atteso, se previsto. |
| `SQLCODE_VALUE` | SQLCODE realmente ottenuto. |
| `SQLERRM_VALUE` | Messaggio errore reale. |
| `ERROR_STACK` | Stack errore. |
| `ERROR_BACKTRACE` | Backtrace PL/SQL. |

Stati possibili:

```text
RUNNING
PASS
FAIL
ERROR
SKIPPED
```

Interpretazione pratica:

| Stato | Significato |
|---|---|
| `PASS` | Il caso è andato a buon fine e non ha assert falliti. |
| `FAIL` | Il caso è stato eseguito, ma il risultato non è quello atteso. |
| `ERROR` | Errore inatteso durante l'esecuzione. |
| `SKIPPED` | Caso non eseguito, di solito perché richiede completamento manuale. |
| `RUNNING` | Stato temporaneo durante l'esecuzione. |

## 7.3 TST_CASE_PARAM

`TST_CASE_PARAM` salva i parametri di input.

Viene usata anche per salvare il valore iniziale dei parametri `IN OUT`.

Campi principali:

| Campo | Significato |
|---|---|
| `PARAM_ID` | Identificativo del parametro loggato. |
| `CASE_ID` | Case di riferimento. |
| `PARAM_NAME` | Nome parametro. |
| `PARAM_MODE` | `IN`, `OUT`, `IN OUT`, `RETURN`. |
| `PARAM_TYPE` | Tipo dati dichiarato/logico. |
| `VALUE_VARCHAR2` | Valore testuale. |
| `VALUE_NUMBER` | Valore numerico. |
| `VALUE_DATE` | Valore data. |
| `VALUE_TIMESTAMP` | Valore timestamp. |
| `VALUE_CLOB` | Valore CLOB. |

## 7.4 TST_CASE_OUTPUT

`TST_CASE_OUTPUT` salva output, parametri `OUT`, valori finali degli `IN OUT` e return value.

Campi principali:

| Campo | Significato |
|---|---|
| `OUTPUT_ID` | Identificativo output. |
| `CASE_ID` | Case di riferimento. |
| `OUTPUT_NAME` | Nome output. |
| `OUTPUT_TYPE` | Tipo dati. |
| `VALUE_*` | Valore salvato sulla colonna coerente col tipo. |

Esempi di `OUTPUT_NAME`:

```text
RETURN_VALUE
P_ESITO
P_IMPORTO
```

## 7.5 TST_ASSERT_RESULT

`TST_ASSERT_RESULT` salva gli assert.

Campi principali:

| Campo | Significato |
|---|---|
| `ASSERT_ID` | Identificativo assert. |
| `CASE_ID` | Case di riferimento. |
| `ASSERT_NAME` | Nome del controllo. |
| `EXPECTED_VALUE` | Valore atteso. |
| `ACTUAL_VALUE` | Valore reale. |
| `STATUS` | `PASS` oppure `FAIL`. |
| `MESSAGE` | Messaggio opzionale. |

## 7.6 TST_LOG_MSG

`TST_LOG_MSG` contiene messaggi tecnici liberi.

Può essere usata per tracciare passaggi intermedi, warning o dettagli diagnostici.

Livelli previsti:

```text
DEBUG
INFO
WARN
ERROR
```

## 7.7 TST_GENERATED_OBJECT

`TST_GENERATED_OBJECT` salva i DDL generati dal generatore.

Campi principali:

| Campo | Significato |
|---|---|
| `GENERATED_ID` | Identificativo generazione. |
| `SOURCE_OWNER` | Owner del package target. |
| `SOURCE_PACKAGE_NAME` | Package target. |
| `GENERATED_PACKAGE_NAME` | Package `_TEST` generato. |
| `GENERATED_AT` | Timestamp generazione. |
| `SOURCE_SIGNATURE_HASH` | Hash della firma sorgente. |
| `GENERATION_STATUS` | Stato generazione. |
| `GENERATED_DDL` | Codice DDL generato. |
| `NOTE` | Note libere. |

---

# 8. Package runtime

## 8.1 TST_RUNNER

`TST_RUNNER` gestisce run e case.

API principali:

```sql
function start_run(...) return number;
function start_case(...) return number;
procedure end_case_success(...);
procedure end_case_error(...);
procedure skip_case(...);
procedure end_run_success(...);
procedure end_run_error(...);
```

### start_run

Apre una nuova run.

Esempio:

```sql
l_run_id := tst_runner.start_run(
  p_owner                  => user,
  p_package_name           => 'PKG_ORDINI',
  p_program_name           => 'CAMBIA_STATO_ORDINE',
  p_generated_package_name => 'PKG_ORDINI_TEST',
  p_transaction_mode       => 'ROLLBACK',
  p_note                   => 'Test cambio stato ordine'
);
```

### start_case

Apre un caso all'interno della run.

```sql
l_case_id := tst_runner.start_case(
  p_run_id           => l_run_id,
  p_case_code        => r.case_code,
  p_case_description => r.case_description,
  p_expect_error     => r.expect_error,
  p_expect_sqlcode   => r.expect_sqlcode
);
```

### end_case_success

Chiude positivamente un caso.

```sql
tst_runner.end_case_success(l_case_id);
```

Attenzione: il metodo considera anche eventuali assert falliti. Quindi un caso può terminare come `FAIL` anche se la chiamata PL/SQL non ha sollevato errori.

### end_case_error

Chiude un caso con errore.

```sql
tst_runner.end_case_error(
  p_case_id     => l_case_id,
  p_sqlcode     => sqlcode,
  p_sqlerrm     => sqlerrm,
  p_error_stack => dbms_utility.format_error_stack,
  p_backtrace   => dbms_utility.format_error_backtrace
);
```

Il runner distingue gli errori attesi da quelli inattesi usando `EXPECT_ERROR` e `EXPECT_SQLCODE` salvati sul case.

## 8.2 TST_LOG

`TST_LOG` salva parametri, output, return value e messaggi tecnici.

### Loggare un parametro

```sql
tst_log.log_param(
  p_case_id    => l_case_id,
  p_param_name => 'P_ID_ORDINE',
  p_param_mode => 'IN',
  p_param_type => 'NUMBER',
  p_value      => r.p_id_ordine
);
```

Sono presenti overload per:

- `VARCHAR2`;
- `NUMBER`;
- `DATE`;
- `TIMESTAMP`;
- `CLOB`, tramite procedura dedicata.

Per CLOB:

```sql
tst_log.log_param_clob(
  p_case_id    => l_case_id,
  p_param_name => 'P_XML',
  p_param_mode => 'IN',
  p_param_type => 'CLOB',
  p_value      => r.p_xml
);
```

### Loggare un output

```sql
tst_log.log_output(
  p_case_id     => l_case_id,
  p_output_name => 'P_ESITO',
  p_output_type => 'VARCHAR2',
  p_value       => l_esito
);
```

### Loggare un return value

```sql
tst_log.log_return_value(
  p_case_id    => l_case_id,
  p_value_type => 'VARCHAR2',
  p_value      => l_return_value
);
```

Il nome dell'output sarà convenzionalmente `RETURN_VALUE`.

### Loggare un messaggio tecnico

```sql
tst_log.message(
  p_run_id  => l_run_id,
  p_case_id => l_case_id,
  p_level   => 'INFO',
  p_message => 'Inizio verifica stato ordine'
);
```

Il logging usa autonomous transaction. Questo significa che i log restano salvati anche se il test fa rollback.

## 8.3 TST_ASSERT

`TST_ASSERT` fornisce assert minimi.

API principali:

```sql
tst_assert.eq_varchar2(...);
tst_assert.eq_number(...);
tst_assert.eq_date(...);
tst_assert.eq_timestamp(...);
tst_assert.is_null(...);
tst_assert.is_not_null(...);
tst_assert.assert_true(...);
tst_assert.pass(...);
tst_assert.fail(...);
```

### Assert su valore VARCHAR2

```sql
tst_assert.eq_varchar2(
  p_case_id  => l_case_id,
  p_name     => 'STATO_ORDINE',
  p_expected => r.expected_status,
  p_actual   => l_actual_status
);
```

### Assert su valore NUMBER

```sql
tst_assert.eq_number(
  p_case_id   => l_case_id,
  p_name      => 'NUMERO_RIGHE_LOG',
  p_expected  => 1,
  p_actual    => l_count,
  p_tolerance => 0
);
```

### Assert su condizione booleana

```sql
tst_assert.assert_true(
  p_case_id    => l_case_id,
  p_name       => 'ORDINE_ESISTENTE',
  p_condition  => l_count = 1,
  p_message    => 'L ordine dovrebbe esistere dopo la procedura'
);
```

### Fallimento manuale

```sql
tst_assert.fail(
  p_case_id  => l_case_id,
  p_name     => 'CONTROLLO_CUSTOM',
  p_message  => 'Condizione business non rispettata',
  p_expected => 'VALIDATO',
  p_actual   => l_actual_status
);
```

## 8.4 TST_UTIL

`TST_UTIL` contiene utility comuni, usate soprattutto dal generatore e dai wrapper.

Esempi tipici:

- conversione boolean verso stringa;
- conversione flag verso boolean;
- normalizzazione stringhe;
- gestione valori testuali.

Per esempio, il generatore usa `TST_UTIL.FLAG_TO_BOOLEAN` per trattare parametri `BOOLEAN` rappresentati nel cursore come stringhe.

---

# 9. Package generatore

## 9.1 TST_SIGNATURE

`TST_SIGNATURE` calcola la firma pubblica di un package.

API principali:

```sql
function get_signature_text(...) return clob;
function get_signature_hash(...) return varchar2;
function has_signature_changed(...) return varchar2;
function simple_type_category(...) return varchar2;
function is_simple_supported(...) return varchar2;
```

### Ottenere il testo firma

```sql
select tst_signature.get_signature_text(
         p_owner        => user,
         p_package_name => 'DEMO_PKG_ORDINI'
       ) as signature_text
from dual;
```

### Ottenere l'hash firma

```sql
select tst_signature.get_signature_hash(
         p_owner        => user,
         p_package_name => 'DEMO_PKG_ORDINI'
       ) as signature_hash
from dual;
```

L'hash serve a capire se il package target è cambiato rispetto al momento in cui è stato generato il wrapper `_TEST`.

## 9.2 TST_GENERATOR

`TST_GENERATOR` genera il codice del package `_TEST`.

API principali:

```sql
function default_test_package_name(...) return varchar2;
function generate_package_test_ddl(...) return clob;
function generate_package_test(...) return number;
procedure print_generated_ddl(...);
```

### Nome default del package test

```sql
select tst_generator.default_test_package_name('PKG_ORDINI')
from dual;
```

Risultato atteso:

```text
PKG_ORDINI_TEST
```

### Generare DDL come CLOB

```sql
declare
  l_ddl clob;
begin
  l_ddl := tst_generator.generate_package_test_ddl(
    p_owner               => user,
    p_package_name        => 'DEMO_PKG_ORDINI',
    p_test_package_name   => 'DEMO_PKG_ORDINI_GEN_TEST',
    p_include_unsupported => 'Y',
    p_transaction_mode    => 'ROLLBACK'
  );

  dbms_output.put_line(dbms_lob.substr(l_ddl, 32000, 1));
end;
/
```

### Generare e salvare in tabella

Questa è la modalità consigliata.

```sql
declare
  l_generated_id number;
begin
  l_generated_id := tst_generator.generate_package_test(
    p_owner               => user,
    p_package_name        => 'DEMO_PKG_ORDINI',
    p_test_package_name   => 'DEMO_PKG_ORDINI_GEN_TEST',
    p_output_mode         => 'TABLE',
    p_include_unsupported => 'Y',
    p_transaction_mode    => 'ROLLBACK',
    p_note                => 'Prima generazione wrapper demo'
  );

  dbms_output.put_line('Generated id = ' || l_generated_id);
end;
/

commit;
```

### Stampare il DDL generato

```sql
set serveroutput on size unlimited
exec tst_generator.print_generated_ddl(<GENERATED_ID>);
```

Sostituire `<GENERATED_ID>` con il valore restituito dalla generazione.

---

# 10. Flusso operativo consigliato

Il flusso completo consigliato è questo.

## 10.1 Installare il tool

```sql
@00_install_all.sql
```

## 10.2 Generare il wrapper

```sql
declare
  l_generated_id number;
begin
  l_generated_id := tst_generator.generate_package_test(
    p_owner               => 'APP',
    p_package_name        => 'PKG_ORDINI',
    p_test_package_name   => 'PKG_ORDINI_TEST',
    p_output_mode         => 'TABLE',
    p_include_unsupported => 'Y',
    p_transaction_mode    => 'ROLLBACK',
    p_note                => 'Generazione iniziale test package'
  );

  dbms_output.put_line('Generated id = ' || l_generated_id);
end;
/

commit;
```

## 10.3 Recuperare il DDL

```sql
select generated_id,
       source_owner,
       source_package_name,
       generated_package_name,
       source_signature_hash,
       generation_status,
       generated_at
from tst_generated_object
order by generated_id desc;
```

Poi:

```sql
set serveroutput on size unlimited
exec tst_generator.print_generated_ddl(123);
```

In alternativa, da SQL Developer si può aprire il CLOB `GENERATED_DDL` direttamente dalla griglia dati.

## 10.4 Salvare il DDL nel repository

Il DDL generato non dovrebbe restare solo in tabella.

Il flusso consigliato è:

```text
1. Genero il DDL.
2. Lo salvo come file .sql.
3. Lo metto su Git.
4. Lo compilo in ambiente dev.
5. Lo personalizzo.
6. Versiono le modifiche.
```

Esempio nome file:

```text
pkg_ordini_test.sql
```

## 10.5 Compilare il wrapper

Dopo aver salvato il DDL generato in un file:

```sql
@pkg_ordini_test.sql
```

Controllare eventuali errori:

```sql
show errors package pkg_ordini_test
show errors package body pkg_ordini_test
```

Oppure:

```sql
select name,
       type,
       line,
       position,
       text
from user_errors
where name = 'PKG_ORDINI_TEST'
order by sequence;
```

## 10.6 Popolare il cursore dei casi

Il generatore produce cursori vuoti o di scaffolding.

Esempio iniziale:

```sql
cursor c_test is
  select cast(null as varchar2(100))  as case_code,
         cast(null as varchar2(4000)) as case_description,
         cast(null as number)         as p_id_ordine,
         cast(null as varchar2(30))   as p_stato_new,
         cast(null as varchar2(100))  as p_user,
         cast('N' as varchar2(1))     as expect_error,
         cast(null as number)         as expect_sqlcode
  from dual
  where 1 = 0;
```

Lo sviluppatore deve modificarlo:

```sql
cursor c_test is
  select 'ORD_OK_001' as case_code,
         'Cambio stato valido' as case_description,
         1001 as p_id_ordine,
         'VALIDATO' as p_stato_new,
         'FABIO' as p_user,
         'N' as expect_error,
         cast(null as number) as expect_sqlcode,
         'VALIDATO' as expected_status
  from dual
  union all
  select 'ORD_ERR_001',
         'Cambio stato non ammesso',
         1002,
         'VALIDATO',
         'FABIO',
         'Y',
         -20001,
         cast(null as varchar2(30))
  from dual;
```

## 10.7 Aggiungere assert specifici

Dopo la chiamata al target, aggiungere controlli reali.

Esempio:

```sql
select stato
into l_actual_status
from ordini
where id_ordine = r.p_id_ordine;

tst_assert.eq_varchar2(
  p_case_id  => l_case_id,
  p_name     => 'STATO_ORDINE',
  p_expected => r.expected_status,
  p_actual   => l_actual_status
);
```

## 10.8 Lanciare il test

```sql
begin
  pkg_ordini_test.test_cambia_stato_ordine;
end;
/
```

## 10.9 Consultare gli esiti

```sql
select *
from tst_v_run_summary
order by run_id desc;
```

```sql
select *
from tst_v_case_detail
where run_id = :run_id
order by case_id;
```

```sql
select *
from tst_v_assert_failure
where run_id = :run_id
order by assert_id;
```

---

# 11. Esempio completo con package demo

Il progetto contiene una demo già pronta.

## 11.1 Installare oggetto demo e wrapper demo

```sql
@90_demo_target.sql
@91_demo_test_wrapper.sql
```

## 11.2 Eseguire la demo

```sql
begin
  demo_pkg_ordini_test.test_cambia_stato_ordine;
  demo_pkg_ordini_test.test_normalizza_codice;
end;
/
```

## 11.3 Leggere riepilogo run

```sql
select run_id,
       source_package_name,
       source_program_name,
       status,
       total_cases,
       success_cases,
       failed_cases,
       elapsed_ms
from tst_v_run_summary
order by run_id desc;
```

## 11.4 Leggere dettaglio case

```sql
select case_code,
       case_description,
       status,
       expect_error,
       expect_sqlcode,
       sqlcode_value,
       sqlerrm_value,
       elapsed_ms
from tst_v_case_detail
where run_id = :run_id
order by case_id;
```

## 11.5 Leggere assert falliti

```sql
select case_code,
       assert_name,
       expected_value,
       actual_value,
       message
from tst_v_assert_failure
where run_id = :run_id
order by assert_id;
```

## 11.6 Leggere parametri usati

```sql
select p.param_name,
       p.param_mode,
       p.param_type,
       p.value_varchar2,
       p.value_number,
       p.value_date,
       p.value_timestamp,
       dbms_lob.substr(p.value_clob, 4000, 1) as value_clob
from tst_case_param p
where p.case_id = :case_id
order by p.param_id;
```

## 11.7 Leggere output e return value

```sql
select o.output_name,
       o.output_type,
       o.value_varchar2,
       o.value_number,
       o.value_date,
       o.value_timestamp,
       dbms_lob.substr(o.value_clob, 4000, 1) as value_clob
from tst_case_output o
where o.case_id = :case_id
order by o.output_id;
```

---

# 12. Gestione function

Per le function il wrapper generato deve:

1. dichiarare una variabile locale per il valore di ritorno;
2. chiamare la function;
3. loggare il return value;
4. confrontarlo eventualmente con un valore atteso.

Esempio function target:

```sql
function normalizza_codice(
  p_codice in varchar2
) return varchar2;
```

Esempio wrapper:

```sql
l_return_value varchar2(4000);
```

Chiamata:

```sql
l_return_value := pkg_articoli.normalizza_codice(
  p_codice => r.p_codice
);
```

Logging:

```sql
tst_log.log_return_value(
  p_case_id    => l_case_id,
  p_value_type => 'VARCHAR2',
  p_value      => l_return_value
);
```

Assert:

```sql
tst_assert.eq_varchar2(
  p_case_id  => l_case_id,
  p_name     => 'RETURN_VALUE',
  p_expected => r.expected_return_value,
  p_actual   => l_return_value
);
```

Nel cursore conviene quindi aggiungere una colonna:

```sql
expected_return_value
```

---

# 13. Gestione procedure

Per le procedure il wrapper deve concentrarsi sugli effetti prodotti.

Esempio target:

```sql
procedure cambia_stato_ordine(
  p_id_ordine in number,
  p_stato_new in varchar2,
  p_user      in varchar2
);
```

La procedura non restituisce direttamente un valore. Quindi il test deve verificare il database dopo la chiamata.

Esempio:

```sql
pkg_ordini.cambia_stato_ordine(
  p_id_ordine => r.p_id_ordine,
  p_stato_new => r.p_stato_new,
  p_user      => r.p_user
);

select stato
into l_actual_status
from ordini
where id_ordine = r.p_id_ordine;

tst_assert.eq_varchar2(
  p_case_id  => l_case_id,
  p_name     => 'STATO_ORDINE',
  p_expected => r.expected_status,
  p_actual   => l_actual_status
);
```

Questo è un punto importante: per il PL/SQL gestionale spesso il risultato corretto non è un return value, ma lo stato finale dei dati.

---

# 14. Parametri IN, OUT e IN OUT

## 14.1 Parametri IN

I parametri `IN` vengono letti direttamente dal cursore.

```sql
cursor c_test is
  select 1001 as p_id_ordine,
         'VALIDATO' as p_stato_new
  from dual;
```

Logging:

```sql
tst_log.log_param(l_case_id, 'P_ID_ORDINE', 'IN', 'NUMBER', r.p_id_ordine);
tst_log.log_param(l_case_id, 'P_STATO_NEW', 'IN', 'VARCHAR2', r.p_stato_new);
```

Chiamata:

```sql
pkg_ordini.cambia_stato_ordine(
  p_id_ordine => r.p_id_ordine,
  p_stato_new => r.p_stato_new
);
```

## 14.2 Parametri OUT

I parametri `OUT` richiedono una variabile locale.

Target:

```sql
procedure calcola_esito(
  p_id_ordine in number,
  p_esito     out varchar2
);
```

Wrapper:

```sql
l_esito varchar2(4000);
```

Chiamata:

```sql
pkg_ordini.calcola_esito(
  p_id_ordine => r.p_id_ordine,
  p_esito     => l_esito
);
```

Logging output:

```sql
tst_log.log_output(
  p_case_id     => l_case_id,
  p_output_name => 'P_ESITO',
  p_output_type => 'VARCHAR2',
  p_value       => l_esito
);
```

## 14.3 Parametri IN OUT

I parametri `IN OUT` hanno un valore iniziale e un valore finale.

Target:

```sql
procedure ricalcola_importo(
  p_id_ordine in number,
  p_importo   in out number
);
```

Nel cursore:

```sql
select 1001 as p_id_ordine,
       150.50 as p_importo_iniziale,
       180.75 as expected_importo_finale
from dual;
```

Nel wrapper:

```sql
l_importo number;
```

Prima della chiamata:

```sql
l_importo := r.p_importo_iniziale;

tst_log.log_param(
  p_case_id    => l_case_id,
  p_param_name => 'P_IMPORTO',
  p_param_mode => 'IN OUT',
  p_param_type => 'NUMBER',
  p_value      => l_importo
);
```

Chiamata:

```sql
pkg_ordini.ricalcola_importo(
  p_id_ordine => r.p_id_ordine,
  p_importo   => l_importo
);
```

Logging finale:

```sql
tst_log.log_output(
  p_case_id     => l_case_id,
  p_output_name => 'P_IMPORTO',
  p_output_type => 'NUMBER',
  p_value       => l_importo
);
```

Assert:

```sql
tst_assert.eq_number(
  p_case_id  => l_case_id,
  p_name     => 'IMPORTO_FINALE',
  p_expected => r.expected_importo_finale,
  p_actual   => l_importo
);
```

---

# 15. Errori attesi

Non tutti gli errori sono fallimenti.

In molti casi si vuole verificare che una procedura sollevi un errore applicativo.

Esempio:

```text
Cambio stato non ammesso -> atteso ORA-20001
```

Nel cursore:

```sql
select 'ORD_ERR_001' as case_code,
       'Cambio stato non ammesso' as case_description,
       1002 as p_id_ordine,
       'VALIDATO' as p_stato_new,
       'Y' as expect_error,
       -20001 as expect_sqlcode
from dual;
```

Nel wrapper, il blocco exception chiama:

```sql
tst_runner.end_case_error(
  p_case_id     => l_case_id,
  p_sqlcode     => sqlcode,
  p_sqlerrm     => sqlerrm,
  p_error_stack => dbms_utility.format_error_stack,
  p_backtrace   => dbms_utility.format_error_backtrace
);
```

La logica del runner deve interpretare il caso così:

| Situazione | Esito |
|---|---|
| Errore atteso e SQLCODE corretto | `PASS` |
| Errore atteso ma SQLCODE diverso | `FAIL` |
| Errore non atteso | `ERROR` oppure `FAIL`, in base alla logica implementata |
| Nessun errore ma errore atteso | `FAIL` |
| Nessun errore e nessun errore atteso | `PASS`, salvo assert falliti |

Questa gestione è molto utile per testare validazioni business.

---

# 16. Transazioni e rollback

La modalità consigliata è:

```text
ROLLBACK
```

Il wrapper usa un savepoint prima di ogni case:

```sql
savepoint tst_case_sp;
```

A fine caso:

```sql
rollback to tst_case_sp;
```

Questo consente di eseguire test che fanno DML senza lasciare dati sporchi.

## 16.1 Limite importante

Se il codice target fa `COMMIT`, il savepoint viene perso.

In quel caso il framework non può garantire il rollback automatico.

Questa non è una mancanza del tool, ma una regola Oracle: un `COMMIT` chiude la transazione e invalida i savepoint precedenti.

## 16.2 Best practice

Per codice testabile, la regola consigliata è:

```text
Il codice business non dovrebbe fare COMMIT interno.
Il COMMIT dovrebbe essere deciso dal livello orchestratore.
```

Questa regola rende il codice più facile da testare, riusare e comporre.

## 16.3 Logging con autonomous transaction

Il logging del framework è autonomo.

Questo significa che i dati di `TST_RUN`, `TST_CASE`, `TST_CASE_PARAM`, `TST_CASE_OUTPUT`, `TST_ASSERT_RESULT` e `TST_LOG_MSG` restano salvati anche se il test fa rollback.

È una scelta corretta per un harness di test: altrimenti, facendo rollback del caso, si perderebbe anche la traccia del test.

---

# 17. Signature hash

Il generatore salva un hash della firma del package sorgente.

La firma considera le informazioni pubbliche lette dal dizionario dati, come:

- nome package;
- procedure/function;
- overload;
- argomenti;
- posizione;
- tipo;
- modalità `IN`, `OUT`, `IN OUT`;
- return type.

Questo serve a intercettare una situazione frequente:

```text
Il package applicativo è cambiato,
ma il package _TEST è rimasto vecchio.
```

## 17.1 Verificare package con firma cambiata

```sql
select source_owner,
       source_package_name,
       generated_package_name,
       signature_changed,
       generated_at
from tst_v_generated_latest
order by generated_at desc;
```

Se `SIGNATURE_CHANGED = 'Y'`, il target è cambiato rispetto alla generazione.

In quel caso conviene:

1. confrontare la nuova firma;
2. rigenerare il wrapper;
3. non sovrascrivere automaticamente quello personalizzato;
4. fare merge manuale delle differenze utili.

---

# 18. Tipi supportati nella v0.2

La v0.2 è volutamente limitata ai tipi semplici.

Tipi supportati:

```text
NUMBER
VARCHAR2
VARCHAR
CHAR
NVARCHAR2
NCHAR
DATE
TIMESTAMP
CLOB
BOOLEAN, con rappresentazione testuale
```

## 18.1 BOOLEAN

`BOOLEAN` è un tipo PL/SQL, non SQL.

Questo significa che non può essere selezionato direttamente da un cursore SQL e non può essere salvato in una colonna tabellare boolean.

Il tool lo rappresenta tramite stringhe o flag.

Esempio nel cursore:

```sql
select 'Y' as p_flag_attivo
from dual;
```

Conversione nel wrapper:

```sql
l_flag_attivo := tst_util.flag_to_boolean(r.p_flag_attivo);
```

Per loggare un boolean conviene convertirlo in testo.

Esempi possibili:

```text
TRUE
FALSE
NULL
Y
N
```

La convenzione va mantenuta coerente nel progetto.

---

# 19. Casi manuali e unsupported

Non tutti i subprogram possono essere generati automaticamente in modo completo.

Casi tipicamente manuali:

```text
RECORD PL/SQL
collection
TABLE OF
VARRAY
OBJECT TYPE complessi
REF CURSOR
BLOB
JSON object type
funzioni pipelined
parametri basati su tipi package
procedure che fanno DDL
procedure con COMMIT interno
```

La v0.2 può generare stub marcati come `SKIPPED` o `MANUAL_REQUIRED`, in modo che l'intero package `_TEST` resti compilabile e che il punto da completare sia evidente.

Questa è una scelta importante: meglio generare un wrapper incompleto ma leggibile, piuttosto che fallire tutta la generazione per un solo metodo complesso.

---

# 20. Query utili di consultazione

## 20.1 Ultime run

```sql
select run_id,
       source_owner,
       source_package_name,
       source_program_name,
       status,
       total_cases,
       success_cases,
       failed_cases,
       elapsed_ms,
       started_at,
       ended_at
from tst_v_run_summary
order by run_id desc;
```

## 20.2 Dettaglio casi di una run

```sql
select case_id,
       case_code,
       case_description,
       status,
       expect_error,
       expect_sqlcode,
       sqlcode_value,
       sqlerrm_value,
       elapsed_ms
from tst_v_case_detail
where run_id = :run_id
order by case_id;
```

## 20.3 Assert falliti

```sql
select case_code,
       assert_name,
       expected_value,
       actual_value,
       message,
       created_at
from tst_v_assert_failure
where run_id = :run_id
order by assert_id;
```

## 20.4 Parametri di un case

```sql
select param_name,
       param_mode,
       param_type,
       value_varchar2,
       value_number,
       value_date,
       value_timestamp,
       dbms_lob.substr(value_clob, 4000, 1) as value_clob
from tst_case_param
where case_id = :case_id
order by param_id;
```

## 20.5 Output di un case

```sql
select output_name,
       output_type,
       value_varchar2,
       value_number,
       value_date,
       value_timestamp,
       dbms_lob.substr(value_clob, 4000, 1) as value_clob
from tst_case_output
where case_id = :case_id
order by output_id;
```

## 20.6 Log tecnici

```sql
select log_ts,
       log_level,
       dbms_lob.substr(message, 4000, 1) as message,
       sqlcode_value,
       sqlerrm_value
from tst_log_msg
where run_id = :run_id
order by log_ts;
```

## 20.7 Oggetti generati

```sql
select generated_id,
       source_owner,
       source_package_name,
       generated_package_name,
       source_signature_hash,
       generation_status,
       generated_at
from tst_generated_object
order by generated_id desc;
```

## 20.8 Controllo firma cambiata

```sql
select source_owner,
       source_package_name,
       generated_package_name,
       signature_changed,
       generated_at
from tst_v_generated_latest
order by generated_at desc;
```

---

# 21. Come personalizzare un wrapper generato

Il wrapper generato è solo il punto di partenza.

Le parti da modificare più spesso sono:

1. cursore `c_test`;
2. colonne `expected_*`;
3. query post-esecuzione;
4. assert;
5. gestione casi particolari;
6. eventuale setup dati prima della chiamata;
7. eventuale cleanup specifico.

## 21.1 Popolare casi statici

```sql
cursor c_test is
  select 'CASE_001' as case_code,
         'Caso base valido' as case_description,
         1001 as p_id_ordine,
         'VALIDATO' as p_stato_new,
         'N' as expect_error,
         cast(null as number) as expect_sqlcode,
         'VALIDATO' as expected_status
  from dual;
```

## 21.2 Popolare casi da tabelle reali

```sql
cursor c_test is
  select 'ORD_' || o.id_ordine as case_code,
         'Validazione ordine ' || o.id_ordine as case_description,
         o.id_ordine as p_id_ordine,
         'VALIDATO' as p_stato_new,
         'N' as expect_error,
         cast(null as number) as expect_sqlcode,
         'VALIDATO' as expected_status
  from ordini o
  where o.stato = 'INSERITO'
    and rownum <= 100;
```

Questo è molto utile per test AM o regressioni tecniche su dati reali controllati.

## 21.3 Aggiungere setup dati

A volte il caso richiede una preparazione.

```sql
insert into ordini_test_appoggio(id_ordine, stato)
values (r.p_id_ordine, 'INSERITO');
```

Attenzione alla transazione: se il wrapper usa `ROLLBACK TO SAVEPOINT`, anche il setup fatto dopo il savepoint viene annullato a fine case.

## 21.4 Aggiungere assert su conteggio

```sql
select count(*)
into l_log_count
from ordini_log
where id_ordine = r.p_id_ordine;

tst_assert.eq_number(
  p_case_id  => l_case_id,
  p_name     => 'LOG_CREATO',
  p_expected => 1,
  p_actual   => l_log_count
);
```

## 21.5 Aggiungere assert su esistenza

```sql
select count(*)
into l_count
from ordini
where id_ordine = r.p_id_ordine
  and stato = r.expected_status;

tst_assert.assert_true(
  p_case_id   => l_case_id,
  p_name      => 'ORDINE_IN_STATO_ATTESO',
  p_condition => l_count = 1,
  p_message   => 'Ordine non trovato nello stato atteso'
);
```

---

# 22. Versionamento consigliato

I package `_TEST` vanno versionati.

Motivo: dopo la generazione vengono modificati a mano.

Flusso consigliato:

```text
src/test/plsql/pkg_ordini_test.sql
src/test/plsql/pkg_articoli_test.sql
src/test/plsql/pkg_clienti_test.sql
```

Ogni volta che si cambia il package applicativo:

1. controllare `TST_V_GENERATED_LATEST`;
2. se la firma è cambiata, rigenerare il wrapper in tabella;
3. confrontare nuovo DDL e vecchio wrapper versionato;
4. applicare manualmente le modifiche necessarie;
5. non perdere i casi di test già scritti.

## 22.1 Non sovrascrivere alla cieca

La rigenerazione automatica distruttiva è pericolosa.

Il wrapper contiene parti manuali preziose:

- cursori popolati;
- query di setup;
- assert custom;
- commenti;
- casi AM;
- workaround tecnici.

Per questo la v0.2 salva il DDL in tabella e non lo compila/sovrascrive direttamente.

---

# 23. Best practice

## 23.1 Tenere il wrapper leggibile

Il wrapper deve restare codice PL/SQL leggibile.

Evitare di trasformarlo in un blocco enorme pieno di logica generica.

## 23.2 Usare case_code significativi

Meglio:

```text
ORD_VALID_001
ORD_ERR_STATO_001
ART_NORM_NULL_001
```

Peggio:

```text
TEST1
AAA
PROVA
```

Il `CASE_CODE` deve aiutare a capire subito cosa è stato testato.

## 23.3 Aggiungere expected result nel cursore

Non limitarsi agli input.

Aggiungere colonne come:

```text
expected_status
expected_return_value
expected_count
expected_sqlcode
expected_flag
```

Questo rende il test leggibile e auto-documentante.

## 23.4 Non abusare dei test su dati reali

I cursori possono leggere dati reali, ma bisogna stare attenti.

I test basati su dati reali sono utili, ma meno stabili di quelli con fixture controllate.

Quando possibile, creare casi deterministici.

## 23.5 Non mettere commit nei package business

Il codice con `COMMIT` interno è più difficile da testare.

Quando possibile:

```text
Package business: fa DML, ma non committa.
Orchestratore/job: decide commit o rollback.
```

## 23.6 Tenere separati test tecnici e bonifiche

Il tool può aiutare anche in AM, ma non va trasformato in un esecutore di bonifiche non controllate.

Se un wrapper modifica dati reali, deve essere chiarissimo:

- ambiente;
- transazione;
- rollback/commit;
- dati coinvolti;
- owner;
- filtri.

## 23.7 Aggiungere note alla run

Usare `p_note` in `start_run` o in generazione per spiegare lo scopo della run.

Esempio:

```sql
p_note => 'Regressione CR 12345 - cambio stato ordini'
```

---

# 24. Troubleshooting

## 24.1 Il package generato non compila

Controllare:

```sql
select name,
       type,
       line,
       position,
       text
from user_errors
where name = '<NOME_PACKAGE_TEST>'
order by sequence;
```

Cause frequenti:

- tipo parametro non supportato;
- package target non visibile dallo schema corrente;
- grants mancanti;
- sinonimi non gestiti come previsto;
- overload complesso;
- BOOLEAN gestito in modo non coerente;
- nome generato troppo lungo;
- target modificato dopo la generazione.

## 24.2 Non vedo il DDL stampato

Abilitare `SERVEROUTPUT`:

```sql
set serveroutput on size unlimited
```

Poi:

```sql
exec tst_generator.print_generated_ddl(<GENERATED_ID>);
```

In SQL Developer controllare che l'output DBMS Output sia abilitato per la connessione.

## 24.3 La run resta RUNNING

Può succedere se l'esecuzione viene interrotta brutalmente o se c'è un errore non gestito fuori dai blocchi previsti.

Query:

```sql
select *
from tst_run
where status = 'RUNNING'
order by started_at desc;
```

In una versione futura può essere utile aggiungere una procedura amministrativa per marcare come `ERROR` le run rimaste appese.

## 24.4 Gli assert falliscono ma la procedura non dà errore

È normale.

Significa che il codice è stato eseguito, ma il risultato non è quello atteso.

Controllare:

```sql
select *
from tst_v_assert_failure
where run_id = :run_id;
```

## 24.5 Il rollback non funziona

Verificare se il codice target fa `COMMIT`.

Se il target committa internamente, il wrapper non può annullare le modifiche con `ROLLBACK TO SAVEPOINT`.

## 24.6 Errore su DBMS_CRYPTO

Se il problema riguarda il calcolo hash, verificare i privilegi:

```sql
select *
from user_errors
where name = 'TST_SIGNATURE';
```

Potrebbe servire un grant esplicito:

```sql
grant execute on sys.dbms_crypto to <schema_tool>;
```

## 24.7 Il generatore non vede il package target

Controllare visibilità dizionario:

```sql
select owner,
       object_name,
       object_type,
       status
from all_objects
where owner = upper(:owner)
  and object_name = upper(:package_name);
```

Controllare anche:

```sql
select owner,
       package_name,
       object_name,
       procedure_name,
       overload
from all_procedures
where owner = upper(:owner)
  and object_name = upper(:package_name)
order by procedure_name;
```

---

# 25. Limiti della v0.2

La v0.2 è una base tecnica, non un prodotto finito.

Limiti principali:

- non compila automaticamente il DDL generato;
- non fa merge con wrapper già modificati;
- non gestisce dataset tabellari;
- non integra ancora profiler e coverage;
- non gestisce automaticamente tipi complessi;
- non ha una procedura amministrativa di cleanup;
- non ha ancora report HTML/CSV;
- non ha gestione ruoli/permessi applicativi;
- non ha una strategia di migrazione schema/versioning;
- non ha test automatici del tool stesso.

Questi limiti sono accettabili per una v0.2. La priorità è avere una base comprensibile, installabile e migliorabile.

---

# 26. Roadmap suggerita

## 26.1 v0.3 - Dataset table-driven

Aggiungere tabelle per salvare casi di test fuori dal codice.

Possibile modello:

```text
TST_DATASET
TST_DATASET_CASE
TST_DATASET_PARAM
```

Questo permetterebbe di usare test configurabili da tabella, utili per regressioni massive.

## 26.2 v0.4 - Reportistica

Aggiungere viste/report più comodi:

- riepilogo run;
- dettaglio fail;
- storico per package;
- confronto run;
- export CSV;
- report HTML.

## 26.3 v0.5 - Profiler e coverage

Integrare in modo opzionale:

- `DBMS_PROFILER`;
- `DBMS_HPROF`;
- `DBMS_PLSQL_CODE_COVERAGE`.

La modalità default dovrebbe restare `LIGHT`.

## 26.4 v0.6 - Migrazione e manutenzione

Aggiungere:

- script upgrade;
- cleanup controllato;
- gestione retention;
- archiviazione run vecchie;
- procedura per chiudere run appese.

## 26.5 v0.7 - Miglioramento generatore

Possibili evoluzioni:

- gestione più elegante degli overload;
- riconoscimento tipi custom semplici;
- generazione sezioni marker per merge manuale;
- output diretto su file tramite SQLcl o script esterni;
- template configurabili.

---

# 27. Convenzioni consigliate

## 27.1 Naming package test

```text
<PACKAGE_TARGET>_TEST
```

Esempi:

```text
PKG_ORDINI_TEST
PKG_ARTICOLI_TEST
PKG_CLIENTI_TEST
```

## 27.2 Naming procedure test

```text
TEST_<NOME_PROCEDURA>
```

In caso di overload:

```text
TEST_<NOME_PROCEDURA>_<OVERLOAD>
```

Esempi:

```text
TEST_CAMBIA_STATO_ORDINE
TEST_ELABORA_001
TEST_ELABORA_002
```

## 27.3 Naming case code

Formato consigliato:

```text
<AREA>_<SCENARIO>_<NUMERO>
```

Esempi:

```text
ORD_VALID_001
ORD_ERR_STATO_001
ART_NORM_001
CLI_CF_ERR_001
```

## 27.4 Naming assert

Usare nomi chiari e stabili:

```text
RETURN_VALUE
STATO_ORDINE
LOG_CREATO
NUMERO_RIGHE_ELABORATE
DATA_FINE_VALIDA
```

---

# 28. Esempio di template wrapper completo

Questo è un esempio semplificato dello stile atteso.

```sql
procedure test_cambia_stato_ordine is

  cursor c_test is
    select 'ORD_OK_001' as case_code,
           'Cambio stato valido' as case_description,
           1001 as p_id_ordine,
           'VALIDATO' as p_stato_new,
           'FABIO' as p_user,
           'N' as expect_error,
           cast(null as number) as expect_sqlcode,
           'VALIDATO' as expected_status
    from dual;

  l_run_id        number;
  l_case_id       number;
  l_actual_status varchar2(30);

begin
  l_run_id := tst_runner.start_run(
    p_owner                  => user,
    p_package_name           => 'PKG_ORDINI',
    p_program_name           => 'CAMBIA_STATO_ORDINE',
    p_generated_package_name => 'PKG_ORDINI_TEST',
    p_transaction_mode       => 'ROLLBACK'
  );

  for r in c_test loop
    savepoint tst_case_sp;

    l_case_id := tst_runner.start_case(
      p_run_id           => l_run_id,
      p_case_code        => r.case_code,
      p_case_description => r.case_description,
      p_expect_error     => r.expect_error,
      p_expect_sqlcode   => r.expect_sqlcode
    );

    begin
      tst_log.log_param(l_case_id, 'P_ID_ORDINE', 'IN', 'NUMBER', r.p_id_ordine);
      tst_log.log_param(l_case_id, 'P_STATO_NEW', 'IN', 'VARCHAR2', r.p_stato_new);
      tst_log.log_param(l_case_id, 'P_USER', 'IN', 'VARCHAR2', r.p_user);

      pkg_ordini.cambia_stato_ordine(
        p_id_ordine => r.p_id_ordine,
        p_stato_new => r.p_stato_new,
        p_user      => r.p_user
      );

      select stato
      into l_actual_status
      from ordini
      where id_ordine = r.p_id_ordine;

      tst_assert.eq_varchar2(
        p_case_id  => l_case_id,
        p_name     => 'STATO_ORDINE',
        p_expected => r.expected_status,
        p_actual   => l_actual_status
      );

      tst_runner.end_case_success(l_case_id);

      rollback to tst_case_sp;
    exception
      when others then
        tst_runner.end_case_error(
          p_case_id     => l_case_id,
          p_sqlcode     => sqlcode,
          p_sqlerrm     => sqlerrm,
          p_error_stack => dbms_utility.format_error_stack,
          p_backtrace   => dbms_utility.format_error_backtrace
        );

        rollback to tst_case_sp;
    end;
  end loop;

  tst_runner.end_run_success(l_run_id);
exception
  when others then
    if l_run_id is not null then
      tst_runner.end_run_error(
        p_run_id  => l_run_id,
        p_sqlcode => sqlcode,
        p_sqlerrm => sqlerrm
      );
    end if;
    raise;
end test_cambia_stato_ordine;
```

---

# 29. Linee guida per l'adozione nel progetto

Per introdurre il tool in un progetto reale, conviene procedere così.

## 29.1 Primo giro tecnico

1. Installare in schema dedicato o schema di sviluppo.
2. Compilare runtime e generatore.
3. Eseguire demo.
4. Verificare tabelle e viste.
5. Generare wrapper per un package semplice.
6. Personalizzare 2 o 3 casi reali.
7. Lanciare e verificare gli esiti.

## 29.2 Secondo giro su package reale

Scegliere un package non troppo complesso, preferibilmente con:

- procedure con parametri semplici;
- function con return value semplice;
- pochi effetti collaterali;
- niente commit interno;
- logica business verificabile con query post-esecuzione.

## 29.3 Definire convenzioni di team

Prima di usarlo diffusamente, stabilire:

- dove salvare i package `_TEST`;
- naming dei case;
- naming degli assert;
- policy su rollback/commit;
- quando rigenerare;
- come fare review dei wrapper;
- se i test possono leggere dati reali;
- come pulire o storicizzare le run vecchie.

---

# 30. Sintesi finale

Il PL/SQL Test Harness serve a standardizzare un'attività che spesso nei progetti Oracle viene fatta in modo artigianale: lanciare procedure e function, verificare risultati, annotare errori, ripetere casi e controllare regressioni.

La forza del tool non è l'automazione totale. La forza è creare una base concreta e ripetibile:

```text
Package target
  -> generatore
    -> package _TEST
      -> cursore casi
        -> runtime comune
          -> log, output, assert, esiti
```

La cosa più importante da ricordare è questa:

```text
Il generatore produce scaffolding.
Il valore vero nasce dalla personalizzazione dei casi e degli assert.
```

Usato bene, il tool può diventare molto utile per:

- regressioni tecniche;
- attività AM;
- test di procedure batch;
- verifica function di normalizzazione/calcolo;
- controlli post-modifica;
- documentazione implicita degli scenari;
- onboarding di nuovi sviluppatori;
- analisi degli errori ricorrenti.

Va però mantenuto leggero. Meglio pochi pattern chiari e usati davvero, che un framework troppo ambizioso e difficile da mantenere.
