create or replace package body tst_signature as

  c_hash_chunk_size constant pls_integer := 30000;

  procedure append_clob(
    p_clob in out nocopy clob,
    p_text in varchar2
  ) is
  begin
    if p_clob is null then
      dbms_lob.createtemporary(p_clob, true);
    end if;

    dbms_lob.append(p_clob, to_clob(p_text));
  end append_clob;

  procedure append_line(
    p_clob in out nocopy clob,
    p_text in varchar2 default null
  ) is
  begin
    append_clob(p_clob, nvl(p_text, '') || chr(10));
  end append_line;

  function normalized_optional_name(
    p_name in varchar2
  ) return varchar2 is
  begin
    if p_name is null then
      return null;
    end if;

    return tst_util.normalize_name(p_name);
  end normalized_optional_name;

  function simple_type_category(
    p_data_type in varchar2,
    p_pls_type  in varchar2 default null
  ) return varchar2 is
    l_data_type varchar2(4000) := upper(trim(p_data_type));
    l_pls_type  varchar2(4000) := upper(trim(p_pls_type));
    l_type      varchar2(4000);
  begin
    l_type := nvl(l_pls_type, l_data_type);

    if l_type is null then
      return 'UNSUPPORTED';
    end if;

    if l_type like '%BOOLEAN%' then
      return 'BOOLEAN';
    elsif l_data_type in ('VARCHAR2','VARCHAR','CHAR','NVARCHAR2','NCHAR','ROWID','UROWID') then
      return 'VARCHAR2';
    elsif l_data_type in ('NUMBER','FLOAT','BINARY_FLOAT','BINARY_DOUBLE')
       or l_pls_type in ('NUMBER','BINARY_INTEGER','PLS_INTEGER','SIMPLE_INTEGER','INTEGER','NATURAL','NATURALN','POSITIVE','POSITIVEN','SIGNTYPE') then
      return 'NUMBER';
    elsif l_data_type = 'DATE' then
      return 'DATE';
    elsif l_data_type = 'TIMESTAMP' then
      return 'TIMESTAMP';
    elsif l_data_type = 'CLOB' then
      return 'CLOB';
    else
      return 'UNSUPPORTED';
    end if;
  end simple_type_category;

  function is_simple_supported(
    p_data_type in varchar2,
    p_pls_type  in varchar2 default null
  ) return varchar2 is
  begin
    if simple_type_category(p_data_type, p_pls_type) = 'UNSUPPORTED' then
      return 'N';
    else
      return 'Y';
    end if;
  end is_simple_supported;

  function get_signature_text(
    p_owner        in varchar2,
    p_package_name in varchar2,
    p_program_name in varchar2 default null
  ) return clob is
    l_owner        varchar2(128) := tst_util.normalize_name(p_owner);
    l_package_name varchar2(128) := tst_util.normalize_name(p_package_name);
    l_program_name varchar2(128) := normalized_optional_name(p_program_name);
    l_count        number;
    l_text         clob;
  begin
    select count(*)
      into l_count
      from all_objects
     where owner = l_owner
       and object_name = l_package_name
       and object_type = 'PACKAGE';

    if l_count = 0 then
      raise_application_error(-20930, 'Package not found or not visible: ' || l_owner || '.' || l_package_name);
    end if;

    append_line(l_text, 'TST_SIGNATURE_V01');
    append_line(l_text, 'OWNER=' || l_owner);
    append_line(l_text, 'PACKAGE=' || l_package_name);
    append_line(l_text, 'PROGRAM_FILTER=' || nvl(l_program_name, '<ALL>'));

    for p in (
      select procedure_name,
             overload,
             subprogram_id
        from all_procedures
       where owner = l_owner
         and object_name = l_package_name
         and object_type = 'PACKAGE'
         and procedure_name is not null
         and (l_program_name is null or procedure_name = l_program_name)
       order by procedure_name, lpad(nvl(overload, '0'), 10, '0'), subprogram_id
    ) loop
      append_line(l_text, 'SUBPROGRAM=' || p.procedure_name || ';OVERLOAD=' || nvl(p.overload, '<NULL>') || ';SUBPROGRAM_ID=' || p.subprogram_id);

      for a in (
        select argument_name,
               position,
               sequence,
               in_out,
               data_type,
               pls_type,
               type_owner,
               type_name,
               type_subname,
               defaulted,
               data_level
          from all_arguments
         where owner = l_owner
           and package_name = l_package_name
           and object_name = p.procedure_name
           and nvl(overload, chr(0)) = nvl(p.overload, chr(0))
         order by sequence
      ) loop
        append_line(
          l_text,
          'ARG=' || nvl(a.argument_name, '<RETURN>') ||
          ';POS=' || a.position ||
          ';SEQ=' || a.sequence ||
          ';MODE=' || nvl(a.in_out, '<NULL>') ||
          ';DATA_TYPE=' || nvl(a.data_type, '<NULL>') ||
          ';PLS_TYPE=' || nvl(a.pls_type, '<NULL>') ||
          ';TYPE=' || nvl(a.type_owner, '<NULL>') || '.' || nvl(a.type_name, '<NULL>') || '.' || nvl(a.type_subname, '<NULL>') ||
          ';DEFAULTED=' || nvl(a.defaulted, '<NULL>') ||
          ';DATA_LEVEL=' || a.data_level ||
          ';CATEGORY=' || simple_type_category(a.data_type, a.pls_type)
        );
      end loop;
    end loop;

    return l_text;
  end get_signature_text;

  function get_signature_hash(
    p_owner        in varchar2,
    p_package_name in varchar2,
    p_program_name in varchar2 default null
  ) return varchar2 is
    l_text   clob;
    l_len    integer;
    l_pos    integer := 1;
    l_piece  varchar2(32767);
    l_hash   varchar2(64);
  begin
    l_text := get_signature_text(
                p_owner        => p_owner,
                p_package_name => p_package_name,
                p_program_name => p_program_name
              );

    select rawtohex(standard_hash('TST_SIGNATURE_V01', 'SHA256'))
      into l_hash
      from dual;

    l_len := dbms_lob.getlength(l_text);

    while l_pos <= l_len loop
      l_piece := dbms_lob.substr(l_text, c_hash_chunk_size, l_pos);

      select rawtohex(standard_hash(l_hash || ':' || l_piece, 'SHA256'))
        into l_hash
        from dual;

      l_pos := l_pos + c_hash_chunk_size;
    end loop;

    return l_hash;
  end get_signature_hash;

  function has_signature_changed(
    p_owner         in varchar2,
    p_package_name  in varchar2,
    p_expected_hash in varchar2,
    p_program_name  in varchar2 default null
  ) return varchar2 is
    l_actual_hash varchar2(64);
  begin
    if p_expected_hash is null then
      return 'Y';
    end if;

    l_actual_hash := get_signature_hash(
                       p_owner        => p_owner,
                       p_package_name => p_package_name,
                       p_program_name => p_program_name
                     );

    if upper(trim(p_expected_hash)) = l_actual_hash then
      return 'N';
    else
      return 'Y';
    end if;
  end has_signature_changed;

end tst_signature;
/
show errors package body tst_signature
