set define off

prompt Creating demo generated-style test wrapper...

create or replace package demo_pkg_ordini_test as

  procedure test_cambia_stato_ordine;

  procedure test_normalizza_codice;

end demo_pkg_ordini_test;
/
show errors package demo_pkg_ordini_test

create or replace package body demo_pkg_ordini_test as

  procedure test_cambia_stato_ordine is

    cursor c_test is
      select 'ORD_OK_001' as case_code,
             'Cambio stato valido' as case_description,
             1001 as p_id_ordine,
             'VALIDATO' as p_stato_new,
             'FABIO' as p_user,
             'N' as expect_error,
             cast(null as number) as expect_sqlcode,
             'VALIDATO' as expected_status
      from dual
      union all
      select 'ORD_ERR_001' as case_code,
             'Cambio stato non ammesso su ordine chiuso' as case_description,
             1002 as p_id_ordine,
             'VALIDATO' as p_stato_new,
             'FABIO' as p_user,
             'Y' as expect_error,
             -20001 as expect_sqlcode,
             cast(null as varchar2(30)) as expected_status
      from dual;

    l_run_id number;
    l_case_id number;
    l_actual_status demo_ordini.stato%type;

  begin
    l_run_id := tst_runner.start_run(
      p_owner                  => user,
      p_package_name           => 'DEMO_PKG_ORDINI',
      p_program_name           => 'CAMBIA_STATO_ORDINE',
      p_generated_package_name => 'DEMO_PKG_ORDINI_TEST',
      p_transaction_mode       => 'ROLLBACK',
      p_note                   => 'Demo wrapper generated-style for procedure.'
    );

    for r in c_test loop
      savepoint tst_case_sp;

      l_case_id := tst_runner.start_case(
        p_run_id           => l_run_id,
        p_case_code        => r.case_code,
        p_case_description => r.case_description,
        p_expect_error     => r.expect_error,
        p_expect_sqlcode   => r.expect_sqlcode
      );

      begin
        tst_log.log_param(l_case_id, 'P_ID_ORDINE', 'IN', 'NUMBER', r.p_id_ordine);
        tst_log.log_param(l_case_id, 'P_STATO_NEW', 'IN', 'VARCHAR2', r.p_stato_new);
        tst_log.log_param(l_case_id, 'P_USER', 'IN', 'VARCHAR2', r.p_user);

        demo_pkg_ordini.cambia_stato_ordine(
          p_id_ordine => r.p_id_ordine,
          p_stato_new => r.p_stato_new,
          p_user      => r.p_user
        );

        select stato
          into l_actual_status
          from demo_ordini
         where id_ordine = r.p_id_ordine;

        tst_assert.eq_varchar2(
          p_case_id  => l_case_id,
          p_name     => 'STATO_ORDINE',
          p_expected => r.expected_status,
          p_actual   => l_actual_status
        );

        tst_runner.end_case_success(l_case_id);

        rollback to tst_case_sp;
      exception
        when others then
          tst_runner.end_case_error(
            p_case_id     => l_case_id,
            p_sqlcode     => sqlcode,
            p_sqlerrm     => sqlerrm,
            p_error_stack => dbms_utility.format_error_stack,
            p_backtrace   => dbms_utility.format_error_backtrace
          );

          rollback to tst_case_sp;
      end;
    end loop;

    tst_runner.end_run_success(l_run_id);
  exception
    when others then
      if l_run_id is not null then
        tst_runner.end_run_error(
          p_run_id  => l_run_id,
          p_sqlcode => sqlcode,
          p_sqlerrm => sqlerrm
        );
      end if;
      raise;
  end test_cambia_stato_ordine;

  procedure test_normalizza_codice is

    cursor c_test is
      select 'NORM_001' as case_code,
             'Trim e uppercase' as case_description,
             ' abc123 ' as p_codice,
             'ABC123' as expected_return_value,
             'N' as expect_error,
             cast(null as number) as expect_sqlcode
      from dual
      union all
      select 'NORM_002' as case_code,
             'Null input' as case_description,
             cast(null as varchar2(100)) as p_codice,
             cast(null as varchar2(100)) as expected_return_value,
             'N' as expect_error,
             cast(null as number) as expect_sqlcode
      from dual;

    l_run_id number;
    l_case_id number;
    l_return_value varchar2(4000);

  begin
    l_run_id := tst_runner.start_run(
      p_owner                  => user,
      p_package_name           => 'DEMO_PKG_ORDINI',
      p_program_name           => 'NORMALIZZA_CODICE',
      p_generated_package_name => 'DEMO_PKG_ORDINI_TEST',
      p_transaction_mode       => 'ROLLBACK',
      p_note                   => 'Demo wrapper generated-style for function.'
    );

    for r in c_test loop
      savepoint tst_case_sp;

      l_case_id := tst_runner.start_case(
        p_run_id           => l_run_id,
        p_case_code        => r.case_code,
        p_case_description => r.case_description,
        p_expect_error     => r.expect_error,
        p_expect_sqlcode   => r.expect_sqlcode
      );

      begin
        tst_log.log_param(l_case_id, 'P_CODICE', 'IN', 'VARCHAR2', r.p_codice);

        l_return_value := demo_pkg_ordini.normalizza_codice(
          p_codice => r.p_codice
        );

        tst_log.log_return_value(l_case_id, 'VARCHAR2', l_return_value);

        tst_assert.eq_varchar2(
          p_case_id  => l_case_id,
          p_name     => 'RETURN_VALUE',
          p_expected => r.expected_return_value,
          p_actual   => l_return_value
        );

        tst_runner.end_case_success(l_case_id);

        rollback to tst_case_sp;
      exception
        when others then
          tst_runner.end_case_error(
            p_case_id     => l_case_id,
            p_sqlcode     => sqlcode,
            p_sqlerrm     => sqlerrm,
            p_error_stack => dbms_utility.format_error_stack,
            p_backtrace   => dbms_utility.format_error_backtrace
          );

          rollback to tst_case_sp;
      end;
    end loop;

    tst_runner.end_run_success(l_run_id);
  exception
    when others then
      if l_run_id is not null then
        tst_runner.end_run_error(
          p_run_id  => l_run_id,
          p_sqlcode => sqlcode,
          p_sqlerrm => sqlerrm
        );
      end if;
      raise;
  end test_normalizza_codice;

end demo_pkg_ordini_test;
/
show errors package body demo_pkg_ordini_test

prompt Demo test wrapper created.
