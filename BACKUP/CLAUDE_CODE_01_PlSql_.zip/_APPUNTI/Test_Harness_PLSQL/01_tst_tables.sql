set define off

prompt Creating PL/SQL Test Harness tables...

create table tst_run (
  run_id                 number generated always as identity,
  source_owner           varchar2(128) not null,
  source_package_name    varchar2(128),
  source_program_name    varchar2(128),
  generated_package_name varchar2(128),
  started_at             timestamp(6) default systimestamp not null,
  ended_at               timestamp(6),
  elapsed_ms             number(18,3),
  status                 varchar2(30) default 'RUNNING' not null,
  total_cases            number default 0 not null,
  success_cases          number default 0 not null,
  failed_cases           number default 0 not null,
  warning_cases          number default 0 not null,
  profile_mode           varchar2(30) default 'NONE' not null,
  coverage_mode          varchar2(30) default 'NONE' not null,
  transaction_mode       varchar2(30) default 'ROLLBACK' not null,
  client_identifier      varchar2(256),
  module_name            varchar2(128),
  action_name            varchar2(128),
  note                   clob,
  created_by             varchar2(128) default sys_context('USERENV','SESSION_USER') not null,
  created_at             timestamp(6) default systimestamp not null,
  constraint tst_run_pk primary key (run_id),
  constraint tst_run_ck_status check (status in ('RUNNING','SUCCESS','FAILED','ERROR')),
  constraint tst_run_ck_profile check (profile_mode in ('NONE','PROFILER','HPROF')),
  constraint tst_run_ck_coverage check (coverage_mode in ('NONE','BASIC','FULL')),
  constraint tst_run_ck_trn check (transaction_mode in ('ROLLBACK','COMMIT','MANUAL'))
);

create table tst_case (
  case_id          number generated always as identity,
  run_id           number not null,
  case_code        varchar2(100),
  case_description varchar2(4000),
  started_at       timestamp(6) default systimestamp not null,
  ended_at         timestamp(6),
  elapsed_ms       number(18,3),
  status           varchar2(30) default 'RUNNING' not null,
  expect_error     varchar2(1) default 'N' not null,
  expect_sqlcode   number,
  sqlcode_value    number,
  sqlerrm_value    varchar2(4000),
  error_stack      clob,
  error_backtrace  clob,
  created_by       varchar2(128) default sys_context('USERENV','SESSION_USER') not null,
  created_at       timestamp(6) default systimestamp not null,
  constraint tst_case_pk primary key (case_id),
  constraint tst_case_run_fk foreign key (run_id) references tst_run(run_id),
  constraint tst_case_ck_status check (status in ('RUNNING','PASS','FAIL','ERROR','SKIPPED')),
  constraint tst_case_ck_expect_error check (expect_error in ('Y','N'))
);

create index tst_case_i01 on tst_case(run_id, status);
create index tst_case_i02 on tst_case(case_code);

create table tst_case_param (
  param_id        number generated always as identity,
  case_id         number not null,
  param_name      varchar2(128) not null,
  param_mode      varchar2(20) not null,
  param_type      varchar2(128) not null,
  value_varchar2  varchar2(4000),
  value_number    number,
  value_date      date,
  value_timestamp timestamp(6),
  value_clob      clob,
  created_at      timestamp(6) default systimestamp not null,
  constraint tst_case_param_pk primary key (param_id),
  constraint tst_case_param_case_fk foreign key (case_id) references tst_case(case_id),
  constraint tst_case_param_ck_mode check (param_mode in ('IN','OUT','IN OUT','RETURN'))
);

create index tst_case_param_i01 on tst_case_param(case_id, param_name);

create table tst_case_output (
  output_id       number generated always as identity,
  case_id         number not null,
  output_name     varchar2(128) not null,
  output_type     varchar2(128) not null,
  value_varchar2  varchar2(4000),
  value_number    number,
  value_date      date,
  value_timestamp timestamp(6),
  value_clob      clob,
  created_at      timestamp(6) default systimestamp not null,
  constraint tst_case_output_pk primary key (output_id),
  constraint tst_case_output_case_fk foreign key (case_id) references tst_case(case_id)
);

create index tst_case_output_i01 on tst_case_output(case_id, output_name);

create table tst_assert_result (
  assert_id       number generated always as identity,
  case_id         number not null,
  assert_name     varchar2(200) not null,
  expected_value  clob,
  actual_value    clob,
  status          varchar2(10) not null,
  message         varchar2(4000),
  created_at      timestamp(6) default systimestamp not null,
  constraint tst_assert_result_pk primary key (assert_id),
  constraint tst_assert_result_case_fk foreign key (case_id) references tst_case(case_id),
  constraint tst_assert_result_ck_status check (status in ('PASS','FAIL'))
);

create index tst_assert_result_i01 on tst_assert_result(case_id, status);

create table tst_log_msg (
  log_id        number generated always as identity,
  run_id        number,
  case_id       number,
  log_ts        timestamp(6) default systimestamp not null,
  log_level     varchar2(20) default 'INFO' not null,
  message       clob,
  sqlcode_value number,
  sqlerrm_value varchar2(4000),
  created_by    varchar2(128) default sys_context('USERENV','SESSION_USER') not null,
  constraint tst_log_msg_pk primary key (log_id),
  constraint tst_log_msg_run_fk foreign key (run_id) references tst_run(run_id),
  constraint tst_log_msg_case_fk foreign key (case_id) references tst_case(case_id),
  constraint tst_log_msg_ck_level check (log_level in ('DEBUG','INFO','WARN','ERROR'))
);

create index tst_log_msg_i01 on tst_log_msg(run_id, case_id, log_ts);

create table tst_generated_object (
  generated_id          number generated always as identity,
  source_owner          varchar2(128) not null,
  source_package_name   varchar2(128) not null,
  generated_package_name varchar2(128) not null,
  generated_at          timestamp(6) default systimestamp not null,
  source_signature_hash varchar2(4000),
  generation_status     varchar2(30) default 'GENERATED' not null,
  generated_ddl         clob,
  note                  clob,
  created_by            varchar2(128) default sys_context('USERENV','SESSION_USER') not null,
  constraint tst_generated_object_pk primary key (generated_id),
  constraint tst_generated_object_ck_status check (generation_status in ('GENERATED','ERROR','SKIPPED','MANUAL_REQUIRED'))
);

create index tst_generated_object_i01 on tst_generated_object(source_owner, source_package_name, generated_at);

prompt Creating PL/SQL Test Harness views...

create or replace view tst_v_run_summary as
select r.run_id,
       r.source_owner,
       r.source_package_name,
       r.source_program_name,
       r.generated_package_name,
       r.started_at,
       r.ended_at,
       r.elapsed_ms,
       r.status,
       r.total_cases,
       r.success_cases,
       r.failed_cases,
       r.warning_cases,
       r.profile_mode,
       r.coverage_mode,
       r.transaction_mode,
       r.created_by
from tst_run r;

create or replace view tst_v_case_detail as
select c.case_id,
       c.run_id,
       r.source_owner,
       r.source_package_name,
       r.source_program_name,
       c.case_code,
       c.case_description,
       c.started_at,
       c.ended_at,
       c.elapsed_ms,
       c.status,
       c.expect_error,
       c.expect_sqlcode,
       c.sqlcode_value,
       c.sqlerrm_value,
       (select count(*) from tst_assert_result a where a.case_id = c.case_id) as assert_count,
       (select count(*) from tst_assert_result a where a.case_id = c.case_id and a.status = 'FAIL') as failed_assert_count
from tst_case c
join tst_run r on r.run_id = c.run_id;

create or replace view tst_v_assert_failure as
select a.assert_id,
       a.case_id,
       c.run_id,
       r.source_owner,
       r.source_package_name,
       r.source_program_name,
       c.case_code,
       a.assert_name,
       dbms_lob.substr(a.expected_value, 4000, 1) as expected_value,
       dbms_lob.substr(a.actual_value, 4000, 1) as actual_value,
       a.message,
       a.created_at
from tst_assert_result a
join tst_case c on c.case_id = a.case_id
join tst_run r on r.run_id = c.run_id
where a.status = 'FAIL';

prompt Tables and views created.
