set define off
set serveroutput on size unlimited

prompt Installing PL/SQL Test Harness generator v0.3...

@10_tst_signature.pks
@11_tst_signature.pkb
@12_tst_generator.pks
@13_tst_generator.pkb
@14_tst_generator_views.sql

prompt Generator v0.3 installed.
