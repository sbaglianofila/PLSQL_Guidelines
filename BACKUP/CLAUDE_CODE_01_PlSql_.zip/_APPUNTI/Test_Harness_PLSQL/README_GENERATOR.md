# PL/SQL Test Harness - Generatore v0.2

Questo blocco aggiunge al runtime v0.1 due package:

- `TST_SIGNATURE`, per calcolare la firma/hash di un package PL/SQL leggendo il dizionario dati.
- `TST_GENERATOR`, per generare il DDL di un package `<PACKAGE>_TEST` nello stile del test harness.

La scelta rimane volutamente prudente: il generatore non compila direttamente il codice prodotto, ma salva il DDL in `TST_GENERATED_OBJECT.generated_ddl`. In questo modo puoi rivedere il package generato, copiarlo in repository, modificarlo e compilarlo consapevolmente.

## Installazione

Prima installa il runtime v0.1. Poi esegui:

```sql
@00_install_generator.sql
```

## Generare un wrapper

Esempio:

```sql
declare
  l_generated_id number;
begin
  l_generated_id := tst_generator.generate_package_test(
    p_owner               => 'APP',
    p_package_name        => 'PKG_ORDINI',
    p_test_package_name   => 'PKG_ORDINI_TEST',
    p_output_mode         => 'TABLE',
    p_include_unsupported => 'Y',
    p_transaction_mode    => 'ROLLBACK'
  );

  dbms_output.put_line('Generated id = ' || l_generated_id);
end;
/
commit;
```

Il DDL viene salvato qui:

```sql
select generated_id,
       source_owner,
       source_package_name,
       generated_package_name,
       source_signature_hash,
       generation_status,
       generated_at
from tst_generated_object
order by generated_id desc;
```

Per stamparlo:

```sql
set serveroutput on size unlimited
exec tst_generator.print_generated_ddl(<GENERATED_ID>);
```

## Tipi supportati nella v0.2

Il generatore produce wrapper completi per parametri semplici:

- `NUMBER`
- `VARCHAR2`, `VARCHAR`, `CHAR`, `NVARCHAR2`, `NCHAR`
- `DATE`
- `TIMESTAMP`
- `CLOB`
- `BOOLEAN`, usando colonne `VARCHAR2` nel cursore e conversione tramite `TST_UTIL.FLAG_TO_BOOLEAN`

Per return value semplici genera anche l'assert automatico `RETURN_VALUE`, dove possibile.

## Casi marcati come manuali

Se il subprogram contiene record, collection, object type, ref cursor, strutture nidificate o tipi non riconosciuti, il generatore produce uno stub compilabile che apre una run e marca il caso come `SKIPPED` con motivo `MANUAL_REQUIRED`.

Questa scelta evita che l'intero package generato fallisca per un singolo subprogram complesso.

## Signature hash

`TST_SIGNATURE.GET_SIGNATURE_HASH` calcola un fingerprint della firma pubblica del package. Il valore viene salvato in `TST_GENERATED_OBJECT.source_signature_hash`.

La vista `TST_V_GENERATED_LATEST` mostra se la firma attuale è diversa da quella usata in generazione:

```sql
select source_owner,
       source_package_name,
       generated_package_name,
       signature_changed,
       generated_at
from tst_v_generated_latest;
```

Se `SIGNATURE_CHANGED = 'Y'`, il package target è cambiato e conviene rigenerare o almeno rivedere il wrapper `_TEST`.

## Flusso consigliato

1. Genera il wrapper in tabella.
2. Stampa o esporta il DDL.
3. Salvalo nel repository Git.
4. Compilalo in ambiente dev.
5. Popola i cursori `c_test`.
6. Aggiungi assert specifici dove serve.
7. Lancia le procedure `test_*`.
8. Analizza `TST_RUN`, `TST_CASE`, `TST_ASSERT_RESULT`, `TST_CASE_PARAM`, `TST_CASE_OUTPUT`.

## Limiti noti

Questa versione è volutamente una base tecnica:

- non fa merge intelligente con wrapper già personalizzati;
- non gestisce table-driven dataset;
- non integra ancora profiler/coverage;
- non automatizza record, collection, ref cursor e object type;
- non compila direttamente il DDL generato.

Sono scelte volute per mantenere il tool semplice, leggibile e manutenibile.
