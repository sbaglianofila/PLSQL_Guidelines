create or replace
function is_leap_year (i_year in number)
    return varchar2
is
begin

    if (mod(p_year,4) <> 0)
    then
        return (lib_constants.k_NO);

    elsif (mod(p_year,400) = 0)
    then
        return (lib_constants.k_YES);

    elsif (mod(p_year,100) = 0)
    then
        return (lib_constants.k_NO);

    else
        return (lib_constants.k_YES);

    end if;

end is_leap_year;
/