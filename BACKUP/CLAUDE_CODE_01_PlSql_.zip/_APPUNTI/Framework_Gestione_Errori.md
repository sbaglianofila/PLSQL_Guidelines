# Guida finale - Gestione errori e logging in Oracle PL/SQL

## 1. Obiettivo

Questa guida descrive una possibile gestione centralizzata di messaggi, log ed errori in Oracle PL/SQL.

L'obiettivo e' avere:

- una tabella catalogo per messaggi ed errori applicativi;
- la possibilita' di codificare anche errori Oracle noti;
- wrapper comodi per `START`, `END`, `INFO`, `WARN`, `DEBUG`, `ERROR`;
- messaggi personalizzabili con placeholder tipo `{01}`, `{02}`, `{03}`;
- salvataggio di stack, backtrace e call stack solo per gli errori;
- gestione del debug da configurazione runtime;
- debug molto fine solo con compilazione condizionale;
- uso robusto anche in presenza di connection pool, evitando di dipendere da stato globale di package o contesti sessione.

La scelta finale e':

```text
unit_name       = chi sta scrivendo il log, per esempio PKG_ORDINI.IMPORTA_ORDINI
context_code    = dominio/categoria del messaggio, per esempio APP, ORACLE, BATCH, INTEGRATION
message_code    = codice funzionale del messaggio, per esempio ORD_ARTICOLO_NON_VALIDO
correlation_id  = identificativo esplicito della singola esecuzione/flusso
```

`unit_name` e `correlation_id` vengono passati esplicitamente dal chiamante, cosi' il logging resta prevedibile anche con connection pool.

---

## 2. Concetti principali

### 2.1 `MESSAGE_TYPE` vs `SEVERITY_CODE`

Sono due attributi diversi.

`MESSAGE_TYPE` risponde alla domanda:

> Che tipo di evento e' questo record?

`SEVERITY_CODE` risponde alla domanda:

> Quanto e' importante o grave questo record?

Valori consigliati per `MESSAGE_TYPE`:

```text
START
END
LOG
ERROR
```

Valori consigliati per `SEVERITY_CODE`:

```text
TRACE
DEBUG
INFO
WARN
ERROR
FATAL
```

Esempi:

| Caso | MESSAGE_TYPE | SEVERITY_CODE |
|---|---|---|
| Inizio procedura | START | INFO |
| Fine procedura | END | INFO |
| Messaggio informativo | LOG | INFO |
| Warning funzionale | LOG | WARN |
| Debug tecnico | LOG | DEBUG |
| Errore normale | ERROR | ERROR |
| Errore bloccante grave | ERROR | FATAL |

Questa separazione permette query diverse:

```sql
-- Solo errori
select *
from   app_log_event
where  message_type = 'ERROR';
```

```sql
-- Solo warning ed errori, indipendentemente dal tipo record
select *
from   app_log_event
where  severity_code in ('WARN', 'ERROR', 'FATAL');
```

```sql
-- Ciclo di vita procedure
select *
from   app_log_event
where  message_type in ('START', 'END');
```

---

## 3. Tabelle

### 3.1 Catalogo messaggi: `APP_LOG_MESSAGE`

Contiene i messaggi codificati, sia applicativi sia Oracle.

```sql
create table app_log_message (
    message_id            number generated always as identity primary key,
    context_code          varchar2(30)   not null,
    message_code          varchar2(100)  not null,

    default_message_type  varchar2(20)   default 'LOG'  not null,
    default_severity_code varchar2(20)   default 'INFO' not null,

    oracle_error_code     number,
    app_error_code        number,

    message_template      varchar2(4000) not null,
    is_active             char(1)        default 'Y' not null,

    created_at            timestamp      default systimestamp not null,
    updated_at            timestamp,

    constraint ck_alm_type
        check (default_message_type in ('START', 'END', 'LOG', 'ERROR')),

    constraint ck_alm_severity
        check (default_severity_code in ('TRACE', 'DEBUG', 'INFO', 'WARN', 'ERROR', 'FATAL')),

    constraint ck_alm_active
        check (is_active in ('Y', 'N')),

    constraint ck_alm_app_error_code
        check (
            app_error_code is null
            or app_error_code between -20999 and -20000
        ),

    constraint uk_alm_code
        unique (context_code, message_code)
);

create index ix_alm_oracle_error
    on app_log_message (oracle_error_code);

create index ix_alm_app_error
    on app_log_message (app_error_code);
```

Esempi:

```sql
insert into app_log_message (
    context_code,
    message_code,
    default_message_type,
    default_severity_code,
    oracle_error_code,
    message_template
) values (
    'ORACLE',
    'ORA_00001',
    'ERROR',
    'ERROR',
    -1,
    'Violazione vincolo univoco'
);
```

```sql
insert into app_log_message (
    context_code,
    message_code,
    default_message_type,
    default_severity_code,
    app_error_code,
    message_template
) values (
    'APP',
    'ORD_ARTICOLO_NON_VALIDO',
    'ERROR',
    'ERROR',
    -20010,
    'L''articolo {01} non e'' valido per il magazzino {02}'
);
```

```sql
insert into app_log_message (
    context_code,
    message_code,
    default_message_type,
    default_severity_code,
    message_template
) values (
    'APP',
    'ORD_IMPORT_COMPLETATO',
    'LOG',
    'INFO',
    'Import ordini completato. Record elaborati: {01}'
);
```

Nota: `START` ed `END` standard non hanno bisogno di `message_code`. Il catalogo serve solo se vuoi un messaggio personalizzato.

---

### 3.2 Configurazione logging: `APP_LOG_CONFIG`

Permette di decidere cosa tracciare a runtime.

La configurazione puo' essere:

1. specifica per `context_code + unit_name`;
2. specifica per `unit_name`;
3. specifica per `context_code`;
4. globale.

```sql
create table app_log_config (
    config_id          number generated always as identity primary key,

    context_code       varchar2(30),
    unit_name          varchar2(261),

    min_level_code     varchar2(20) default 'INFO' not null,
    log_start_end_yn   char(1)      default 'Y'    not null,
    log_debug_yn       char(1)      default 'N'    not null,
    log_trace_yn       char(1)      default 'N'    not null,
    is_active          char(1)      default 'Y'    not null,

    created_at         timestamp    default systimestamp not null,
    updated_at         timestamp,

    constraint ck_alc_level
        check (min_level_code in ('TRACE', 'DEBUG', 'INFO', 'WARN', 'ERROR', 'FATAL')),

    constraint ck_alc_flags
        check (
            log_start_end_yn in ('Y', 'N') and
            log_debug_yn     in ('Y', 'N') and
            log_trace_yn     in ('Y', 'N') and
            is_active        in ('Y', 'N')
        )
);

create unique index uk_alc_scope
    on app_log_config (
        nvl(context_code, '#'),
        nvl(unit_name, '#')
    );
```

Configurazione globale:

```sql
insert into app_log_config (
    context_code,
    unit_name,
    min_level_code,
    log_start_end_yn,
    log_debug_yn,
    log_trace_yn
) values (
    null,
    null,
    'INFO',
    'Y',
    'N',
    'N'
);
```

Configurazione per tutto il dominio applicativo:

```sql
insert into app_log_config (
    context_code,
    unit_name,
    min_level_code,
    log_start_end_yn,
    log_debug_yn,
    log_trace_yn
) values (
    'APP',
    null,
    'INFO',
    'Y',
    'N',
    'N'
);
```

Debug solo su una procedura:

```sql
insert into app_log_config (
    context_code,
    unit_name,
    min_level_code,
    log_start_end_yn,
    log_debug_yn,
    log_trace_yn
) values (
    'APP',
    'PKG_ORDINI.IMPORTA_ORDINI',
    'DEBUG',
    'Y',
    'Y',
    'N'
);
```

---

### 3.3 Eventi log: `APP_LOG_EVENT`

Tabella principale degli eventi.

```sql
create table app_log_event (
    log_id             number generated always as identity primary key,
    log_ts             timestamp default systimestamp not null,

    context_code       varchar2(30)  default 'APP' not null,
    unit_name          varchar2(261) not null,

    message_code       varchar2(100),
    message_type       varchar2(20)  not null,
    severity_code      varchar2(20)  not null,
    message_text       varchar2(4000),

    oracle_error_code  number,
    app_error_code     number,

    correlation_id     varchar2(64),
    payload_json       clob,

    session_user_name  varchar2(128) default sys_context('USERENV', 'SESSION_USER'),
    sid                number        default sys_context('USERENV', 'SID'),

    created_at         timestamp     default systimestamp not null,

    constraint ck_ale_type
        check (message_type in ('START', 'END', 'LOG', 'ERROR')),

    constraint ck_ale_severity
        check (severity_code in ('TRACE', 'DEBUG', 'INFO', 'WARN', 'ERROR', 'FATAL')),

    constraint ck_ale_payload_json
        check (payload_json is json)
);

create index ix_ale_01
    on app_log_event (log_ts, context_code, severity_code);

create index ix_ale_02
    on app_log_event (unit_name, log_ts);

create index ix_ale_03
    on app_log_event (correlation_id, log_ts);

create index ix_ale_04
    on app_log_event (message_type, severity_code, log_ts);

create index ix_ale_05
    on app_log_event (oracle_error_code);
```

Nota su `payload_json`: se usi una versione Oracle in cui il vincolo `is json` sui CLOB non e' disponibile o ha sintassi diversa, togli il constraint o adattalo alla tua versione.

---

### 3.4 Dettaglio errore: `APP_LOG_ERROR_DETAIL`

Contiene stack e diagnostica solo per gli errori.

```sql
create table app_log_error_detail (
    log_id           number primary key,

    error_stack      clob,
    error_backtrace  clob,
    call_stack       clob,
    sqlerrm_text     varchar2(4000),
    diagnostic_json  clob,

    created_at       timestamp default systimestamp not null,

    constraint fk_aled_event
        foreign key (log_id)
        references app_log_event (log_id),

    constraint ck_aled_diagnostic_json
        check (diagnostic_json is json)
);
```

Questa tabella viene popolata solo da `app_log_pkg.error`.

---

## 4. Package di logging

### 4.1 Scelta importante su `error`

La procedura `app_log_pkg.error` deve solo loggare l'errore corrente.

Il `raise;` finale deve restare nel chiamante:

```sql
exception
    when others then
        app_log_pkg.error(
            p_unit_name    => c_unit_name,
            p_message_code => ord_msg_codes.c_err_import_ko
        );
        raise;
end;
```

Questa scelta e' intenzionale: in PL/SQL il `raise;` senza nome e' il modo piu' pulito per rilanciare l'eccezione corrente dal relativo exception handler. Se lo nascondi dentro un wrapper generico, rischi di perdere chiarezza e, a seconda dell'implementazione, anche parte del comportamento originale.

Quindi niente `p_reraise` nel package finale.

---

### 4.2 Package specification

```sql
create or replace package app_log_pkg authid definer is

    subtype t_context is varchar2(30);
    subtype t_code    is varchar2(100);

    c_ctx_app        constant varchar2(30) := 'APP';
    c_ctx_oracle     constant varchar2(30) := 'ORACLE';
    c_ctx_batch      constant varchar2(30) := 'BATCH';
    c_ctx_integration constant varchar2(30) := 'INTEGRATION';

    type t_params is table of varchar2(4000);

    function params(
        p01 in varchar2 default null,
        p02 in varchar2 default null,
        p03 in varchar2 default null,
        p04 in varchar2 default null,
        p05 in varchar2 default null,
        p06 in varchar2 default null,
        p07 in varchar2 default null,
        p08 in varchar2 default null,
        p09 in varchar2 default null,
        p10 in varchar2 default null
    ) return t_params;

    procedure start_proc(
        p_unit_name      in varchar2,
        p_context_code   in t_context default c_ctx_app,
        p_correlation_id in varchar2 default null,
        p_payload_json   in clob     default null
    );

    procedure end_proc(
        p_unit_name      in varchar2,
        p_context_code   in t_context default c_ctx_app,
        p_correlation_id in varchar2 default null,
        p_payload_json   in clob     default null
    );

    procedure start_msg(
        p_unit_name      in varchar2,
        p_message_code   in t_code,
        p_context_code   in t_context default c_ctx_app,
        p_params         in t_params default null,
        p_correlation_id in varchar2 default null,
        p_payload_json   in clob     default null
    );

    procedure end_msg(
        p_unit_name      in varchar2,
        p_message_code   in t_code,
        p_context_code   in t_context default c_ctx_app,
        p_params         in t_params default null,
        p_correlation_id in varchar2 default null,
        p_payload_json   in clob     default null
    );

    procedure info(
        p_unit_name      in varchar2,
        p_message_code   in t_code,
        p_context_code   in t_context default c_ctx_app,
        p_params         in t_params default null,
        p_correlation_id in varchar2 default null,
        p_payload_json   in clob     default null
    );

    procedure warn(
        p_unit_name      in varchar2,
        p_message_code   in t_code,
        p_context_code   in t_context default c_ctx_app,
        p_params         in t_params default null,
        p_correlation_id in varchar2 default null,
        p_payload_json   in clob     default null
    );

    procedure debug(
        p_unit_name      in varchar2,
        p_message_code   in t_code,
        p_context_code   in t_context default c_ctx_app,
        p_params         in t_params default null,
        p_correlation_id in varchar2 default null,
        p_payload_json   in clob     default null
    );

    procedure error(
        p_unit_name      in varchar2,
        p_message_code   in t_code default null,
        p_context_code   in t_context default c_ctx_app,
        p_params         in t_params default null,
        p_correlation_id in varchar2 default null,
        p_payload_json   in clob     default null,
        p_severity_code  in varchar2 default 'ERROR'
    );

    procedure raise_error(
        p_message_code in t_code,
        p_context_code in t_context default c_ctx_app,
        p_params       in t_params default null
    );

end app_log_pkg;
/
```

---

### 4.3 Package body

Questa e' una versione completa ma ancora leggibile. In produzione puoi raffinare caching, gestione fallback, sanitizzazione payload, partizionamento e retention.

```sql
create or replace package body app_log_pkg is

    type t_message_def is record (
        context_code          app_log_message.context_code%type,
        message_code          app_log_message.message_code%type,
        default_message_type  app_log_message.default_message_type%type,
        default_severity_code app_log_message.default_severity_code%type,
        oracle_error_code     app_log_message.oracle_error_code%type,
        app_error_code        app_log_message.app_error_code%type,
        message_template      app_log_message.message_template%type
    );

    function severity_rank(p_severity_code in varchar2)
        return number
    is
    begin
        return case upper(p_severity_code)
            when 'TRACE' then 10
            when 'DEBUG' then 20
            when 'INFO'  then 30
            when 'WARN'  then 40
            when 'ERROR' then 50
            when 'FATAL' then 60
            else 30
        end;
    end severity_rank;


    function params(
        p01 in varchar2 default null,
        p02 in varchar2 default null,
        p03 in varchar2 default null,
        p04 in varchar2 default null,
        p05 in varchar2 default null,
        p06 in varchar2 default null,
        p07 in varchar2 default null,
        p08 in varchar2 default null,
        p09 in varchar2 default null,
        p10 in varchar2 default null
    ) return t_params
    is
        l_params t_params := t_params();
    begin
        l_params.extend(10);
        l_params(1)  := p01;
        l_params(2)  := p02;
        l_params(3)  := p03;
        l_params(4)  := p04;
        l_params(5)  := p05;
        l_params(6)  := p06;
        l_params(7)  := p07;
        l_params(8)  := p08;
        l_params(9)  := p09;
        l_params(10) := p10;

        return l_params;
    end params;


    function format_message(
        p_template in varchar2,
        p_params   in t_params
    ) return varchar2
    is
        l_msg varchar2(4000) := p_template;
    begin
        if p_params is not null then
            for i in 1 .. p_params.count loop
                l_msg := replace(
                    l_msg,
                    '{' || lpad(i, 2, '0') || '}',
                    coalesce(p_params(i), '<NULL>')
                );
            end loop;
        end if;

        return l_msg;
    end format_message;


    function get_message_def(
        p_context_code in varchar2,
        p_message_code in varchar2
    ) return t_message_def
    is
        l_def t_message_def;
    begin
        select context_code,
               message_code,
               default_message_type,
               default_severity_code,
               oracle_error_code,
               app_error_code,
               message_template
        into   l_def.context_code,
               l_def.message_code,
               l_def.default_message_type,
               l_def.default_severity_code,
               l_def.oracle_error_code,
               l_def.app_error_code,
               l_def.message_template
        from   app_log_message
        where  context_code = p_context_code
        and    message_code = p_message_code
        and    is_active = 'Y';

        return l_def;
    exception
        when no_data_found then
            l_def.context_code          := p_context_code;
            l_def.message_code          := p_message_code;
            l_def.default_message_type  := 'LOG';
            l_def.default_severity_code := 'INFO';
            l_def.oracle_error_code     := null;
            l_def.app_error_code        := null;
            l_def.message_template      := '[' || p_context_code || '/' || p_message_code || ']';
            return l_def;
    end get_message_def;


    function is_enabled(
        p_context_code  in varchar2,
        p_unit_name     in varchar2,
        p_severity_code in varchar2,
        p_message_type  in varchar2
    ) return boolean
    is
        l_min_level_code   app_log_config.min_level_code%type;
        l_log_start_end_yn app_log_config.log_start_end_yn%type;
        l_log_debug_yn     app_log_config.log_debug_yn%type;
        l_log_trace_yn     app_log_config.log_trace_yn%type;
    begin
        begin
            select min_level_code,
                   log_start_end_yn,
                   log_debug_yn,
                   log_trace_yn
            into   l_min_level_code,
                   l_log_start_end_yn,
                   l_log_debug_yn,
                   l_log_trace_yn
            from (
                select c.*,
                       case
                           when c.context_code = p_context_code
                            and c.unit_name    = p_unit_name then 1
                           when c.context_code is null
                            and c.unit_name    = p_unit_name then 2
                           when c.context_code = p_context_code
                            and c.unit_name    is null then 3
                           when c.context_code is null
                            and c.unit_name    is null then 4
                           else 99
                       end as priority
                from   app_log_config c
                where  c.is_active = 'Y'
                and    (
                           (c.context_code = p_context_code and c.unit_name = p_unit_name)
                        or (c.context_code is null       and c.unit_name = p_unit_name)
                        or (c.context_code = p_context_code and c.unit_name is null)
                        or (c.context_code is null       and c.unit_name is null)
                       )
                order by priority
            )
            where rownum = 1;
        exception
            when no_data_found then
                return p_severity_code in ('ERROR', 'FATAL');
        end;

        if p_message_type in ('START', 'END')
           and l_log_start_end_yn = 'N'
        then
            return false;
        end if;

        if p_severity_code = 'DEBUG'
           and l_log_debug_yn = 'N'
        then
            return false;
        end if;

        if p_severity_code = 'TRACE'
           and l_log_trace_yn = 'N'
        then
            return false;
        end if;

        return severity_rank(p_severity_code) >= severity_rank(l_min_level_code);
    end is_enabled;


    procedure insert_event(
        p_context_code      in varchar2,
        p_unit_name         in varchar2,
        p_message_code      in varchar2,
        p_message_type      in varchar2,
        p_severity_code     in varchar2,
        p_message_text      in varchar2,
        p_oracle_error_code in number,
        p_app_error_code    in number,
        p_correlation_id    in varchar2,
        p_payload_json      in clob,
        p_log_id            out number
    ) is
        pragma autonomous_transaction;
    begin
        insert into app_log_event (
            context_code,
            unit_name,
            message_code,
            message_type,
            severity_code,
            message_text,
            oracle_error_code,
            app_error_code,
            correlation_id,
            payload_json
        ) values (
            p_context_code,
            p_unit_name,
            p_message_code,
            p_message_type,
            p_severity_code,
            p_message_text,
            p_oracle_error_code,
            p_app_error_code,
            p_correlation_id,
            p_payload_json
        )
        returning log_id into p_log_id;

        commit;
    exception
        when others then
            rollback;
            p_log_id := null;
    end insert_event;


    procedure insert_error_detail(
        p_log_id          in number,
        p_error_stack     in clob,
        p_error_backtrace in clob,
        p_call_stack      in clob,
        p_sqlerrm_text    in varchar2,
        p_diagnostic_json in clob default null
    ) is
        pragma autonomous_transaction;
    begin
        if p_log_id is null then
            return;
        end if;

        insert into app_log_error_detail (
            log_id,
            error_stack,
            error_backtrace,
            call_stack,
            sqlerrm_text,
            diagnostic_json
        ) values (
            p_log_id,
            p_error_stack,
            p_error_backtrace,
            p_call_stack,
            p_sqlerrm_text,
            p_diagnostic_json
        );

        commit;
    exception
        when others then
            rollback;
    end insert_error_detail;


    procedure write_raw(
        p_unit_name         in varchar2,
        p_context_code      in varchar2,
        p_message_code      in varchar2,
        p_message_type      in varchar2,
        p_severity_code     in varchar2,
        p_message_text      in varchar2,
        p_oracle_error_code in number default null,
        p_app_error_code    in number default null,
        p_correlation_id    in varchar2 default null,
        p_payload_json      in clob     default null,
        p_log_id            out number
    ) is
    begin
        p_log_id := null;

        if not is_enabled(
            p_context_code  => p_context_code,
            p_unit_name     => p_unit_name,
            p_severity_code => p_severity_code,
            p_message_type  => p_message_type
        ) then
            return;
        end if;

        insert_event(
            p_context_code      => p_context_code,
            p_unit_name         => p_unit_name,
            p_message_code      => p_message_code,
            p_message_type      => p_message_type,
            p_severity_code     => p_severity_code,
            p_message_text      => p_message_text,
            p_oracle_error_code => p_oracle_error_code,
            p_app_error_code    => p_app_error_code,
            p_correlation_id    => p_correlation_id,
            p_payload_json      => p_payload_json,
            p_log_id            => p_log_id
        );
    end write_raw;


    procedure write_message(
        p_unit_name       in varchar2,
        p_context_code    in varchar2,
        p_message_code    in varchar2,
        p_forced_type     in varchar2,
        p_forced_severity in varchar2,
        p_params          in t_params default null,
        p_correlation_id  in varchar2 default null,
        p_payload_json    in clob     default null,
        p_log_id          out number
    ) is
        l_def          t_message_def;
        l_message_text varchar2(4000);
    begin
        l_def := get_message_def(
            p_context_code => p_context_code,
            p_message_code => p_message_code
        );

        l_message_text := format_message(
            p_template => l_def.message_template,
            p_params   => p_params
        );

        write_raw(
            p_unit_name         => p_unit_name,
            p_context_code      => p_context_code,
            p_message_code      => p_message_code,
            p_message_type      => coalesce(p_forced_type, l_def.default_message_type),
            p_severity_code     => coalesce(p_forced_severity, l_def.default_severity_code),
            p_message_text      => l_message_text,
            p_oracle_error_code => l_def.oracle_error_code,
            p_app_error_code    => l_def.app_error_code,
            p_correlation_id    => p_correlation_id,
            p_payload_json      => p_payload_json,
            p_log_id            => p_log_id
        );
    end write_message;


    procedure start_proc(
        p_unit_name      in varchar2,
        p_context_code   in t_context default c_ctx_app,
        p_correlation_id in varchar2 default null,
        p_payload_json   in clob     default null
    ) is
        l_log_id number;
    begin
        write_raw(
            p_unit_name      => p_unit_name,
            p_context_code   => p_context_code,
            p_message_code   => null,
            p_message_type   => 'START',
            p_severity_code  => 'INFO',
            p_message_text   => 'Inizio procedura ' || p_unit_name,
            p_correlation_id => p_correlation_id,
            p_payload_json   => p_payload_json,
            p_log_id         => l_log_id
        );
    end start_proc;


    procedure end_proc(
        p_unit_name      in varchar2,
        p_context_code   in t_context default c_ctx_app,
        p_correlation_id in varchar2 default null,
        p_payload_json   in clob     default null
    ) is
        l_log_id number;
    begin
        write_raw(
            p_unit_name      => p_unit_name,
            p_context_code   => p_context_code,
            p_message_code   => null,
            p_message_type   => 'END',
            p_severity_code  => 'INFO',
            p_message_text   => 'Fine procedura ' || p_unit_name,
            p_correlation_id => p_correlation_id,
            p_payload_json   => p_payload_json,
            p_log_id         => l_log_id
        );
    end end_proc;


    procedure start_msg(
        p_unit_name      in varchar2,
        p_message_code   in t_code,
        p_context_code   in t_context default c_ctx_app,
        p_params         in t_params default null,
        p_correlation_id in varchar2 default null,
        p_payload_json   in clob     default null
    ) is
        l_log_id number;
    begin
        write_message(
            p_unit_name       => p_unit_name,
            p_context_code    => p_context_code,
            p_message_code    => p_message_code,
            p_forced_type     => 'START',
            p_forced_severity => 'INFO',
            p_params          => p_params,
            p_correlation_id  => p_correlation_id,
            p_payload_json    => p_payload_json,
            p_log_id          => l_log_id
        );
    end start_msg;


    procedure end_msg(
        p_unit_name      in varchar2,
        p_message_code   in t_code,
        p_context_code   in t_context default c_ctx_app,
        p_params         in t_params default null,
        p_correlation_id in varchar2 default null,
        p_payload_json   in clob     default null
    ) is
        l_log_id number;
    begin
        write_message(
            p_unit_name       => p_unit_name,
            p_context_code    => p_context_code,
            p_message_code    => p_message_code,
            p_forced_type     => 'END',
            p_forced_severity => 'INFO',
            p_params          => p_params,
            p_correlation_id  => p_correlation_id,
            p_payload_json    => p_payload_json,
            p_log_id          => l_log_id
        );
    end end_msg;


    procedure info(
        p_unit_name      in varchar2,
        p_message_code   in t_code,
        p_context_code   in t_context default c_ctx_app,
        p_params         in t_params default null,
        p_correlation_id in varchar2 default null,
        p_payload_json   in clob     default null
    ) is
        l_log_id number;
    begin
        write_message(
            p_unit_name       => p_unit_name,
            p_context_code    => p_context_code,
            p_message_code    => p_message_code,
            p_forced_type     => 'LOG',
            p_forced_severity => 'INFO',
            p_params          => p_params,
            p_correlation_id  => p_correlation_id,
            p_payload_json    => p_payload_json,
            p_log_id          => l_log_id
        );
    end info;


    procedure warn(
        p_unit_name      in varchar2,
        p_message_code   in t_code,
        p_context_code   in t_context default c_ctx_app,
        p_params         in t_params default null,
        p_correlation_id in varchar2 default null,
        p_payload_json   in clob     default null
    ) is
        l_log_id number;
    begin
        write_message(
            p_unit_name       => p_unit_name,
            p_context_code    => p_context_code,
            p_message_code    => p_message_code,
            p_forced_type     => 'LOG',
            p_forced_severity => 'WARN',
            p_params          => p_params,
            p_correlation_id  => p_correlation_id,
            p_payload_json    => p_payload_json,
            p_log_id          => l_log_id
        );
    end warn;


    procedure debug(
        p_unit_name      in varchar2,
        p_message_code   in t_code,
        p_context_code   in t_context default c_ctx_app,
        p_params         in t_params default null,
        p_correlation_id in varchar2 default null,
        p_payload_json   in clob     default null
    ) is
        l_log_id number;
    begin
        write_message(
            p_unit_name       => p_unit_name,
            p_context_code    => p_context_code,
            p_message_code    => p_message_code,
            p_forced_type     => 'LOG',
            p_forced_severity => 'DEBUG',
            p_params          => p_params,
            p_correlation_id  => p_correlation_id,
            p_payload_json    => p_payload_json,
            p_log_id          => l_log_id
        );
    end debug;


    procedure error(
        p_unit_name      in varchar2,
        p_message_code   in t_code default null,
        p_context_code   in t_context default c_ctx_app,
        p_params         in t_params default null,
        p_correlation_id in varchar2 default null,
        p_payload_json   in clob     default null,
        p_severity_code  in varchar2 default 'ERROR'
    ) is
        l_log_id       number;
        l_message_text varchar2(4000);
        l_def          t_message_def;
        l_sqlcode      number := sqlcode;
        l_sqlerrm      varchar2(4000) := sqlerrm;
    begin
        if p_message_code is not null then
            l_def := get_message_def(
                p_context_code => p_context_code,
                p_message_code => p_message_code
            );

            l_message_text := format_message(
                p_template => l_def.message_template,
                p_params   => p_params
            );
        else
            l_message_text := l_sqlerrm;
        end if;

        write_raw(
            p_unit_name         => p_unit_name,
            p_context_code      => p_context_code,
            p_message_code      => p_message_code,
            p_message_type      => 'ERROR',
            p_severity_code     => p_severity_code,
            p_message_text      => l_message_text,
            p_oracle_error_code => case when l_sqlcode <> 0 then l_sqlcode end,
            p_app_error_code    => case
                                      when l_sqlcode between -20999 and -20000
                                      then l_sqlcode
                                    end,
            p_correlation_id    => p_correlation_id,
            p_payload_json      => p_payload_json,
            p_log_id            => l_log_id
        );

        insert_error_detail(
            p_log_id          => l_log_id,
            p_error_stack     => dbms_utility.format_error_stack,
            p_error_backtrace => dbms_utility.format_error_backtrace,
            p_call_stack      => dbms_utility.format_call_stack,
            p_sqlerrm_text    => l_sqlerrm,
            p_diagnostic_json => null
        );
    end error;


    procedure raise_error(
        p_message_code in t_code,
        p_context_code in t_context default c_ctx_app,
        p_params       in t_params default null
    ) is
        l_def          t_message_def;
        l_message_text varchar2(4000);
    begin
        l_def := get_message_def(
            p_context_code => p_context_code,
            p_message_code => p_message_code
        );

        if l_def.app_error_code is null then
            raise_application_error(
                -20000,
                'Errore applicativo non configurato per message_code=' || p_message_code
            );
        end if;

        l_message_text := format_message(
            p_template => l_def.message_template,
            p_params   => p_params
        );

        raise_application_error(
            l_def.app_error_code,
            l_message_text
        );
    end raise_error;

end app_log_pkg;
/
```

---

## 5. Package di costanti per i `message_code`

I `message_code` non dovrebbero essere scritti come stringhe sparse nel codice.

Da evitare:

```sql
app_log_pkg.error(
    p_unit_name    => c_unit_name,
    p_message_code => 'ORD_IMPORT_KO'
);
```

Meglio usare costanti:

```sql
app_log_pkg.error(
    p_unit_name    => c_unit_name,
    p_message_code => ord_msg_codes.c_err_import_ko
);
```

### 5.1 Package per dominio

Scelta consigliata:

```sql
create or replace package ord_msg_codes is

    c_err_articolo_non_valido constant varchar2(100) := 'ORD_ARTICOLO_NON_VALIDO';
    c_err_import_ko           constant varchar2(100) := 'ORD_IMPORT_KO';
    c_wrn_articolo_saltato    constant varchar2(100) := 'ORD_ARTICOLO_SALTATO';
    c_inf_import_completato   constant varchar2(100) := 'ORD_IMPORT_COMPLETATO';
    c_dbg_articolo_corrente   constant varchar2(100) := 'ORD_DEBUG_ARTICOLO_CORRENTE';

end ord_msg_codes;
/
```

### 5.2 Quante costanti mettere in un package

Non c'e' un limite pratico basso imposto da Oracle per un package di sole costanti, ma c'e' un limite umano.

Regola consigliata:

```text
1-50      tranquillissimo
50-150    gestibile
150-300   gestibile solo se ben organizzato
300-500   da valutare split
oltre 500 meglio dividere quasi sempre
```

Soglia pratica consigliata:

```text
oltre 200 costanti: valuta split
oltre 300 costanti: quasi sicuramente splitta
```

Meglio avere:

```text
app_msg_codes   -- messaggi comuni trasversali
ord_msg_codes   -- ordini
mag_msg_codes   -- magazzino
int_msg_codes   -- integrazioni
```

piuttosto che un unico `app_msg_codes` con centinaia di codici eterogenei.

---

## 6. Pattern d'uso consigliato

### 6.1 Procedura semplice

```sql
create or replace procedure prc_importa_ordini is
    c_unit_name constant varchar2(261) := 'PRC_IMPORTA_ORDINI';
    l_corr_id   varchar2(64) := rawtohex(sys_guid());
begin
    app_log_pkg.start_proc(
        p_unit_name      => c_unit_name,
        p_correlation_id => l_corr_id
    );

    -- logica applicativa

    app_log_pkg.info(
        p_unit_name      => c_unit_name,
        p_message_code   => ord_msg_codes.c_inf_import_completato,
        p_params         => app_log_pkg.params(125),
        p_correlation_id => l_corr_id
    );

    app_log_pkg.end_proc(
        p_unit_name      => c_unit_name,
        p_correlation_id => l_corr_id
    );

exception
    when others then
        app_log_pkg.error(
            p_unit_name      => c_unit_name,
            p_message_code   => ord_msg_codes.c_err_import_ko,
            p_correlation_id => l_corr_id
        );
        raise;
end;
/
```

### 6.2 Package applicativo

```sql
create or replace package body pkg_ordini is

    c_pkg_name constant varchar2(128) := 'PKG_ORDINI';

    procedure importa_ordini is
        c_unit_name constant varchar2(261) := c_pkg_name || '.IMPORTA_ORDINI';
        l_corr_id   varchar2(64) := rawtohex(sys_guid());
    begin
        app_log_pkg.start_proc(
            p_unit_name      => c_unit_name,
            p_correlation_id => l_corr_id
        );

        for r in (
            select cod_articolo,
                   cod_magazzino
            from   stg_ordini
        ) loop

            $if $$fine_debug $then
                app_log_pkg.debug(
                    p_unit_name      => c_unit_name,
                    p_message_code   => ord_msg_codes.c_dbg_articolo_corrente,
                    p_params         => app_log_pkg.params(r.cod_articolo, r.cod_magazzino),
                    p_correlation_id => l_corr_id
                );
            $end

            if articolo_non_valido(r.cod_articolo) then
                app_log_pkg.raise_error(
                    p_context_code => app_log_pkg.c_ctx_app,
                    p_message_code => ord_msg_codes.c_err_articolo_non_valido,
                    p_params       => app_log_pkg.params(r.cod_articolo, r.cod_magazzino)
                );
            end if;

        end loop;

        app_log_pkg.end_proc(
            p_unit_name      => c_unit_name,
            p_correlation_id => l_corr_id
        );

    exception
        when others then
            app_log_pkg.error(
                p_unit_name      => c_unit_name,
                p_message_code   => ord_msg_codes.c_err_import_ko,
                p_correlation_id => l_corr_id
            );
            raise;
    end importa_ordini;

end pkg_ordini;
/
```

### 6.3 Start/End standard

Uso quotidiano:

```sql
app_log_pkg.start_proc(
    p_unit_name => c_unit_name
);

app_log_pkg.end_proc(
    p_unit_name => c_unit_name
);
```

Risultato:

```text
Inizio procedura PKG_ORDINI.IMPORTA_ORDINI
Fine procedura PKG_ORDINI.IMPORTA_ORDINI
```

Nessun `message_code` necessario.

### 6.4 Start/End personalizzati

Solo se vuoi un messaggio catalogato:

```sql
app_log_pkg.start_msg(
    p_unit_name      => c_unit_name,
    p_message_code   => ord_msg_codes.c_inf_import_completato,
    p_params         => app_log_pkg.params(l_nome_file),
    p_correlation_id => l_corr_id
);
```

---

## 7. Placeholder nei messaggi

La convenzione scelta e':

```text
{01}, {02}, {03}, ..., {10}
```

Esempio catalogo:

```sql
insert into app_log_message (
    context_code,
    message_code,
    default_message_type,
    default_severity_code,
    app_error_code,
    message_template
) values (
    'APP',
    ord_msg_codes.c_err_articolo_non_valido,
    'ERROR',
    'ERROR',
    -20010,
    'L''articolo {01} non e'' valido per il magazzino {02}'
);
```

Uso:

```sql
app_log_pkg.raise_error(
    p_message_code => ord_msg_codes.c_err_articolo_non_valido,
    p_params       => app_log_pkg.params(l_cod_articolo, l_cod_magazzino)
);
```

Risultato:

```text
L'articolo ABC123 non e' valido per il magazzino M01
```

Nota: se un parametro e' `NULL`, nella versione proposta viene sostituito con `<NULL>`, cosi' il log resta leggibile.

---

## 8. Debug runtime e debug compile-time

### 8.1 Debug runtime

Si abilita da tabella di configurazione:

```sql
update app_log_config
set    min_level_code = 'DEBUG',
       log_debug_yn   = 'Y'
where  context_code = 'APP'
and    unit_name = 'PKG_ORDINI.IMPORTA_ORDINI';
```

Questo abilita i log `DEBUG` gia' presenti nel codice compilato.

### 8.2 Debug fine con compilazione condizionale

Per log molto verbosi o costosi, usare compilazione condizionale.

Esempio nel codice:

```sql
$if $$fine_debug $then
    app_log_pkg.debug(
        p_unit_name      => c_unit_name,
        p_message_code   => ord_msg_codes.c_dbg_articolo_corrente,
        p_params         => app_log_pkg.params(r.cod_articolo, r.cod_magazzino),
        p_correlation_id => l_corr_id
    );
$end
```

Compilazione con debug fine attivo:

```sql
alter session set plsql_ccflags = 'fine_debug:true';
alter package pkg_ordini compile body;
```

Compilazione con debug fine disattivo:

```sql
alter session set plsql_ccflags = 'fine_debug:false';
alter package pkg_ordini compile body;
```

Logica consigliata:

```text
DEBUG runtime:
    per log di debug normali, poco costosi

Compilazione condizionale:
    per log molto dettagliati, dentro loop pesanti, o con calcolo di payload costoso
```

---

## 9. Connection pool: regole da seguire

Con connection pool e' meglio evitare di basare la logica su:

- variabili globali di package;
- `set_correlation_id` persistenti;
- contesti sessione come fonte principale del flusso;
- `CLIENT_IDENTIFIER` come unico identificativo applicativo.

Non sono strumenti vietati, ma nel disegno finale non sono necessari.

Regola proposta:

```text
unit_name      sempre esplicito
correlation_id esplicito se serve correlare piu' log
context_code   esplicito o default APP
```

Esempio:

```sql
l_corr_id varchar2(64) := rawtohex(sys_guid());
```

poi:

```sql
app_log_pkg.info(
    p_unit_name      => c_unit_name,
    p_message_code   => ord_msg_codes.c_inf_import_completato,
    p_params         => app_log_pkg.params(l_count),
    p_correlation_id => l_corr_id
);
```

---

## 10. Query utili

### 10.1 Ultimi errori

```sql
select e.log_id,
       e.log_ts,
       e.context_code,
       e.unit_name,
       e.message_code,
       e.message_text,
       e.oracle_error_code,
       e.app_error_code
from   app_log_event e
where  e.message_type = 'ERROR'
order  by e.log_ts desc;
```

### 10.2 Dettaglio errore

```sql
select e.log_ts,
       e.context_code,
       e.unit_name,
       e.message_code,
       e.message_text,
       e.oracle_error_code,
       e.app_error_code,
       d.sqlerrm_text,
       d.error_stack,
       d.error_backtrace,
       d.call_stack
from   app_log_event e
join   app_log_error_detail d
       on d.log_id = e.log_id
where  e.log_id = :p_log_id;
```

### 10.3 Log di una singola esecuzione

```sql
select log_ts,
       message_type,
       severity_code,
       unit_name,
       message_code,
       message_text
from   app_log_event
where  correlation_id = :p_correlation_id
order  by log_ts;
```

### 10.4 Tempi tra Start e End per correlation_id

```sql
select correlation_id,
       unit_name,
       min(case when message_type = 'START' then log_ts end) as start_ts,
       max(case when message_type = 'END'   then log_ts end) as end_ts,
       max(case when message_type = 'END'   then log_ts end)
       - min(case when message_type = 'START' then log_ts end) as elapsed_time
from   app_log_event
where  correlation_id is not null
group  by correlation_id,
          unit_name;
```

### 10.5 Errori per procedura

```sql
select unit_name,
       message_code,
       count(*) as error_count,
       max(log_ts) as last_error_ts
from   app_log_event
where  message_type = 'ERROR'
group  by unit_name,
          message_code
order  by error_count desc;
```

---

## 11. Criticita'

### 11.1 Autonomous transaction

Il logging usa `pragma autonomous_transaction` per scrivere i log anche se la transazione chiamante va in rollback.

Vantaggi:

- il log resta disponibile anche dopo errori e rollback;
- utile per audit tecnico e troubleshooting;
- evita che un rollback cancelli proprio le informazioni dell'errore.

Svantaggi:

- il log puo' contenere eventi relativi a operazioni poi rollbackate;
- ogni scrittura log fa commit autonomo;
- loggare troppo dentro loop pesanti puo' degradare le performance.

Regola pratica:

```text
Loggare sempre START, END, ERROR.
Loggare INFO solo per eventi significativi.
Loggare DEBUG solo se necessario.
Evitare log riga-per-riga in loop massivi, salvo debug temporaneo.
```

### 11.2 Errori nel logger

Il logger non deve mai rompere la procedura chiamante.

Per questo gli insert del log catturano `when others`, fanno rollback autonomo e non rilanciano.

In alternativa, in sistemi molto critici, si puo' prevedere una fallback table minimale o un fallback su file tramite job esterno, ma non lo metterei nella prima versione.

### 11.3 Payload JSON

`payload_json` e' utile, ma va usato con attenzione.

Da evitare:

- dati personali non necessari;
- password/token/segreti;
- payload enormi;
- dati soggetti a policy di retention diversa dal log tecnico.

Meglio salvare solo diagnostica utile e sintetica.

### 11.4 Message catalog troppo rigido

Se un `message_code` non esiste, la proposta fa comunque scrivere un fallback tipo:

```text
[APP/ORD_IMPORT_KO]
```

Questo evita che un errore di configurazione del catalogo impedisca il logging.

In ambienti molto governati puoi decidere di essere piu' severo, ma per un logger tecnico e' meglio non bloccare.

### 11.5 Costanti messaggi

Le costanti aiutano, ma non devono diventare una discarica.

Meglio package per dominio:

```text
ord_msg_codes
mag_msg_codes
int_msg_codes
```

anziche' un unico package gigante.

---

## 12. Punti di sviluppo futuri

### 12.1 Partizionamento e retention

Se il volume cresce, valutare partizionamento per data su `APP_LOG_EVENT.LOG_TS`.

Possibili policy:

```text
DEBUG/TRACE  retention breve, per esempio 7-15 giorni
INFO         retention media, per esempio 30-90 giorni
ERROR        retention lunga, per esempio 6-24 mesi
```

### 12.2 Purge automatico

Procedura schedulata:

```sql
create or replace procedure app_log_purge(
    p_days_to_keep in number default 90
) is
begin
    delete from app_log_error_detail d
    where exists (
        select 1
        from   app_log_event e
        where  e.log_id = d.log_id
        and    e.log_ts < systimestamp - p_days_to_keep
    );

    delete from app_log_event e
    where  e.log_ts < systimestamp - p_days_to_keep;

    commit;
end;
/
```

Da adattare se usi partizioni: in quel caso e' spesso meglio droppare/truncare partizioni.

### 12.3 Mascheramento dati sensibili

Possibile funzione futura:

```sql
function sanitize_payload(p_payload_json in clob) return clob;
```

Per rimuovere o mascherare campi come:

```text
password
token
secret
iban
codice fiscale
email
telefono
```

### 12.4 Cache configurazione

Attualmente `is_enabled` legge la tabella di configurazione.

Per volumi alti si puo' valutare una cache in package, ma con connection pool e configurazioni runtime bisogna gestire bene invalidazione e refresh.

Prima versione consigliata: niente cache.

Ottimizzazione successiva:

```text
cache con TTL breve
cache resettabile con procedura admin
cache disabilitabile
```

### 12.5 Vista semplificata per consultazione

```sql
create or replace view app_log_error_v as
select e.log_id,
       e.log_ts,
       e.context_code,
       e.unit_name,
       e.message_code,
       e.message_text,
       e.oracle_error_code,
       e.app_error_code,
       d.sqlerrm_text,
       d.error_stack,
       d.error_backtrace,
       d.call_stack
from   app_log_event e
join   app_log_error_detail d
       on d.log_id = e.log_id
where  e.message_type = 'ERROR';
```

### 12.6 Supporto APEX

Se usi APEX, puoi aggiungere campi opzionali:

```text
app_id
page_id
app_user
request
session_id_apex
```

Ma li terrei fuori dal modello base se vuoi mantenere il logger generico.

### 12.7 Supporto multi-lingua

Se un giorno serve, puoi separare i template:

```text
APP_LOG_MESSAGE
APP_LOG_MESSAGE_TEXT
```

con chiave:

```text
context_code, message_code, language_code
```

Per ora non lo introdurrei: aggiunge complessita' senza beneficio immediato.

---

## 13. Checklist di implementazione

Ordine consigliato:

```text
1. Creare APP_LOG_MESSAGE
2. Creare APP_LOG_CONFIG
3. Creare APP_LOG_EVENT
4. Creare APP_LOG_ERROR_DETAIL
5. Creare APP_LOG_PKG
6. Creare package di costanti per dominio, per esempio ORD_MSG_CODES
7. Inserire configurazione globale APP
8. Inserire primi messaggi catalogati
9. Adeguare una procedura pilota
10. Validare log START/END/ERROR
11. Aggiungere INFO/WARN/DEBUG dove serve
12. Solo dopo, valutare purge, retention e partizionamento
```

---

## 14. Scelta finale sintetica

La versione finale usa:

```text
APP_LOG_MESSAGE        catalogo messaggi/errori con placeholder
APP_LOG_CONFIG         configurazione runtime per contesto e/o procedura
APP_LOG_EVENT          eventi principali
APP_LOG_ERROR_DETAIL   stack/backtrace/call stack solo per errori
APP_LOG_PKG            API unica di logging
*_MSG_CODES            costanti message_code per dominio
```

Wrapper principali:

```text
start_proc  messaggio automatico START
end_proc    messaggio automatico END
start_msg   START personalizzato da catalogo
end_msg     END personalizzato da catalogo
info        LOG/INFO da catalogo
warn        LOG/WARN da catalogo
debug       LOG/DEBUG da catalogo
error       ERROR + dettaglio tecnico, da usare in exception handler
raise_error raise_application_error da catalogo
```

Pattern errore finale:

```sql
exception
    when others then
        app_log_pkg.error(
            p_unit_name      => c_unit_name,
            p_message_code   => ord_msg_codes.c_err_import_ko,
            p_correlation_id => l_corr_id
        );
        raise;
end;
```

Pattern errore applicativo:

```sql
if articolo_non_valido(l_cod_articolo) then
    app_log_pkg.raise_error(
        p_message_code => ord_msg_codes.c_err_articolo_non_valido,
        p_params       => app_log_pkg.params(l_cod_articolo, l_cod_magazzino)
    );
end if;
```

---

## 15. Riferimenti Oracle utili

- `DBMS_UTILITY.FORMAT_ERROR_STACK`, `FORMAT_ERROR_BACKTRACE`, `FORMAT_CALL_STACK`: Oracle Database PL/SQL Packages and Types Reference, `DBMS_UTILITY`.
- `RAISE_APPLICATION_ERROR`: Oracle PL/SQL Language Reference, sezione sulle eccezioni sollevate esplicitamente.
- Compilazione condizionale PL/SQL: Oracle PL/SQL Language Reference, sezione Conditional Compilation.
- `PLSQL_CCFLAGS`: Oracle Database Reference.
- `AUTONOMOUS_TRANSACTION`: Oracle PL/SQL Language Reference, sezione Autonomous Transactions.

Link principali:

- https://docs.oracle.com/en/database/oracle/oracle-database/19/arpls/DBMS_UTILITY.html
- https://docs.oracle.com/en/database/oracle/oracle-database/23/lnpls/raising-exceptions-explicitly.html
- https://docs.oracle.com/en/database/oracle/oracle-database/23/lnpls/conditional-compilation1.html
- https://docs.oracle.com/en/database/oracle/oracle-database/21/refrn/PLSQL_CCFLAGS.html
- https://docs.oracle.com/en/database/oracle/oracle-database/23/lnpls/autonomous-transactions.html
