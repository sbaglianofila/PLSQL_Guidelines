# Job Guard — precondizioni standardizzate per procedure PL/SQL

Documento di riferimento per l'implementazione di un meccanismo centralizzato di
precondizioni ("semafori") da valutare all'ingresso delle procedure batch.

Target: Oracle 19c come baseline. Nessuna dipendenza da feature 23ai.
Ambito: libreria di utility, non framework. Il gate non orchestra nulla e non
decide nulla al posto del chiamante: valuta e restituisce un verdetto.

---

## 1. Principi di design

Prima di guardare il codice conviene fissare le tre idee su cui l'intero
meccanismo si regge, perché sono anche i tre punti su cui è più facile
sbagliare rifacendolo a mano.

**Separazione fra valutazione, decisione e azione.** Il package di guardia
valuta le regole e produce un verdetto. Non scrive log applicativi, non solleva
eccezioni per conto proprio (con l'unica eccezione dell'errore di
configurazione), non fa `return` al posto del chiamante. È la procedura
chiamante che, ricevuto il verdetto, decide se uscire in silenzio o esplodere.
Questa separazione è ciò che rende il gate riusabile fra job con politiche
diverse: lo stesso identico check di finestra oraria può essere bloccante per un
job e informativo per un altro, senza toccare una riga di codice.

**Verdetto ternario, mai booleano.** Le decisioni possibili sono `RUN`, `SKIP`,
`ABORT`. La distinzione fra `SKIP` e `ABORT` è la ragione stessa di esistere di
questa libreria. "Non c'è niente da elaborare", "sono fuori finestra oraria",
"oggi è festivo" sono condizioni fisiologiche che devono terminare il job in
modo pulito e silenzioso; "il job predecessore è fallito", "manca il parametro
di configurazione", "sto girando sul database sbagliato" sono anomalie che
devono generare un errore visibile. Comprimendo tutto in un booleano si finisce
sempre in uno dei due fossi: o si soffocano gli errori veri, o si inonda di
falsi positivi chi presidia i batch di notte.

**Dispatch statico.** Il tipo di regola è un codice preso da un dominio chiuso,
e nel body c'è un `case` che mappa ogni codice a una funzione privata
compilata. Non si mettono nomi di funzione in tabella da eseguire con
`execute immediate`. Il prezzo di quella flessibilità è che si perdono le
dipendenze nel data dictionary, la compilazione smette di segnalare cosa si
rompe quando si rinomina qualcosa, e il debug diventa archeologia. Il livello
giusto di dinamicità è: *quali* regole valgono per *quale* job sta in tabella,
*come* si valuta una regola sta nel codice.

Da questi principi discende una regola operativa non negoziabile: **nessuna
funzione di check può avere effetti collaterali**. Niente `commit`, niente
`rollback`, niente DML, niente transazioni autonome, niente chiamate a servizi
esterni. Un check deve essere una interrogazione pura, richiamabile un numero
arbitrario di volte con lo stesso risultato. Se questa invariante salta, il gate
diventa esso stesso una sorgente di stato e non è più possibile ragionarci
sopra.

---

## 2. Modello dati

Tre tabelle. La prima è il dominio chiuso dei tipi di regola, che serve sia come
foreign key sia come documentazione dei parametri attesi.

```sql
create table job_guard_rule_type (
  rule_code      varchar2(30)   not null,
  description    varchar2(400)  not null,
  param_1_usage  varchar2(200),
  param_2_usage  varchar2(200),
  constraint job_guard_rule_type_pk primary key (rule_code)
);

insert into job_guard_rule_type values
 ('ENABLED',     'Il job risulta abilitato a parametro',
  'nome del parametro applicativo', null);
insert into job_guard_rule_type values
 ('ENVIRONMENT', 'Il database corrente e'' fra quelli ammessi',
  'elenco db_name separati da virgola', null);
insert into job_guard_rule_type values
 ('TIME_WINDOW', 'L''orario corrente ricade nella finestra ammessa',
  'ora inizio HH24:MI', 'ora fine HH24:MI');
insert into job_guard_rule_type values
 ('DAY_OF_WEEK', 'Il giorno corrente e'' fra quelli ammessi',
  'elenco 1-7 separato da virgola, 1=lunedi''', null);
insert into job_guard_rule_type values
 ('DEPENDENCY',  'Il job indicato e'' terminato con successo',
  'nome del job predecessore', 'validita'' in ore, default stessa data');
insert into job_guard_rule_type values
 ('DATA_READY',  'L''oggetto indicato contiene almeno una riga',
  'nome oggetto (deve essere in job_guard_object_wl)', null);
commit;
```

La seconda è l'associazione job → regole. La `severity` sta qui e non nel tipo,
proprio perché la stessa regola deve poter essere bloccante per un job e non per
un altro.

```sql
create table job_guard_rule (
  job_name     varchar2(128) not null,
  rule_seq     number(3)     not null,
  rule_code    varchar2(30)  not null,
  severity     varchar2(10)  not null,
  param_1      varchar2(200),
  param_2      varchar2(200),
  active_flag  varchar2(1) default 'Y' not null,
  note         varchar2(400),
  constraint job_guard_rule_pk  primary key (job_name, rule_seq),
  constraint job_guard_rule_fk1 foreign key (rule_code)
             references job_guard_rule_type (rule_code),
  constraint job_guard_rule_ck1 check (severity in ('SKIP','ABORT')),
  constraint job_guard_rule_ck2 check (active_flag in ('Y','N'))
);
```

La terza è il registro delle esecuzioni. Serve a due scopi distinti che è bene
tenere mentalmente separati: è la sorgente dati del check `DEPENDENCY`, ed è
l'audit trail dei job. **Non è** il meccanismo di mutua esclusione — su questo
si torna al paragrafo 6.

```sql
create table job_run (
  run_id        number generated always as identity,
  job_name      varchar2(128) not null,
  business_date date,
  status        varchar2(10)  not null,
  started_at    timestamp default systimestamp not null,
  ended_at      timestamp,
  sid           number,
  message       varchar2(4000),
  constraint job_run_pk  primary key (run_id),
  constraint job_run_ck1 check (status in ('RUNNING','SUCCESS','FAILED','SKIPPED'))
);

create index job_run_ix1 on job_run (job_name, business_date, status);
```

Infine una whitelist per il check `DATA_READY`, l'unico che richiede SQL
dinamico. Senza whitelist quel check è una porta aperta: chi ha accesso in
scrittura alla tabella delle regole ottiene di fatto esecuzione arbitraria.

```sql
create table job_guard_object_wl (
  object_name varchar2(128) not null,
  constraint job_guard_object_wl_pk primary key (object_name)
);
```

---

## 3. Package specification

```sql
create or replace package pkg_job_guard as
  /*
   * Valutazione centralizzata delle precondizioni di esecuzione dei job.
   * Nessuna funzione di questo package esegue DML o commit.
   */

  c_run   constant varchar2(10) := 'RUN';
  c_skip  constant varchar2(10) := 'SKIP';
  c_abort constant varchar2(10) := 'ABORT';

  c_sev_skip  constant varchar2(10) := 'SKIP';
  c_sev_abort constant varchar2(10) := 'ABORT';

  type t_verdict is record (
    decision      varchar2(10),
    failed_rules  varchar2(400),
    message       varchar2(4000)
  );

  /* Valuta tutte le regole attive del job e restituisce il verdetto
     composto. Non solleva eccezioni applicative, tranne ORA-20901 in caso
     di regola non gestita dal dispatch. */
  function evaluate (
    p_job_name in varchar2,
    p_ref_date in date default sysdate
  ) return t_verdict;

  /* Variante che solleva eccezione se la decisione non e' RUN.
     Da usare quando il chiamante non ha nulla da decidere. */
  procedure assert_can_run (
    p_job_name in varchar2,
    p_ref_date in date default sysdate
  );

  /* Restituisce la descrizione testuale delle regole configurate.
     Utile in diagnostica e nei test. */
  function describe (p_job_name in varchar2) return varchar2;

end pkg_job_guard;
/
```

Le due facce, `evaluate` e `assert_can_run`, coprono i due casi reali. La
funzione serve quando il chiamante deve distinguere lo `SKIP` dall'`ABORT`; la
procedura serve nei casi in cui qualunque precondizione non soddisfatta è un
errore e non ha senso scrivere tre righe di boilerplate.

---

## 4. Package body

```sql
create or replace package body pkg_job_guard as

  e_bad_config exception;
  pragma exception_init(e_bad_config, -20901);

  ---------------------------------------------------------------------------
  -- Check privati. Ciascuno restituisce TRUE/FALSE e valorizza o_message
  -- solo in caso di esito negativo.
  ---------------------------------------------------------------------------

  function chk_enabled (
    p_param_name in varchar2,
    o_message    out varchar2
  ) return boolean is
    l_value varchar2(200);
  begin
    -- Adattare alla tabella parametri effettiva dell'applicazione.
    select param_value into l_value
      from app_parameter
     where param_name = p_param_name;

    if upper(l_value) in ('Y','1','TRUE') then
      return true;
    end if;
    o_message := 'job disabilitato da parametro ' || p_param_name;
    return false;
  exception
    when no_data_found then
      raise_application_error(-20902,
        'Parametro di abilitazione inesistente: ' || p_param_name);
  end chk_enabled;


  function chk_environment (
    p_db_list in varchar2,
    o_message out varchar2
  ) return boolean is
    l_db varchar2(128) := sys_context('userenv','db_name');
  begin
    if ',' || upper(p_db_list) || ',' like '%,' || upper(l_db) || ',%' then
      return true;
    end if;
    o_message := 'database corrente ' || l_db ||
                 ' non ammesso (ammessi: ' || p_db_list || ')';
    return false;
  end chk_environment;


  function chk_time_window (
    p_from     in varchar2,
    p_to       in varchar2,
    p_ref_date in date,
    o_message  out varchar2
  ) return boolean is
    l_now  varchar2(4) := to_char(p_ref_date,'HH24MI');
    l_from varchar2(4) := replace(p_from,':');
    l_to   varchar2(4) := replace(p_to,':');
    l_ok   boolean;
  begin
    if l_from <= l_to then
      l_ok := l_now between l_from and l_to;
    else
      -- finestra a cavallo della mezzanotte
      l_ok := (l_now >= l_from) or (l_now <= l_to);
    end if;

    if not l_ok then
      o_message := 'fuori finestra oraria ' || p_from || '-' || p_to ||
                   ' (ora corrente ' || to_char(p_ref_date,'HH24:MI') || ')';
    end if;
    return l_ok;
  end chk_time_window;


  function chk_day_of_week (
    p_day_list in varchar2,
    p_ref_date in date,
    o_message  out varchar2
  ) return boolean is
    -- 'D' dipende da NLS_TERRITORY: si usa la differenza da un lunedi' noto.
    l_dow varchar2(1) :=
      to_char(trunc(p_ref_date) - trunc(p_ref_date,'IW') + 1);
  begin
    if ',' || p_day_list || ',' like '%,' || l_dow || ',%' then
      return true;
    end if;
    o_message := 'giorno della settimana ' || l_dow ||
                 ' non ammesso (ammessi: ' || p_day_list || ')';
    return false;
  end chk_day_of_week;


  function chk_dependency (
    p_dep_job    in varchar2,
    p_max_age_hh in varchar2,
    p_ref_date   in date,
    o_message    out varchar2
  ) return boolean is
    l_cnt number;
  begin
    if p_max_age_hh is null then
      -- semantica di default: successo nella stessa data di business
      select count(*) into l_cnt
        from job_run
       where job_name      = p_dep_job
         and status        = 'SUCCESS'
         and business_date = trunc(p_ref_date);
    else
      select count(*) into l_cnt
        from job_run
       where job_name = p_dep_job
         and status   = 'SUCCESS'
         and ended_at >= systimestamp
                         - numtodsinterval(to_number(p_max_age_hh),'HOUR');
    end if;

    if l_cnt > 0 then
      return true;
    end if;
    o_message := 'dipendenza non soddisfatta: ' || p_dep_job ||
                 ' senza esecuzione OK' ||
                 case when p_max_age_hh is null
                      then ' in data ' || to_char(trunc(p_ref_date),'dd/mm/yyyy')
                      else ' nelle ultime ' || p_max_age_hh || ' ore'
                 end;
    return false;
  end chk_dependency;


  function chk_data_ready (
    p_object_name in varchar2,
    o_message     out varchar2
  ) return boolean is
    l_wl  number;
    l_cnt number;
    l_obj varchar2(128);
  begin
    select count(*) into l_wl
      from job_guard_object_wl
     where object_name = upper(p_object_name);

    if l_wl = 0 then
      raise_application_error(-20903,
        'Oggetto non in whitelist DATA_READY: ' || p_object_name);
    end if;

    l_obj := dbms_assert.sql_object_name(upper(p_object_name));

    execute immediate
      'select count(*) from (select 1 from ' || l_obj || ' where rownum = 1)'
      into l_cnt;

    if l_cnt > 0 then
      return true;
    end if;
    o_message := 'nessun dato da elaborare su ' || p_object_name;
    return false;
  end chk_data_ready;

  ---------------------------------------------------------------------------
  -- Motore
  ---------------------------------------------------------------------------

  function evaluate (
    p_job_name in varchar2,
    p_ref_date in date default sysdate
  ) return t_verdict is
    l_v        t_verdict;
    l_ok       boolean;
    l_msg      varchar2(4000);
    l_abort    boolean := false;
    l_skip     boolean := false;
    l_prev_mod varchar2(64);
    l_prev_act varchar2(64);
  begin
    l_v.decision := c_run;

    pkg_app_context.save_module_action(l_prev_mod, l_prev_act);
    pkg_app_context.set_module('JOB_GUARD', p_job_name);

    for r in (select rule_seq, rule_code, severity, param_1, param_2
                from job_guard_rule
               where job_name    = p_job_name
                 and active_flag = 'Y'
               order by rule_seq)
    loop
      pkg_app_context.set_action(r.rule_code);
      l_msg := null;

      case r.rule_code
        when 'ENABLED'     then l_ok := chk_enabled(r.param_1, l_msg);
        when 'ENVIRONMENT' then l_ok := chk_environment(r.param_1, l_msg);
        when 'TIME_WINDOW' then l_ok := chk_time_window(r.param_1, r.param_2,
                                                        p_ref_date, l_msg);
        when 'DAY_OF_WEEK' then l_ok := chk_day_of_week(r.param_1,
                                                        p_ref_date, l_msg);
        when 'DEPENDENCY'  then l_ok := chk_dependency(r.param_1, r.param_2,
                                                       p_ref_date, l_msg);
        when 'DATA_READY'  then l_ok := chk_data_ready(r.param_1, l_msg);
        else
          raise_application_error(-20901,
            'Regola non gestita dal dispatch: ' || r.rule_code ||
            ' (job ' || p_job_name || ', seq ' || r.rule_seq || ')');
      end case;

      if not l_ok then
        if r.severity = c_sev_abort then
          l_abort := true;
        else
          l_skip := true;
        end if;
        l_v.failed_rules := substr(
          ltrim(l_v.failed_rules || ',' || r.rule_code, ','), 1, 400);
        l_v.message := substr(
          l_v.message || case when l_v.message is not null then '; ' end ||
          '[' || r.severity || '/' || r.rule_code || '] ' || l_msg, 1, 4000);
      end if;
    end loop;

    if    l_abort then l_v.decision := c_abort;
    elsif l_skip  then l_v.decision := c_skip;
    end if;

    pkg_app_context.restore_module_action(l_prev_mod, l_prev_act);
    return l_v;
  exception
    when others then
      pkg_app_context.restore_module_action(l_prev_mod, l_prev_act);
      raise;
  end evaluate;


  procedure assert_can_run (
    p_job_name in varchar2,
    p_ref_date in date default sysdate
  ) is
    l_v t_verdict;
  begin
    l_v := evaluate(p_job_name, p_ref_date);
    if l_v.decision <> c_run then
      raise_application_error(-20900,
        'Precondizioni non soddisfatte per ' || p_job_name ||
        ' [' || l_v.decision || ']: ' || l_v.message);
    end if;
  end assert_can_run;


  function describe (p_job_name in varchar2) return varchar2 is
    l_out varchar2(32767);
  begin
    for r in (select r.rule_seq, r.rule_code, r.severity, r.param_1,
                     r.param_2, r.active_flag, t.description
                from job_guard_rule r
                join job_guard_rule_type t on t.rule_code = r.rule_code
               where r.job_name = p_job_name
               order by r.rule_seq)
    loop
      l_out := l_out || r.rule_seq || '. ' || r.rule_code ||
               ' (' || r.severity || ')' ||
               case when r.active_flag = 'N' then ' [DISATTIVA]' end ||
               ' p1=' || nvl(r.param_1,'-') ||
               ' p2=' || nvl(r.param_2,'-') || chr(10);
    end loop;
    return nvl(l_out, 'Nessuna regola configurata per ' || p_job_name);
  end describe;

end pkg_job_guard;
/
```

Due scelte nel motore meritano una nota.

Il ramo `else` del `case` solleva eccezione invece di ignorare la regola. È
deliberato: garantisce che una riga inserita in tabella con un `rule_code` che
il codice non gestisce si manifesti subito e rumorosamente. Una regola fantasma
che non blocca nulla è peggio dell'assenza di regole, perché produce falsa
sicurezza. La foreign key verso `job_guard_rule_type` copre già il caso, ma la
difesa in profondità qui costa tre righe.

Il loop valuta **tutte** le regole attive e non si ferma alla prima che fallisce.
Costa qualche millisecondo e risparmia il gioco a rimbalzo in cui si sistema una
precondizione, si rilancia, se ne scopre un'altra, e così via per tre giri.

---

## 5. Integrazione nel chiamante

```sql
procedure carico_fatture is
  l_v pkg_job_guard.t_verdict;
begin
  l_v := pkg_job_guard.evaluate('CARICO_FATTURE');

  if l_v.decision = pkg_job_guard.c_skip then
    pkg_log.info('CARICO_FATTURE saltato: ' || l_v.message);
    return;

  elsif l_v.decision = pkg_job_guard.c_abort then
    raise_application_error(-20010,
      'CARICO_FATTURE bloccato: ' || l_v.message);
  end if;

  -- corpo effettivo del job
end carico_fatture;
```

Il gate va chiamato come **prima istruzione** della procedura, prima di
qualunque DML e prima dell'apertura di cursori. Se serve un contesto che il gate
non può calcolare da solo (una data di business derivata, per esempio), lo si
passa via `p_ref_date`, non lo si va a leggere dentro un check.

Esempio di configurazione corrispondente:

```sql
insert into job_guard_rule (job_name, rule_seq, rule_code, severity, param_1, param_2)
values ('CARICO_FATTURE', 10, 'ENVIRONMENT', 'ABORT', 'PRODDB,COLLDB', null);

insert into job_guard_rule (job_name, rule_seq, rule_code, severity, param_1, param_2)
values ('CARICO_FATTURE', 20, 'ENABLED',     'ABORT', 'CARICO_FATTURE_ENABLED', null);

insert into job_guard_rule (job_name, rule_seq, rule_code, severity, param_1, param_2)
values ('CARICO_FATTURE', 30, 'DEPENDENCY',  'ABORT', 'IMPORT_ANAGRAFICHE', null);

insert into job_guard_rule (job_name, rule_seq, rule_code, severity, param_1, param_2)
values ('CARICO_FATTURE', 40, 'TIME_WINDOW', 'SKIP',  '22:00', '05:00');

insert into job_guard_rule (job_name, rule_seq, rule_code, severity, param_1, param_2)
values ('CARICO_FATTURE', 50, 'DATA_READY',  'SKIP',  'STG_FATTURE', null);
commit;
```

Si noti l'ordine delle severità: le condizioni ambientali e di configurazione
sono `ABORT`, quelle di opportunità (finestra, presenza dati) sono `SKIP`. È il
partizionamento che funziona nella maggior parte dei casi reali.

---

## 6. Il caso a parte: mutua esclusione

"Non c'è già un'altra istanza in esecuzione" sembra una precondizione come le
altre, ma non lo è, e va tenuta fuori da `pkg_job_guard`. Tutti gli altri check
sono interrogazioni pure; questo **acquisisce una risorsa** che qualcuno dovrà
rilasciare. Infilandolo nel gate si ottengono due danni: il gate smette di
essere idempotente, e ci si ritrova con un lock acquisito senza un punto
naturale dove rilasciarlo.

Va quindi implementato come coppia esplicita `acquire`/`release` nel chiamante,
usando gli user lock e **non** una colonna di stato su tabella. La ragione è di
resilienza: un flag `RUNNING` su tabella sopravvive al crash della sessione e
blocca il job finché qualcuno non lo resetta a mano, tipicamente alle tre di
notte; uno user lock viene rilasciato dal database quando la sessione muore.

```sql
create or replace package pkg_job_lock as
  function  try_acquire (p_job_name in varchar2,
                         p_timeout  in number default 0) return boolean;
  procedure release (p_job_name in varchar2);
end pkg_job_lock;
/

create or replace package body pkg_job_lock as

  type t_handles is table of varchar2(128) index by varchar2(128);
  g_handles t_handles;

  function get_handle (p_job_name in varchar2) return varchar2 is
    l_handle varchar2(128);
  begin
    if g_handles.exists(p_job_name) then
      return g_handles(p_job_name);
    end if;
    -- ATTENZIONE: allocate_unique usa una transazione autonoma e committa.
    -- Va invocata all'inizio, prima di qualunque DML applicativa.
    dbms_lock.allocate_unique('JOB_' || p_job_name, l_handle);
    g_handles(p_job_name) := l_handle;
    return l_handle;
  end get_handle;

  function try_acquire (p_job_name in varchar2,
                        p_timeout  in number default 0) return boolean is
    l_res number;
  begin
    l_res := dbms_lock.request(
               lockhandle        => get_handle(p_job_name),
               lockmode          => dbms_lock.x_mode,
               timeout           => p_timeout,
               release_on_commit => false);
    case l_res
      when 0 then return true;   -- acquisito
      when 4 then return true;   -- gia' posseduto da questa sessione
      when 1 then return false;  -- timeout: lo tiene un altro
      when 3 then return false;  -- parametro errato / gia' in attesa
      else raise_application_error(-20904,
             'DBMS_LOCK.REQUEST rc=' || l_res || ' per ' || p_job_name);
    end case;
  end try_acquire;

  procedure release (p_job_name in varchar2) is
    l_res number;
  begin
    l_res := dbms_lock.release(get_handle(p_job_name));
  end release;

end pkg_job_lock;
/
```

Uso nel chiamante, con `release` in un handler che copre entrambe le uscite:

```sql
procedure carico_fatture is
  l_v pkg_job_guard.t_verdict;
begin
  if not pkg_job_lock.try_acquire('CARICO_FATTURE') then
    pkg_log.info('CARICO_FATTURE gia'' in esecuzione, uscita');
    return;
  end if;

  begin
    l_v := pkg_job_guard.evaluate('CARICO_FATTURE');
    -- ... gestione verdetto e corpo del job ...
    pkg_job_lock.release('CARICO_FATTURE');
  exception
    when others then
      pkg_job_lock.release('CARICO_FATTURE');
      raise;
  end;
end carico_fatture;
```

`job_run` resta comunque popolata, ma come registro di audit e come sorgente
del check `DEPENDENCY`. Non è il lucchetto.

---

## 7. Convenzioni

**Codici errore.** Il range `-20900 / -20909` è riservato alla libreria di
guardia e non va usato altrove:

| Codice  | Significato                                         |
|---------|-----------------------------------------------------|
| -20900  | Precondizioni non soddisfatte (`assert_can_run`)    |
| -20901  | Regola presente in tabella ma non gestita dal case  |
| -20902  | Parametro di abilitazione inesistente               |
| -20903  | Oggetto `DATA_READY` fuori whitelist                |
| -20904  | Errore inatteso su `DBMS_LOCK.REQUEST`              |

**Naming.** Oggetti con prefisso `job_guard_`, package `pkg_job_guard` e
`pkg_job_lock`, funzioni di check private con prefisso `chk_`. I `rule_code`
sono in maiuscolo, senza spazi, massimo 30 caratteri.

**Strumentazione.** `evaluate` imposta `module` = `'JOB_GUARD'`,
`action` = nome del job, poi `action` = `rule_code` prima di ogni check, con
ripristino dei valori precedenti all'uscita (anche in caso di eccezione). In
questo modo, su un check che pende, `v$session` mostra esattamente su quale
regola si è fermato.

**Estensione con un nuovo tipo di regola.** L'operazione richiede quattro passi,
tutti obbligatori: inserire la riga in `job_guard_rule_type` con la descrizione
dei parametri; scrivere la funzione `chk_*` privata nel body; aggiungere il ramo
al `case` di `evaluate`; scrivere il test case. Non esiste modo di aggiungere
una regola senza toccare il codice, ed è esattamente l'obiettivo.

---

## 8. Anti-pattern

Cose che questa libreria deliberatamente **non** fa, e che non vanno introdotte
in fase di integrazione.

Non esegue nomi di procedura letti da tabella tramite `execute immediate`. Il
solo SQL dinamico ammesso è il conteggio di `DATA_READY`, protetto da whitelist
e da `dbms_assert`.

Nessun check fa `commit`, `rollback` o DML. Se un check "ha bisogno" di scrivere
qualcosa, il requisito è mal posto: quella scrittura appartiene al chiamante.

Il gate non scrive su `job_run` e non invia notifiche. Restituisce un verdetto;
logging e alerting sono responsabilità del chiamante, che è l'unico a sapere se
uno `SKIP` merita una riga di log informativa o il silenzio.

Non si usa una colonna di stato su tabella come lock. Vedi paragrafo 6.

Non si accorpano `SKIP` e `ABORT` in un booleano, nemmeno "per ora", nemmeno
"tanto poi lo sistemiamo". È la distinzione da cui dipende l'intera utilità del
meccanismo.

---

## 9. Test da implementare

Casi minimi da coprire prima di considerare la libreria utilizzabile:

- job senza regole configurate → `RUN`
- solo regole `SKIP` fallite → `SKIP`, con `failed_rules` valorizzato
- almeno una `ABORT` fallita insieme a `SKIP` fallite → `ABORT`
- regola con `active_flag = 'N'` fallita → ignorata, verdetto `RUN`
- `TIME_WINDOW` a cavallo della mezzanotte, con `p_ref_date` a `23:30` e a
  `06:00`
- `TIME_WINDOW` con estremi coincidenti
- `DEPENDENCY` con predecessore in stato `FAILED` → fallisce
- `DEPENDENCY` con predecessore `SUCCESS` ma data di business precedente →
  fallisce
- `DATA_READY` su oggetto fuori whitelist → ORA-20903
- `rule_code` non gestito dal `case` (inserito disabilitando temporaneamente la
  FK) → ORA-20901
- `evaluate` chiamata due volte di seguito → stesso verdetto, nessun effetto
  collaterale osservabile
- `try_acquire` da due sessioni distinte → la seconda ottiene `false`
- `module` e `action` ripristinati ai valori precedenti dopo `evaluate`, sia in
  uscita normale sia dopo eccezione
