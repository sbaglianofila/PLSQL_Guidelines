prompt File: lib_calendar.pks.sql <start>
-- =============================================================================
-- File:     lib_calendar.pks.sql
-- Oggetto:  lib_calendar (specifica del package)
-- Schema:   #APP#
-- Scopo:    Calendario di business - un complemento genuino: Oracle non sa nulla
--           di giorni lavorativi e festività. Serve qualsiasi progetto con
--           scadenze, SLA o elaborazioni tipo "primo giorno lavorativo del mese".
--           Il weekend è sabato e domenica (indipendente dal locale); le festività
--           vengono da ref_holidays, opzionalmente per calendario.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260705  AA   Creazione
-- =============================================================================

prompt lib_calendar: Creating package specification

create or replace
package lib_calendar
is
--------------------------------------------------------------------------------
-- Vero quando la data non è né un weekend né una festività del calendario.
-- i_date     : data da testare (componente orario ignorata).
-- i_calendar : codice del calendario; default 'DEFAULT'.
-- return     : true quando è un giorno lavorativo.
function is_working_day(i_date in date, i_calendar in varchar2 default 'DEFAULT')
    return boolean;
--------------------------------------------------------------------------------
-- Primo giorno lavorativo strettamente dopo i_date.
function next_working_day(i_date in date, i_calendar in varchar2 default 'DEFAULT')
    return date;
--------------------------------------------------------------------------------
-- Ultimo giorno lavorativo strettamente prima di i_date.
function previous_working_day(i_date in date, i_calendar in varchar2 default 'DEFAULT')
    return date;
--------------------------------------------------------------------------------
-- Aggiunge i_days giorni lavorativi a i_date (negativo per andare indietro).
-- Weekend e festività sono saltati; un offset zero restituisce la data troncata
-- invariata.
-- i_date     : data di partenza.
-- i_days     : numero di giorni lavorativi da aggiungere (può essere negativo).
-- i_calendar : codice del calendario; default 'DEFAULT'.
-- return     : la data lavorativa risultante.
function add_working_days(i_date in date, i_days in number, i_calendar in varchar2 default 'DEFAULT')
    return date;
--------------------------------------------------------------------------------
-- Conteggio dei giorni lavorativi tra due date, esclusa la più vecchia e inclusa
-- la più recente; negativo quando i_to precede i_from.
-- i_from     : prima data.
-- i_to       : seconda data.
-- i_calendar : codice del calendario; default 'DEFAULT'.
-- return     : conteggio con segno dei giorni lavorativi.
function working_days_between(i_from in date, i_to in date, i_calendar in varchar2 default 'DEFAULT')
    return number;
--------------------------------------------------------------------------------

end lib_calendar;
/

show errors package lib_calendar

prompt File: lib_calendar.pks.sql <end>
