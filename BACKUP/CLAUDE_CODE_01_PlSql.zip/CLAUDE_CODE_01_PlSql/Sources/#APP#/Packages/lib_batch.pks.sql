prompt File: lib_batch.pks.sql <start>
-- =============================================================================
-- File:     lib_batch.pks.sql
-- Oggetto:  lib_batch (specifica del package)
-- Schema:   #APP#
-- Scopo:    Ciclo di vita dei processi batch. Dà a ogni run un'identità tracciata
--           su log_process_runs (inizio, fine, esito, contatori), così l'AM può
--           rispondere a "com'è andato il batch di stanotte?" con una query.
--           Imposta il module/action di sessione via lib_session e può tenere un
--           lock di istanza singola via lib_lock.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260705  AA   Creazione
-- =============================================================================

prompt lib_batch: Creating package specification

create or replace
package lib_batch
is
--------------------------------------------------------------------------------
-- Apre un run su log_process_runs e ne restituisce l'id. Strumenta la sessione
-- (module = nome del processo) e, quando i_single_instance è true, acquisisce un
-- lock non bloccante sul nome del processo, sollevando lib_err.e_already_running
-- se un altro run lo detiene.
-- i_process_name    : nome logico del processo.
-- i_single_instance : true per vietare run concorrenti dello stesso processo.
-- return            : il nuovo id del run.
function start_run( i_process_name    in varchar2
                  , i_single_instance in boolean default false
                  )
    return number;
--------------------------------------------------------------------------------
-- Chiude un run con un esito e delle statistiche, rilasciando il lock di istanza
-- singola se detenuto.
-- i_run_id         : run da chiudere.
-- i_status         : stato finale (SUCCESS di default).
-- i_rows_processed : righe elaborate con successo.
-- i_rows_rejected  : righe scartate.
procedure end_run( i_run_id         in number
                 , i_status         in varchar2 default 'SUCCESS'
                 , i_rows_processed in number default null
                 , i_rows_rejected  in number default null
                 );
--------------------------------------------------------------------------------
-- Chiude un run come FAILED, registrando l'errore corrente, e rilascia il lock di
-- istanza singola se detenuto. Pensata per essere chiamata da un exception
-- handler.
-- i_run_id        : run da chiudere.
-- i_error_message : testo dell'errore; default sqlerrm.
procedure fail_run(i_run_id in number, i_error_message in varchar2 default null);
--------------------------------------------------------------------------------
-- Registra l'avanzamento intermedio di un processo lungo: aggiorna l'action di
-- sessione e, quando fornito, il contatore delle righe elaborate.
-- i_run_id  : run in avanzamento.
-- i_step    : etichetta del passo corrente (pubblicata come action di sessione).
-- i_counter : conteggio progressivo delle righe elaborate, se tracciato.
procedure checkpoint(i_run_id in number, i_step in varchar2, i_counter in number default null);
--------------------------------------------------------------------------------

end lib_batch;
/

show errors package lib_batch

prompt File: lib_batch.pks.sql <end>
