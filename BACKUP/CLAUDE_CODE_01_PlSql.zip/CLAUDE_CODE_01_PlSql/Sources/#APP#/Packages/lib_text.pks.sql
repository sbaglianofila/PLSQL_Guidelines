prompt File: lib_text.pks.sql <start>
-- =============================================================================
-- File:     lib_text.pks.sql
-- Oggetto:  lib_text (specifica del package)
-- Schema:   #APP#
-- Scopo:    Helper di testo - solo ciò che Oracle non offre, o offre in modo
--           scomodo. Il package più a rischio di essere una brutta copia, da qui
--           l'elenco chiuso più severo. Esplicitamente fuori scope: wrapper di
--           upper/trim/lpad, is_number/is_date (esiste validate_conversion),
--           replace banali.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260705  AA   Creazione
-- =============================================================================

prompt lib_text: Creating package specification

create or replace
package lib_text
is
-- Collezione di stringhe, tipo di ritorno di split e input di join.
type t_strings_type is table of varchar2(4000 char);
--------------------------------------------------------------------------------
-- Divide una stringa in una collezione su un separatore (l'inverso di listagg,
-- che non ha una controparte nativa prima di APEX). Restituisce una collezione
-- vuota per input null; un singolo elemento quando il separatore è assente.
-- i_text      : stringa da dividere.
-- i_separator : separatore; default virgola.
-- return      : i pezzi, in ordine.
function split(i_text in varchar2, i_separator in varchar2 default ',')
    return t_strings_type;
--------------------------------------------------------------------------------
-- Unisce una collezione in una stringa con un separatore, per i casi in cui il
-- dato non è già in una query.
-- i_strings   : pezzi da unire.
-- i_separator : separatore; default virgola.
-- return      : la stringa unita.
function join(i_strings in t_strings_type, i_separator in varchar2 default ',')
    return varchar2;
--------------------------------------------------------------------------------
-- Sostituisce i segnaposto %1..%5 in un template. La primitiva generica dietro i
-- template dei messaggi.
-- i_template : template con segnaposto %1..%5.
-- i_p1..5    : valori di sostituzione.
-- return     : la stringa composta.
function format( i_template in varchar2
               , i_p1       in varchar2 default null
               , i_p2       in varchar2 default null
               , i_p3       in varchar2 default null
               , i_p4       in varchar2 default null
               , i_p5       in varchar2 default null
               )
    return varchar2;
--------------------------------------------------------------------------------
-- Normalizza il testo in un codice mnemonico: maiuscolo, accenti ripiegati,
-- sequenze di caratteri non alfanumerici ridotte a un singolo underscore e
-- trimmate.
-- i_text : testo da normalizzare.
-- return : il codice normalizzato.
function normalize_code(i_text in varchar2)
    return varchar2;
--------------------------------------------------------------------------------

end lib_text;
/

show errors package lib_text

prompt File: lib_text.pks.sql <end>
