prompt File: lib_config.pkb.sql <start>
-- =============================================================================
-- File:     lib_config.pkb.sql
-- Oggetto:  lib_config (corpo del package)
-- Schema:   #APP#
-- Scopo:    Accesso tipizzato e in cache a cfg_parameters con conversione
--           controllata ed errori parlanti dal catalogo lib_err.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260705  AA   Creazione
-- =============================================================================

prompt lib_config: Creating package body

create or replace
package body lib_config
is
-- Costanti --------------------------------------------------------------------
k_SCOPE       constant lib_types.scope_sbt := 'lib_config';
k_PARAM_ENV   constant lib_types.name_sbt  := 'ENVIRONMENT';
k_ENV_DEV     constant lib_types.code_sbt  := 'DEV';
k_ENV_PROD    constant lib_types.code_sbt  := 'PROD';
k_TYPE_NUMBER constant lib_types.code_sbt  := 'NUMBER';
k_TYPE_DATE   constant lib_types.code_sbt  := 'DATE';
k_TYPE_FLAG   constant lib_types.code_sbt  := 'FLAG';

-- Tipi ------------------------------------------------------------------------
-- Cache dei valori grezzi dei parametri, con chiave il nome.
type t_cache_type is table of cfg_parameters.param_value%type
    index by cfg_parameters.param_name%type;

-- Globali ---------------------------------------------------------------------
g_cache   t_cache_type;
g_loaded  boolean := false;

-- Moduli privati --------------------------------------------------------------
--------------------------------------------------------------------------------
procedure load_cache
-- Carica tutti i parametri nella cache in un'unica passata.
is
begin
    g_cache.delete;

    for r_param in ( select cfp.param_name
                          , cfp.param_value
                       from cfg_parameters cfp
                   )
    loop
        g_cache(r_param.param_name) := r_param.param_value;
    end loop;

    g_loaded := true;
end load_cache;
--------------------------------------------------------------------------------
function raw_value(i_name in varchar2, o_found out boolean)
    return varchar2
-- Restituisce il valore testuale grezzo di un parametro e se esiste.
-- i_name  : nome del parametro.
-- o_found : impostato a true quando il parametro esiste.
-- return  : il valore grezzo memorizzato (può essere null).
is
begin
    if ( not g_loaded )
    then
        load_cache;
    end if;

    o_found := g_cache.exists(i_name);

    if ( o_found )
    then
        return (g_cache(i_name));
    else
        return (null);
    end if;
end raw_value;
--------------------------------------------------------------------------------

-- Moduli pubblici -------------------------------------------------------------
--------------------------------------------------------------------------------
function get_string(i_name in varchar2, i_default in varchar2 default null)
    return varchar2
-- Getter stringa: applica la convenzione obbligatorio/default e la cache.
is
    l_found  boolean;
    l_value  cfg_parameters.param_value%type;
begin
    l_value := raw_value(i_name => i_name, o_found => l_found);

    if ( not l_found )
    then
        if ( i_default is not null )
        then
            return (i_default);
        end if;

        lib_err.raise(i_error => lib_err.k_CONFIG_PARAM_MISSING, i_p1 => i_name, i_scope => k_SCOPE);
    end if;

    return (l_value);
end get_string;
--------------------------------------------------------------------------------
function get_number(i_name in varchar2, i_default in number default null)
    return number
-- Getter numerico: conversione controllata, errore parlante se non è un numero.
is
    l_str  cfg_parameters.param_value%type := get_string(i_name => i_name, i_default => to_char(i_default));
    l_num  number;
begin
    if ( l_str is null )
    then
        return (i_default);
    end if;

    l_num := to_number(l_str default null on conversion error);

    if ( l_num is null )
    then
        lib_err.raise( i_error => lib_err.k_CONFIG_PARAM_INVALID
                     , i_p1    => i_name
                     , i_p2    => k_TYPE_NUMBER
                     , i_p3    => l_str
                     , i_scope => k_SCOPE
                     );
    end if;

    return (l_num);
end get_number;
--------------------------------------------------------------------------------
function get_date(i_name in varchar2, i_default in date default null)
    return date
-- Getter data: conversione con k_DATE_FMT, errore parlante se non è una data.
is
    -- FX è solo un modificatore di to_date; lo si toglie per il to_char del default.
    l_str   cfg_parameters.param_value%type := get_string( i_name    => i_name
                                                         , i_default => to_char(i_default, replace(lib_constants.k_DATE_FMT, 'FX'))
                                                         );
    l_date  date;
begin
    if ( l_str is null )
    then
        return (i_default);
    end if;

    l_date := to_date(l_str default null on conversion error, lib_constants.k_DATE_FMT);

    if ( l_date is null )
    then
        lib_err.raise( i_error => lib_err.k_CONFIG_PARAM_INVALID
                     , i_p1    => i_name
                     , i_p2    => k_TYPE_DATE
                     , i_p3    => l_str
                     , i_scope => k_SCOPE
                     );
    end if;

    return (l_date);
end get_date;
--------------------------------------------------------------------------------
function get_flag(i_name in varchar2, i_default in varchar2 default null)
    return varchar2
-- Getter flag ('Y'/'N'): errore parlante se il valore memorizzato è diverso.
is
    l_flag  cfg_parameters.param_value%type := get_string(i_name => i_name, i_default => i_default);
begin
    if ( l_flag is not null
         and l_flag not in (lib_constants.k_YES, lib_constants.k_NO) )
    then
        lib_err.raise( i_error => lib_err.k_CONFIG_PARAM_INVALID
                     , i_p1    => i_name
                     , i_p2    => k_TYPE_FLAG
                     , i_p3    => l_flag
                     , i_scope => k_SCOPE
                     );
    end if;

    return (l_flag);
end get_flag;
--------------------------------------------------------------------------------
procedure set_value(i_name in varchar2, i_value in varchar2)
-- Unica via di scrittura: cattura il valore precedente, aggiorna, logga la
-- modifica e invalida la cache. Non fa commit.
is
    l_previous  cfg_parameters.param_value%type;
begin
    -- Cattura il valore precedente di un parametro modificabile; valida anche
    -- che il parametro esista e sia modificabile.
    begin
        select cfp.param_value
          into l_previous
          from cfg_parameters cfp
         where cfp.param_name    = i_name
           and cfp.is_modifiable = lib_constants.k_YES
           for update of cfp.param_value;
    exception
        when no_data_found
        then
            lib_err.raise(i_error => lib_err.k_CONFIG_PARAM_MISSING, i_p1 => i_name, i_scope => k_SCOPE);
    end;

    update cfg_parameters cfp
       set cfp.param_value = i_value
     where cfp.param_name  = i_name;

    lib_logging.log_info( i_text  =>    'Parameter ' || i_name
                                     || ' changed from [' || l_previous || '] to [' || i_value || ']'
                        , i_scope => k_SCOPE
                        );

    -- Il valore memorizzato è cambiato: forza un reload alla lettura successiva.
    g_loaded := false;
end set_value;
--------------------------------------------------------------------------------
function environment
    return varchar2
-- Codice dell'ambiente dal parametro ENVIRONMENT; default DEV.
is
begin
    return (get_string(i_name => k_PARAM_ENV, i_default => k_ENV_DEV));
end environment;
--------------------------------------------------------------------------------
function is_production
    return boolean
-- Vero solo quando environment = 'PROD'.
is
begin
    return (environment = k_ENV_PROD);
end is_production;
--------------------------------------------------------------------------------
procedure refresh
-- Svuota la cache: la lettura successiva ricarica da cfg_parameters.
is
begin
    g_loaded := false;
end refresh;
--------------------------------------------------------------------------------

end lib_config;
/

show errors package body lib_config

prompt File: lib_config.pkb.sql <end>
