prompt File: lib_mail_engine.apex.pkb.sql <start>
-- =============================================================================
-- File:     lib_mail_engine.apex.pkb.sql
-- Oggetto:  lib_mail_engine (corpo del package - motore APEX_MAIL)
-- Schema:   #APP#
-- Scopo:    Implementazione APEX_MAIL di lib_mail_engine. Installa QUESTO body
--           OPPURE lib_mail_engine.utl_smtp.pkb.sql, mai entrambi. Usa lo stack
--           mail di APEX (impostazioni SMTP configurate in APEX Instance
--           Administration). Prerequisiti: APEX installato, apex_mail eseguibile
--           dall'owner, e - per girare fuori da una sessione APEX (es. un job
--           batch) - un contesto di workspace, preso dal parametro di
--           configurazione opzionale MAIL_APEX_WORKSPACE.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260705  AA   Creazione
-- =============================================================================

prompt lib_mail_engine (APEX_MAIL): Creating package body

create or replace
package body lib_mail_engine
is
-- Costanti --------------------------------------------------------------------
k_SCOPE           constant lib_types.scope_sbt := 'lib_mail_engine';
k_BACKEND         constant varchar2(9 char)    := 'APEX_MAIL';
k_PARAM_WORKSPACE constant lib_types.name_sbt  := 'MAIL_APEX_WORKSPACE';
k_HTML_FALLBACK   constant varchar2(80 char)   := 'This message requires an HTML-capable email client.';

-- Moduli privati --------------------------------------------------------------
--------------------------------------------------------------------------------
procedure ensure_context
-- Stabilisce il contesto di workspace APEX quando MAIL_APEX_WORKSPACE è
-- configurato, così apex_mail può girare fuori da una sessione APEX.
is
    k_WORKSPACE  constant varchar2(256 char) := lib_config.get_string(k_PARAM_WORKSPACE, i_default => null);
begin
    if ( k_WORKSPACE is not null )
    then
        apex_util.set_workspace(p_workspace => k_WORKSPACE);
    end if;
end ensure_context;
--------------------------------------------------------------------------------

-- Moduli pubblici -------------------------------------------------------------
--------------------------------------------------------------------------------
function backend
    return varchar2
-- Identificatore del motore.
is
begin
    return (k_BACKEND);
end backend;
--------------------------------------------------------------------------------
procedure deliver( i_from    in varchar2
                 , i_to      in varchar2
                 , i_cc      in varchar2
                 , i_bcc     in varchar2
                 , i_subject in varchar2
                 , i_body    in clob
                 , i_is_html in boolean
                 )
-- Trasmette via apex_mail.send (variante HTML o testo) e forza la consegna.
is
    l_mail_id  number;
begin
    ensure_context;

    if ( i_is_html )
    then
        l_mail_id := apex_mail.send( p_to        => i_to
                                   , p_from      => i_from
                                   , p_body      => to_clob(k_HTML_FALLBACK)
                                   , p_body_html => i_body
                                   , p_subj      => i_subject
                                   , p_cc        => i_cc
                                   , p_bcc       => i_bcc
                                   );
    else
        l_mail_id := apex_mail.send( p_to    => i_to
                                   , p_from  => i_from
                                   , p_body  => i_body
                                   , p_subj  => i_subject
                                   , p_cc    => i_cc
                                   , p_bcc   => i_bcc
                                   );
    end if;

    -- Forza la consegna immediata; lib_mail fornisce già la coda sopra.
    apex_mail.push_queue;
exception
    when others
    then
        lib_err.raise(i_error => lib_err.k_MAIL_SEND_FAILED, i_p1 => sqlerrm, i_scope => k_SCOPE);
end deliver;
--------------------------------------------------------------------------------

end lib_mail_engine;
/

show errors package body lib_mail_engine

prompt File: lib_mail_engine.apex.pkb.sql <end>
