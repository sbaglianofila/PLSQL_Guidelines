prompt File: cfg_error_messages.dat.sql <start>
-- =============================================================================
-- File:     cfg_error_messages.dat.sql
-- Object:   Seed data for cfg_error_messages
-- Schema:   #APP#
-- Purpose:  Baseline message templates for the lib_err catalog codes. One row
--           per k_ constant declared in lib_err; the numeric codes and their
--           named exceptions live in the lib_err specification, the text lives
--           here so it can be corrected at runtime. Infrastructure band
--           (-20000..-20099). Functional-domain messages (bands from -20100 on)
--           are seeded by each project alongside their own error codes.
-- Note:     Uses MERGE so the script is idempotent and safe to re-run. The merge
--           does not overwrite an existing template, only inserts missing rows,
--           so runtime corrections are preserved on re-run.
-- -----------------------------------------------------------------------------
-- Changelog (authoritative history: version control)
--   Date      Aut  Change
--   20260708  AA   Creation
-- =============================================================================

whenever sqlerror exit failure rollback

prompt cfg_error_messages: Seeding rows
merge into cfg_error_messages t
using ( select -20000 as error_code, 'INVALID_PARAMETER'     as error_name, 'Invalid parameter %1: %2'                        as message_template from dual
        union all
        select -20001, 'STALE_DATA',            'Data was modified by another session; please retry.'    from dual
        union all
        select -20002, 'LOCK_REQUEST_FAILED',   'Could not acquire application lock %1.'                  from dual
        union all
        select -20003, 'ALREADY_RUNNING',       'Process %1 is already running.'                          from dual
        union all
        select -20004, 'CONFIG_PARAM_MISSING',  'Configuration parameter %1 not found.'                   from dual
        union all
        select -20005, 'CONFIG_PARAM_INVALID',  'Configuration parameter %1 is not a valid %2: %3'        from dual
        union all
        select -20006, 'INVALID_TABLE_NAME',    'Invalid table name: %1'                                  from dual
        union all
        select -20007, 'PARAM_TOO_LARGE',       'Parameter %1 exceeds the maximum allowed size.'          from dual
        union all
        select -20008, 'INVALID_FILENAME',      'Invalid file name: %1'                                   from dual
        union all
        select -20009, 'FILE_NOT_FOUND',        'File %1 not found in directory %2.'                       from dual
        union all
        select -20010, 'MAIL_SEND_FAILED',      'Mail send failed: %1'                                     from dual
        union all
        select -20011, 'MAIL_TEMPLATE_MISSING', 'Email template %1 not found.'                             from dual
        union all
        select -20012, 'FILE_IO_ERROR',         'File I/O error on %1/%2: %3'                              from dual
        union all
        select -20013, 'REPORT_NOT_FOUND',      'Report %1 not found.'                                     from dual
        union all
        select -20099, 'UNEXPECTED',            'Unexpected error: %1'                                     from dual
        union all
        select -20014, 'NOT_ALLOWED',           'Operation not allowed: %1'                                from dual
        union all
        select -20999, 'BUSINESS_ERROR',        'Business error: %1'                                       from dual
      ) s
   on (t.error_code = s.error_code)
 when not matched then
    insert (  t.error_code
            , t.error_name
            , t.message_template
           )
    values (  s.error_code
            , s.error_name
            , s.message_template
           );

prompt cfg_error_messages: Committing seed data
commit;

prompt File: cfg_error_messages.dat.sql <end>
