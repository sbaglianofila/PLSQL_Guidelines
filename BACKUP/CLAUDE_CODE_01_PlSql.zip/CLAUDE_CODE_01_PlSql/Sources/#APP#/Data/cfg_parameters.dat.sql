prompt File: cfg_parameters.dat.sql <start>
-- =============================================================================
-- File:     cfg_parameters.dat.sql
-- Oggetto:  Dati di seed / configurazione per cfg_parameters
-- Schema:   #APP#
-- Scopo:    Parametri di base consumati dai package di libreria. ENVIRONMENT è di
--           solo provisioning (is_modifiable = N) e va impostato al valore reale
--           (DEV/TEST/PROD) per ciascun ambiente. I parametri di logging sono
--           modificabili a runtime tramite lib_config.set_value.
-- Nota:     Usa MERGE così lo script è idempotente e rieseguibile senza rischi. Il
--           merge non sovrascrive un valore esistente, inserisce solo le righe
--           mancanti, così le modifiche per ambiente sono preservate a ogni ri-esecuzione.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260705  AA   Creazione
--   20260720  AA   Aggiunta param_group ai parametri seminati (GENERAL/LOGGING/MAIL).
--                  Il merge resta insert-only: il backfill delle righe già
--                  presenti è in cfg_parameters.20260720_01.alt.sql
-- =============================================================================

whenever sqlerror exit failure rollback

prompt cfg_parameters: Seeding rows
merge into cfg_parameters t
using ( select 'ENVIRONMENT'         as param_name
             , 'GENERAL'             as param_group
             , 'DEV'                 as param_value
             , 'STRING'              as param_type
             , 'Environment identity (DEV/TEST/PROD); set at provisioning.' as description
             , 'N'                   as is_modifiable
          from dual
        union all
        select 'LOG_MIN_LEVEL'
             , 'LOGGING'
             , 'INFO'
             , 'STRING'
             , 'Minimum level written by lib_logging: DEBUG, INFO or WARN.'
             , 'Y'
          from dual
        union all
        select 'LOG_RETENTION_DAYS'
             , 'LOGGING'
             , '90'
             , 'NUMBER'
             , 'Age in days beyond which lib_logging.purge deletes log rows.'
             , 'Y'
          from dual
        union all
        select 'MAIL_ENABLED'
             , 'MAIL'
             , 'N'
             , 'FLAG'
             , 'Master switch: lib_mail.process_queue delivers only when Y.'
             , 'Y'
          from dual
        union all
        select 'MAIL_FROM_DEFAULT'
             , 'MAIL'
             , 'no-reply@example.com'
             , 'STRING'
             , 'Default sender address used by lib_mail when none is supplied.'
             , 'Y'
          from dual
        union all
        select 'MAIL_TEST_RECIPIENT'
             , 'MAIL'
             , 'devnull@example.com'
             , 'STRING'
             , 'Mailbox all non-production mail is redirected to by the lib_mail environment guard.'
             , 'Y'
          from dual
        union all
        select 'MAIL_SMTP_HOST'
             , 'MAIL'
             , 'localhost'
             , 'STRING'
             , 'SMTP server host (UTL_SMTP engine only).'
             , 'Y'
          from dual
        union all
        select 'MAIL_SMTP_PORT'
             , 'MAIL'
             , '25'
             , 'NUMBER'
             , 'SMTP server port (UTL_SMTP engine only).'
             , 'Y'
          from dual
        union all
        select 'MAIL_MAX_ATTEMPTS'
             , 'MAIL'
             , '3'
             , 'NUMBER'
             , 'Delivery attempts before lib_mail marks a queued message FAILED.'
             , 'Y'
          from dual
        union all
        select 'MAIL_RETRY_BACKOFF_MIN'
             , 'MAIL'
             , '5'
             , 'NUMBER'
             , 'Base minutes between delivery retries (multiplied by attempt number).'
             , 'Y'
          from dual
        union all
        select 'MAIL_APEX_WORKSPACE'
             , 'MAIL'
             , cast(null as varchar2(1))
             , 'STRING'
             , 'APEX workspace for apex_mail outside an APEX session (APEX_MAIL engine only); leave empty otherwise.'
             , 'Y'
          from dual
      ) s
   on (t.param_name = s.param_name)
 when not matched then
    insert (  t.param_name
            , t.param_group
            , t.param_value
            , t.param_type
            , t.description
            , t.is_modifiable
           )
    values (  s.param_name
            , s.param_group
            , s.param_value
            , s.param_type
            , s.description
            , s.is_modifiable
           );

prompt cfg_parameters: Committing seed data
commit;

prompt File: cfg_parameters.dat.sql <end>
