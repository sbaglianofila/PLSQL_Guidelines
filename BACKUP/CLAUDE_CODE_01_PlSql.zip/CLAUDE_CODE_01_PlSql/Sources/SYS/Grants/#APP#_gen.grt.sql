prompt File: #APP#_gen.grt.sql <start>
-- =============================================================================
-- File:     #APP#_gen.grt.sql
-- Oggetto:  Privilegi di sistema e dizionario per #APP#_GEN (SOLO DEV/TEST)
-- Schema:   eseguire come utente privilegiato / DBA
-- Scopo:    Al tooling si concede: CREATE SESSION; i privilegi per creare i
--           propri oggetti di generazione; e i privilegi di dizionario per
--           introspezionare i metadati. NON riceve alcun privilegio di DDL
--           sull'owner (nessun CREATE ANY): legge ed emette artefatti, non
--           scrive su #APP# (vedi schemi.md).
-- Nota:     VINCOLO D'AMBIENTE: si esegue SOLO in sviluppo/test. I privilegi di
--           dizionario ampi non hanno ragione di stare in produzione, dove
--           questo schema non deve esistere.
-- -----------------------------------------------------------------------------
-- Changelog (la storia autorevole è nel version control)
--   Data      Aut  Modifica
--   20260719  AA   Creazione
-- =============================================================================

prompt #APP#_gen: Grant CREATE SESSION
grant create session to #APP#_gen;

prompt #APP#_gen: Grant di creazione dei propri oggetti di generazione
grant create procedure, create table, create view to #APP#_gen;

prompt #APP#_gen: Grant di introspezione del dizionario
grant select_catalog_role   to #APP#_gen;
grant select any dictionary to #APP#_gen;

prompt File: #APP#_gen.grt.sql <end>
