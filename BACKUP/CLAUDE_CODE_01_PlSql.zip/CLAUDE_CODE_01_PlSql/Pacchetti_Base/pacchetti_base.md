# Pacchetti base — catalogo e linee di contenuto

Questo documento è il catalogo ragionato dei package PL/SQL di base che accompagnano la partenza di un progetto costruito su questa base. Per ciascun package indica lo scopo, il contenuto atteso in forma di sottoprogrammi rappresentativi, le tabelle di appoggio e i prerequisiti di provisioning. Non è ancora la specifica esecutiva: è la mappa da cui attingere quando si realizzano i package, pensata per essere generosa — meglio depennare un'idea che scoprirne la mancanza a progetto avviato. Le priorità di realizzazione sono in fondo.

Il documento va letto insieme alle guidelines: i package qui elencati sono esattamente quelli che gli esempi dei capitoli 04–12 danno già per esistenti (`lib_types`, `lib_constants`, `lib_err`, `lib_logging`, `lib_lock`), più i servizi che completano una base di progetto. Realizzarli significa rendere effettivamente applicabili le regole che oggi li citano.

## Il principio: complemento, non copia

La trappola classica dei package di utilità è la brutta copia di Oracle: il `lib_date.to_date` che fa una `to_date`, il `lib_number.is_number` che riscrive ciò che `validate_conversion` fa nativamente dal 12c, il wrapper uno-a-uno su `dbms_scheduler` che aggiunge un livello di indirezione senza aggiungere valore. Questi package sembrano produttività e sono debito: vanno mantenuti, documentati e imparati, e l'unica cosa che offrono è una firma diversa per una funzione che esisteva già.

La regola di ammissione al set di base è quindi questa: **un sottoprogramma entra in un package base solo se fa qualcosa che Oracle non fa, o se combina più primitive Oracle in un comportamento di progetto** (convenzioni, logging, configurazione, guardie d'ambiente). Prima di scrivere una utility si verifica cosa offre già il dizionario delle funzioni SQL e dei package `DBMS_*`/`UTL_*`; se esiste l'equivalente nativo, si usa quello e il wrapper non si scrive.

Per fissare il confine, alcuni esempi concreti di ciò che **non** va scritto:

- niente wrapper di conversione: `to_date`/`to_char`/`to_number` con formato esplicito e `default ... on conversion error` (capitolo 12 delle guidelines) coprono già tutto, inclusa la validazione (`validate_conversion`);
- niente doppioni di funzioni stringa o data native (`initcap`, `trim`, `add_months`, `last_day`, `months_between`, `next_day`);
- niente reimplementazioni JSON: dalla 19c le API native (`json_object_t`, `json_array_t`, funzioni SQL/JSON) sono complete;
- niente wrapper passacarte su `dbms_scheduler`, `dbms_output`, `dbms_utility`: si chiamano direttamente, qualificati con `sys.`;
- niente "librerie matematiche": `round`, `trunc`, `mod`, `floor` esistono già; una funzione di arrotondamento entra solo se incorpora una *regola di business* (es. arrotondamento fiscale).

Il valore dei package base sta altrove: nel dare al progetto un modo **unico e osservabile** di trattare errori, log, configurazione, lock, batch, file e mail — le cose che ogni progetto reinventa in modo diverso se nessuno le standardizza.

## Regole trasversali

Alcune regole valgono per tutti i package del set, e conviene fissarle prima del catalogo.

I package base vivono nello **schema owner** `#APP#` e, salvo eccezioni dichiarate, **non vengono grantati** ai consumer: sono infrastruttura interna usata dalle API applicative, non superficie esposta. Per questo non richiedono lo sdoppiamento logica/guscio, che è riservato a ciò che si granta; se un giorno un package base dovesse essere esposto (ad esempio una funzione di `lib_report` invocabile dal batch), per quella sola parte si applica il meccanismo guscio come per qualsiasi API (la logica tiene il nome pulito, il guscio grantato prende il suffisso `_shell`).

Ogni package rispetta le guidelines senza sconti: prefisso `lib_` con nome esteso per i package di libreria (i package operativi usano invece `pkg_`, con la logica dal nome pulito e il guscio esposto `_shell`), parametri `i_`/`o_`/`io_`, costanti `k_MAIUSCOLE`, sottotipi `_sbt`, nessuna variabile pubblica nella spec (stato nel body con getter/setter), commento di documentazione prima dell'`is` di ogni sottoprogramma. Ogni package nasce con la sua **suite utPLSQL** (`test_<nome>`) e, dove ha tabelle di appoggio, con i relativi file baseline, seed e query di controllo: un package base senza test è un controsenso, dato che è il codice più riusato del progetto.

Le **dipendenze sono a strati e vanno in una sola direzione**: le fondamenta (tipi, costanti, errori, log) non dipendono da nulla; i servizi dipendono dalle fondamenta; le integrazioni dipendono dai servizi. Un package di fondamenta che chiama `lib_mail` è un errore di architettura — se il logging deve notificare via mail, è un processo schedulato a leggere i log e a spedirli, non il logger a conoscere la posta.

---

## Livello 0 — Fondamenta

Sono i package senza i quali gli altri non si scrivono. Non hanno dipendenze reciproche se non, al più, verso `lib_types` e `lib_constants`.

### `lib_types` — sottotipi condivisi

Sola specifica, senza body: raccoglie i sottotipi `_sbt` trasversali al progetto, allineati ai domini di `Catalogo/domini.md`. È il package più citato dalle guidelines ed è deliberatamente piccolo: un sottotipo entra solo se rappresenta un concetto ricorrente, non "per completezza".

- Sottotipi testuali per taglia: `code_sbt`, `name_sbt`, `short_text_sbt`, `text_sbt`, `big_string_sbt` (dimensioni coerenti con i domini `code`, `name`, `description`, `note`);
- sottotipi tecnici usati dai package base: `lock_name_sbt`, `lock_handle_sbt`, `scope_sbt` (per il logging), `percentage_sbt`, `flag_sbt` (`Y`/`N` pre-23ai);
- eventuali sottotipi numerici di dominio (`amount_sbt`, `quantity_sbt`) quando il progetto li adotta.

### `lib_constants` — costanti di progetto

Il punto unico per i valori letterali trasversali, secondo la regola del capitolo 04 delle guidelines, con le funzioni `deterministic` che espongono al SQL le costanti che servono anche nelle query. Contiene solo costanti davvero trasversali: i valori di stato di una singola entità di business stanno nel package API di quell'entità, non qui.

- Valori dei flag (`k_YES`/`k_NO`), formati data canonici del progetto (`k_DATE_FMT`, `k_TIMESTAMP_FMT`, sempre con `FX` dove usati in conversione);
- soglie e limiti condivisi (dimensione dei batch bulk, durata di default dei lock, giorni di retention dei log);
- per ogni costante necessaria in SQL, la corrispondente funzione deterministica (`function yes return varchar2 deterministic`).

Vale la pena chiarire un dubbio che ricorre: **serve una tabella "costanti" a database?** No, e conviene dire perché, perché la domanda torna. L'asse che conta non è *dove* vive il valore — codice o DB — ma **chi lo possiede e quando può cambiare**; e su quell'asse le tre case esistono già. Ciò che il codice dà per scontato e il cui cambiamento *è* un evento di rilascio sta in `lib_constants`: lì hai il controllo del compilatore (un nome sbagliato non compila), costo di lettura nullo e — dove serve in una query — l'esposizione a SQL già risolta dalle funzioni deterministiche, senza bisogno di alcuna tabella. Ciò che l'esercizio deve poter cambiare senza rilascio, o che varia per ambiente, sta in `cfg_parameters`, con tipi, cache, unica via di scrittura e la governance di `is_modifiable`. Ciò che è uno di un *insieme* di valori di dominio ammessi sta nelle lookup `ref_lookups`/`ref_lookup_values`. Una quarta tabella di costanti sarebbe per forza o un doppione più debole di `cfg_parameters` (se i valori sono mutabili) o una `lib_constants` peggiore (se sono immutabili: perderesti il controllo del compilatore e ti ritroveresti una "costante" che chiunque può `UPDATE`-are — cioè non più una costante). La regola di smistamento è quindi una sola domanda: se il codice dipende dal valore esatto e cambiarlo è un rilascio va in `lib_constants`; se lo tara l'esercizio senza rilascio, o varia per ambiente, va in `cfg_parameters`; se è uno di un insieme di valori ammessi, va in una lookup. In breve: **`lib_constants` per l'immutabile, `cfg_parameters` per il configurabile** — la linea non è codice-contro-DB.

### `lib_err` — catalogo e motore degli errori

Il package che le guidelines usano in tutti gli esempi (`lib_err.raise(i_error => lib_err.k_...)`, `when lib_err.e_lock_request_failed`). Tiene insieme in un solo oggetto il **catalogo** — codici ed eccezioni con nome, dichiarati nella specifica — e il **motore** — le procedure che sollevano, arricchiscono e rilanciano, implementate nel body.

Il principio che tiene i codici pochi: **un `-20xxx` è un *meccanismo di segnalazione*, non l'identità di un messaggio.** Da qui due livelli:

- pochi **codici dedicati** con eccezione con nome, uno per ogni condizione che un chiamante può dover intercettare e su cui ramificare (`k_INVALID_PARAMETER`, `k_STALE_DATA`, i codici dei lock, `k_NOT_ALLOWED`, `k_UNEXPECTED`...); il loro messaggio fisso vive come dato in `cfg_error_messages` (righe `APP`);
- un unico codice generico **`k_BUSINESS_ERROR` (`-20999`)** sotto cui si sollevano **tutti** i tanti messaggi di dominio, la cui identità è il **`message_code`** (in `cfg_messages`), non il numero. Così un'applicazione ha messaggi illimitati senza consumare lo spazio scarso dei `-20xxx`.

Contenuto del body (il motore):

- `raise(i_error, i_p1, ...)` — solleva un **codice dedicato** col suo messaggio fisso dal catalogo; è l'unico punto (con `raise_msg`) che chiama `raise_application_error`;
- `raise_msg(i_message_code, i_p1, ..., i_error => k_BUSINESS_ERROR)` — solleva un **messaggio di dominio** identificato dal suo `message_code`: compone il testo da `cfg_messages` (via `lib_logging.message_of`) e lo segnala sotto `BUSINESS_ERROR` per default, oppure sotto uno dei codici dedicati quando quel caso specifico deve restare intercettabile per nome. È la via che il codice di dominio usa nella stragrande maggioranza dei casi; i `message_code` si tengono come costanti in package `*_msg_codes`;
- `reraise` — rilancia l'eccezione corrente preservando lo stack, dopo il log;
- `message_of(i_error)` — restituisce il messaggio composto di un codice dedicato, per chi deve mostrarlo senza sollevare;
- integrazione fissa con `lib_logging`: ogni `raise`/`raise_msg` registra l'errore con backtrace prima di sollevarlo, così il log è completo anche se il chiamante ingoia l'eccezione.

I codici dedicati sono per natura **di infrastruttura** e li possiedono i package base (`lib_lock`/`lib_batch` i lock, `lib_config` la config, `lib_assert` i parametri, il futuro `lib_authz` `NOT_ALLOWED`); il codice di dominio, salvo i pochi casi da intercettare, passa sempre da `raise_msg` + `BUSINESS_ERROR`. Questo rende superflua la vecchia assegnazione dei `-20xxx` per fasce di dominio.

### `lib_logging` — logging strutturato

Il motore di tracciamento su cui poggiano diagnosi e query di controllo: scrive su tabelle `log_*` in **transazione autonoma** (l'unico uso legittimo del pragma, capitolo 06), così che il log sopravviva al rollback della transazione applicativa. È il pezzo che rende leggibile "cosa è successo" in esercizio, ed è il presupposto della categoria di query di controllo "lettura dei log in produzione".

- `log_error(i_text, ...)` — registra messaggio, `sqlerrm`, `dbms_utility.format_error_backtrace`, call stack, utente effettivo (proxy-aware, via `lib_session`) e timestamp;
- **errori Oracle "parlanti"**: quando si logga un errore nativo Oracle, se il suo `sqlcode` è a catalogo in `cfg_error_messages` come riga `ORACLE` il messaggio registrato usa il testo personalizzato, altrimenti l'`sqlerrm`; l'`sqlerrm` grezzo è comunque conservato in `log_error_details.sqlerrm_text`, così il dettaglio tecnico non si perde mai. La risoluzione è nel writer, quindi vale per **ogni** errore loggato, non solo per chi passa da `lib_err.reraise`;
- `log_warn` / `log_info` / `log_debug(i_text, ...)` — livelli inferiori, filtrati a runtime;
- `start_proc` / `end_proc` / `end_proc_error` — marcatori di ciclo di vita (`message_type` `START`/`END`): `start_proc` genera e restituisce un `execution_id` (span id) e **apre un frame** di strumentazione (salva module/action, imposta l'`ACTION` allo scope, reclama il `MODULE` solo se nullo — mai sovrascrive il nome-processo del batch/APEX); `end_proc` chiude il frame sul **successo**, `end_proc_error` sul percorso di **errore** (nel `when others` obbligatorio). Poiché l'handler è obbligatorio, a ogni `start_proc` corrisponde sempre una chiusura → lo stack di module/action resta bilanciato e si ripristina anche in errore, senza gestione manuale;
- **due assi indipendenti** su ogni riga: `log_level` (gravità: DEBUG/INFO/WARN/ERROR) e `message_type` (natura: START/END/LOG/ERROR); più due identificativi opzionali passati esplicitamente (pool-safe): `correlation_id` (il flusso, *trace id*) ed `execution_id` (la singola invocazione, *span id*), entrambi generabili con `new_correlation_id`/`new_execution_id`;
- **messaggi a catalogo** (opzionale): overload di `log_info`/`log_warn`/`log_debug` che prendono un `i_message_code` + segnaposto posizionali `%1..%10` (`i_p1..i_p10`) e compongono il testo da `cfg_messages` — gemella di `cfg_error_messages`, ma per i messaggi non-errore, così il testo è correggibile a runtime senza ricompilare. I codici stanno come costanti in package di dominio `*_msg_codes` (es. `ord_msg_codes.c_inf_import_completato := 'ORD_IMPORT_COMPLETED'`), mai come stringhe sparse; un codice assente degrada a `[<code>]`. Convive con la forma a testo libero (`i_text`), disambiguata dalla notazione con nome (già regola del framework);
- abilitazione **configurabile senza ricompilare**: livello minimo globale, letto da `lib_config` e tenuto in cache nel body; il debug si accende su un modulo in produzione senza toccare il codice;
- `purge(i_retention_days)` — pulizia con retention da configurazione, pensata per un job schedulato;
- tabelle di appoggio: `log_events` (flusso unico DEBUG/INFO/WARN/ERROR, con `message_type`, `process_name`, `scope`, `error_code`, `correlation_id`, `execution_id`), `log_error_details` (`sqlerrm` grezzo, backtrace e call stack, una riga per errore, in join su `event_id`), `cfg_messages` (catalogo dei messaggi non-errore, senza seed di framework perché i codici sono di dominio) e `cfg_error_messages` (catalogo degli errori: righe `APP` in banda `-20xxx` lette da `lib_err`, righe `ORACLE` di override lette qui). Le colonne devono includere ciò che le query di controllo di `query_di_controllo.md` già interrogano.

---

## Livello 1 — Sessione e configurazione

### `lib_session` — identità, contesto e strumentazione di sessione

Il package dei "contesti": risponde a *chi sta operando* e *cosa sta facendo la sessione*, e centralizza l'uso dei contesti applicativi. È il complemento di progetto a `sys_context`, non un suo wrapper: il valore sta nel fissare **quale** identità conta in un modello con proxy e utenze tecniche, e nel dare un solo posto agli attributi di sessione che le viste e le API leggono.

Distingue nettamente due informazioni che prima erano schiacciate su uno stesso slot: **chi** opera (l'utente applicativo) e **quale chiamata** è in corso (il correlation id). La prima vive nel contesto applicativo `APP_CTX`, la seconda nel `CLIENT_IDENTIFIER`; così, sotto un connection pool, si distinguono utenti e richieste concorrenti allo stesso tempo.

- `current_actor` — l'identità effettiva: l'utente applicativo pubblicato nel contesto `APP_CTX` (attributo `APP_USER`), altrimenti `proxy_user` via proxy, altrimenti `session_user`. Non legge più il `client_identifier` (che ora porta il correlation id). È la funzione che popola `created_by`/`modified_by`;
- `set_actor(i_user)` — pubblica l'utente applicativo nel contesto `APP_CTX` (fonte di `current_actor`) e lo specchia in `CLIENT_INFO`, così resta visibile in `v$session`;
- `set_correlation(i_correlation_id)` — pubblica il correlation id della chiamata nel `CLIENT_IDENTIFIER`, visibile in `v$session` e tracciabile con `DBMS_MONITOR` attraverso le sessioni del pool; `current_correlation` lo rilegge;
- `session_info` — istantanea forense della sessione (attributi `USERENV` utili non già nel log — `session_user`, `os_user`, `host`, `ip_address`, `sid`, `instance`, `service`, gli NLS — più l'`app_user` di `APP_CTX`), come coppie chiave=valore; la usa `lib_logging` per `log_error_details.session_data` ed è riutilizzabile ovunque serva il "chi/dove/come" di una sessione;
- `set_step(i_module, i_action)` / `set_action(i_action)` — strumentazione via `dbms_application_info` con troncamento sicuro (module 48 / action 32 byte); `set_step` sovrascrive entrambi, `set_action` aggiorna solo il passo corrente;
- `open_step(i_action)` / `close_step` — meccanismo di annidamento usato da `start_proc`/`end_proc`: `open_step` salva il module/action correnti su uno stack interno e imposta la nuova `ACTION`; `close_step` ne fa il pop e ripristina. Raramente li chiami direttamente. Lo stack è tenuto **bilanciato dall'handler `when others` obbligatorio** (ogni `start_proc` è chiuso da `end_proc`/`end_proc_error`), quindi non fa leak; una voce orfana è comunque svuotata da `clear_session` al confine della richiesta;
- `clear_session` — azzera lo stato di sessione per richiesta (utente `APP_CTX`, `CLIENT_IDENTIFIER`, `CLIENT_INFO` **e** module/action): da chiamare al ritorno di una connessione al pool, così la richiesta successiva non eredita l'identità né la strumentazione della precedente;
- il **contesto applicativo `APP_CTX`** (`create context APP_CTX using #APP#.lib_session`) è scrivibile **solo** da `lib_session` (l'identità non è falsificabile) ed è estendibile ad altri attributi di sessione del progetto, pronti per un eventuale futuro VPD. Richiede il privilegio `CREATE ANY CONTEXT` in provisioning.

**Regola d'oro sotto connection pool (APEX incluso): il contesto va reimpostato a ogni richiesta, non una volta sola.** Lo stato di sessione del *database* — module, `CLIENT_IDENTIFIER`, contesto `APP_CTX` — vive per la durata di **una singola richiesta** su **una singola** sessione del pool; non segue la sessione applicativa. In APEX, il caricamento di una pagina e il submit di un bottone sono due richieste diverse, potenzialmente su due sessioni fisiche diverse: impostare il module "al caricamento pagina" non serve a nulla quando poi il processo del bottone gira su un'altra sessione. Ciò che invece **persiste** tra le richieste è lo stato di sessione *APEX* (`:APP_USER`, `:APP_ID`, gli item…), che sta nel repository di APEX: da lì si ripubblica il contesto sulla sessione DB **all'inizio di ogni richiesta**, e lo si ripulisce **alla fine**, con gli agganci di APEX in *Shared Components → Security Attributes → Database Session*.

```sql
-- Initialization PL/SQL Code (inizio di ogni richiesta, sulla sessione che lavora)
begin
   lib_session.set_actor(i_user => :APP_USER);
   lib_session.set_correlation(i_correlation_id => :APP_SESSION || '-' || :APP_PAGE_ID);
   lib_session.set_step(i_module => 'APEX:' || :APP_ID, i_action => 'PAGE ' || :APP_PAGE_ID);
end;

-- Cleanup PL/SQL Code (fine della richiesta, prima del ritorno al pool)
begin
   lib_session.clear_session;
end;
```

Con questo schema il cambio di sessione tra caricamento e submit è un non-problema: non si conserva stato tra le richieste, lo si **ricostruisce a ogni richiesta** dalla fonte durevole. La stessa disciplina vale per ogni confine d'ingresso — il batch la assolve con `lib_batch.start_run`, APEX con l'Initialization Code — mentre le procedure riusabili non impostano il module, lo ereditano: è ciò che le rende identiche da maschera e da batch.

### `lib_config` — parametri applicativi

L'accesso disciplinato alla tabella `cfg_parameters`: getter tipizzati, default espliciti, cache. Evita le due derive classiche — parametri letti con `select` sparse nel codice, e valori "temporaneamente" hardcoded in attesa della tabella che non arriva mai.

- `get_string(i_name)`, `get_number(i_name)`, `get_date(i_name)`, `get_flag(i_name)` — con conversione controllata (formati espliciti) ed errore parlante dal catalogo di `lib_err` se il parametro manca o non converte; varianti con `i_default` per i parametri facoltativi;
- `set_value(i_name, i_value)` — l'unico punto di scrittura, che registra la modifica nel log (chi, quando, valore precedente);
- **identità d'ambiente**: `environment` (`DEV`/`TEST`/`PROD`, da una riga di configurazione valorizzata al provisioning) e `is_production` — la guardia che `lib_mail`, i job e gli strumenti usano per comportarsi diversamente fuori dalla produzione;
- cache nel body con `refresh` esplicito, per non pagare una query a ogni lettura;
- tabelle di appoggio: `cfg_parameters` (nome, **gruppo**, valore, tipo dichiarato, descrizione, modificabilità) e `cfg_parameter_groups` (la lista governata dei gruppi). La colonna `param_group` raggruppa logicamente i parametri della stessa area (`GENERAL`, `LOGGING`, `MAIL`, ...), rendendo esplicito ciò che prima era solo una convenzione sui prefissi dei nomi: serve a interrogare la configurazione per area e, soprattutto, a far produrre a `gen_doc` una documentazione in sezioni anziché un elenco piatto. I valori ammessi non sono liberi ma vincolati da una foreign key a `cfg_parameter_groups`, che oltre a impedire la proliferazione per refuso porta per ciascun gruppo l'**etichetta** leggibile, la **descrizione** dell'area e il **`sort_order`** — cioè esattamente ciò che serve a comporre le sezioni del documento nell'ordine voluto invece che in ordine alfabetico del codice. È una tabella dedicata del pillar `cfg_` e non un set di `ref_lookups`, per la stessa ragione per cui lo sono i cataloghi `cfg_error_messages`/`cfg_messages`: un gruppo di parametri è metadato di configurazione, non un valore di dominio mostrato all'utente, e tenerlo qui evita che la configurazione — che è fondamenta e va creata e seminata per prima — dipenda dal meccanismo delle lookup.

### `lib_lookup` — valori di riferimento

Il gemello di `lib_config` sul versante dei **dati di riferimento**: l'accesso in lettura alle lookup generiche `ref_lookups`/`ref_lookup_values` (definite in `Architettura_DB/lookups.md`), perché le `select` sulle liste di valori non si sparpaglino in tutto il codice. La differenza di sostanza da `lib_config` è la convenzione di errore: la configurazione è una leva di comportamento e un parametro obbligatorio mancante è un errore che si solleva; una lookup è un *valore di dominio* mostrato all'utente, quindi la lettura è **lasca** — un set o un codice assente non solleva, così tendine e decode restano robusti di fronte a un dato mancante.

- `values_of(i_lookup_code)` — l'elenco ordinato dei soli valori **validi** di un set (`is_valid = 'Y'`), da usare per popolare una tendina; torna una collezione PL/SQL di record (`t_values`), vuota per un set inesistente;
- `label_of(i_lookup_code, i_value_code)` — l'etichetta di un codice, **anche se ritirato**, così i dati storici restano leggibili a video; `null` se il codice non è nel set;
- `is_valid(i_lookup_code, i_value_code)` — verifica che un codice appartenga al set e sia attualmente valido, per validare un valore in scrittura quando non c'è la foreign key composita con costante;
- `default_of(i_lookup_code)` — il codice del valore predefinito del set (`is_default = 'Y'`), per non cablare il preselezionato nell'applicazione;
- cache per set nel body con `refresh` esplicito (opzionalmente del solo set indicato), dato che le lookup cambiano di rado;
- tabelle di appoggio: `ref_lookups` (testata dei set, PK naturale `lookup_code`) e `ref_lookup_values` (valori con `label`, `sort_order`, `is_valid`/`is_default` e i tre slot tipizzati `num_value`/`char_value`/`date_value`). Nessun prerequisito SYS.

### `lib_authz` — autorizzazione funzionale

Il lettore dei permessi applicativi: risponde a "questo utente può fare questa cosa?" e fornisce l'elenco delle funzionalità con i modi effettivi, sulle tabelle `adm_*` definite in `Architettura_DB/utenti_profili.md`. È il complemento in lettura del pillar RBAC, tenuto — come `lib_lookup` — fuori dal codice applicativo perché la risoluzione dei permessi non si sparpagli. Il permesso effettivo è l'**unione (OR)** di due contributi: i grant da profilo, letti dalla vista materializzata aggregata `mv_user_effective_perms` (già filtrata a "valida oggi"), e le **eccezioni nominali** `adm_user_functionalities`, lette al volo e filtrate per validità temporale — cioè `has_access = MV(profilo) OR live(eccezione valida ora)`. La convenzione di lettura è **lasca ma fail-closed**: un utente sconosciuto o disattivato, una funzionalità non concessa o un modo non riconosciuto tornano semplicemente "no".

- `has_access(i_username, i_functionality_code, i_mode)` — vero/falso sul singolo permesso; `i_mode` è uno tra le costanti `k_mode_read`/`k_mode_write`/`k_mode_execute`. Overload sull'utente di sessione (`lib_session.current_actor`);
- `assert_access(...)` — il **punto di applicazione**: non fa nulla se l'accesso è concesso, solleva `AUTHZ_ACCESS_DENIED` sotto `lib_err.k_NOT_ALLOWED` se non lo è (sul modello di `lib_workflow.assert_action`). Overload di sessione;
- `functionalities_of(i_username)` — l'elenco delle funzionalità con i modi effettivi, tipicamente per costruire il menu all'accesso; overload di sessione;
- cache **per utente e per sessione** con freschezza limitata (cambio di giorno + TTL breve), perché i permessi hanno finestre temporali a grana data: una cache che non scada non "vedrebbe" una scadenza a mezzanotte o una revoca. `refresh(i_username)` la invalida (un utente o tutti);
- `refresh_mv` — il **punto unico di refresh della MV** (`dbms_mview.refresh` completo e atomico), condiviso dal job schedulato e dall'invocazione su evento; distinto da `refresh`, che tocca solo la cache di sessione;
- tabelle e oggetti di appoggio: le `adm_*` e la MV `mv_user_effective_perms`; il seed del messaggio in `Data/authz_messages.dat.sql`; il job giornaliero `Jobs/authz_refresh_mv.job.sql` (DBMS_SCHEDULER a 00:00, richiede il grant di sistema `create job`). Nessun prerequisito SYS di package (`dbms_mview` e `dbms_scheduler` sono già eseguibili da PUBLIC).

### `lib_authz_admin` — scrittura sui permessi

Il gemello di **scrittura** di `lib_authz`: la Table API che incapsula le modifiche amministrative alle `adm_*` (assegnazioni, grant, eccezioni, composizione dei profili, ciclo di vita degli utenti), così che nessuno faccia DML sparsa dimenticandosi audit e refresh. È il punto in cui il pillar RBAC diventa scrivibile in modo governato, ed è l'esecutore del **refresh su evento** promesso da `utenti_profili.md`.

- `assign_profile` / `revoke_profile` (assegnazioni con finestra) e `grant_functionality` / `revoke_functionality` (grant con modi e finestra) — le operazioni che toccano ciò che la MV materializza: dopo il commit chiamano `lib_authz.refresh_mv`;
- `add_role_to_profile` / `remove_role_from_profile` (composizione) e `grant_exception` / `revoke_exception` (eccezioni nominali, motivazione obbligatoria) e `create_user` / `set_user_active` — committano soltanto, perché la composizione non entra nella MV (i ruoli non gate) e le eccezioni e lo stato utente li legge al volo `lib_authz`;
- **contratto transazionale**: queste procedure **committano da sé** (DML → commit → eventuale `refresh_mv`), deroga dichiarata e circoscritta alla regola "commit al chiamante", imposta dal vincolo "refresh dopo il commit"; da non invocare dentro una transazione applicativa aperta. Il caricamento iniziale del catalogo resta agli script di seed, non a questa API;
- dipende da `lib_authz` (`refresh_mv`), `lib_assert` (validazione argomenti) e `lib_constants`; nessun prerequisito SYS. Concessioni e revoche sono **upsert idempotenti** (merge); le revoche non sollevano se non c'era nulla.

---

## Livello 2 — Servizi

### `lib_lock` — lock applicativi

Il pattern del capitolo 11 promosso a package: serializzare processi che non devono girare in parallelo, appoggiandosi a `sys.dbms_lock` così che il rilascio sia garantito da Oracle anche in caso di crash della sessione.

- `request(i_lock_name, i_timeout_seconds)` — alloca l'handle con `allocate_unique`, richiede il lock esclusivo, solleva `lib_err.e_lock_request_failed` (o un più specifico `e_already_running`) se il lock non si ottiene nel tempo dato;
- `release(i_lock_handle)`;
- `run_exclusive` (facoltativo, seconda battuta): esegue una procedura passata per nome dentro la coppia request/release, per non duplicare il boilerplate try/finally nei batch;
- prerequisito: `grant execute on sys.dbms_lock` (già previsto in `template_system_grant.grt.sql`).

### `lib_batch` — ciclo di vita dei processi batch

Dà a ogni elaborazione un **run tracciato**: inizio, fine, esito, contatori. È ciò che permette all'AM di rispondere a "il batch di stanotte com'è andato?" con una query invece che con un'indagine, ed è il bersaglio della query di controllo "esito e durata degli ultimi run" già prevista in `query_di_controllo.md`.

- `start_run(i_process_name) return run_id` — apre il run su `log_process_runs`, imposta module/action via `lib_session`, opzionalmente acquisisce il lock di esecuzione singola via `lib_lock`;
- `end_run(i_run_id, i_status, i_rows_processed, i_rows_rejected)` — chiude il run con esito e statistiche; una variante `fail_run` registra l'errore corrente e chiude come fallito;
- `checkpoint(i_run_id, i_step, i_counter)` — avanzamento intermedio per i processi lunghi (aggiorna il run e l'action di sessione);
- tabelle di appoggio: `log_process_runs` (processo, inizio, fine, stato, contatori, run precedente) — la stessa che le query di controllo interrogano.

### `lib_assert` — validazione degli argomenti

Il complemento applicativo di `dbms_assert` (che valida identificatori SQL, non argomenti di business): rende la validazione dei parametri all'ingresso delle API una riga leggibile invece di un `if` con `raise` artigianale. Piccolo per costruzione.

- `not_null(i_value, i_param_name)` — solleva `lib_err.e_invalid_parameter` con il nome del parametro nel messaggio;
- `is_true(i_condition, i_error)` — asserzione generica con errore del catalogo;
- `in_range(i_value, i_min, i_max, i_param_name)`, `max_length(i_value, i_max, i_param_name)`;
- da tenere d'occhio: non deve crescere fino a duplicare i vincoli del database — l'integrità dei dati resta ai constraint; qui si validano gli *argomenti* delle chiamate.

### `lib_text` — testo: solo ciò che manca a Oracle

Il package più a rischio brutta copia, quindi con la lista chiusa più severa. Dentro solo ciò che Oracle non offre o offre in modo scomodo:

- `split(i_text, i_separator) return t_strings_type` — da stringa a collection (l'inverso di `listagg`, che nativamente non esiste senza APEX);
- `join(i_strings, i_separator)` — da collection a stringa, per i casi in cui i dati non sono già in una query;
- `format(i_template, i_p1, i_p2, ...)` — sostituzione di segnaposto `%1`, `%2` nei messaggi; è la primitiva usata da `lib_err` e `lib_mail` per i template;
- `normalize_code(i_text)` — normalizzazione per codici: maiuscole, accenti rimossi, spazi e caratteri non ammessi sostituiti; utile per generare codici mnemonici coerenti;
- eventuali helper CLOB *mirati* (costruzione efficiente di un CLOB da molti frammenti varchar2), solo se il profiling ne dimostra il bisogno;
- esplicitamente fuori: wrapper di `upper`/`trim`/`lpad`, `is_number`/`is_date` (esiste `validate_conversion`), replace multipli banali.

### `lib_calendar` — calendario di business

Un complemento vero: Oracle non sa nulla di giorni lavorativi e festività. Serve a qualsiasi progetto con scadenze, SLA o elaborazioni "il primo giorno lavorativo del mese".

- `is_working_day(i_date)`, `next_working_day(i_date)`, `previous_working_day(i_date)`;
- `add_working_days(i_date, i_days)`, `working_days_between(i_from, i_to)`;
- definizione del weekend e calendario festività su tabella `ref_holidays` (data, descrizione, eventuale calendario multiplo se il progetto opera su più piazze);
- da valutare in seconda battuta: periodi fiscali/contabili (`fiscal_period_of(i_date)`), se il dominio li usa.

---

## Livello 3 — Integrazione e output

### `lib_file` — I/O su file

Sopra `utl_file`, ma solo dove `utl_file` è scomodo o pericoloso da usare a mano crudo: lettura e scrittura intere, errori parlanti, directory da configurazione.

- `read_clob(i_directory, i_filename)` / `write_clob(i_directory, i_filename, i_content)` — file interi da/verso CLOB, con gestione dei chunk e chiusura garantita anche su eccezione;
- `exists(i_directory, i_filename)`, `remove`, `rename` — con mappatura degli errori `utl_file` (ORA-29283 e famiglia) su errori del catalogo comprensibili;
- validazione del nome file (niente path traversal: il nome non contiene separatori di percorso);
- directory logiche risolte via `lib_config` (`k_DIR_IMPORT`, `k_DIR_EXPORT`), non hardcoded nei chiamanti;
- prerequisiti: `grant execute on sys.utl_file` (ambienti hardened) e oggetti `DIRECTORY` con `read`/`write` grantati all'owner — richieste già previste nel provisioning SYS.

### `lib_mail` — invio mail

Il package generico di posta, il cui valore non è "chiamare `utl_smtp`" ma tutto ciò che ci sta intorno: costruzione corretta del messaggio, template, coda, e la guardia d'ambiente che evita di spedire mail vere dal collaudo.

- `send(i_to, i_subject, i_body, ...)` — invio con supporto multiparte: corpo testo/HTML, allegati da CLOB/BLOB con mime type, destinatari multipli, cc/bcc;
- `send_template(i_template_code, i_to, i_p1, ...)` — corpo e oggetto da `cfg_email_templates` con segnaposto risolti via `lib_text.format`: i testi si cambiano a configurazione, non a codice;
- **guardia d'ambiente**: fuori produzione (`lib_config.is_production = false`) i destinatari reali vengono riscritti verso una casella di test e il messaggio marcato — regola non aggirabile dal chiamante;
- modalità **accodata** come default consigliato: `send` scrive su `wrk_mail_queue` e un job schedulato spedisce con retry e backoff, così l'invio non allunga né fa fallire la transazione applicativa; l'invio sincrono resta disponibile per i casi che lo richiedono;
- ogni invio (o fallimento) tracciato via `lib_logging`;
- prerequisiti: `grant execute on sys.utl_smtp` + ACL di rete verso il mail server (previsti nel provisioning); da registrare come decisione: se l'infrastruttura ha APEX, `apex_mail` può fare da motore dietro la stessa interfaccia.

### `lib_report` — report automatici

Il tassello che lega insieme query di controllo, scheduler e posta: produce e recapita report tabellari senza che ogni esigenza di reportistica diventi un sviluppo ad hoc. Il caso d'uso principe è il **monitoraggio AM**: eseguire periodicamente le query di controllo e farsi vivo solo quando c'è qualcosa da guardare.

- `render_csv(i_cursor) return clob` / `render_html(i_cursor) return clob` — trasformano un `sys_refcursor` in CSV o tabella HTML usando `dbms_sql` per descrivere le colonne: funziona con qualsiasi query senza codice dedicato;
- `run_report(i_report_code)` — esegue un report registrato: legge la definizione, esegue la query, formatta e recapita via `lib_mail` o `lib_file`;
- registro dei report su `cfg_reports` (codice, descrizione, testo SQL o funzione che restituisce il cursore, formato, destinatari, pianificazione);
- modalità **"solo anomalie"**: per i report costruiti su query di controllo (convenzione "zero righe = tutto a posto") il recapito avviene solo se la query restituisce righe — il silenzio è la buona notizia;
- ogni esecuzione è un run di `lib_batch`, quindi tracciata e interrogabile.

### `lib_http` — chiamate HTTP in uscita *(opzionale, quando serve un'integrazione)*

Solo per progetti che chiamano servizi esterni dal database. Sopra `utl_http`, con il valore nelle cose che a mano si sbagliano: timeout espliciti, log di richiesta e risposta, mappatura degli errori, gestione degli header ripetitivi (autenticazione, content type). Da ricordare nei prerequisiti che HTTPS richiede il wallet configurato dal DBA oltre alla ACL. Se il progetto non ha integrazioni in uscita, questo package semplicemente non si crea.

### `lib_queue` — code di lavoro su tabella *(opzionale)*

La standardizzazione del pattern `wrk_` + `for update skip locked` del capitolo 06, per i progetti con elaborazioni a worker paralleli: `enqueue` di unità di lavoro, `dequeue` a lotti con skip delle righe contese, marcatura di esito con spostamento degli scarti verso la tabella `err_` corrispondente. Vale la pena solo se il pattern ricorre su più code; per una coda singola il pattern documentato basta.

### Sullo scheduling: convenzioni, non package

`dbms_scheduler` è deliberatamente **senza wrapper**: è già un'API completa e un `lib_scheduler` passacarte sarebbe l'esempio da manuale di brutta copia. Ciò che serve è una pagina di convenzioni (nomenclatura dei job `#APP#_<processo>_job`, job che invocano procedure le quali aprono un run con `lib_batch`, log degli esiti, abilitazione per ambiente) da aggiungere alle guidelines o a questo documento quando i primi job nascono. Se col tempo emergesse boilerplate ricorrente — creazione di job standard con le convenzioni applicate — si potrà valutare un singolo helper, non prima.

---

## Tooling di generazione (schema `#APP#_GEN`, solo sviluppo/test)

Questi package vivono nello schema di tooling, hanno i privilegi di introspezione che l'owner non ha, ed **emettono sorgenti** che entrano nel progetto dal normale percorso di install e review (mai installati direttamente). Sono la parte del set con il miglior rapporto tra sforzo e fatica risparmiata.

### `gen_shell` — generazione dei gusci

Legge dal dizionario la spec di un package di logica (nome pulito) e genera spec e body del guscio `_shell` corrispondente: firme identiche, corpo di pura delega, header conforme ai template. Elimina il costo di doppia manutenzione del meccanismo guscio — la modifica si fa sulla logica e il guscio si rigenera — che è oggi il prezzo più alto del pattern. Analogamente può generare la vista guscio `_shell_v` dalla vista di logica `_v` (elenco colonne esplicito).

### `gen_testbook` — precompilazione del test book

Interroga i metadati di utPLSQL (le annotazioni delle suite presenti) e genera lo scheletro del test book JSON con i casi `utplsql` già elencati e riferiti a suite e procedure. Chi implementa completa precondizioni, query di controllo e sign-off invece di partire dal foglio bianco. È il primo pezzo del generatore pianificato in `STATUS.md`.

### `gen_doc` — documentazione dal dizionario

Estrae commenti di tabelle e colonne, firme dei package esposti e commenti di documentazione, e produce markdown: il catalogo dati e la referenza API del progetto restano generabili e quindi sempre allineabili. È la ragione per cui le guidelines insistono sui commenti a dizionario.

### `gen_qc` — scheletri di query di controllo

Genera dal dizionario le query di controllo standard di un rilascio: oggetti invalidi dello schema, riepilogo delle migrazioni attese, e — per le tabelle indicate — gli scheletri delle verifiche di consistenza (orfani sulle FK dichiarate, duplicati sulle chiavi univoche). Chi implementa parte da una base meccanica e aggiunge le verifiche funzionali che solo lui conosce.

---

## Riepilogo e priorità

La tabella riassume il catalogo; la colonna delle priorità propone le ondate di realizzazione. La prima ondata è ciò che serve per scrivere il primo package applicativo *bene* (errori, log, configurazione, run); la seconda completa i servizi; la terza si attiva a domanda.

| Package | Livello | Tabelle di appoggio | Prerequisiti SYS | Priorità |
|---|---|---|---|---|
| `lib_types` | Fondamenta | — | — | 1ª ondata |
| `lib_constants` | Fondamenta | — | — | 1ª ondata |
| `lib_err` | Fondamenta | — (catalogo nella spec) | — | 1ª ondata |
| `lib_logging` | Fondamenta | `log_events`, `log_error_details` | — | 1ª ondata |
| `lib_session` | Sessione | contesto `APP_CTX` | `create any context` (per il contesto `APP_CTX`) | 1ª ondata |
| `lib_config` | Sessione | `cfg_parameters` | — | 1ª ondata |
| `lib_lookup` | Sessione | `ref_lookups`, `ref_lookup_values` | — | 2ª ondata |
| `lib_authz` | Sessione | `adm_*`, `mv_user_effective_perms`, job `authz_refresh_mv` | `create job` (job di refresh MV) | 2ª ondata |
| `lib_authz_admin` | Sessione | `adm_*` (scrittura) | — | 2ª ondata |
| `lib_lock` | Servizi | — | `execute on sys.dbms_lock` | 1ª ondata |
| `lib_batch` | Servizi | `log_process_runs` | — | 1ª ondata |
| `lib_assert` | Servizi | — | — | 2ª ondata |
| `lib_text` | Servizi | — | — | 2ª ondata |
| `lib_calendar` | Servizi | `ref_holidays` | — | 2ª ondata |
| `lib_file` | Integrazione | — | `utl_file` + `DIRECTORY` | 2ª ondata |
| `lib_mail` | Integrazione | `cfg_email_templates`, `wrk_mail_queue` | `utl_smtp` + ACL | 2ª ondata |
| `lib_report` | Integrazione | `cfg_reports` | — (usa mail/file) | 2ª ondata |
| `lib_http` | Integrazione | — | `utl_http` + ACL + wallet | A domanda |
| `lib_queue` | Integrazione | tabelle `wrk_` dedicate | — | A domanda |
| `gen_shell` | Tooling GEN | — | dizionario (già previsto per `#APP#_GEN`) | 2ª ondata |
| `gen_testbook` | Tooling GEN | — | dizionario | 3ª ondata |
| `gen_doc` | Tooling GEN | — | dizionario | 3ª ondata |
| `gen_qc` | Tooling GEN | — | dizionario | 3ª ondata |

Due note per la fase di realizzazione. La prima: ogni package della prima ondata va disegnato **spec-first** — si scrive e si rivede la specifica con i commenti di documentazione, la si valida contro gli usi già presenti nelle guidelines (le firme citate negli esempi sono il contratto minimo), e solo dopo si implementa il body con la sua suite di test. La seconda: le tabelle di appoggio (`log_*`, `cfg_*`, `ref_holidays`, `wrk_mail_queue`) seguono il percorso normale dei sorgenti — baseline, commenti a dizionario, seed idempotenti per i dati di configurazione — e ognuna porta con sé le query di controllo che la riguardano.
